package com.scotiabank.ehome.ui.steps.stage4;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.step.QAFTestStepProvider;
import com.qmetry.qaf.automation.ui.WebDriverTestBase;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebDriver;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.quantum.utils.ConfigurationUtils;
import com.scotiabank.ehome.ui.steps.Common;
import com.scotiabank.ehome.ui.steps.ExcelDataToDataTable;
import com.scotiabank.ehome.ui.steps.Utility;
import com.scotiabank.ehome.ui.steps.valueObjects.Tuple;
import com.scotiabank.ehome.ui.steps.valueObjects.TypeOfRateVO;
import com.thoughtworks.qdox.model.expression.Add;

import org.junit.runner.RunWith;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;

import cucumber.api.CucumberOptions;
import cucumber.api.DataTable;
import cucumber.api.PendingException;
import cucumber.api.Transform;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import cucumber.api.junit.Cucumber;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import static com.scotiabank.ehome.ui.steps.BusinessCalculations.*;
import static com.scotiabank.ehome.ui.steps.Utility.*;

import org.openqa.selenium.Keys;
@QAFTestStepProvider

public class PreviousEmployerAddress {
	private QAFExtendedWebDriver webDriver = Utility.getDriver();
    public Actions action = null;
    public static WebDriverWait wait=Utility.getWait();	
    
    private Map<String,Map<String,Boolean>> employerAddressDataset = getScreenDataset(Utility.getExcelFilePath("eHomeTestDatastage-4.xlsx"), "EmployerAddress");
    private Map<String,Map<String,Boolean>> employerDetailsDataset = getScreenDataset(Utility.getExcelFilePath("eHomeTestDatastage-4.xlsx"), "EmployerDetails");
    private Map<String,Map<String,Boolean>> industryAndJobTitleDataset = getScreenDataset(Utility.getExcelFilePath("eHomeTestDatastage-4.xlsx"), "IndustryAndJobTitle");
    private Map<String,Map<String,Boolean>> negativeValuesDataset = getScreenDataset(Utility.getExcelFilePath("eHomeTestDatastage-4.xlsx"), "NegativeValues");
    private Map<String,Map<String,Boolean>> annualIncomeDataset = getScreenDataset(Utility.getExcelFilePath("eHomeTestDatastage-4.xlsx"), "AnnualIncome");
    private Map<String,Map<String,Boolean>> empDurationDataset = getScreenDataset(Utility.getExcelFilePath("eHomeTestDatastage-4.xlsx"), "EmploymentDuration");
    private Map<String,Map<String,Boolean>> previousEmplyerDetailsDataset = getScreenDataset(Utility.getExcelFilePath("eHomeTestDatastage-4.xlsx"), "PreviousEmplyerDetails");
    private Map<String,Map<String,Boolean>> previousEmployerAddressDataset = getScreenDataset(Utility.getExcelFilePath("eHomeTestDatastage-4.xlsx"), "PreviousAddress");
    
	
    @Given("^Customer should login and navigates to previous employer address$")
	public void customer_should_login_and_navigates_to_previous_employer_address() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Common.sessionBreakerContinueButtonClick();
        EmpStatus.employedButtonClicked();
        EmpType.commissionedSalesButtonClicked();
        IndustryAndJobTitle.jobField(Utility.getLabelValueForDataPointer(industryAndJobTitleDataset, "Industry_JobTitle_Field_of_work"));
        IndustryAndJobTitle.jobTitle(Utility.getLabelValueForDataPointer(industryAndJobTitleDataset, "Industry_JobTitle_Job_Title"));
        Common.continueButtonClicked();
        EmployerDetails.employername(Utility.getLabelValueForDataPointer(employerDetailsDataset, "Employer_Details_employername"));
        EmployerDetails.employerphone(Utility.getLabelValueForDataPointer(employerDetailsDataset, "Employer_Details_employerphone"));
        Common.continueButtonClicked();
        EmpAddress.employeraddress(Utility.getLabelValueForDataPointer(employerAddressDataset, "Employer_Address"));
        Common.continueButtonClicked();		
        AnnualIncome.annualincomeSalary(Utility.getLabelValueForDataPointer(annualIncomeDataset, "Employer_AnnualIncome_Salary"));
        Common.continueButtonClicked();
        String year = Utility.getLabelValueForDataPointer(empDurationDataset, ("Employer_Duration_lessThan2Years_years"));
        String month = Utility.getLabelValueForDataPointer(empDurationDataset, ("Employer_Duration_lessThan2Years_months"));
        EmploymentDuration.employmentDuration(year, month);
        Common.continueButtonClicked();
        PreviousEmployerDetails.previousEmployerName(Utility.getLabelValueForDataPointer(previousEmplyerDetailsDataset, "Employer_PreviosDetails_employername"));
        PreviousEmployerDetails.previousEmployerPhone(Utility.getLabelValueForDataPointer(previousEmplyerDetailsDataset, "Employer_PreviosDetails_employerphone"));
	    Common.continueButtonClicked();
	    
	}

   // Previous_Employer_Address_TC-002
	@When("^Verify \"([^\"]*)\" should be on the previous employer address screen$")
	public void verify_should_be_on_the_previous_employer_address_screen(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    
	}

	@Then("^Verify \"([^\"]*)\" headertext should be on the previous employer address screen$")
	public void verify_headertext_should_be_on_the_previous_employer_address_screen1(String dataPointer) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String value = Utility.getLabelValueForDataPointer(previousEmployerAddressDataset, dataPointer);
		Assert.assertEquals(Common.headertext(), value,"Couldn't found expected header text");
		
	}
	// Previous_Employer_Address_TC-003
	
	
	// Previous_Employer_Address_TC-004
	@When("^Enter \"([^\"]*)\" invalid address in previous employer address screen$")
    public void enter_invalid_address_in_the_previous_Employer_address_screen(String dataPointer) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String value = Utility.getLabelValueForDataPointer(negativeValuesDataset, dataPointer);
		QAFExtendedWebElement previousaddresss = new QAFExtendedWebElement("ehome.PreviousEmployerAddress.address");
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(previousaddresss));
		previousaddresss.clear();
		previousaddresss.sendKeys(value);
	}
	// Previous_Employer_Address_TC-005
	 public static void previousemployeraddress(String address) throws InterruptedException {
    	Thread.sleep(3000);
    	QAFExtendedWebElement Enteraddress= new QAFExtendedWebElement("ehome.PreviousEmployerAddress.address");
    	Enteraddress.clear();
    	char[] addarr = address.toCharArray();
    	for(char oneAt : addarr) {
    		Enteraddress.sendKeys(oneAt+"");
    		Thread.sleep(2000);
	    	}	
    	Thread.sleep(5000);
    	  QAFExtendedWebElement eleAddress = new QAFExtendedWebElement(By.xpath("//*[@id=\"app\"]/div/div[1]/div[1]/section/div/div[3]/div[1]/div/div[2]/div/ul"));
          List<WebElement> liLi = eleAddress.findElements(By.tagName("li"));
         wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).ignoring(ArrayIndexOutOfBoundsException.class).until(ExpectedConditions.visibilityOf(liLi.get(1)));
          Thread.sleep(2000);
          liLi.get(1).click();
          Thread.sleep(3000);
	   	 }
	    
	    @When("^Enter \"([^\"]*)\" in previous employer address screen$")
	    public void enter_valid_address_in_previos_Employer_address_screen(String dataPointer) throws Throwable {
	        // Write code here that turns the phrase above into concrete actions
	    	String value1 = Utility.getLabelValueForDataPointer(previousEmployerAddressDataset, dataPointer);
    	   	previousemployeraddress(value1);
	    	
	          
	    }

	

}