package com.scotiabank.ehome.ui.steps.stage4;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.step.QAFTestStepProvider;
import com.qmetry.qaf.automation.ui.WebDriverTestBase;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebDriver;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.quantum.utils.ConfigurationUtils;
import com.scotiabank.ehome.ui.steps.Common;
import com.scotiabank.ehome.ui.steps.ExcelDataToDataTable;
import com.scotiabank.ehome.ui.steps.Utility;
import com.scotiabank.ehome.ui.steps.valueObjects.Tuple;
import com.scotiabank.ehome.ui.steps.valueObjects.TypeOfRateVO;
import com.thoughtworks.qdox.model.expression.Add;

import org.junit.runner.RunWith;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;

import cucumber.api.CucumberOptions;
import cucumber.api.DataTable;
import cucumber.api.PendingException;
import cucumber.api.Transform;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import cucumber.api.junit.Cucumber;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import static com.scotiabank.ehome.ui.steps.BusinessCalculations.*;
import static com.scotiabank.ehome.ui.steps.Utility.*;

import org.openqa.selenium.Keys;
@QAFTestStepProvider

public class EmployerDetails {
	 public static WebDriverWait wait=Utility.getWait();
	  String testCaseID = Utility.getScenarioID();
    
     
	@Given("^Customer should login and navigates to Employer Details screen$")
	public void customer_should_login_and_navigates_to_Employment_Details_screen() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		Utility.launchURL(ConfigurationUtils.getBaseBundle().getPropertyValue ("env.baseurl2"));
		Common.sessionBreakerContinueButtonClick();
        EmpStatus.employedButtonClicked();
        EmpType.commissionedSalesButtonClicked();
        Thread.sleep(3000);
        String jobField=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage04_Employment_InputData", testCaseID, "Industry_JobTitle_Field_of_work");
        IndustryAndJobTitle.jobField(jobField);
        Thread.sleep(3000);
        String jobTitle=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage04_Employment_InputData", testCaseID, "Industry_JobTitle_Job_Title");
        IndustryAndJobTitle.jobTitle(jobTitle);
        Common.continueButtonClicked();
   	}

	//employer_name_and_Phone_002

	@When("^Verify \"([^\"]*)\" should be on the Employer Details screen$")
	public void verify_should_be_on_the_Employment_name_and_phone_screen1(String dataPointer) throws Throwable {
		 // Write code here that turns the phrase above into concrete actions
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage04_Employment_ExpectedData", testCaseID, dataPointer);
		Assert.assertEquals(Common.headerMessage(), value,"Couldn't found expected header text");
	}

	@Then("^Verify \"([^\"]*)\" headertext should be on the Employer Details screen$")
	public void verify_headertext_should_be_on_the_Employment_name_and_phone_screen(String dataPointer) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Thread.sleep(2000);
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage04_Employment_ExpectedData", testCaseID, dataPointer);
		Assert.assertEquals(Common.headertext(), value,"Couldn't found expected header text");
    }
	//employer_name_and_Phone_004
	
	@When("^Enter the \"([^\"]*)\" invalid Employer name in the Employer details screen$")
	public void enter_the_invalid_Employer_name_in_the_Employer_details_screen(String dataPointer) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String col="InputValues";
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "CommonErrorMessages", dataPointer,col);
		QAFExtendedWebElement employerName= new QAFExtendedWebElement("ehome.employerDetails.employerName");
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(employerName));
		employerName.clear();
		employerName.sendKeys(value);
	    
	}
	
	@Then("^\"([^\"]*)\" should be displayed for name in the Employer details screen$")
	public void error_message_should_be_displayed_in_the_Employer_details_screen(String dataPointer) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage04_Employment_ExpectedData", testCaseID, dataPointer);
    	QAFExtendedWebElement employerNameErrorMessage= new QAFExtendedWebElement("ehome.employerDetails.errorMessage");
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(employerNameErrorMessage));
        Assert.assertEquals(employerNameErrorMessage.getText(), value,"Couldn't found expected header text");
	    
	}
	//Employer_Phone
	@When("^Enter the \"([^\"]*)\" invalid Employer phone in the Employer details screen$")
	public void enter_the_invalid_Employer_phone_in_the_Employer_details_screen(String dataPointer) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String col="InputValues";
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "CommonErrorMessages", dataPointer,col);
		QAFExtendedWebElement employerphone= new QAFExtendedWebElement("ehome.employerDetails.employerPhone");
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(employerphone));
		employerphone.clear();
		employerphone.sendKeys(value);
	    
	}
	
	@Then("^\"([^\"]*)\" should be displayed for phone in the Employer details screen$")
	public void error_message_should_be_displayed_for_phone_in_the_Employer_details_screen(String dataPointer) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage04_Employment_ExpectedData", testCaseID, dataPointer);
    	QAFExtendedWebElement employerphoneErrorMessage= new QAFExtendedWebElement("ehome.employerDetails.phoneErrorMessage");
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(employerphoneErrorMessage));
        Assert.assertEquals(employerphoneErrorMessage.getText(), value,"Couldn't found expected header text");
	    
	}

	@Then("^Phone Error message should be displayed  in the Employer Details screen$")
	public void Phone_error_message_should_be_displayed_in_the_Employment_name_and_phone_screen() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
			QAFExtendedWebElement phoneErrorMessage= new QAFExtendedWebElement("ehome.employerDetails.phoneErrorMessage");
	        Assert.assertEquals(phoneErrorMessage.getText(), "Please enter your employer's phone number","Could not found 'Please enter your employer's phone number'");
		    
		}
	    
	@When("^Enter the \"([^\"]*)\" valid employerphone  in the Employer Details screen$")
	public void enter_the_valid_employment_phone_in_the_Employment_name_and_phone_screen(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		QAFExtendedWebElement employmentPhoneName= new QAFExtendedWebElement("ehome.employerDetails.employerPhone");
		employmentPhoneName.clear();
         employmentPhoneName.sendKeys(arg1);
	    
	}

	@Then("^Green with a check mark should be displayed  in the phone of Employer Details screen$")
	public void green_with_a_check_mark_should_be_displayed_in_phone_the_Employment_name_and_phone_screen() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		QAFExtendedWebElement greenicon= new QAFExtendedWebElement("ehome.employerDetails.greenicon.phone");
		if(!greenicon.isPresent()) {
			Assert.fail("Couldn't see the green check mark");
			
		}
	    
	}
	
	//employer_name_and_Phone_005
	 public static void employername(String name) {
		QAFExtendedWebElement employmentName= new QAFExtendedWebElement("ehome.employerDetails.employerName");
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(employmentName));
		
		employmentName.clear();
		employmentName.sendKeys(name);
	 }

	@When("^Enter the \"([^\"]*)\" in employer name in the Employer Details screen$")
	public void enter_the_in_employment_name_in_the_Employment_name_and_phone_screen(String dataPointer) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage04_Employment_InputData", testCaseID, dataPointer);
		employername(value);
		 Thread.sleep(3000);
	}
	
	//Emplyer phone
	public static void employerphone(String phone) {
		QAFExtendedWebElement employmentPhone= new QAFExtendedWebElement("ehome.employerDetails.employerPhone");
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(employmentPhone));
		employmentPhone.clear();
		employmentPhone.sendKeys(phone);
	 }
	@When("^Enter the \"([^\"]*)\" in employer Phone in the Employer Details screen$")
	public void enter_the_in_employer_phone_in_the_Employment_name_and_phone_screen(String dataPointer) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage04_Employment_InputData", testCaseID, dataPointer);
		employerphone(value);   
		 Thread.sleep(3000);
	}
	
//	@Then("^\"([^\"]*)\" should be displayed in employer phone in the Employer Details screen$")
//	public void  should_be_displayed_in_the_Employer_Details_screen(String dataPointer) throws Throwable {
//	    // Write code here that turns the phrase above into concrete actions
//		String value = Utility.getLabelValueForDataPointer(employerDetailsDataset, dataPointer);
//		QAFExtendedWebElement phoneErrorMessage= new QAFExtendedWebElement("//*[@id=\"employerPhone-group-invalid\"]");
//        Assert.assertEquals(phoneErrorMessage.getText(), value,"Could not found 'Please enter your employer's phone number'");
//	}
	
	@Then("^Green with a check mark should be displayed  in the employer name in Employer Details screen$")
	public void green_with_a_check_mark_should_be_displayed_in_the_employer_name_in_Employer_Details_screen() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		QAFExtendedWebElement greenicon= new QAFExtendedWebElement("ehome.employerDetails.greenicon.name");
		if(!greenicon.isPresent()) {
			Assert.fail("Couldn't see the green check mark");
			
		}
	}

	
	@Then("^Green with a check mark should be displayed in the name of Employer Details screen$")
	public void green_with_a_check_mark_should_be_displayed_in_the_Employment_name_and_phone_screen() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		QAFExtendedWebElement greenicon= new QAFExtendedWebElement("ehome.employerDetails.greenicon.name");
		if(!greenicon.isPresent()) {
			Assert.fail("Couldn't see the green check mark");
			}	
		}
	
	@Then("^Green with a check mark should be displayed in the phone of Employer Details screen$")
	public void green_with_a_check_mark_should_be_displayed_in_the_phone_of_Employer_Details_screen() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		QAFExtendedWebElement greenicon= new QAFExtendedWebElement("ehome.employerDetails.greenicon.phone");
		if(!greenicon.isPresent()) {
			Assert.fail("Couldn't see the green check mark");
			
		}
	    
	}
//	//employer_name_and_Phone_006
//	@When("^Click on the Continue button in the Employer Details screen$")
//	public void click_on_the_Continue_button_in_the_Employment_name_and_phone_screen() throws Throwable {
//	    // Write code here that turns the phrase above into concrete actions
//		QAFExtendedWebElement continueEmploymenNameandPhone= new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[2]/button[2]");
//		Thread.sleep(3000);
//		continueEmploymenNameandPhone.click();
//	    
//	}

//	@Then("^It should navigate to What address screen$")
//	public void it_should_navigate_to_What_address_screen() throws Throwable {
//	    // Write code here that turns the phrase above into concrete actions
//	    
//	}
}

	
