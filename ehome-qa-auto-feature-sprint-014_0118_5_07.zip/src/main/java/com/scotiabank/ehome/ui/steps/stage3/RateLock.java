package com.scotiabank.ehome.ui.steps.stage3;
import com.qmetry.qaf.automation.step.QAFTestStepProvider;
import com.qmetry.qaf.automation.ui.WebDriverTestBase;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebDriver;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.quantum.utils.ConfigurationUtils;
//import com.scotiabank.ehome.ui.steps.valueObjects.TypeOfRateVO;

import com.scotiabank.ehome.ui.steps.BusinessCalculations;
import com.scotiabank.ehome.ui.steps.Common;
import com.scotiabank.ehome.ui.steps.Utility;
import com.scotiabank.ehome.ui.steps.valueObjects.TypeOfRateVO;
import cucumber.api.PendingException;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.FluentWait;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.beans.PropertyChangeListener;

import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import static com.scotiabank.ehome.ui.steps.BusinessCalculations.calculateLoanRequested;
import static com.scotiabank.ehome.ui.steps.Utility.*;
@QAFTestStepProvider

public class RateLock {

    private QAFExtendedWebDriver webDriver = new WebDriverTestBase().getDriver();
    public Actions action = null;
    WebDriverWait wait = new WebDriverWait(webDriver, 50000);

    String testCaseID = Utility.getScenarioID();

    QAFExtendedWebElement Continue = new QAFExtendedWebElement("ehome.tellus.continue.button");
    QAFExtendedWebElement eHomeHeader = new QAFExtendedWebElement("ehome.rate.Header.text");

    QAFExtendedWebElement loanrequestedinformation = new QAFExtendedWebElement("ehome.loanrequestedinformation.i");
    QAFExtendedWebElement loanrequestedinformationtext = new QAFExtendedWebElement("ehome.loanrequestedinformation.text");
    QAFExtendedWebElement loanrequestedinformationclose = new QAFExtendedWebElement("ehome.loanrequestedinformation.close");
    QAFExtendedWebElement Purchasepricevalue = new QAFExtendedWebElement("ehome.purchaseprice.span");
    QAFExtendedWebElement downpaymentvalue = new QAFExtendedWebElement("ehome.downpayment.span");

    QAFExtendedWebElement mortgagesummarytitle = new QAFExtendedWebElement("ehome.mortgagesummarytitle.text");
    QAFExtendedWebElement Purchaseprice = new QAFExtendedWebElement("ehome.purchaseprice.text");
    QAFExtendedWebElement downpayment = new QAFExtendedWebElement("ehome.downpayment.text");
    QAFExtendedWebElement loanrequested = new QAFExtendedWebElement("ehome.loanrequested.text");
    QAFExtendedWebElement loanrequestedvalue = new QAFExtendedWebElement("ehome.loanrequested.span");

    QAFExtendedWebElement headertext1 = new QAFExtendedWebElement("ehome.ratelock.headertext1");
    QAFExtendedWebElement headertext2 = new QAFExtendedWebElement("ehome.ratelock.headertext2");

    QAFExtendedWebElement selectFixed = new QAFExtendedWebElement("ehome.typeofrate.selectfixed.radio");
    QAFExtendedWebElement selectVariable = new QAFExtendedWebElement("ehome.typeofrate.selectvariable.radio");
    QAFExtendedWebElement twoyearss = new QAFExtendedWebElement("ehome.termsofrate.2years.radio");
    QAFExtendedWebElement twoyear = new QAFExtendedWebElement("ehome.ratepresentation.twoyears.select");
    QAFExtendedWebElement whatmortgagetermareyoulookingfor = new QAFExtendedWebElement("ehome.termofrate.header");
    QAFExtendedWebElement RatePresentmentHeader = new QAFExtendedWebElement("ehome.ratePresentation.Header");
    //QAFExtendedWebElement loanrequestedvalue = new QAFExtendedWebElement("ehome.ratepresentation.loanrequested.span");

    QAFExtendedWebElement twoyears = new QAFExtendedWebElement("ehome.ratePresentation.twoyears");
    QAFExtendedWebElement twoyearsrate = new QAFExtendedWebElement("ehome.ratePresentation.twoyears.rate");
    QAFExtendedWebElement twoyearsmonthlypayment = new QAFExtendedWebElement("ehome.ratePresentation.twoyears.MonthlyPayment");
    QAFExtendedWebElement twoyearsmonthlypaymentvalue = new QAFExtendedWebElement("ehome.ratePresentation.twoyears.MonthlyPaymentValue");
    QAFExtendedWebElement twoyearsselect = new QAFExtendedWebElement("ehome.ratepresentation.twoyears.select");

    QAFExtendedWebElement threeyears = new QAFExtendedWebElement("ehome.ratePresentation.threeyears");
    QAFExtendedWebElement threeyearsrate = new QAFExtendedWebElement("ehome.ratePresentation.threeyears.rate");
    QAFExtendedWebElement threeyearsmonthlypayment = new QAFExtendedWebElement("ehome.ratePresentation.threeyears.MonthlyPayment");
    QAFExtendedWebElement threeyearsmonthlypaymentvalue = new QAFExtendedWebElement("ehome.ratePresentation.threeyears.MonthlyPaymentValue");
    QAFExtendedWebElement threeyearsselect = new QAFExtendedWebElement("ehome.ratepresentation.threeyears.select");

    QAFExtendedWebElement fouryears = new QAFExtendedWebElement("ehome.ratePresentation.fouryears");
    QAFExtendedWebElement fouryearsrate = new QAFExtendedWebElement("ehome.ratePresentation.fouryears.rate");
    QAFExtendedWebElement fouryearsmonthlypayment = new QAFExtendedWebElement("ehome.ratePresentation.fouryears.MonthlyPayment");
    QAFExtendedWebElement fouryearsmonthlypaymentvalue = new QAFExtendedWebElement("ehome.ratePresentation.fouryears.MonthlyPaymentValue");
    QAFExtendedWebElement fouryearsselect = new QAFExtendedWebElement("ehome.ratepresentation.fouryears.select");

    QAFExtendedWebElement fiveyears = new QAFExtendedWebElement("ehome.ratePresentation.fiveyears");
    QAFExtendedWebElement fiveyearsrate = new QAFExtendedWebElement("ehome.ratePresentation.fiveyears.rate");
    QAFExtendedWebElement fiveyearsmonthlypayment = new QAFExtendedWebElement("ehome.ratePresentation.fiveyears.MonthlyPayment");
    QAFExtendedWebElement fiveyearsmonthlypaymentvalue = new QAFExtendedWebElement("ehome.ratePresentation.fiveyears.MonthlyPaymentValue");
    QAFExtendedWebElement fiveyearsselect = new QAFExtendedWebElement("ehome.ratepresentation.fiveyears.select");

    QAFExtendedWebElement fiveyearsvariable = new QAFExtendedWebElement("ehome.ratePresentation.fiveyears.variable");
    QAFExtendedWebElement fiveyearsvariablerate = new QAFExtendedWebElement("ehome.ratePresentation.fiveyears.variable.rate");
    QAFExtendedWebElement fiveyearsvariablemonthlypayment = new QAFExtendedWebElement("ehome.ratePresentation.fiveyears.variable.MonthlyPayment");
    QAFExtendedWebElement fiveyearsvariablemonthlypaymentvalue = new QAFExtendedWebElement("ehome.ratePresentation.fiveyears.variable.MonthlyPaymentValue");
    QAFExtendedWebElement fiveyearsvariableselect = new QAFExtendedWebElement("ehome.ratepresentation.fiveyears.variable.select");

    //QAFExtendedWebElement fiveyearsvariable = new QAFExtendedWebElement("ehome.ratepresentation.fiveyears.variable");

    QAFExtendedWebElement Mortgage = new QAFExtendedWebElement("ehome.ratelock.Mortgage");


    @Given("^Customer should login and navigates to Rate Lock$")
    public void CustomershouldloginandnavigatestoRatePresentationbyselecting() throws Throwable {

        Common.stage2ToStage3(testCaseID);
        wait.until(ExpectedConditions.visibilityOf(eHomeHeader));
        Continue.click();
        selectFixed.click();
        if (!twoyearss.verifyPresent())
            throw new AssertionError("Couldn't find 2 years button");
        Thread.sleep(2000);
        twoyearss.click();
        if (!twoyear.verifyPresent())
            throw new AssertionError("Couldn't find 2 years button");
        wait.until(ExpectedConditions.elementToBeClickable(twoyear));
        twoyear.click();
    }


    //Rate_Lock_003
    @When("^Verify Lock&Hold Screen Message and Header text in Rate Lock Screen$")
    public void verifyLockHoldScreenMessageAndHeaderTextInRateLockScreen() throws Throwable {

        headertext1.assertPresent();
        String Rate_Lock_Message = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage03_Rate_ExpectedData", testCaseID, "Rate_Lock_Message");
        Assert.assertEquals(headertext1.getText(), Rate_Lock_Message, "Couldn't find Great choice.");

        headertext2.assertPresent();
        String Rate_Lock_Header = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage03_Rate_ExpectedData", testCaseID, "Rate_Lock_Header");
        Assert.assertEquals(headertext2.getText(), Rate_Lock_Header, "Couldn't find Lock & Hold your rate to secure it for 90 days");
    }


    @Then("^Verify 'You can only Lock&Hold one rate' and its content in Rate Lock Screen$")
    public void verifyYouCanOnlyLockHoldOneRateAndItsContentInRateLockScreen() throws Throwable {
        QAFExtendedWebElement YoucanonlyLockandHoldonerate = new QAFExtendedWebElement("ehome.ratelock.YoucanonlyLockandHoldonerate");
        QAFExtendedWebElement p1 = new QAFExtendedWebElement("ehome.ratelock.ContentP1");
        QAFExtendedWebElement p2 = new QAFExtendedWebElement("ehome.ratelock.ContentP2");
        QAFExtendedWebElement p3 = new QAFExtendedWebElement("ehome.ratelock.ContentP3");

        YoucanonlyLockandHoldonerate.assertPresent();
        String Lock_Hold_Rate_Header = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage03_Rate_ExpectedData", testCaseID, "Lock_Hold_Rate_Header");
        Assert.assertEquals(YoucanonlyLockandHoldonerate.getText(), Lock_Hold_Rate_Header, "Couldn't find You can only Lock & Hold one rate");

        p1.assertPresent();
        String Lock_Hold_Rate_P1 = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage03_Rate_ExpectedData", testCaseID, "Lock_Hold_Rate_P1");
        Assert.assertEquals(p1.getText(), Lock_Hold_Rate_P1, "Couldn't find Your rate will be guaranteed for 90 days from the date you lock in your rate as long as your mortgage application is submitted and approved, and no changes are made to your application.");

        p2.assertPresent();
        String Lock_Hold_Rate_P2 = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage03_Rate_ExpectedData", testCaseID, "Lock_Hold_Rate_P2");
        Assert.assertEquals(p2.getText(), Lock_Hold_Rate_P2, "Couldn't find Your rate will be guaranteed for 90 days from the date you lock in your rate as long as your mortgage application is submitted and approved, and no changes are made to your application.");

        p3.assertPresent();
        String Lock_Hold_Rate_P3 = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage03_Rate_ExpectedData", testCaseID, "Lock_Hold_Rate_P3");
        Assert.assertEquals(p3.getText(), Lock_Hold_Rate_P3, "Couldn't find Your rate will be guaranteed for 90 days from the date you lock in your rate as long as your mortgage application is submitted and approved, and no changes are made to your application.");
    }

    //Rate_Lock_004
    @When("^Click on the Lock and hold in Rate Lock Screen$")
    public void Click_on_the_Lock_and_hold_in_Rate_Lock_Screen() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        QAFExtendedWebElement LockandHold = new QAFExtendedWebElement("ehome.ratelock.LockandHold");
        if (!LockandHold.verifyPresent())
            throw new AssertionError("Couldn't find Lock & Hold on the screen");
        LockandHold.click();

    }

    @Then("^It should navigate to rate customization Screen$")
    public void It_should_navigate_to_rate_customization_Screen() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        Thread.sleep(2000);
        QAFExtendedWebElement RateCustomizationHeader = new QAFExtendedWebElement("ehome.RateCustomization.Unlockyourrate");
        Assert.assertEquals(RateCustomizationHeader.getText(), "Unlock your rate");

    }

    //Rate_Lock_005
    @When("^Click on the Select a differnt rate in Rate Lock Screen$")
    public void clickOnTheSelectADifferntRateInRateLockScreen() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        QAFExtendedWebElement Selectadifferentrate = new QAFExtendedWebElement("ehome.ratelock.Selectadifferentrate");
        if (!Selectadifferentrate.verifyPresent())
            throw new AssertionError("Couldn't find Select a differnt rate on the screen");
        Selectadifferentrate.click();

    }

    @Then("^It should navigate to rate Presentation Screen$")
    public void It_should_navigate_to_rate_Presentation_Screen() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        Thread.sleep(2000);
        QAFExtendedWebElement RatePresentation = new QAFExtendedWebElement("ehome.ratepresentation.header");
        Assert.assertEquals(RatePresentation.getText(), "Choose from these online exclusive mortgage offers we have just for you!");

    }

    //Rate_Lock_005 to Rate_Lock_009
    @When("^Verify the Mortgage as \"([^\"]*)\" in Rate and lock screen$")
    public void VerifytheMortgageinRateandlockscreen(String expectedText) throws Throwable {
        if (expectedText.contentEquals("2 year closed")) {
            Assert.assertEquals(Mortgage.getText(), expectedText, "Couldn't find Mortgage as 2 years");
        } else if (expectedText.contentEquals("3 year closed")) {
            Assert.assertEquals(Mortgage.getText(), expectedText, "Couldn't find Mortgage as 3 years");
        } else if (expectedText.contentEquals("4 year closed")) {
            Assert.assertEquals(Mortgage.getText(), expectedText, "Couldn't find Mortgage as 4 years");
        } else if (expectedText.contentEquals("5 year closed")) {
            Assert.assertEquals(Mortgage.getText(), expectedText, "Couldn't find Mortgage as 5 years");
        }

    }

    @Then("^Check for default insurance$")
    public void Checkfordefaultinsurance() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        //To Check default insurance in the information icon
        if (!loanrequestedinformation.verifyPresent())
            throw new AssertionError("Couldn't find Loan requested information icon");
        loanrequestedinformation.click();

        loanrequestedinformationtext.assertPresent();
        String Loan_Requested_Information_Text = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage03_Rate_ExpectedData", testCaseID, "Loan_Requested_Information_Text");
        Assert.assertEquals(loanrequestedinformationtext.getText(), Loan_Requested_Information_Text, "Couldn't find Default Insurance amount");

        loanrequestedinformationclose.assertPresent();
        loanrequestedinformationclose.click();

        Purchasepricevalue.assertPresent();
        double Purchasepricedb = Utility.convertCurrencyToDouble.apply(Purchasepricevalue.getText());

        downpaymentvalue.assertPresent();
        double downpaymentdb = Utility.convertCurrencyToDouble.apply(downpaymentvalue.getText());

        Boolean isDownPaymentLessThan20Percent = BusinessCalculations.isDownPaymentLessThan20Percent(Purchasepricedb, downpaymentdb);
        System.out.println(isDownPaymentLessThan20Percent + "isDownPaymentLessThan20Percent");
    }

    @When("^Verify Purchase price and Down payment and calculated Loan requested on the screen when DownPayment is < (\\d+)%$")
    public void verifyPurchasePriceAndDownPaymentAndCalculatedLoanRequestedOnTheScreenWhenDownPaymentIs(int arg0) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        //To Check Mortgage summary text

        mortgagesummarytitle.assertPresent();
        String Mortgage_Summary_Title = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage03_Rate_ExpectedData", testCaseID, "Mortgage_Summary_Title");
        Assert.assertEquals(mortgagesummarytitle.getText(), Mortgage_Summary_Title, "Mortgage summary not present on Rate Presentation");

        //To Check Purchaseprice text
        Purchaseprice.assertPresent();
        String Purchase_Price_Title = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage03_Rate_ExpectedData", testCaseID, "Purchase_Price_Title");
        Assert.assertEquals(Purchaseprice.getText(), Purchase_Price_Title, "Couldn't find the Purchase price:");

        //To Check Purchaseprice value
        Purchasepricevalue.assertPresent();
        String PurchasePriceFromExcel = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage03_Rate_ExpectedData", testCaseID, "Purchase_Price");
        Assert.assertEquals(Purchasepricevalue.getText(), PurchasePriceFromExcel, "Couldn't find the Purchase price value");
        //To Check Down payment text

        downpayment.assertPresent();
        String Down_Payment_Title = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage03_Rate_ExpectedData", testCaseID, "Down_Payment_Title");
        Assert.assertEquals(downpayment.getText(), Down_Payment_Title, "Couldn't find the Down payment:");

        //To Check Down payment Value
        downpaymentvalue.assertPresent();
        String DownPaymentFromExcel = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage03_Rate_ExpectedData", testCaseID, "Down_Payment_Amount");
        Assert.assertEquals(downpaymentvalue.getText(), DownPaymentFromExcel, "Couldn't find the Down payment value");

        //To Check Loanrequested text
        loanrequested.assertPresent();
        String Loan_Requested_Title = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage03_Rate_ExpectedData", testCaseID, "Loan_Requested_Title");
        Assert.assertEquals(loanrequested.getText(), Loan_Requested_Title, "Couldn't find the Loan requested:");

        //To Check Loanrequested Value
        loanrequestedvalue.assertPresent();
        double loanvalue = Utility.convertCurrencyToDouble.apply(loanrequestedvalue.getText());
        double Purchasepricedb = Utility.convertCurrencyToDouble.apply(Purchasepricevalue.getText());
        double downpaymentdb = Utility.convertCurrencyToDouble.apply(downpaymentvalue.getText());
        Double CalculatedLoanRequest = calculateLoanRequested.apply(Purchasepricedb, downpaymentdb);
        System.out.println("CalculatedLoanRequest" + CalculatedLoanRequest + "     " + loanvalue);
        Assert.assertEquals(loanvalue, CalculatedLoanRequest + 2296, "There is an error is calculating the loan requested value");

    }

    @Then("^Verify Default insurance is not available$")
    public void verifyDefaultInsuranceIsNotAvailable() throws Throwable {
        if (loanrequestedinformation.isPresent())
            throw new AssertionError("Couldn't find Loan requested information icon");
    }

    @When("^Verify Purchase price and Down payment and calculated Loan requested on the Rate Lock screen when DownPayment is >= (\\d+)%$")
    public void verifyPurchasePriceAndDownPaymentAndCalculatedLoanRequestedOnTheRateLockScreenWhenDownPaymentIs(int arg0) throws Throwable {
        mortgagesummarytitle.assertPresent();
        String Mortgage_Summary_Title = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage03_Rate_ExpectedData", testCaseID, "Mortgage_Summary_Title");
        Assert.assertEquals(mortgagesummarytitle.getText(), Mortgage_Summary_Title, "Mortgage summary not present on Rate Presentation");

        //To Check Purchaseprice text
        Purchaseprice.assertPresent();
        String Purchase_Price_Title = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage03_Rate_ExpectedData", testCaseID, "Purchase_Price_Title");
        Assert.assertEquals(Purchaseprice.getText(), Purchase_Price_Title, "Couldn't find the Purchase price:");

        //To Check Purchaseprice value
        Purchasepricevalue.assertPresent();
        String PurchasePriceFromExcel = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage03_Rate_ExpectedData", testCaseID, "Purchase_Price");
        Assert.assertEquals(Purchasepricevalue.getText(), PurchasePriceFromExcel, "Couldn't find the Purchase price value");
        //To Check Down payment text

        downpayment.assertPresent();
        String Down_Payment_Title = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage03_Rate_ExpectedData", testCaseID, "Down_Payment_Title");
        Assert.assertEquals(downpayment.getText(), Down_Payment_Title, "Couldn't find the Down payment:");

        //To Check Down payment Value
        downpaymentvalue.assertPresent();
        String DownPaymentFromExcel = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage03_Rate_ExpectedData", testCaseID, "Down_Payment_Amount");
        Assert.assertEquals(downpaymentvalue.getText(), DownPaymentFromExcel, "Couldn't find the Down payment value");

        //To Check Loanrequested text
        loanrequested.assertPresent();
        String Loan_Requested_Title = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage03_Rate_ExpectedData", testCaseID, "Loan_Requested_Title");
        Assert.assertEquals(loanrequested.getText(), Loan_Requested_Title, "Couldn't find the Loan requested:");

        //To Check Loanrequested Value
        loanrequestedvalue.assertPresent();
        double loanvalue = Utility.convertCurrencyToDouble.apply(loanrequestedvalue.getText());
        double Purchasepricedb = Utility.convertCurrencyToDouble.apply(Purchasepricevalue.getText());
        double downpaymentdb = Utility.convertCurrencyToDouble.apply(downpaymentvalue.getText());
        Double CalculatedLoanRequest = calculateLoanRequested.apply(Purchasepricedb, downpaymentdb);
        System.out.println("CalculatedLoanRequest" + CalculatedLoanRequest + "     " + loanvalue);
        Assert.assertEquals(loanvalue, CalculatedLoanRequest, "There is an error is calculating the loan requested value");


    }

    @Given("^Customer should login and navigates to Rate Presentment Screen$")
    public void customerShouldLoginAndNavigatesToRatePresentmentScreen() throws Throwable {

        Common.stage2ToStage3(testCaseID);
        wait.until(ExpectedConditions.visibilityOf(eHomeHeader));
        Continue.click();
    }

    @When("^'Fixed' component is selected in Rate Screen$")
    public void fixedComponentIsSelectedInRateScreen() throws Throwable {
        selectFixed.click();
        QAFExtendedWebElement typeofrate = new QAFExtendedWebElement("ehome.typeofrate.header");
        if (!typeofrate.verifyText("What type of rate are you looking for?"))
            throw new AssertionError("Not able to launch what type of rate page");

    }

    @When("^'Variable' component is selected in Rate Screen$")
    public void variableComponentIsSelectedInRateScreen() throws Throwable {
    selectVariable.click();
        QAFExtendedWebElement typeofrate = new QAFExtendedWebElement("ehome.typeofrate.header");
        if (!typeofrate.verifyText("What type of rate are you looking for?"))
            throw new AssertionError("Not able to launch what type of rate page");
    }

    @Then("^Verify the headers on Term selection page$")
    public void verifyTheHeadersOnTermSelectionPage() throws Throwable {

        whatmortgagetermareyoulookingfor.assertPresent();
        String Mortgage_Term_Header = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage03_Rate_ExpectedData", testCaseID, "Mortgage_Term_Header");
        Assert.assertEquals(whatmortgagetermareyoulookingfor.getText(), Mortgage_Term_Header, "Couldn't find What mortgage term are you looking for? screen");
    }

    @When("^Click on \"([^\"]*)\" in What mortgage term are you looking for in Mortgage Term screen page$")
    public void clickOnInWhatMortgageTermAreYouLookingForInMortgageTermScreenPage(String expectedText) throws Throwable {
        if (expectedText.contentEquals("2 year")) {
            QAFExtendedWebElement twoyears = new QAFExtendedWebElement("ehome.termsofrate.2years.radio");
            if (!twoyears.verifyPresent())
                throw new AssertionError("Couldn't find 2 years button");
            twoyears.click();
        } else if (expectedText.contentEquals("3 year")) {
            QAFExtendedWebElement threeyears = new QAFExtendedWebElement("ehome.termsofrate.3years.radio");
            if (!threeyears.verifyPresent())
                throw new AssertionError("Couldn't find 3 years button");
            threeyears.click();

        } else if (expectedText.contentEquals("4 year")) {
            QAFExtendedWebElement fouryears = new QAFExtendedWebElement("ehome.termsofrate.4years.radio");
            if (!fouryears.verifyPresent())
                throw new AssertionError("Couldn't find 4 years button");
            fouryears.click();
        } else if (expectedText.contentEquals("5 year")) {
            QAFExtendedWebElement fiveyears = new QAFExtendedWebElement("ehome.termsofrate.5years.radio");
            if (!fiveyears.verifyPresent())
                throw new AssertionError("Couldn't find 5 years button");
            fiveyears.click();
        }
    }

    @Then("^Verify headers on Rate Presentation screen when navigated$")
    public void verifyHeadersOnRatePresentationScreenWhenNavigated() throws Throwable {
        Thread.sleep(2000);
        RatePresentmentHeader.assertPresent();
        String Rate_Presentation_Header = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage03_Rate_ExpectedData", testCaseID, "Rate_Presentation_Header");
        Assert.assertEquals(RatePresentmentHeader.getText(), Rate_Presentation_Header, "Couldn't find Choose from these online exclusive mortgage offers we have just for you!");
    }

    @And("^\"([^\"]*)\" years should be highlighted with Rate Monthly payment and select button should be displayed on the Rate Presentation Screen$")
    public void yearsShouldBeHighlightedWithRateMonthlyPaymentAndSelectButtonShouldBeDisplayedOnTheRatePresentationScreen(String expectedText) throws Throwable {
        if (expectedText.contentEquals("2")) {
            // TO Check the highlighted with Rate Monthly payment

            String color = twoyears.getCssValue("background-color");
            String hex = convertRGBToHex(color);
            Assert.assertEquals("#8230df", hex);
            if (!hex.contentEquals("#8230df"))
                throw new AssertionError("2years is not highlighted with #8230df color");
            // TO Check the Rate Monthly payment

            if (!twoyearsrate.verifyPresent())
                throw new AssertionError("Couldn't find Rate");
            // TO Check the MonthlyPayment Text

            if (!twoyearsmonthlypayment.verifyPresent())
                throw new AssertionError("Couldn't find monthly payement");
            // TO Check the MonthlyPayment Value for 2 years

            if (!twoyearsmonthlypaymentvalue.verifyPresent())
                throw new AssertionError("Couldn't find monthly payementvalue for 2 years ");
            // TO Check the Select Button

            if (!twoyearsselect.verifyPresent())
                throw new AssertionError("Couldn't find select button");

        } else if (expectedText.contentEquals("3")) {
            String color = threeyears.getCssValue("background-color");
            String hex = convertRGBToHex(color);
            Assert.assertEquals("#8230df", hex);
            if (!hex.contentEquals("#8230df"))
                throw new AssertionError("2years is not highlighted with #8230df color");
            if (!threeyearsrate.verifyPresent())
                throw new AssertionError("Couldn't find Rate");
            if (!threeyearsmonthlypayment.verifyPresent())
                throw new AssertionError("Couldn't find monthly payement");
            if (!threeyearsselect.verifyPresent())
                throw new AssertionError("Couldn't find select button");
            // TO Check the MonthlyPayment Value for 3 years
            if (!threeyearsmonthlypaymentvalue.verifyPresent())
                throw new AssertionError("Couldn't find monthly payementvalue for 3 years ");
        }
        else if (expectedText.contentEquals("4")) {
            String color = fouryears.getCssValue("background-color");
            String hex = convertRGBToHex(color);
            Assert.assertEquals("#8230df", hex);
            if (!hex.contentEquals("#8230df"))
                throw new AssertionError("2years is not highlighted with #8230df color");
            if (!fouryearsrate.verifyPresent())
                throw new AssertionError("Couldn't find Rate");
            if (!fouryearsmonthlypayment.verifyPresent())
                throw new AssertionError("Couldn't find monthly payement");
            if (!fouryearsselect.verifyPresent())
                throw new AssertionError("Couldn't find select button");
            // TO Check the MonthlyPayment Value for 4 years
            if (!fouryearsmonthlypaymentvalue.verifyPresent())
                throw new AssertionError("Couldn't find monthly payementvalue for 4 years ");

        }
        else if (expectedText.contentEquals("5")) {
            String color = fiveyears.getCssValue("background-color");
            String hex = convertRGBToHex(color);
            Assert.assertEquals("#8230df", hex);
            if (!hex.contentEquals("#8230df"))
                throw new AssertionError("2years is not highlighted with #8230df color");
            if (!fiveyearsrate.verifyPresent())
                throw new AssertionError("Couldn't find Rate");
            if (!fiveyearsmonthlypayment.verifyPresent())
                throw new AssertionError("Couldn't find monthly payement");
            if (!fiveyearsselect.verifyPresent())
                throw new AssertionError("Couldn't find select button");
            // TO Check the MonthlyPayment Value for 5 years
            if (!fiveyearsmonthlypaymentvalue.verifyPresent())
                throw new AssertionError("Couldn't find monthly payementvalue for 5 years ");
        }
    }

    @When("^\"([^\"]*)\" is selected on the rate Presentment Screen$")
    public void isSelectedOnTheRatePresentmentScreen(String expectedText) throws Throwable {
        if (expectedText.contentEquals("2 year")) {
            twoyearsselect.click();
        } else if (expectedText.contentEquals("3 year")) {
            threeyearsselect.click();
        } else if (expectedText.contentEquals("4 year")) {
            fouryearsselect.click();
        } else if (expectedText.contentEquals("5 year")) {
            fiveyearsselect.click();
        }
    }


    @When("^Verify Variable Rate and Payment amount should be displayed for (\\d+) year Variable rate product$")
    public void verifyVariableRateAndPaymentAmountShouldBeDisplayedForYearVariableRateProduct(int arg0) throws Throwable {
        if (!fiveyearsvariable.verifyPresent())
            throw new AssertionError("Couldn't find 5 years button");
        // fiveyearsvariable.click();
    }

    @Then("^(\\d+) years variable should be highlighted with Rate Monthly payment and select button should be displayed on the Rate Presentation Screen$")
    public void yearsVariableShouldBeHighlightedWithRateMonthlyPaymentAndSelectButtonShouldBeDisplayedOnTheRatePresentationScreen(int arg0) throws Throwable {
        String color = fiveyearsvariable.getCssValue("background-color");
        String hex = convertRGBToHex(color);
        Assert.assertEquals("#8230df", hex);
        if (!hex.contentEquals("#8230df"))
            throw new AssertionError("2years is not highlighted with #8230df color");
        // TO Check the Rate Monthly payment

        if (!fiveyearsvariablerate.verifyPresent())
            throw new AssertionError("Couldn't find Rate");
        // TO Check the MonthlyPayment Text

        if (!fiveyearsvariablemonthlypayment.verifyPresent())
            throw new AssertionError("Couldn't find monthly payement");
        // TO Check the MonthlyPayment Value for 2 years

        if (!fiveyearsvariablemonthlypaymentvalue.verifyPresent())
            throw new AssertionError("Couldn't find monthly payementvalue for 2 years ");
        // TO Check the Select Button

        if (!fiveyearsvariableselect.verifyPresent())
            throw new AssertionError("Couldn't find select button");


    }

    @When("^(\\d+) years variable rate is selected on the rate Presentment Screen$")
    public void yearsVariableRateIsSelectedOnTheRatePresentmentScreen(int arg0) throws Throwable {
        fiveyearsvariableselect.click();
    }
}
