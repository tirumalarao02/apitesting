package com.quantum.config;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.keys.ApplicationProperties;
import com.quantum.utility.Utils;

public class SystemProperties {
    public static String JIRA_ROOT_URL = System.getProperty("jiraRootURL", ConfigurationManager.getBundle().getString("xray.root.url")).toLowerCase();
    public static String JIRA_USERNAME = System.getProperty("jiraUsername", ConfigurationManager.getBundle().getString("xray.user.name")).toLowerCase();
    //public static String JIRA_PASSWORD = System.getProperty("jiraPassword", ConfigurationManager.getBundle().getString("encrypted.xray.password"));
    public static String JIRA_PASSWORD = System.getProperty("jiraPassword", Utils.decryptString(ConfigurationManager.getBundle().getString("xray.password")));

    public static String JIRA_ISSUE_KEYS = System.getProperty("jiraIssueKeys", ConfigurationManager.getBundle().getString("xray.issue.keys"));
    public static String PROJECT_KEYS = System.getProperty("jiraProjectKeys", ConfigurationManager.getBundle().getString("xray.project.key"));

    public static String FEATURE_FILE_NAME = System.getProperty("importedScenarioFile", "downloadXray");
    public static String TESTNG_XML_REPORT_FILEPATH = System.getProperty("testngXmlReportFilepath", "target/surefire-reports/testng-results.xml");
    public static String IMPORTED_SCENARIO_DIRECTORY = System.getProperty("importedScenarioDirectory", "src/main/resources/scenarios");

    public static String JSON_FILE_NAME = System.getProperty("jsonFile", "cucumber.json");
}
