package com.scotiabank.ehome.ui.steps.stage7;

import static com.scotiabank.ehome.ui.steps.Utility.getScreenDataset;

import java.util.Map;

import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.qmetry.qaf.automation.step.QAFTestStepProvider;
import com.qmetry.qaf.automation.ui.WebDriverTestBase;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebDriver;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.quantum.utils.ConfigurationUtils;
import com.scotiabank.ehome.ui.steps.Common;
import com.scotiabank.ehome.ui.steps.Utility;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

@QAFTestStepProvider
public class ApplicationSummary {
	
	private QAFExtendedWebDriver webDriver = Utility.getDriver();
    public Actions action = null;
    public static WebDriverWait wait=Utility.getWait();	
    
    //private Map<String,Map<String,Boolean>> emailAddressExcel = getScreenDataset(Utility.getExcelFilePath("eHomeTestDatastage-4.xlsx"), "MobilePhoneNumber");
    //private Map<String,Map<String,Boolean>> emailAddressDataset = getScreenDataset(Utility.getExcelFilePath("eHomeTestDatastage-4.xlsx"), "IndustryAndJobTitle");
    
    QAFExtendedWebElement termsandconditionsContinue= new QAFExtendedWebElement("ehome.termsandconditions.agreeAndContinue");
    QAFExtendedWebElement consentpageyesContinue= new QAFExtendedWebElement("ehome.consentPage.yesContinue");
    QAFExtendedWebElement feedbackContinue= new QAFExtendedWebElement("ehome.feedback.continue");
    QAFExtendedWebElement appReadyHeaderText= new QAFExtendedWebElement("ehome.appready.headertext");
    QAFExtendedWebElement mortgageSummaryText= new QAFExtendedWebElement("ehome.appready.mortgageSummaryText");
    QAFExtendedWebElement AssessYourEligibilityText= new QAFExtendedWebElement("ehome.appready.AssessYourEligibilityText");
    QAFExtendedWebElement AssessYourEligibilityBoldText= new QAFExtendedWebElement("ehome.appready.AssessYourEligibilityBoldText");
    QAFExtendedWebElement RateExpiryDateText= new QAFExtendedWebElement("ehome.appready.RateExpiryDate");
    QAFExtendedWebElement RateExpiryDateTextI= new QAFExtendedWebElement("ehome.appready.RateExpiryDateI");
    QAFExtendedWebElement RateExpiryDateIButton= new QAFExtendedWebElement("ehome.appready.RateExpiryDateIButton");
    QAFExtendedWebElement feebBackHeaderText= new QAFExtendedWebElement("ehome.feebBack.headerText");
    
	@Given("^Customer should login and navigate to 'Application Summary' Screen$")
	public void customer_should_login_and_navigate_to_Application_Summary_Screen() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		 Utility.launchURL(ConfigurationUtils.getBaseBundle().getPropertyValue("env.baseurl3"));
		 termsandconditionsContinue.click();
		 Thread.sleep(1000);
		 consentpageyesContinue.click();
		 Thread.sleep(1000);
		 feedbackContinue.click();
		 Thread.sleep(1000);
	}
	
	@Then("^Verify \"([^\"]*)\" , \"([^\"]*)\" , \"([^\"]*)\" , \"([^\"]*)\" , \"([^\"]*)\" , \"([^\"]*)\"$")
	public void verify(String dataPointer1, String dataPointer2, String dataPointer3, String dataPointer4, String dataPointer5, String dataPointer6) throws Throwable {
	
	    // Write code here that turns the phrase above into concrete actions
	 
   	 
//    	AddAnother.assertPresent();
 //	     if(!AddAnother.verifyPresent())
 	//            throw new AssertionError("Couldn't find the Add Another");
		String testCaseID = Utility.getScenarioID();
        String applicationReadyToBeSubmitted = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage07_ExpectedData",testCaseID , dataPointer1);
 	    Assert.assertEquals(appReadyHeaderText.getText(), applicationReadyToBeSubmitted,"Application Ready To Be Submitted");
 	    
 	    String mortgageSummaryTxt = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage07_ExpectedData",testCaseID , dataPointer2);
	    Assert.assertEquals(mortgageSummaryText.getText(), mortgageSummaryTxt,"mortgageSummaryTxt");

	    String AssessYourEligibilityTxt = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage07_ExpectedData",testCaseID , dataPointer3);
	    Assert.assertEquals(AssessYourEligibilityText.getText(), AssessYourEligibilityTxt,"AssessYourEligibilityTxt");
	    
	    String AssessYourEligibilityBoldTxt = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage07_ExpectedData",testCaseID , dataPointer4);
	    Assert.assertEquals(AssessYourEligibilityBoldText.getText(), AssessYourEligibilityBoldTxt,"AssessYourEligibilityBoldTxt");
	    
	    String RateExpiryDateTxt = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage07_ExpectedData",testCaseID , dataPointer5);
	    Assert.assertEquals(RateExpiryDateText.getText(), RateExpiryDateTxt,"RateExpiryDateText");
	    
	    RateExpiryDateIButton.click();
	    Thread.sleep(1000);
	    String RateExpiryDateITxt = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage07_ExpectedData",testCaseID , dataPointer6);
	    Assert.assertEquals(RateExpiryDateTextI.getText(), RateExpiryDateITxt,"RateExpiryDateText");
	}
	
	@When("^click on Back button from Application Summary screen$")
	public void click_on_Back_button_from_Application_Summary_screen() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    Common.backButtonClicked();
	}

	@Then("^Verify \"([^\"]*)\" Screen$")
	public void verify_Screen(String dataPointer) throws Throwable {
		String testCaseID = Utility.getScenarioID();
	    // Write code here that turns the phrase above into concrete actions
		String feebBackHeaderTxt = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage07_ExpectedData",testCaseID , dataPointer);
	    Assert.assertEquals(feebBackHeaderText.getText(), feebBackHeaderTxt,"feebBackHeaderTxt");
	}
}
