package com.quantum.steps;

import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.step.QAFTestStepProvider;
import com.qmetry.qaf.automation.ui.WebDriverTestBase;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

import java.io.FileInputStream;
import java.util.Properties;

import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

@QAFTestStepProvider
public class scotiabank {
	String actualResult = "";
	String expectedResult = "Englishxx";
	WebDriverTestBase driverSession;
	
    @Given("^User is on Visa Scotia homepage$")
    public void userIsOnVisaScotiaHomepage() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        //new WebDriverTestBase().getDriver().get("http://www.scotiabank.com");
    	//new WebDriverTestBase().getDriver().get(ConfigurationManager.getBundle().getString("env.baseurl"));
    	driverSession = new WebDriverTestBase();
    	driverSession.getDriver().get(ConfigurationManager.getBundle().getString("env.baseurl"));
    	driverSession.getDriver().manage().window().maximize();
  
    }

    @When("^User perform the actions to navigate to Personal Information page$")
    public void userPerformTheActionsToNavigateToPersonalInformationPage() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        //QAFExtendedWebElement personalBankingLinkElement = new QAFExtendedWebElement("css=ul#main-nav a.personal-banking");
        QAFExtendedWebElement personalBankingLinkElement = new QAFExtendedWebElement("scotiabank.personalbanking.link");
        QAFExtendedWebElement englishLanguageLinkElement = new QAFExtendedWebElement("css=a.lang-en");
        QAFExtendedWebElement productLinkElement = new QAFExtendedWebElement("css=div#personal-banking-content-links");
        QAFExtendedWebElement northAmericaLinkElement = new QAFExtendedWebElement("css=div#background-location a.north-america");
        QAFExtendedWebElement canadaLinkElement = new QAFExtendedWebElement("css=div#background-location ul.country-list li:nth-child(1) a");
        QAFExtendedWebElement applyNowBtnElement = new QAFExtendedWebElement("css=li:nth-child(1) div.visible-desktop a.btn-primary");
        QAFExtendedWebElement applyNowLinkElement = new QAFExtendedWebElement("css=div.cta-secondary a");
        QAFExtendedWebElement termsandconChkbxElement = new QAFExtendedWebElement("css=div.inputContainer input#DISC_AGREE");
        QAFExtendedWebElement startBtnElement = new QAFExtendedWebElement("css=div.buttons button.red-btn ");


        personalBankingLinkElement.click();
        Thread.sleep(5000);
        //Assert.assertEquals(expectedResult, englishLanguageLinkElement.getText());
        //Assert.assertEquals("", expectedResult, "actualResult");
        //Assert.assertEquals("arg0", arg1, arg2);
        //englishLanguageLinkElement.assertAttribute(name, value, label);
        //englishLanguageLinkElement.verifyText("Englishxxx", "English Verification");
        englishLanguageLinkElement.assertText("Englishxxx");
        englishLanguageLinkElement.click();
        productLinkElement.click();
        northAmericaLinkElement.click();
        canadaLinkElement.click();
        applyNowBtnElement.click();
        applyNowLinkElement.click();
        termsandconChkbxElement.click();
        startBtnElement.click();
        Thread.sleep(5000);
    }

    @Then("^User should be able to see Personal Information page$")
    public void userShouldBeAbleToSeePersonalInformationPage() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        QAFExtendedWebElement personalInformationTextElement = new QAFExtendedWebElement("css=div.progress-bar div.sub-title h2");
        QAFExtendedWebElement titleSelectElement = new QAFExtendedWebElement("css=#TITLE");
        QAFExtendedWebElement firstNameInputTextElement = new QAFExtendedWebElement("css=#FNAME");
        QAFExtendedWebElement initialInputTextElement = new QAFExtendedWebElement("css=#INITIAL");
        QAFExtendedWebElement lastNameInputTextElement = new QAFExtendedWebElement("css=#LNAME");

        personalInformationTextElement.verifyText("Step 1 of 4: Personal Information");
        Select titleSelect = new Select(titleSelectElement);
        titleSelect.selectByVisibleText("Mr");
        Thread.sleep(5000);
        firstNameInputTextElement.sendKeys("Nikhil");
        Thread.sleep(5000);
        initialInputTextElement.sendKeys("NA");
        Thread.sleep(5000);
        lastNameInputTextElement.sendKeys("Agrawal");
        Thread.sleep(5000);
    }

    @And("^User should be able to see helpline number on the Personal Information page$")
    public void userShouldBeAbleToSeeHelplineNumberOnThePersonalInformationPage() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        QAFExtendedWebElement contactScotiaBankTextElement = new QAFExtendedWebElement("css=span#helpLine span.phone");
        contactScotiaBankTextElement.verifyText("1-888-882-8958");
    }

    @Given("^User is on Mastercard Scotia homepage$")
    public void userIsOnMastercardScotiaHomepage() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        new WebDriverTestBase().getDriver().get("http://www.scotiabank.com/ca/en/personal/credit-cards/mastercard/momentum-card.html");
    }

    @When("^User perform the actions to navigate to Enter Your Info page$")
    public void userPerformTheActionsToNavigateToEnterYourInfoPage() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        QAFExtendedWebElement applyNowBtnMasterCardElement = new QAFExtendedWebElement("css=section#product-cta div.product-cta-content a.button--primary");
        QAFExtendedWebElement acceptAndContinueBtnMasterCardElement = new QAFExtendedWebElement("css=div.disclosureAccept button.button-primary");

        Thread.sleep(5000);
        applyNowBtnMasterCardElement.click();
        Thread.sleep(5000);
        acceptAndContinueBtnMasterCardElement.click();
    }

    @Then("^User should be able to see Enter Your Info page$")
    public void userShouldBeAbleToSeeEnterYourInfoPage() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        QAFExtendedWebElement enterYourInfoTextElement = new QAFExtendedWebElement("css=div.progress-text span");
        enterYourInfoTextElement.verifyText("Step 1 of 3: Enter your info");
    }

    @And("^User should be able to see Contact Us link on Enter Your Info page$")
    public void userShouldBeAbleToSeeContactUsLinkOnEnterYourInfoPage() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        QAFExtendedWebElement contactUsLinkElement = new QAFExtendedWebElement("css=div.page-header li a.tooltip-toggle");
        contactUsLinkElement.verifyPresent();
    }
}
