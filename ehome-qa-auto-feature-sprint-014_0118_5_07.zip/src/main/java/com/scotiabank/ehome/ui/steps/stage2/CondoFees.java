package com.scotiabank.ehome.ui.steps.stage2;

import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.step.QAFTestStepProvider;
import com.qmetry.qaf.automation.ui.WebDriverTestBase;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebDriver;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.quantum.utils.ConfigurationUtils;
import com.scotiabank.ehome.ui.steps.Common;
import com.scotiabank.ehome.ui.steps.ExcelDataToDataTable;
import com.scotiabank.ehome.ui.steps.Utility;
import com.scotiabank.ehome.ui.steps.valueObjects.Tuple;
import com.scotiabank.ehome.ui.steps.valueObjects.TypeOfRateVO;
import com.thoughtworks.qdox.model.expression.Add;

import org.junit.runner.RunWith;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;

import cucumber.api.CucumberOptions;
import cucumber.api.DataTable;
import cucumber.api.PendingException;
import cucumber.api.Transform;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import cucumber.api.junit.Cucumber;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import static com.scotiabank.ehome.ui.steps.BusinessCalculations.*;
import static com.scotiabank.ehome.ui.steps.Utility.*;


@QAFTestStepProvider
public class CondoFees {
	  public static WebDriverWait wait=Utility.getWait();

	// Scenario:Condo_Fees_001

	@Given("^Customer should login and navigates to Condo Fees screen$")
	public void CustomershouldloginandnavigatetoAreaofPropertyscreen() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		Utility.launchURL(ConfigurationUtils.getBaseBundle().getPropertyValue ("env.baseurl1"));
    	//To click Continue in Section breaker
        Common.sessionBreakerContinueButtonClick();
        //To enter manual address 
       	Common.enterAddressManually();
       	//To select house
 	     PropertyType.condoButtonClicked();
         Thread.sleep(2000);      
   	}

	// Scenario: Condo_Fees_002
	@When("^verify \"([^\"]*)\" message in Condo Fees screen$")
	public void Verify_message_in_Condo_fees_screen(String dataPointer) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	//TO Check the header message
    	String testCaseID = Utility.getScenarioID();
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_ExpectedData", testCaseID, dataPointer);
		Assert.assertEquals(Common.headerMessage(), value,"Couldn't found expected header text");
	}

	@Then("^\"([^\"]*)\" header should be displayed in Condo Fees screen$")
	public void header_should_be_displayed_in_Condo_Fees_screen(String dataPointer) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		String testCaseID = Utility.getScenarioID();
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_ExpectedData", testCaseID, dataPointer);
		Assert.assertEquals(Common.headertext(), value,"Couldn't found expected header text");
	}
	@And("^\"([^\"]*)\" should be displayed in Condo Fees screen$")
	public void should_be_displayed_in_Condo_Fees_screen(String dataPointer) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		String testCaseID = Utility.getScenarioID();
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_ExpectedData", testCaseID, dataPointer);
		QAFExtendedWebElement condo$= new QAFExtendedWebElement("ehome.CondoFees.$");
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(condo$));
		Assert.assertEquals(condo$.getText(), value,"Couldn't found expected header text");
	}

	// Scenario: Condo_Fees_003
	
	@When("^Enter \"([^\"]*)\" in Monthly Condo Fees screen$")
	public void enter_in_Monthly_Condo_Fees_screen(String dataPointer) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "CommonErrorMessages",dataPointer, "InputValues" );
		QAFExtendedWebElement condoFees= new QAFExtendedWebElement("ehome.CondoFees.CondoFees.input");
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(condoFees));
		condoFees.clear();
		condoFees.sendKeys(value);
	   
	}
		@Then("^\"([^\"]*)\" should be displayed Condo Fees screen$")
		public void should_be_displayed_Condo_Fees_screen(String dataPointer) throws Throwable {
			// Write code here that turns the phrase above into concrete actions
			String testCaseID = Utility.getScenarioID();
			String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_ExpectedData", testCaseID, dataPointer);
			QAFExtendedWebElement errormsg = new QAFExtendedWebElement("ehome.CondoFees.errormsg");
			wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(errormsg));
			Assert.assertEquals(errormsg.getText(), value,"Couldn't found expected header text");
	}
			
		// Scenario: Condo_Fees_004


		// Scenario: Condo_Fees_005

		@When("^Green check mark should be displayed$")
		public void Green_check_mark_should_be_displayed() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
			QAFExtendedWebElement greenicon= new QAFExtendedWebElement("ehome.CondoFees.greenicon");
			greenicon.isPresent();
		    
		}
		 public static void condoFees(String value) {
			 QAFExtendedWebElement condoFees= new QAFExtendedWebElement("ehome.CondoFees.CondoFees.input");
				wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(condoFees));
				condoFees.clear();
				condoFees.sendKeys(value);
		        
			}
		
		// Scenario: Condo_Fees_006
		@When("^Enter \"([^\"]*)\" Monthly Condo Fees in Condo Fees screen$")
	    public void Enter_an_valid_Monthly_Condo_Fees_in_Condo_Fees_screen(String dataPointer) throws Throwable {
	        // Write code here that turns the phrase above into concrete actions
			String testCaseID = Utility.getScenarioID();
			String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_InputData", testCaseID, dataPointer);
			condoFees(value);
	}
	 
		
		
	
}	

