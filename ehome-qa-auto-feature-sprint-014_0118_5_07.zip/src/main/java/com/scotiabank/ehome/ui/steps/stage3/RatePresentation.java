package com.scotiabank.ehome.ui.steps.stage3;
import com.perfectomobile.httpclient.utils.StringUtils;
import com.qmetry.qaf.automation.step.QAFTestStepProvider;
import com.qmetry.qaf.automation.testng.dataprovider.QAFDataProvider;
import com.qmetry.qaf.automation.ui.WebDriverTestBase;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebDriver;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.quantum.utils.ConfigurationUtils;

import com.scotiabank.ehome.ui.steps.BusinessCalculations;
import com.scotiabank.ehome.ui.steps.Common;
import com.scotiabank.ehome.ui.steps.PaymentScheduleEnum;
import com.scotiabank.ehome.ui.steps.Utility;
import com.scotiabank.ehome.ui.steps.valueObjects.Tuple;
import com.scotiabank.ehome.ui.steps.valueObjects.TypeOfRateVO;

import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import static com.scotiabank.ehome.ui.steps.BusinessCalculations.*;
import static com.scotiabank.ehome.ui.steps.Utility.*;
@QAFTestStepProvider
public class RatePresentation {
	private QAFExtendedWebDriver webDriver = new WebDriverTestBase().getDriver();
    public Actions action = null;
    WebDriverWait wait = new WebDriverWait(webDriver,50000);
    String testCaseID = Utility.getScenarioID();
    
    QAFExtendedWebElement mortgagesummarytitle = new QAFExtendedWebElement("ehome.mortgagesummarytitle.text");
    QAFExtendedWebElement Purchaseprice = new QAFExtendedWebElement("ehome.purchaseprice.text");
    QAFExtendedWebElement downpayment = new QAFExtendedWebElement("ehome.downpayment.text");
    QAFExtendedWebElement loanrequested = new QAFExtendedWebElement("ehome.loanrequested.text");
    QAFExtendedWebElement loanrequestedvalue = new QAFExtendedWebElement("ehome.loanrequested.span");
    QAFExtendedWebElement Purchasepricevalue = new QAFExtendedWebElement("ehome.purchaseprice.span");
    QAFExtendedWebElement downpaymentvalue = new QAFExtendedWebElement("ehome.downpayment.span");
   QAFExtendedWebElement  defaultInsurance = new QAFExtendedWebElement("//*[@id=\"loan-requested\"]");
    //@QAFDataProvider(dataFile = "src/main/resources/data/RatePresentment.xlsx", sheetName="Sheet1", key="data")
    @Given("^Customer should login and navigates to Rate Presentation by selecting fixed$")
    public void CustomershouldloginandnavigatestoRatePresentationFixed() throws Throwable {
    	//Common.stage2ToStage3(testCaseID);
    	
    	 // Write code here that turns the phrase above into concrete actions
    	Utility.launchURL(ConfigurationUtils.getBaseBundle().getPropertyValue ("env.baseurl"));
        //Click on continue on section breaker
        QAFExtendedWebElement buttonContinue= new QAFExtendedWebElement("ehome.rate.continue.button");
        buttonContinue.click();
        //Click on the select button in fixed
        QAFExtendedWebElement selectFixed= new QAFExtendedWebElement("ehome.typeofrate.selectfixed.radio");
        selectFixed.click ();
        TypeOfRateVO.getInstance().setTypeOfRate(TypeOfRateVO.TYPE_OF_RATE_FIXED_RATE);
        Thread.sleep(3000);
        fixedMortgageTermClicked("2 year");
        
    }
    @Given("^Customer should login and navigates to Rate Presentation by selecting variable$")
    public void CustomershouldloginandnavigatestoRatePresentationVariable() throws Throwable {
    	//Common.stage2ToStage3(testCaseID);
    	
    	 // Write code here that turns the phrase above into concrete actions
    	Utility.launchURL(ConfigurationUtils.getBaseBundle().getPropertyValue ("env.baseurl"));
        //Click on continue on section breaker
        QAFExtendedWebElement buttonContinue= new QAFExtendedWebElement("ehome.rate.continue.button");
        buttonContinue.click();
        //Click on the select button in variable
        QAFExtendedWebElement selectVariable = new QAFExtendedWebElement("ehome.typeofrate.selectvariable.radio");
        selectVariable.click();
        TypeOfRateVO.getInstance().setRateOfInterest(0.45);
        TypeOfRateVO.getInstance().setTypeOfRate(TypeOfRateVO.TYPE_OF_RATE_VARIABLE_RATE);
        
    }
    

    // Rate_Presentation_002

    @When("^Verify Mortgage summary of Purchase price Down payment and Loan requested on Rate Presentation Screen$")
    public void verify_Mortgage_summary_of_Purchase_price_Down_payment_and_Loan_requested_on_Rate_Presentation_Screen() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        //To Check Mortgage summary text
    	
        //To Check Mortgage Summary text
        mortgagesummarytitle.assertPresent();
        String Mortgage_Summary_Title = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage03_Rate_ExpectedData", testCaseID, "Mortgage_Summary_Title");
        Assert.assertEquals(mortgagesummarytitle.getText(), Mortgage_Summary_Title, "Mortgage summary not present on Rate Presentation");

        //To Check Purchaseprice text
        Purchaseprice.assertPresent();
        String Purchase_Price_Title = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage03_Rate_ExpectedData", testCaseID, "Purchase_Price_Title");
        Assert.assertEquals(Purchaseprice.getText(), Purchase_Price_Title, "Couldn't find the Purchase price:");

        //To Check Down payment text
        downpayment.assertPresent();
        String Down_Payment_Title = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage03_Rate_ExpectedData", testCaseID, "Down_Payment_Title");
        Assert.assertEquals(downpayment.getText(), Down_Payment_Title, "Couldn't find the Down payment:");

        //To Check Loanrequested text
        loanrequested.assertPresent();
        String Loan_Requested_Title = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage03_Rate_ExpectedData", testCaseID, "Loan_Requested_Title");
        Assert.assertEquals(loanrequested.getText(), Loan_Requested_Title, "Couldn't find the Loan requested:");

        //To Check Loanrequested Value
        loanrequestedvalue.assertPresent();
        double loanvalue = Utility.convertCurrencyToDouble.apply(loanrequestedvalue.getText());
        double Purchasepricedb = Utility.convertCurrencyToDouble.apply(Purchasepricevalue.getText());
        double downpaymentdb = Utility.convertCurrencyToDouble.apply(downpaymentvalue.getText());
        Double CalculatedLoanRequest = calculateLoanRequested.apply(Purchasepricedb, downpaymentdb);
        System.out.println("loanvalue+++++++++"+ loanvalue+"Purchasepricedb+++++++++" +Purchasepricedb+ "downpaymentdb+++++++++++ " + downpaymentdb);
        double default_Insurance = Utility.getDefaultInsuranceValue("src\\main\\resources\\data\\eHomeTestData.xlsx", "DefaultInsurance", Purchasepricedb, downpaymentdb);
      
          if(default_Insurance>0)
          {
        	  if (defaultInsurance.isPresent())
                  throw new AssertionError("Couldn't find Default Insurance information icon");
          
          }
}

    // Rate_Presentation_003
    @When("^Verify \"([^\"]*)\" in Rate presentation Screen$")
    public void VerifyinRatepresentationScreen(String dataPointer) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	Thread.sleep(5000);
    	String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage03_Rate_ExpectedData", testCaseID, dataPointer);
		QAFExtendedWebElement headertext= new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[2]/div[2]/h2");
		 wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(headertext));
		Assert.assertEquals(headertext.getText(), value,"Couldn't found expected header text");
    }

    @Then("^\"([^\"]*)\" Valid date DD YYYY format should display in Rate as of today$")
    public void ValiddateDDYYYYformatshoulddisplayinRateasoftoday(String expectedText) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        QAFExtendedWebElement rateValid = new QAFExtendedWebElement("ehome.ratepresentation.rateasdate");
        String rate = rateValid.getText();
        String date = rate.substring(11);
        String ratetest = expectedText + date;

        System.out.println("xxx" + date + "xxx" + ratetest);
        System.out.println("xxx" + rate);
        Format formatter = new SimpleDateFormat("EEEE, MMMM d, yyyy");
        String today = formatter.format(new Date());
        System.out.println("Today : " + today);

        Assert.assertEquals(date, today, "Couldn't find Date in EEEE, MMMM dd, yyyy format");
        Assert.assertEquals(rate, ratetest, "Couldn't find Rate as of Date in EEEE, MMMM dd, yyyy format");

    }

    // Rate_Presentation_04
    @When("^Verify \"([^\"]*)\" and \"([^\"]*)\" in Rate presentation Screen$")
    public void VerifyAmortizationandPaymentscheduleinRatepresentationScreen(String expectedText1,String expectedText2) throws Throwable {
        QAFExtendedWebElement Amortizationperiod = new QAFExtendedWebElement("ehome.ratepresentation.amortizationperiod.label");
        Amortizationperiod.assertPresent();
        Assert.assertEquals(Amortizationperiod.getText(), expectedText1, "Couldn't find the Amortizationperiod");
        QAFExtendedWebElement Amortizationinformation = new QAFExtendedWebElement(
                "//*[@id=\"app\"]/div/div[1]/div[2]/div[3]/div/div[2]/div/div/div[2]/div[1]/div[1]/div/button");
        Amortizationinformation.click();
        QAFExtendedWebElement Amortizationinformationclose = new QAFExtendedWebElement(
                "ehome.ratepresentation.amortizationperiod.close");
        Amortizationinformationclose.click();

        QAFExtendedWebElement Paymentschedule = new QAFExtendedWebElement(
                "//*[@id=\"app\"]/div/div[1]/div[2]/div[3]/div/div[2]/div/div/div[2]/div[2]/div[1]/span");
        Assert.assertEquals(Paymentschedule.getText(), expectedText2, "Couldn't find the Paymentschedule");
        QAFExtendedWebElement Paymentscheduleinformation = new QAFExtendedWebElement(
                "//*[@id=\"app\"]/div/div[1]/div[2]/div[3]/div/div[2]/div/div/div[2]/div[2]/div[1]/div/button");
        Paymentscheduleinformation.click();
        QAFExtendedWebElement Paymentscheduleinformationclose = new QAFExtendedWebElement(
                "//*[@id=\"payment-schedule\"]/button");
        Paymentscheduleinformationclose.click();

    }

    @Then("^Amortization period dropdownn and Payment schedule dropdown information icon should displayed$")
    public void Amortization_period_dropdown_and_Payment_schedule_dropdownin_formation_icon_should_displayed() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        QAFExtendedWebElement Amortizationperiod = new QAFExtendedWebElement(
                "//*[@id=\"app\"]/div/div[1]/div[2]/div[3]/div/div[2]/div/div/div[2]/div[1]/div[1]/span");
        if (!Amortizationperiod.verifyPresent())
            throw new AssertionError("Couldn't find Amortization period text");

        QAFExtendedWebElement Amortizationperiod25years = new QAFExtendedWebElement(
                "ehome.ratepresentation.amortizationperiod.25years");
        if (!Amortizationperiod.verifyPresent())
            throw new AssertionError("Couldn't find Amortization period 25 years");
        // Amortizationperiod25years.click();
        QAFExtendedWebElement Amortizationperiod12months = new QAFExtendedWebElement(
                "ehome.ratepresentation.amortizationperiod.months");
        // Amortizationperiod12months.click();
        if (!Amortizationperiod.verifyPresent())
            throw new AssertionError("Couldn't find Amortization period 12 months");
        // Amortizationperiod12months.click();
        QAFExtendedWebElement Paymentschedulemonthly = new QAFExtendedWebElement("//*[@id=\"mortgage-schedule\"]");
        if (!Paymentschedulemonthly.verifyPresent())
            throw new AssertionError("Couldn't find Payment schedule Monthly");
        // Paymentschedulemonthly.click();


        Select oSelectYears = new Select(Amortizationperiod25years);
        List<WebElement> optionsListYears = oSelectYears.getOptions();

        Select oSelectMonths = new Select(Amortizationperiod12months);


        Select oSelectPaymentschedule = new Select(Paymentschedulemonthly);
        List<WebElement> optionsListPaymentschedule = oSelectPaymentschedule.getOptions();

        ArrayList<String> alMessages = new ArrayList<>();

        for (WebElement oneItemYears : optionsListYears) {
            if (oneItemYears.getAttribute("hidden") != null)
                continue;
            oneItemYears.click();
            List<WebElement> optionsListMonths = oSelectMonths.getOptions();
            for (WebElement oneItemMonths : optionsListMonths) {

                oneItemMonths.click();

                if (oneItemMonths.getAttribute("hidden") != null)
                    continue;
                for (WebElement oneItemPaymentschedule : optionsListPaymentschedule) {
                    oneItemPaymentschedule.click();
                    if (oneItemPaymentschedule.getAttribute("hidden") != null)
                        continue;
                    String monthsText = oneItemMonths.getAttribute("value");
                    String yearText = oneItemYears.getAttribute("value");
                    String paymentscheduleStr = oneItemPaymentschedule.getAttribute("value");
                    if (monthsText.contentEquals("Months") || yearText.contentEquals("Years") || paymentscheduleStr.contentEquals("Payment schedule")) {
                        continue;
                    }


                    PaymentScheduleEnum paymentSchedule = PaymentScheduleEnum.getByString(paymentscheduleStr);

                    int monthsAmort = getNumberOfMonthsFromString(monthsText);
                    int yearsAmort = getNumberOfYearsFromString(yearText);

                    getYearsAndInterestRates().forEach((key, map) -> {
                        int numberOfYears = (int) map.get("Years");
                        double effectiveRate = (double) map.get("Interest");
                        double interestFactor = getInterestFactor(effectiveRate);
                        double paymentToTest = 0.0;
                        switch (paymentSchedule) {
                            case BIWEEKLY:
                                paymentToTest = getBiWeeklyPayment(TypeOfRateVO.getInstance().getLoanRequested(), interestFactor, getAmortizationPeriodInMonths(yearsAmort, monthsAmort));
                                break;
                            case WEEKLY:
                                paymentToTest = getWeeklyPayment(TypeOfRateVO.getInstance().getLoanRequested(), interestFactor, getAmortizationPeriodInMonths(yearsAmort, monthsAmort));
                                break;
                            case MONTHLY:
                                paymentToTest = getMonthlyPayment(TypeOfRateVO.getInstance().getLoanRequested(), interestFactor, getAmortizationPeriodInMonths(yearsAmort, monthsAmort));
                                break;

                        }
                        System.out.println("yearText: "+yearText+" monthsText: "+ monthsText+" paymentscheduleStr: "+paymentscheduleStr);
                        Tuple<Boolean, Double> tuple = isInterestSameOnPage(key, paymentToTest);
                        if (!tuple.x) {
                            String[] messageParameters = {yearText, monthsText, paymentscheduleStr, key,  tuple.y + "", paymentToTest + ""};
                            alMessages.add(messageFormatForInterestTest.format(messageParameters));
                            System.out.println("Error..." + messageFormatForInterestTest.format(messageParameters));
                        }

                    });


                    if (paymentscheduleStr.equals("weekly")) {
                        System.out.println("WEEKLY");

                        // TypeOfRateVO.getInstance().setNumberOfYears(2);
                        double effectiveRate = 2.75;
                        captureValuesInRatePresentmentScreen(effectiveRate);
                        System.out.println(TypeOfRateVO.getInstance().getMonthlyPayment()
                                + "TypeOfRateVO.getInstance().getMonthlyPayment()");

                    } else if (oneItemPaymentschedule.getText().equals("bi-weekly")) {
                        System.out.println("BI-WEEKLY");
                    } else if (oneItemPaymentschedule.getText().equals("monthly")) {
                        System.out.println("MONTHLY");
                    }

                }
            }

        }
        Assert.assertEquals(alMessages.size(), 0, alMessages.toString());
    }

    private Tuple<Boolean, Double> isInterestSameOnPage(String years, double paymentValue) {
        boolean pass = false;
        String monthlyPaymentValueStr = "";
        if (years.contentEquals("2")) {
            QAFExtendedWebElement monthlypaymentvalue2 = new QAFExtendedWebElement(
                    "//*[@id='app']/div/div[1]/div[2]/div[7]/div[1]/div[3]/span[2]");
            monthlyPaymentValueStr = monthlypaymentvalue2.getText();

        } else if (years.contentEquals("3")) {
            QAFExtendedWebElement monthlypaymentvalue3 = new QAFExtendedWebElement(
                    "//*[@id='app']/div/div[1]/div[2]/div[7]/div[2]/div[3]/span[2]");
            monthlyPaymentValueStr = monthlypaymentvalue3.getText();

        } else if (years.contentEquals("4")) {
            QAFExtendedWebElement monthlypaymentvalue4 = new QAFExtendedWebElement(
                    "//*[@id='app']/div/div[1]/div[2]/div[7]/div[3]/div[3]/span[2]");
            monthlyPaymentValueStr = monthlypaymentvalue4.getText();

        } else if (years.contentEquals("5")) {
            QAFExtendedWebElement monthlypaymentvalue5 = new QAFExtendedWebElement(
                    "//*[@id='app']/div/div[1]/div[2]/div[7]/div[4]/div[3]/span[2]");
            monthlyPaymentValueStr = monthlypaymentvalue5.getText();

        } else if (years.contentEquals("5_VAR")) {
            QAFExtendedWebElement monthlypaymentvalue5val = new QAFExtendedWebElement(
                    "//*[@id='app']/div/div[1]/div[2]/div[10]/div/div[3]/span[2]");
            monthlyPaymentValueStr = monthlypaymentvalue5val.getText();

        }
        Double monthlyPaymentValueDou = Utility.convertCurrencyToDouble.apply(monthlyPaymentValueStr);
        if (paymentValue == monthlyPaymentValueDou)
            pass = true;
        return new Tuple<>(pass, monthlyPaymentValueDou);
    }


    // Rate_Presentation_005 to Rate_Presentation_008
    @Given("^Customer should login and navigates to Stage 3 - Rate Presentment$")
    public void customerShouldLoginAndNavigatesToStageRatePresentment() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        webDriver = new WebDriverTestBase().getDriver();
        webDriver.get(ConfigurationUtils.getBaseBundle ().getPropertyValue ( "env.baseurl" ) );
        webDriver.manage().window().maximize();
        QAFExtendedWebElement buttonContinue= new QAFExtendedWebElement("ehome.rate.continue.button");
        buttonContinue.click();
        Actions action = new Actions(webDriver);
        WebDriverWait wait= new WebDriverWait ( webDriver,10 );
        QAFExtendedWebElement typeofrate= new QAFExtendedWebElement("ehome.typeofrate.header");
        if(!typeofrate.verifyText( "What type of rate are you looking for?"  ))
            throw new AssertionError("Not able to launch what type of rate page");
    }

    @When("^click on radio button Select for the rate type \"([^\"]*)\" component in What type of Rate you are looking for Screen$")
    public void clickonradiobuttonSelectfortheratetypecomponentintypeofrateyouarelookingforScreen(
            String expectedText) throws Throwable {
        QAFExtendedWebElement selectFixed = new QAFExtendedWebElement("ehome.typeofrate.selectfixed.radio");
        selectFixed.click();
    }

    @Then("^It should navigate to \"([^\"]*)\" screen page$")
    public void ItshouldnavigatetoWhatmortgagetermareyoulookingforscreenpage(String expectedText) throws Throwable {
        Thread.sleep(3000);
        QAFExtendedWebElement whatmortgagetermareyoulookingfor = new QAFExtendedWebElement(
                "ehome.termofrate.header");
        whatmortgagetermareyoulookingfor.assertPresent();
        Assert.assertEquals(whatmortgagetermareyoulookingfor.getText(), expectedText,
                "Couldn't find What mortgage term are you looking for? screen");
    }
    public  void fixedMortgageTermClicked(String value) {
    	 if (value.contentEquals("2 year")) {
             QAFExtendedWebElement twoyears = new QAFExtendedWebElement("ehome.termsofrate.2years.radio");
             if (!twoyears.verifyPresent())
                 throw new AssertionError("Couldn't find 2 years button");
             twoyears.click();
                     

         } else if (value.contentEquals("3 year")) {
             QAFExtendedWebElement threeyears = new QAFExtendedWebElement("ehome.termsofrate.3years.radio");
             if (!threeyears.verifyPresent())
                 throw new AssertionError("Couldn't find 3 years button");
             threeyears.click();

         } else if (value.contentEquals("4 year")) {
             QAFExtendedWebElement fouryears = new QAFExtendedWebElement("ehome.termsofrate.4years.radio");
             if (!fouryears.verifyPresent())
                 throw new AssertionError("Couldn't find 4 years button");
             fouryears.click();

         
         } else if (value.contentEquals("5 year")) {
             QAFExtendedWebElement fiveyears = new QAFExtendedWebElement("ehome.termsofrate.5years.radio");
             if (!fiveyears.verifyPresent())
                 throw new AssertionError("Couldn't find 5 years button");
        
         }

    
        
	}

    @When("^Click on \"([^\"]*)\" in What mortgage term are you looking for screen page$")
    public void ClickoninWhatmortgagetermareyoulookingforscreenpage(String dataPointer) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage03_Rate_ExpectedData", testCaseID, dataPointer);
		 if (value.contentEquals("2 year")) {
            QAFExtendedWebElement twoyears = new QAFExtendedWebElement("ehome.termsofrate.2years.radio");
            if (!twoyears.verifyPresent())
                throw new AssertionError("Couldn't find 2 years button");
            twoyears.click();
                     

        } else if (value.contentEquals("3 year")) {
            QAFExtendedWebElement threeyears = new QAFExtendedWebElement("ehome.termsofrate.3years.radio");
            if (!threeyears.verifyPresent())
                throw new AssertionError("Couldn't find 3 years button");
            threeyears.click();

           
        } else if (value.contentEquals("4 year")) {
            QAFExtendedWebElement fouryears = new QAFExtendedWebElement("ehome.termsofrate.4years.radio");
            if (!fouryears.verifyPresent())
                throw new AssertionError("Couldn't find 4 years button");
            fouryears.click();

         
        } else if (value.contentEquals("5 year")) {
            QAFExtendedWebElement fiveyears = new QAFExtendedWebElement("ehome.termsofrate.5years.radio");
            if (!fiveyears.verifyPresent())
                throw new AssertionError("Couldn't find 5 years button");
            fiveyears.click();
           
        }

    }

//    @Then("^User should navigate to \"([^\"]*)\" rate Presentation screen$")
//    public void UsershouldnavigatetoratePresentationscreen(String expectedText) throws Throwable {
//        Thread.sleep(3000);
//        QAFExtendedWebElement header = new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[2]/div[2]/h2");
//       // header.assertPresent();
//        Assert.assertEquals(header.getText(), expectedText,
//                "Couldn't find Choose from these online exclusive mortgage offers we have just for you!");
//        QAFExtendedWebElement loanrequestedvalue = new QAFExtendedWebElement(
//                "//*[@id=\"app\"]/div/div[1]/div[1]/div[2]/div/div/div[3]/span[2]");
//        loanrequestedvalue.assertPresent();
//        double loanvalue = Utility.convertCurrencyToDouble.apply(loanrequestedvalue.getText());
//        Assert.assertEquals(loanvalue, TypeOfRateVO.getInstance().getLoanRequested(),
//                "There is an error is calculating the loan requested value");
//
//    }

    @And("^\"([^\"]*)\" years should be highlighted with Rate Monthly payment and select button should be displayed$")
    public void yearsshouldbehighlightedwithRateMonthlypaymentandselectbuttonshouldbedisplayed(String expectedText)
            throws Throwable {
        if (expectedText.contentEquals("2")) {
            // TO Check the highlighted with Rate Monthly payment
            QAFExtendedWebElement twoyears = new QAFExtendedWebElement(
                    "//*[@id='app']/div/div[1]/div[2]/div[7]/div[1]/div[1]");
            String color = twoyears.getCssValue("background-color");
            String hex = convertRGBToHex(color);
            Assert.assertEquals("#8230df", hex);
            if (!hex.contentEquals("#8230df"))
                throw new AssertionError("2years is not highlighted with #8230df color");
            // TO Check the Rate Monthly payment
            QAFExtendedWebElement rate = new QAFExtendedWebElement(
                    "//*[@id='app']/div/div[1]/div[2]/div[7]/div[1]/div[2]/span[2]");
            if (!rate.verifyPresent())
                throw new AssertionError("Couldn't find Rate");
            // TO Check the MonthlyPayment Text
            QAFExtendedWebElement monthlypayment = new QAFExtendedWebElement(
                    "//*[@id='app']/div/div[1]/div[2]/div[7]/div[1]/div[3]/span[2]");
            if (!monthlypayment.verifyPresent())
                throw new AssertionError("Couldn't find monthly payement");
            // TO Check the MonthlyPayment Value for 2 years
            QAFExtendedWebElement monthlypaymentvalue = new QAFExtendedWebElement(
                    "//*[@id='app']/div/div[1]/div[2]/div[7]/div[1]/div[3]/span[2]");
            if (!monthlypaymentvalue.verifyPresent())
                throw new AssertionError("Couldn't find monthly payementvalue for 2 years ");
            String monthlypaymentvaluestr = monthlypaymentvalue.getText();
            Double monthlypaymentvaluedb = Utility.convertCurrencyToDouble.apply(monthlypaymentvaluestr);
            TypeOfRateVO.getInstance().setNumberOfYears(2);
            QAFExtendedWebElement twoYearRate = new QAFExtendedWebElement(
                    "//*[@id=\"app\"]/div/div[1]/div[2]/div[7]/div[1]/div[2]/span[2]");
            String Rate= twoYearRate.getText();
            double effectiveRate = Utility.getRateFromString(Rate);
            captureValuesInRatePresentmentScreen(effectiveRate);
            TypeOfRateVO.getInstance().setRateOfInterest(effectiveRate);
            Assert.assertEquals(monthlypaymentvaluedb, TypeOfRateVO.getInstance().getMonthlyPayment(), 0.0,
                    "Monthly payment is not matching to the calculated amount for 2 years");

            // TO Check the Select Button
            QAFExtendedWebElement select = new QAFExtendedWebElement(
                    "//*[@id='app']/div/div[1]/div[2]/div[7]/div[1]/button");
            if (!select.verifyPresent())
                throw new AssertionError("Couldn't find select button");

        } else if (expectedText.contentEquals("3")) {
            QAFExtendedWebElement threeyears = new QAFExtendedWebElement(
                    "//*[@id='app']/div/div[1]/div[2]/div[7]/div[2]/div[1]");
            String color = threeyears.getCssValue("background-color");
            String hex = convertRGBToHex(color);
            Assert.assertEquals("#8230df", hex);
            if (!hex.contentEquals("#8230df"))
                throw new AssertionError("2years is not highlighted with #8230df color");
            QAFExtendedWebElement rate = new QAFExtendedWebElement(
                    "//*[@id='app']/div/div[1]/div[2]/div[7]/div[2]/div[2]/span[2]");
            // System.out.println("rate"+rate.getText());
            if (!rate.verifyPresent())
                throw new AssertionError("Couldn't find Rate");
            QAFExtendedWebElement monthlypayment = new QAFExtendedWebElement(
                    "//*[@id='app']/div/div[1]/div[2]/div[7]/div[2]/div[3]/span[2]");
            if (!monthlypayment.verifyPresent())
                throw new AssertionError("Couldn't find monthly payement");
            QAFExtendedWebElement select = new QAFExtendedWebElement(
                    "//*[@id='app']/div/div[1]/div[2]/div[7]/div[1]/button");
            if (!select.verifyPresent())
                throw new AssertionError("Couldn't find select button");
            // TO Check the MonthlyPayment Value for 3 years
            QAFExtendedWebElement monthlypaymentvalue3 = new QAFExtendedWebElement(
                    "//*[@id='app']/div/div[1]/div[2]/div[7]/div[2]/div[3]/span[2]");
            if (!monthlypaymentvalue3.verifyPresent())
                throw new AssertionError("Couldn't find monthly payementvalue for 3 years ");
            String monthlypaymentvaluestr3 = monthlypaymentvalue3.getText();
            Double monthlypaymentvaluedb3 = Utility.convertCurrencyToDouble.apply(monthlypaymentvaluestr3);
            TypeOfRateVO.getInstance().setNumberOfYears(3);
            QAFExtendedWebElement threeYearRate = new QAFExtendedWebElement(
                    "//*[@id=\"app\"]/div/div[1]/div[2]/div[7]/div[2]/div[2]/span[2]");
            String Rate= threeYearRate.getText();
            double effectiveRate = Utility.getRateFromString(Rate);
            captureValuesInRatePresentmentScreen(effectiveRate);
            TypeOfRateVO.getInstance().setRateOfInterest(effectiveRate);
            Assert.assertEquals(monthlypaymentvaluedb3, TypeOfRateVO.getInstance().getMonthlyPayment(), 0.0,
                    "Monthly payment is not matching to the calculated amount for 3 years");

        } else if (expectedText.contentEquals("4")) {
            QAFExtendedWebElement fouryears = new QAFExtendedWebElement(
                    "//*[@id='app']/div/div[1]/div[2]/div[7]/div[3]/div[1]");
            String color = fouryears.getCssValue("background-color");
            String hex = convertRGBToHex(color);
            Assert.assertEquals("#8230df", hex);
            if (!hex.contentEquals("#8230df"))
                throw new AssertionError("2years is not highlighted with #8230df color");
            QAFExtendedWebElement rate = new QAFExtendedWebElement(
                    "//*[@id='app']/div/div[1]/div[2]/div[7]/div[2]/div[3]/span[2]");
            // System.out.println("rate"+rate.getText());
            if (!rate.verifyPresent())
                throw new AssertionError("Couldn't find Rate");
            QAFExtendedWebElement monthlypayment = new QAFExtendedWebElement(
                    "//*[@id='app']/div/div[1]/div[2]/div[7]/div[3]/div[3]/span[2]");
            if (!monthlypayment.verifyPresent())
                throw new AssertionError("Couldn't find monthly payement");
            QAFExtendedWebElement select = new QAFExtendedWebElement(
                    "//*[@id='app']/div/div[1]/div[2]/div[7]/div[3]/button");
            if (!select.verifyPresent())
                throw new AssertionError("Couldn't find select button");
            // TO Check the MonthlyPayment Value for 4 years
            QAFExtendedWebElement monthlypaymentvalue4 = new QAFExtendedWebElement(
                    "//*[@id='app']/div/div[1]/div[2]/div[7]/div[3]/div[3]/span[2]");
            if (!monthlypaymentvalue4.verifyPresent())
                throw new AssertionError("Couldn't find monthly payementvalue for 4 years ");
            String monthlypaymentvaluestr4 = monthlypaymentvalue4.getText();
            Double monthlypaymentvaluedb4 = Utility.convertCurrencyToDouble.apply(monthlypaymentvaluestr4);
            TypeOfRateVO.getInstance().setNumberOfYears(4);
            QAFExtendedWebElement fourYearRate = new QAFExtendedWebElement(
                    "//*[@id=\"app\"]/div/div[1]/div[2]/div[7]/div[3]/div[2]/span[2]");
            String Rate= fourYearRate.getText();
            double effectiveRate = Utility.getRateFromString(Rate);
            captureValuesInRatePresentmentScreen(effectiveRate);
            TypeOfRateVO.getInstance().setRateOfInterest(effectiveRate);
            Assert.assertEquals(monthlypaymentvaluedb4, TypeOfRateVO.getInstance().getMonthlyPayment(), 0.0,
                    "Monthly payment is not matching to the calculated amount for 4 years");

        } else if (expectedText.contentEquals("5")) {
            QAFExtendedWebElement fouryears = new QAFExtendedWebElement(
                    "//*[@id='app']/div/div[1]/div[2]/div[7]/div[4]/div[1]");
            String color = fouryears.getCssValue("background-color");
            String hex = convertRGBToHex(color);
            Assert.assertEquals("#8230df", hex);
            if (!hex.contentEquals("#8230df"))
                throw new AssertionError("2years is not highlighted with #8230df color");
            QAFExtendedWebElement rate = new QAFExtendedWebElement(
                    "//*[@id='app']/div/div[1]/div[2]/div[7]/div[4]/div[2]/span[2]");
            // System.out.println("rate"+rate.getText());
            if (!rate.verifyPresent())
                throw new AssertionError("Couldn't find Rate");
            QAFExtendedWebElement monthlypayment = new QAFExtendedWebElement(
                    "//*[@id='app']/div/div[1]/div[2]/div[7]/div[4]/div[3]/span[2]");
            if (!monthlypayment.verifyPresent())
                throw new AssertionError("Couldn't find monthly payement");
            QAFExtendedWebElement select = new QAFExtendedWebElement(
                    "//*[@id='app']/div/div[1]/div[2]/div[7]/div[4]/button");
            if (!select.verifyPresent())
                throw new AssertionError("Couldn't find select button");
            // TO Check the MonthlyPayment Value for 5 years
            QAFExtendedWebElement monthlypaymentvalue5 = new QAFExtendedWebElement(
                    "//*[@id='app']/div/div[1]/div[2]/div[7]/div[4]/div[3]/span[2]");
            if (!monthlypaymentvalue5.verifyPresent())
                throw new AssertionError("Couldn't find monthly payementvalue for 5 years ");
            String monthlypaymentvaluestr5 = monthlypaymentvalue5.getText();
            Double monthlypaymentvaluedb5 = Utility.convertCurrencyToDouble.apply(monthlypaymentvaluestr5);
            TypeOfRateVO.getInstance().setNumberOfYears(5);
            QAFExtendedWebElement fiveYearRate = new QAFExtendedWebElement(
                    "//*[@id=\"app\"]/div/div[1]/div[2]/div[7]/div[4]/div[2]/span[2]");
            String Rate= fiveYearRate.getText();
            double effectiveRate = Utility.getRateFromString(Rate);
            captureValuesInRatePresentmentScreen(effectiveRate);
            TypeOfRateVO.getInstance().setRateOfInterest(effectiveRate);
            Assert.assertEquals(monthlypaymentvaluedb5, TypeOfRateVO.getInstance().getMonthlyPayment(), 0.0,
                    "Monthly payment is not matching to the calculated amount for 5 years");

        }
    }

    @When("^click on the select button in \"([^\"]*)\" in rate Presentation$")
    public void clickontheselectbuttoninyearsinratePresentation(String expectedText) throws Throwable {
        if (expectedText.contentEquals("2 year")) {
            QAFExtendedWebElement twoyears = new QAFExtendedWebElement(
                    "//*[@id=\"app\"]/div/div[1]/div[2]/div[7]/div[1]/button[2]");
          //*[@id="app"]/div/div[1]/div[2]/div[7]/div[1]/button[2]
            if (!twoyears.verifyPresent())
                throw new AssertionError("Couldn't find 2 years button");
            twoyears.click();
        } else if (expectedText.contentEquals("3 year")) {
            QAFExtendedWebElement threeyears = new QAFExtendedWebElement(
                    "//*[@id=\"app\"]/div/div[1]/div[2]/div[7]/div[2]/button[2]");
            if (!threeyears.verifyPresent())
                throw new AssertionError("Couldn't find 3 years button ");
            threeyears.click();

        } else if (expectedText.contentEquals("4 year")) {
            QAFExtendedWebElement fouryears = new QAFExtendedWebElement(
                    "//*[@id=\"app\"]/div/div[1]/div[2]/div[7]/div[3]/button[2]");
            if (!fouryears.verifyPresent())
                throw new AssertionError("Couldn't find 4 years button ");
            fouryears.click();

        } else if (expectedText.contentEquals("5 year")) {
            QAFExtendedWebElement fiveyears = new QAFExtendedWebElement(
                    "//*[@id=\"app\"]/div/div[1]/div[2]/div[7]/div[4]/button[2]");
            if (!fiveyears.verifyPresent())
                throw new AssertionError("Couldn't find 5 years button ");
            fiveyears.click();

        }

    }

    @Then("^User should navigate to \"([^\"]*)\"$")
    public void UsershouldnavigatetoLockandHoldyourratetosecureitfor90days(String expectedText) throws Throwable {
        QAFExtendedWebElement lockanandhold = new QAFExtendedWebElement("//*[@id='app']/div/div[1]/div[2]/div[2]/h2");
        if (!lockanandhold.verifyText("Lock & Hold your rate to secure it for 90 days"))
            throw new AssertionError("Couldn't find Lock & Hold your rate to secure it for 90 days!");
        Assert.assertEquals(lockanandhold.getText(), expectedText,
                "Couldn't find Lock & Hold your rate to secure it for 90 days");
    }

    //  Rate_Presentation_009
    @When("^Verify Rate and Payment amount should be displayed for 5 year Variable rate product$")
    public void Verify_Rate_and_Payment_amount_should_be_displayed_for_5_year_Variable_rate_product() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        QAFExtendedWebElement fiveyearsvariable = new QAFExtendedWebElement(
                "//*[@id=\"app\"]/div/div[1]/div[2]/div[7]");
        if (!fiveyearsvariable.verifyPresent())
            throw new AssertionError("Couldn't find 5 years button");
        // fiveyearsvariable.click();
    }

    @Then("^5 years variable should be highlighted with Rate Monthly payment and select button should be displayed$")
    public void five_years_variable_should_be_highlighted_Rate_Monthly_with_payment_and_select_button_should_be_displayed()
            throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        QAFExtendedWebElement fiveyears = new QAFExtendedWebElement(
                "//*[@id=\"app\"]/div/div[1]/div[2]/div[7]/div/div[1]");
        String color = fiveyears.getCssValue("background-color");
        String hex = Utility.convertRGBToHex(color);
        System.out.println("Color="+color+"HEX="+hex);
        Assert.assertEquals("#8230df", hex);
        if (!hex.contentEquals("#8230df"))
            throw new AssertionError("2years is not highlighted with #8230df color");
        QAFExtendedWebElement rate = new QAFExtendedWebElement(
                "//*[@id=\"app\"]/div/div[1]/div[2]/div[7]/div/div[2]/span[2]/span[2]");
        // System.out.println("rate"+rate.getText());
        if (!rate.verifyPresent())
            throw new AssertionError("Couldn't find Rate");
        QAFExtendedWebElement monthlypayment = new QAFExtendedWebElement(
                "//*[@id=\"app\"]/div/div[1]/div[2]/div[7]/div/div[3]/span[2]");
        if (!monthlypayment.verifyPresent())
            throw new AssertionError("Couldn't find monthly payement");
        QAFExtendedWebElement select = new QAFExtendedWebElement(
                "//*[@id=\"app\"]/div/div[1]/div[2]/div[7]/div/button");
        if (!select.verifyPresent())
            throw new AssertionError("Couldn't find select button");
    }

    @When("^click on the select button in 5 years variable in rate Presentation")
    public void click_on_the_select_button_in_5_years_variable_in_rate_Presentation() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        QAFExtendedWebElement fiveyearsvariable = new QAFExtendedWebElement(
                "//*[@id=\"app\"]/div/div[1]/div[2]/div[7]/div/button[2]");
        if (!fiveyearsvariable.verifyPresent())
            throw new AssertionError("Couldn't find 5 years button");
        fiveyearsvariable.click();
        TypeOfRateVO.getInstance().setNumberOfYears(5);
    }

    //  Rate_Presentation_010
        /*@Given("^Customer should login and navigates to Rate Presentation$")
        public void customerShouldLoginAndNavigatesToeRatePresentation() throws Throwable {
            // Write code here that turns the phrase above into concrete actions
            webDriver = new WebDriverTestBase().getDriver();
            webDriver.get(ConfigurationUtils.getBaseBundle().getPropertyValue("env.baseurl"));
            webDriver.manage().window().maximize();
            QAFExtendedWebElement buttonContinue = new QAFExtendedWebElement("ehome.rate.continue.button");
            buttonContinue.click();
            Actions action = new Actions(webDriver);
            WebDriverWait wait = new WebDriverWait(webDriver, 10);
            QAFExtendedWebElement typeofrate = new QAFExtendedWebElement("ehome.typeofrate.header");
            if (!typeofrate.verifyText("What type of rate are you looking for?"))
                throw new AssertionError("Not able to launch what type of rate page");
            QAFExtendedWebElement selectVariable = new QAFExtendedWebElement("ehome.typeofrate.selectvariable.radio");
            selectVariable.click();
        }

        @When("^Click on 2years in What mortgage term are you looking for screen page$")
        public void Click_on_2years_in_What_mortgage_term_are_you_looking_for_screen_page() throws Throwable {
            // Write code here that turns the phrase above into concrete actions
            QAFExtendedWebElement twoyears = new QAFExtendedWebElement(
                    "//*[@id='app']/div/div[1]/div[1]/section/div[3]/div/fieldset/div/span[1]/label");
            if (!twoyears.verifyPresent())
                throw new AssertionError("Couldn't find 2 years button");
            twoyears.click();
        }

        @Then("^User should navigate to rate Presentation screen$")
        public void User_should_navigate_to_rate_Presentation_screen() throws Throwable {
            // Write code here that turns the phrase above into concrete actions
            QAFExtendedWebElement header = new QAFExtendedWebElement("//*[@id='app']/div/div[1]/div[2]/div[2]/h2");
            if (!header.verifyText("Choose from these online exclusive mortgage offers we have just for you!"))
                throw new AssertionError(
                        "Couldn't find Choose from these online exclusive mortgage offers we have just for you!");

        }

        @When("^Verify Rate and Payment amount should be displayed for 2 year fixed rate product$")
        public void Verify_Rate_and_Payment_amount_should_be_displayed_for_2_year_fixed_rate_product() throws Throwable {
            // Write code here that turns the phrase above into concrete actions
            QAFExtendedWebElement twoyears = new QAFExtendedWebElement(
                    "//*[@id='app']/div/div[1]/div[2]/div[7]/div[1]/div[1]/span[1]");
            if (!twoyears.verifyPresent())
                throw new AssertionError("Couldn't find 2 years button");
            System.out.println("2 years" + twoyears.getText());
            // twoyears.click();
        }

        @Then("^2 years should be highlighted with Rate Monthly payment and select button should be displayed$")
        public void Rate_Monthly_payment_and_select_button_should_be_displayed() throws Throwable {
            // Write code here that turns the phrase above into concrete actions
            QAFExtendedWebElement twoyears = new QAFExtendedWebElement(
                    "//*[@id='app']/div/div[1]/div[2]/div[7]/div[1]/div[1]");
            String color = twoyears.getCssValue("background-color");
            String hex = convertRGBToHex(color);
            Assert.assertEquals("#8230df", hex);
            if (!hex.contentEquals("#8230df"))
                throw new AssertionError("2years is not highlighted with #8230df color");
            QAFExtendedWebElement rate = new QAFExtendedWebElement(
                    "//*[@id='app']/div/div[1]/div[2]/div[7]/div[1]/div[2]/span[2]");
            // System.out.println("rate"+rate.getText());
            if (!rate.verifyPresent())
                throw new AssertionError("Couldn't find Rate");
            QAFExtendedWebElement monthlypayment = new QAFExtendedWebElement(
                    "//*[@id='app']/div/div[1]/div[2]/div[7]/div[1]/div[3]/span[2]");
            if (!monthlypayment.verifyPresent())
                throw new AssertionError("Couldn't find monthly payement");
            QAFExtendedWebElement select = new QAFExtendedWebElement(
                    "//*[@id='app']/div/div[1]/div[2]/div[7]/div[1]/button");
            if (!select.verifyPresent())
                throw new AssertionError("Couldn't find select button");

        }

        @When("^click on the select button in 2 years in rate Presentation$")
        public void click_on_the_select_button_in_2_years_in_rate_Presentation() throws Throwable {
            // Write code here that turns the phrase above into concrete actions
            QAFExtendedWebElement twoyears = new QAFExtendedWebElement(
                    "//*[@id='app']/div/div[1]/div[2]/div[7]/div[1]/div[1]");
            if (!twoyears.verifyPresent())
                throw new AssertionError("Couldn't find 2 years button");
            twoyears.click();
        }

        @Then("^User should navigate to Lock and hold screen$")
        public void User_should_navigate_to_Lock_and_hold_screen() throws Throwable {
            // Write code here that turns the phrase above into concrete actions
            QAFExtendedWebElement lockanandhold = new QAFExtendedWebElement("//*[@id='app']/div/div[1]/div[2]/div[2]/h2");
            if (!lockanandhold.verifyText("Lock & Hold your rate to secure it for 90 days"))
                throw new AssertionError("Couldn't find Lock & Hold your rate to secure it for 90 days!");

        }
        @When("^Click on the Back button rate Presentation screen$")
        public void ClickontheBackbuttonratePresentationscreen() throws Throwable {
            // Write code here that turns the phrase above into concrete actions
            QAFExtendedWebElement backbutton = new QAFExtendedWebElement("ehome.ratepresentation.back.button");
            if (!backbutton.verifyPresent())
                throw new AssertionError("Couldn't find back button in rate Presentation");
            backbutton.click();
            Thread.sleep(3000);
        }*/

    @When("^Click on the Back button navigation for the \"([^\"]*)\" product rate Presentation$")
    public void click_on_the_Back_button_navigation_from_the_fixed_product_rate_Presentation(String expectedText1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        if (expectedText1.contentEquals("fixed")) {
            QAFExtendedWebElement backbutton = new QAFExtendedWebElement("ehome.ratepresentation.back.button");
            if (!backbutton.verifyPresent())
                throw new AssertionError("Couldn't find back button in rate Presentation");
            backbutton.click();
            Thread.sleep(3000);
        } else if (expectedText1.contentEquals("variable")) {
            QAFExtendedWebElement backbutton = new QAFExtendedWebElement("ehome.ratepresentation.back.button");
            if (!backbutton.verifyPresent())
                throw new AssertionError("Couldn't find back button in rate Presentation");
            backbutton.click();

        }
    }

    @When("^Click on the Back button navigation for the variable product rate Presentation$")
    public void click_on_the_Back_button_navigation_from_the_variable_product_rate_Presentation() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        QAFExtendedWebElement backbutton = new QAFExtendedWebElement("ehome.ratepresentation.back.button");
        if (!backbutton.verifyPresent())
            throw new AssertionError("Couldn't find back button in rate Presentation");
        backbutton.click();
    }

    @Then("^It should navigate to What mortgage type are you looking for screen page$")
    public void It_should_navigate_to_What_mortgage_type_are_you_looking_for_screen_page() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        Thread.sleep(2000);
        QAFExtendedWebElement typeofrate = new QAFExtendedWebElement("ehome.typeofrate.header");
        Assert.assertEquals(typeofrate.getText(), "What mortgage term are you looking for?","Could not find What mortgage term are you looking for?");
    }

    //  Rate_Presentation_011
    @When("^Verify Closed Term and More on prepayment in Rate presentation Screen$")
    public void Verify_Closed_Term_and_More_on_prepayment_in_Rate_presentation_Screen() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        QAFExtendedWebElement Closedterm = new QAFExtendedWebElement(
                "//*[@id='app']/div/div[1]/div[3]/div/div[1]/div/h3");
        if (!Closedterm.verifyPresent())
            throw new AssertionError("Couldn't find Close Term text");
        QAFExtendedWebElement ClosedtermContent = new QAFExtendedWebElement(
                "//*[@id='app']/div/div[1]/div[3]/div/div[1]/div/p");
        if (!ClosedtermContent.verifyPresent())
            throw new AssertionError("Couldn't find Close Term content");
        QAFExtendedWebElement Moreonprepayment = new QAFExtendedWebElement(
                "//*[@id='app']/div/div[1]/div[3]/div/div[1]/div/div/button/span");
        if (!ClosedtermContent.verifyPresent())
            throw new AssertionError("Couldn't find More on prepayment text");
        // *[@id='app']/div/div[1]/div[3]/div/div[1]/div/div/button
        QAFExtendedWebElement Moreonprepaymentinformation = new QAFExtendedWebElement(
                "//*[@id='app']/div/div[1]/div[3]/div/div[1]/div/div/button");
        if (!ClosedtermContent.verifyPresent())
            throw new AssertionError("Couldn't find More on prepayment information icon");
        Moreonprepaymentinformation.click();
        QAFExtendedWebElement Moreonprepaymentinformationcontent = new QAFExtendedWebElement(
                "//*[@id=\"closed-terms\"]/span/p");
        if (!ClosedtermContent.verifyPresent())
            throw new AssertionError("Couldn't find More on prepayment information icon content");
        QAFExtendedWebElement Moreonprepaymentinformationcontentclose = new QAFExtendedWebElement(
                "//*[@id=\"closed-terms\"]/button");
        if (!ClosedtermContent.verifyPresent())
            throw new AssertionError("Couldn't find More on prepayment information icon content close");

    }

    @Then("^Closed Term content and More on prepaymentcontent should be displayed in Rate presentation Screen$")
    public void Closed_Term_content_and_More_on_prepaymentcontent_should_be_displayed_in_Rate_presentation_Screen()
            throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        QAFExtendedWebElement Closedterm = new QAFExtendedWebElement(
                "//*[@id='app']/div/div[1]/div[3]/div/div[1]/div/h3");
        if (!Closedterm.verifyPresent())
            throw new AssertionError("Couldn't find Close Term text");
        QAFExtendedWebElement ClosedtermContent = new QAFExtendedWebElement(
                "//*[@id='app']/div/div[1]/div[3]/div/div[1]/div/p");
        if (!ClosedtermContent.verifyPresent())
            throw new AssertionError("Couldn't find Close Term content");
        QAFExtendedWebElement Moreonprepayment = new QAFExtendedWebElement(
                "//*[@id='app']/div/div[1]/div[3]/div/div[1]/div/div/button/span");
        if (!ClosedtermContent.verifyPresent())
            throw new AssertionError("Couldn't find More on prepayment text");
        // *[@id='app']/div/div[1]/div[3]/div/div[1]/div/div/button
        QAFExtendedWebElement Moreonprepaymentinformation = new QAFExtendedWebElement(
                "//*[@id='app']/div/div[1]/div[3]/div/div[1]/div/div/button");
        if (!ClosedtermContent.verifyPresent())
            throw new AssertionError("Couldn't find More on prepayment information icon");
        Moreonprepaymentinformation.click();
        QAFExtendedWebElement Moreonprepaymentinformationcontent = new QAFExtendedWebElement(
                "//*[@id=\"closed-terms\"]/span/p");
        if (!ClosedtermContent.verifyPresent())
            throw new AssertionError("Couldn't find More on prepayment information icon content");
        QAFExtendedWebElement Moreonprepaymentinformationcontentclose = new QAFExtendedWebElement(
                "//*[@id=\"closed-terms\"]/button");
        if (!ClosedtermContent.verifyPresent())
            throw new AssertionError("Couldn't find More on prepayment information icon content close");
    }

    //  Rate_Presentation_0012
    @When("^Verify Rate disclaimer and Payment disclaimer in Rate presentation Screen$")
    public void Verify_Rate_disclaimer_and_Payment_disclaimer_in_Rate_presentation_Screen() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        QAFExtendedWebElement Ratedisclaimer = new QAFExtendedWebElement(
                "//*[@id=\"app\"]/div/div[1]/div[4]/div/div/div/div[1]/button/p");
        if (!Ratedisclaimer.verifyPresent())
            throw new AssertionError("Couldn't find Rate disclaimer");
        QAFExtendedWebElement Ratedisclaimerinformation = new QAFExtendedWebElement("//*[@id=\"Rate\"]/p");
        if (!Ratedisclaimerinformation.verifyPresent())
            throw new AssertionError("Couldn't find Rate disclaimer information");
        QAFExtendedWebElement Ratedisclaimerinformationbutton = new QAFExtendedWebElement(
                "//*[@id=\"app\"]/div/div[1]/div[4]/div/div/div/div[1]/button");
        Ratedisclaimerinformationbutton.click();
        //        QAFExtendedWebElement Ratedisclaimerinformationcontent = new QAFExtendedWebElement(
        //                "//*[@id='app']/div/div[1]/div[4]/div/div/div/div[1]/div[2]/p");
        //        if (!Ratedisclaimerinformationcontent.verifyPresent())
        //            throw new AssertionError("Couldn't find Rate disclaimer information content");

        QAFExtendedWebElement Payment = new QAFExtendedWebElement(
                "//*[@id='app']/div/div[1]/div[4]/div/div/div/div[2]/div[1]/p");
        if (!Ratedisclaimer.verifyPresent())
            throw new AssertionError("Couldn't find Payment text");
        QAFExtendedWebElement Paymentinformation = new QAFExtendedWebElement(
                "//*[@id='app']/div/div[1]/div[4]/div/div/div/div[2]/div[1]/i");
        if (!Ratedisclaimer.verifyPresent())
            throw new AssertionError("Couldn't find Payment information ");
        QAFExtendedWebElement Paymentinformationcontent = new QAFExtendedWebElement(
                "//*[@id='app']/div/div[1]/div[4]/div/div/div/div[2]/div[2]/p");
        if (!Ratedisclaimer.verifyPresent())
            throw new AssertionError("Couldn't find Payment information ");

    }

    @Then("^Rate disclaimer content and Payment disclaimer content should be displayed$")
    public void Rate_disclaimer_content_and_Payment_disclaimer_content_should_be_displayed() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        QAFExtendedWebElement Ratedisclaimer = new QAFExtendedWebElement(
                "//*[@id='app']/div/div[1]/div[4]/div/div/div/div[1]/div[1]/p");
        if (!Ratedisclaimer.verifyPresent())
            throw new AssertionError("Couldn't find Rate disclaimer");
        QAFExtendedWebElement Ratedisclaimerinformation = new QAFExtendedWebElement(
                "//*[@id='app']/div/div[1]/div[4]/div/div/div/div[1]/div[1]/i");
        if (!Ratedisclaimerinformation.verifyPresent())
            throw new AssertionError("Couldn't find Rate disclaimer information");
        QAFExtendedWebElement Ratedisclaimerinformationbutton = new QAFExtendedWebElement(
                "//*[@id='app']/div/div[1]/div[4]/div/div/div/div[1]/div[1]/i");
        // Ratedisclaimerinformationbutton.click();
        QAFExtendedWebElement Ratedisclaimerinformationcontent = new QAFExtendedWebElement(
                "//*[@id='app']/div/div[1]/div[4]/div/div/div/div[1]/div[2]/p");
        if (!Ratedisclaimerinformationcontent.verifyPresent())
            throw new AssertionError("Couldn't find Rate disclaimer information content");

        QAFExtendedWebElement Payment = new QAFExtendedWebElement(
                "//*[@id='app']/div/div[1]/div[4]/div/div/div/div[2]/div[1]/p");
        if (!Ratedisclaimer.verifyPresent())
            throw new AssertionError("Couldn't find Payment text");
        QAFExtendedWebElement Paymentinformation = new QAFExtendedWebElement(
                "//*[@id='app']/div/div[1]/div[4]/div/div/div/div[2]/div[1]/i");
        if (!Ratedisclaimer.verifyPresent())
            throw new AssertionError("Couldn't find Payment information ");
        QAFExtendedWebElement Paymentinformationcontent = new QAFExtendedWebElement(
                "//*[@id='app']/div/div[1]/div[4]/div/div/div/div[2]/div[2]/p");
        if (!Ratedisclaimer.verifyPresent())
            throw new AssertionError("Couldn't find Payment information ");
    }

    // -------------------------------------------------------------
    public void captureValuesInRatePresentmentScreen(double effectiveRate) {
        RatePresentment ratePresentment = new RatePresentment();
        double purchasePrice = ratePresentment.getPurchasePrice();
        TypeOfRateVO.getInstance().setPurchasePrice(purchasePrice);

        double downPayment = ratePresentment.getDownPayment();
        TypeOfRateVO.getInstance().setDownPayment(downPayment);
        
        double loanvalue = Utility.convertCurrencyToDouble.apply(loanrequestedvalue.getText());
        double Purchasepricedb = Utility.convertCurrencyToDouble.apply(Purchasepricevalue.getText());
        double downpaymentdb = Utility.convertCurrencyToDouble.apply(downpaymentvalue.getText());
      //  Double CalculatedLoanRequest = calculateLoanRequested.apply(Purchasepricedb, downpaymentdb);
        System.out.println("loanvalue+++++++++"+ loanvalue+"Purchasepricedb+++++++++" +Purchasepricedb+ "downpaymentdb+++++++++++ " + downpaymentdb);
        double default_Insurance = Utility.getDefaultInsuranceValue("src\\main\\resources\\data\\eHomeTestData.xlsx", "DefaultInsurance", Purchasepricedb, downpaymentdb);
      
       // double loanRequested = BusinessCalculations.calculateLoanRequested(purchasePrice, downPayment,default_Insurance);
        double loanRequested = loanvalue;
        TypeOfRateVO.getInstance().setLoanRequested(loanRequested);

        boolean isLessThan20Percent = BusinessCalculations.isDownPaymentLessThan20Percent(purchasePrice, downPayment);
        TypeOfRateVO.getInstance().setLessThan20Percent(isLessThan20Percent);

        int amortizationPeriod = ratePresentment.getAmortizationPeriod();
        TypeOfRateVO.getInstance().setAmortizationPeriodYears(amortizationPeriod);

        PaymentScheduleEnum paymentSchedule = ratePresentment.getPaymentSchedule();
        int paymentScheduleint = ratePresentment.getPaymentSchedule().getNumberOfMonthlyPayments();
        TypeOfRateVO.getInstance().setPaymentScheduleFrequency(paymentScheduleint);

        double interestFactor = BusinessCalculations.getInterestFactor(effectiveRate);
        double weeklypaymentschedule = BusinessCalculations.getBiWeeklyPayment(loanRequested, interestFactor,
                amortizationPeriod);
        TypeOfRateVO.getInstance().setWeeklypayment(weeklypaymentschedule);

        double biWeeklyPayment = BusinessCalculations.getBiWeeklyPayment(loanRequested, interestFactor,
                amortizationPeriod);
        TypeOfRateVO.getInstance().setBiWeeklyPayment(biWeeklyPayment);

        double monthlyPayment = BusinessCalculations.getMonthlyPayment(loanRequested, interestFactor,
                amortizationPeriod);
        TypeOfRateVO.getInstance().setMonthlyPayment(monthlyPayment);
    }

}


