package com.scotiabank.ehome.ui.steps.stage4;
import com.qmetry.qaf.automation.step.QAFTestStepProvider;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebDriver;
import com.quantum.java.pages.ExtentReportHelper;
import com.quantum.utils.ConfigurationUtils;
import com.scotiabank.ehome.ui.steps.Common;
import com.scotiabank.ehome.ui.steps.CommonAppMethodsAssetLiabilities;
import com.scotiabank.ehome.ui.steps.CommonAppMethodsEmployment;
import com.scotiabank.ehome.ui.steps.CommonApplicationMethods;
import com.scotiabank.ehome.ui.steps.Utility;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.support.ui.WebDriverWait;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;

import java.util.Map;
import java.util.concurrent.TimeUnit;
import static com.scotiabank.ehome.ui.steps.Utility.*;

@QAFTestStepProvider

public class OtherIncomeSourceDetailsforEmployed {
	public static WebDriverWait wait=Utility.getWait();
	  static String curDir = System.getProperty("user.dir");
	  static String strfullPathToFile = curDir + "\\src\\main\\resources\\data\\eHomeTestData.xlsx"; // File Path
		
	  static String sheetStage04_InputData ="Stage04_Employment_InputData";
	  static String sheetStage04_ExpectedData ="Stage04_Employment_ExpectedData";
	  static String sheetStage05_ExpectedData ="Stage05_AsetLiblty_ExpectedData";
	  
	  //String strtestCaseID = "OtherSourcesOfIncomeDetails-Employed-TC-014";
	  
	  String strtestCaseID = Utility.getScenarioID();
		  
	  @Then("^Verify 'Other Sources Of Income Details' Screen and presence of all objects on 'Other Sources Of Income Details' Screen$")
		public void Verify_Other_Sources_Of_Income_Details_Screen_and_presence_of_all_objects_on_Other_Sources_Of_Income_Details_Screen() throws Throwable {
		  
		  Map<String, String> Stage04_ExpectedData =  Utility.readTestData(strfullPathToFile, sheetStage04_ExpectedData,strtestCaseID);
		  
		  String strSrcOfIncDetails_Header_ExpectedTitle	= Stage04_ExpectedData.get("Other_Srcs_income_details_Title");
		  Common.continueButtonClicked();
		  if (strtestCaseID.contains("CoApp")){
		  	Thread.sleep(500);
			  Utility.verifyIsObjectPresent("ehome.otherSrcsOfIncDetails.MaternalPaternalLeave", "Maternity/Parental Leave Button");
			  Utility.verifyIsObjectPresent("ehome.coAppOtherIncomeSrcDetails.Title", "Title of coApp Screen");

		  }
		  else
		  {
			  Utility.verifyIsTextPresent("ehome.otherIncomeSrcDetails.Title", "Heading Centre Text", strSrcOfIncDetails_Header_ExpectedTitle);
		  }
		  Utility.verifyIsObjectPresent("ehome.otherSrcsOfIncDetails.ChildSupport", "ChildSupport Details Text Box");
		  Utility.verifyIsObjectPresent("ehome.otherSrcsOfIncDetails.Commission", "Commission Details Text Box");
		  Utility.verifyIsObjectPresent("ehome.otherSrcsOfIncDetails.Investments", "Investments Details Text Box");
		  Utility.verifyIsObjectPresent("ehome.otherSrcsOfIncDetails.PartTimeWork", "PartTimeWork Details Text Box");
		  Utility.verifyIsObjectPresent("ehome.otherSrcsOfIncDetails.PensionDisability", "PensionDisability Details Text Box");
		  Utility.verifyIsObjectPresent("ehome.otherSrcsOfIncDetails.RIFLIF", "RIFLIF Details Text Box");
		  Utility.verifyIsObjectPresent("ehome.otherSrcsOfIncDetails.SeasonalWork", "SeasonalWork Details Text Box");
		  Utility.verifyIsObjectPresent("ehome.otherSrcsOfIncDetails.SpousalSupport", "SpousalSupport Details Text Box");
		  Utility.verifyIsObjectPresent("ehome.otherIncomeSrcDetails.Continue", "Continue");
		  Utility.verifyIsObjectPresent("ehome.otherIncomeSrcDetails.Back", "Back");

		  }
	
		@Then("^Verify 'Other Sources Of Income' Screen when Click on 'Back' button on 'Other Sources Of Income Details' Screen$")
		public void Verify_OtherSourcesOfIncome_Screen_when_Click_on_Back_button_on_Other_Sources_Of_Income_Details_Screen() throws Throwable {

			  Common.continueButtonClicked();
			  Thread.sleep(500);
			  Common.backButtonClicked();
			if (strtestCaseID.contains("CoApp")){
				String Title = Utility.getDriver().findElement("ehome.coAppOtherSrcsOfIncome.SrcOfIncomeTitle").getText();
				if (!(Title.contains("other sources of income")))
					throw new AssertionError("Title is not correct");
			}
			else{
				Map<String, String> Stage04_ExpectedData =  Utility.readTestData(strfullPathToFile, sheetStage04_ExpectedData,strtestCaseID);
				String strSrcOfInc_Header_ExpectedTitle	= Stage04_ExpectedData.get("Emplmt_Srcs_Of_Income_Title");
				Utility.clickObject("ehome.otherIncomeSrcDetails.Back", "Back Button in Other Income Source detail");
				Utility.verifyIsTextPresent("ehome.otherSrcsOfIncome.SrcOfIncomeTitle", "Heading Centre Text", strSrcOfInc_Header_ExpectedTitle);

			}

			  }
		
		
		@Then("^Enter 'Source of income' and Select 'Continue' on 'Other Sources Of Income Details' Screen$")
		public void Enter_Sourceofincome_and_Select_Continue_on_Other_Sources_Of_Income_Details_Screen() throws Throwable {
			
			Map<String, String> Stage04_InputData =  Utility.readTestData(strfullPathToFile, sheetStage04_InputData,strtestCaseID);
			String strChildSupport_Input = Stage04_InputData.get("EmpOtherSrcsOfIncome_ChildSupport");
			String strCommission_Input = Stage04_InputData.get("EmpOtherSrcsOfIncome_Commission");
			String strInvestments_Input = Stage04_InputData.get("EmpOtherSrcsOfIncome_Investments");
			String strPartTimeWork_Input = Stage04_InputData.get("EmpOtherSrcsOfIncome_PartTimeWork");
			String strPensionDisability_Input = Stage04_InputData.get("EmpOtherSrcsOfIncome_PensionDisability");
			String strRIFLIF_Input = Stage04_InputData.get("EmpOtherSrcsOfIncome_RIFLIF");
			String strSeasonalWork_Input = Stage04_InputData.get("EmpOtherSrcsOfIncome_SeasonalWork");
			String strSpousalSupport_Input = Stage04_InputData.get("EmpOtherSrcsOfIncome_SpousalSupport");
			
			String strChildSupport_Amt = Stage04_InputData.get("EmpOtherSrcsOfIncome_ChildSupport_Amt");
			String strCommission_Amt = Stage04_InputData.get("EmpOtherSrcsOfIncome_Commission_Amt");
			String strInvestments_Amt = Stage04_InputData.get("EmpOtherSrcsOfIncome_Investments_Amt");
			String strPartTimeWork_Amt = Stage04_InputData.get("EmpOtherSrcsOfIncome_PartTimeWork_Amt");
			String strPensionDisability_Amt = Stage04_InputData.get("EmpOtherSrcsOfIncome_PensionDisability_Amt");
			String strRIFLIF_Amt = Stage04_InputData.get("EmpOtherSrcsOfIncome_RIFLIF_Amt");
			String strSeasonalWork_Amt = Stage04_InputData.get("EmpOtherSrcsOfIncome_SeasonalWork_Amt");
			String strSpousalSupport_Amt = Stage04_InputData.get("EmpOtherSrcsOfIncome_SpousalSupport_Amt");

			Common.continueButtonClicked();
			if (strChildSupport_Input != "" && strChildSupport_Amt != "")
			{
				CommonAppMethodsEmployment.EnterAnualIncomeSourceAmount(strChildSupport_Input, strChildSupport_Amt);
			}
			if (strCommission_Input != "" && strCommission_Amt != "")
			{
				CommonAppMethodsEmployment.EnterAnualIncomeSourceAmount(strCommission_Input, strCommission_Amt);
			}
			if (strInvestments_Input != "" && strInvestments_Amt != "")
			{
				CommonAppMethodsEmployment.EnterAnualIncomeSourceAmount(strInvestments_Input, strInvestments_Amt);
			}
			if (strPartTimeWork_Input != "" && strPartTimeWork_Amt != "")
			{
				CommonAppMethodsEmployment.EnterAnualIncomeSourceAmount(strPartTimeWork_Input, strPartTimeWork_Amt);
			}
			if (strPensionDisability_Input != "" && strPensionDisability_Amt != "")
			{
				CommonAppMethodsEmployment.EnterAnualIncomeSourceAmount(strPensionDisability_Input, strPensionDisability_Amt);
			}
			if (strRIFLIF_Input != "" && strRIFLIF_Amt != "")
			{
				CommonAppMethodsEmployment.EnterAnualIncomeSourceAmount(strRIFLIF_Input, strRIFLIF_Amt);
			}
			if (strSeasonalWork_Input != "" && strSeasonalWork_Amt != "")
			{
				CommonAppMethodsEmployment.EnterAnualIncomeSourceAmount(strSeasonalWork_Input, strSeasonalWork_Amt);
			}
			if (strSpousalSupport_Input != "" && strSpousalSupport_Amt != "")
			{
				CommonAppMethodsEmployment.EnterAnualIncomeSourceAmount(strSpousalSupport_Input, strSpousalSupport_Amt);
			}
			if (strtestCaseID.contentEquals("CoAppOtherSourcesOfIncomeDetails-Employed-TC-006"))
			{
				Utility.clickObject("//*[@id='app']/div/div[1]/div[2]/div/div[1]/div[3]/button","Button");
				Thread.sleep(1000);
				Utility.sendKeys("ehome.otherSrcsOfIncDetails.MaternalPaternalLeave","3000");
			}
			Utility.clickObject("ehome.otherIncomeSrcDetails.Continue", "Continue in SourceOfIncome Details");
		}
		
		@Then("^Verify 'Err Message' when enter without 'Other Sources Of Income Details' on 'Other Sources Of Income Details' Screen$")
		public void Verify_ErrMessage_without_Details_when_Click_on_Continue_button_on_Other_Sources_Of_Income_Details_Screen() throws Throwable {
			  Map<String, String> Stage04_ExpectedData =  Utility.readTestData(strfullPathToFile, sheetStage04_ExpectedData,strtestCaseID);
			  String Other_Srcs_income_details_MandError_Msg	= Stage04_ExpectedData.get("Other_Srcs_income_details_MandError_Msg");
			  Utility.verifyIsTextPresent("//*[@id='app']/div/div[1]/div[2]/div[1]/div/div/div[2]/p", "Mandatory Error Messages", Other_Srcs_income_details_MandError_Msg);
			}
		
		
		@Then("^Verify 'Remove entire source' links on 'Other Sources Of Income Details' Screen$")
		public void Verify_Remove_entire_source_links_on_Other_Sources_Of_Income_Details_Screen() throws Throwable {
			Map<String, String> Stage04_InputData =  Utility.readTestData(strfullPathToFile, sheetStage04_InputData,strtestCaseID);
			String strChildSupport_Input = Stage04_InputData.get("EmpOtherSrcsOfIncome_ChildSupport");
			String strCommission_Input = Stage04_InputData.get("EmpOtherSrcsOfIncome_Commission");
			String strInvestments_Input = Stage04_InputData.get("EmpOtherSrcsOfIncome_Investments");
			String strPartTimeWork_Input = Stage04_InputData.get("EmpOtherSrcsOfIncome_PartTimeWork");
			String strPensionDisability_Input = Stage04_InputData.get("EmpOtherSrcsOfIncome_PensionDisability");
			String strRIFLIF_Input = Stage04_InputData.get("EmpOtherSrcsOfIncome_RIFLIF");
			String strSeasonalWork_Input = Stage04_InputData.get("EmpOtherSrcsOfIncome_SeasonalWork");
			String strSpousalSupport_Input = Stage04_InputData.get("EmpOtherSrcsOfIncome_SpousalSupport");
			
			String strChildSupport_Amt = Stage04_InputData.get("EmpOtherSrcsOfIncome_ChildSupport_Amt");
			String strCommission_Amt = Stage04_InputData.get("EmpOtherSrcsOfIncome_Commission_Amt");
			String strInvestments_Amt = Stage04_InputData.get("EmpOtherSrcsOfIncome_Investments_Amt");
			String strPartTimeWork_Amt = Stage04_InputData.get("EmpOtherSrcsOfIncome_PartTimeWork_Amt");
			String strPensionDisability_Amt = Stage04_InputData.get("EmpOtherSrcsOfIncome_PensionDisability_Amt");
			String strRIFLIF_Amt = Stage04_InputData.get("EmpOtherSrcsOfIncome_RIFLIF_Amt");
			String strSeasonalWork_Amt = Stage04_InputData.get("EmpOtherSrcsOfIncome_SeasonalWork_Amt");
			String strSpousalSupport_Amt = Stage04_InputData.get("EmpOtherSrcsOfIncome_SpousalSupport_Amt");

			Common.continueButtonClicked();
			
			if (strChildSupport_Input != "" && strChildSupport_Amt != "")
			{
				CommonAppMethodsEmployment.EnterAnualIncomeSourceAmount(strChildSupport_Input, strChildSupport_Amt);
				 Utility.verifyIsObjectPresent("ehome.otherSrcsOfIncDetails.ChildSupportRemove", "ChildSupport Details Remove");
			}
			if (strCommission_Input != "" && strCommission_Amt != "")
			{
				CommonAppMethodsEmployment.EnterAnualIncomeSourceAmount(strCommission_Input, strCommission_Amt);
				Utility.verifyIsObjectPresent("ehome.otherSrcsOfIncDetails.CommissionRemove", "Commission Details Remove");
			}
			if (strInvestments_Input != "" && strInvestments_Amt != "")
			{
				CommonAppMethodsEmployment.EnterAnualIncomeSourceAmount(strInvestments_Input, strInvestments_Amt);
				Utility.verifyIsObjectPresent("ehome.otherSrcsOfIncDetails.InvestmentsRemove", "Investments Details Remove");
			}
			if (strPartTimeWork_Input != "" && strPartTimeWork_Amt != "")
			{
				CommonAppMethodsEmployment.EnterAnualIncomeSourceAmount(strPartTimeWork_Input, strPartTimeWork_Amt);
				Utility.verifyIsObjectPresent("ehome.otherSrcsOfIncDetails.PartTimeWorkRemove", "PartTimeWork Details Remove");
			}
			if (strPensionDisability_Input != "" && strPensionDisability_Amt != "")
			{
				CommonAppMethodsEmployment.EnterAnualIncomeSourceAmount(strPensionDisability_Input, strPensionDisability_Amt);
				Utility.verifyIsObjectPresent("ehome.otherSrcsOfIncDetails.PensionDisabilityRemove", "PensionDisability Details Remove");
			}
			if (strRIFLIF_Input != "" && strRIFLIF_Amt != "")
			{
				CommonAppMethodsEmployment.EnterAnualIncomeSourceAmount(strRIFLIF_Input, strRIFLIF_Amt);
				Utility.verifyIsObjectPresent("ehome.otherSrcsOfIncDetails.RIFLIFRemove", "RIFLIF Details Remove");
			}
			if (strSeasonalWork_Input != "" && strSeasonalWork_Amt != "")
			{
				CommonAppMethodsEmployment.EnterAnualIncomeSourceAmount(strSeasonalWork_Input, strSeasonalWork_Amt);
				Utility.verifyIsObjectPresent("ehome.otherSrcsOfIncDetails.SeasonalWorkRemove", "SeasonalWork Details Remove");
			}
			if (strSpousalSupport_Input != "" && strSpousalSupport_Amt != "")
			{
				CommonAppMethodsEmployment.EnterAnualIncomeSourceAmount(strSpousalSupport_Input, strSpousalSupport_Amt);
				Utility.verifyIsObjectPresent("ehome.otherSrcsOfIncDetails.SpousalSupportRemove", "SpousalSupport Details Remove");
			}
			
			Utility.clickObject("ehome.otherIncomeSrcDetails.Continue", "Continue in SourceOfIncome Details");
		}
		
		
		@Then("^Verify 'Remove entire source' functionality on 'Other Sources Of Income Details' Screen$")
		public void Verify_Remove_entire_source_functionality_on_Other_Sources_Of_Income_Details_Screen() throws Throwable {
			Map<String, String> Stage04_InputData =  Utility.readTestData(strfullPathToFile, sheetStage04_InputData,strtestCaseID);
			String strChildSupport_Input = Stage04_InputData.get("EmpOtherSrcsOfIncome_ChildSupport");
			
			String strChildSupport_Amt = Stage04_InputData.get("EmpOtherSrcsOfIncome_ChildSupport_Amt");

			Common.continueButtonClicked();
			
			if (strChildSupport_Input != "" && strChildSupport_Amt != "")
			{
				CommonAppMethodsEmployment.EnterAnualIncomeSourceAmount(strChildSupport_Input, strChildSupport_Amt);
				 Utility.clickObject("ehome.otherSrcsOfIncDetails.ChildSupportRemove", "ChildSupport Details Remove");
				 Utility.clickObject("//*[@id=\"app\"]/div/div[1]/div[2]/div/div[1]/div[1]/div/div/div[2]/button[1]", "Are you Sure Button? Yes");
				 Utility.verifyIsObjectPresent("ehome.otherIncomeSrcDetails.Showothersources","Link");
			}

		}
		
		
		
		
	
}
