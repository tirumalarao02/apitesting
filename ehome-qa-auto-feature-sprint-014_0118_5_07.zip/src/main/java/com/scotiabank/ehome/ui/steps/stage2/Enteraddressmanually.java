package com.scotiabank.ehome.ui.steps.stage2;

import com.qmetry.qaf.automation.ui.webdriver.QAFWebDriver;
import com.scotiabank.ehome.ui.steps.Common;
import com.scotiabank.ehome.ui.steps.Utility;
import cucumber.api.PendingException;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.Keys;

import com.qmetry.qaf.automation.step.QAFTestStepProvider;
import com.qmetry.qaf.automation.ui.WebDriverTestBase;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebDriver;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.quantum.utils.ConfigurationUtils;


import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;


import org.testng.Assert;

@QAFTestStepProvider
public class Enteraddressmanually {
	QAFExtendedWebElement streetNumber= new QAFExtendedWebElement("ehome.enteraddressmanually.streetnumber");
	QAFExtendedWebElement streetName= new QAFExtendedWebElement("ehome.enteraddressmanually.streetname");
	QAFExtendedWebElement city= new QAFExtendedWebElement("ehome.enteraddressmanually.city");
	QAFExtendedWebElement unitnumber= new QAFExtendedWebElement("ehome.enteraddressmanually.unitnumber");
	QAFExtendedWebElement province= new QAFExtendedWebElement("ehome.enteraddressmanually.province");
	QAFExtendedWebElement postalCode= new QAFExtendedWebElement("ehome.enteraddressmanually.postalCode");
	QAFExtendedWebElement country= new QAFExtendedWebElement("ehome.enteraddressmanually.country");
	QAFExtendedWebElement countryHidden= new QAFExtendedWebElement("ehome.enteraddressmanually.countryHidden");
	QAFExtendedWebElement continueWhattypeofproperty= new QAFExtendedWebElement("ehome.enteraddressmanually.continue.button");
	QAFExtendedWebElement yournewhome= new QAFExtendedWebElement("ehome.enteraddressmanually.yournewhome");
	QAFExtendedWebElement propertyScreenHeader= new QAFExtendedWebElement("ehome.enteraddressmanually.propertyScreenHeader");

	QAFExtendedWebElement streetNumberError= new QAFExtendedWebElement("ehome.enteraddressmanually.streetnumberError");
	QAFExtendedWebElement streetNameError= new QAFExtendedWebElement("ehome.enteraddressmanually.streetnameError");
	QAFExtendedWebElement cityError= new QAFExtendedWebElement("ehome.enteraddressmanually.cityError");
	QAFExtendedWebElement provinceError= new QAFExtendedWebElement("ehome.enteraddressmanually.provinceError");
	QAFExtendedWebElement postalCodeError= new QAFExtendedWebElement("ehome.enteraddressmanually.postalCodeError");
	QAFExtendedWebElement TypeofPropertyhouseselect= new QAFExtendedWebElement("ehome.whenistheclosingdate.TypeofPropertyhouseselect");

	QAFExtendedWebDriver driver = new WebDriverTestBase().getDriver();
	WebDriverWait wait = new WebDriverWait(driver, 50000);

	String testCaseID = Utility.getScenarioID();

	@And("^Verify \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\" fields should be mandatory$")
	public void VerifyfieldsShouldBeMandatory(String datapointer, String datapointer1, String datapointer2, String datapointer3, String datapointer4) throws Throwable {

			streetNumber.click();
			streetName.click();
			wait.until(ExpectedConditions.visibilityOf(streetNumberError));
			String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_ExpectedData",testCaseID , datapointer);
			Assert.assertEquals(streetNumberError.getText(), value,"Couldn't found expected Street Number error message, 'Street Number' should be mandatory");

			city.click();
			wait.until(ExpectedConditions.visibilityOf(streetNameError));
			String value1=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_ExpectedData",testCaseID , datapointer1);
			Assert.assertEquals(streetNameError.getText(), value1,"Couldn't found expected Street Name error message, 'Street Name' should be mandatory");

			province.click();
			wait.until(ExpectedConditions.visibilityOf(cityError));
			String value2=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_ExpectedData",testCaseID , datapointer2);
			Assert.assertEquals(cityError.getText(), value2,"Couldn't found expected City error message, 'City' should be mandatory");

			postalCode.click();
			wait.until(ExpectedConditions.visibilityOf(provinceError));
			String value3=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_ExpectedData",testCaseID , datapointer3);
			Assert.assertEquals(provinceError.getText(), value3,"Couldn't found expected Province error message, 'Province' should be mandatory");

			city.click();
			wait.until(ExpectedConditions.visibilityOf(postalCodeError));
			String value4=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_ExpectedData",testCaseID , datapointer4);
			Assert.assertEquals(postalCodeError.getText(), value4,"Couldn't found expected Postal Code error message, 'Postal Code' should be mandatory");
		}

	@When("^entering text in the Street Number \"([^\"]*)\" field$")
	public void enteringTextInTheStreetNumberField(String datapointer) throws Throwable {

		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_InputData",testCaseID , datapointer);
		streetNumber.sendKeys(value);

	}

	@Then("^the 'street number' field should accept (\\d+) to (\\d+) characters$")
	public void the_street_number_field_should_accept_to_characters(int arg1, int arg2) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		if (!((streetNumber.getAttribute("value").length()>0) && (streetNumber.getText().length()<12))) {
			Thread.sleep(2000);
			throw new AssertionError("Street Number field should accept upto 11 characters");
		}
	}

	@When("^entering text in the Street Name \"([^\"]*)\" field$")
	public void enteringTextInTheStreetNameField(String datapointer) throws Throwable {

		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_InputData",testCaseID , datapointer);
		streetName.sendKeys(value);
	}

	@Then("^the 'street name' field should accept (\\d+) to (\\d+) characters\\.$")
	public void the_street_name_field_should_accept_to_characters(int arg1, int arg2) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		if (!((streetName.getAttribute("value").length()>0) && (streetName.getText().length()<28))) {
			 throw new AssertionError("Street Name field should accept upto 27 characters");
		}
	}

	@When("^entering text in the Unit Number \"([^\"]*)\" field$")
	public void enteringTextInTheUnitNumberField(String datapointer) throws Throwable {
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_InputData",testCaseID , datapointer);
		unitnumber.sendKeys(value);
	}

	@Then("^the 'unit number' field should accept (\\d+) to (\\d+) characters\\.$")
	public void the_unit_number_field_should_accept_to_characters(int arg1, int arg2) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		if (!((unitnumber.getAttribute("value").length()>0) && (unitnumber.getText().length()<7))) {
			 throw new AssertionError("Unit Number field should accept upto 6 characters");
		}
	}

	@When("^entering text in the City \"([^\"]*)\"field$")
	public void enteringTextInTheCityField(String datapointer) throws Throwable {
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_InputData",testCaseID , datapointer);
		city.sendKeys(value);
	}

	@Then("^the 'city' field should accept (\\d+) to (\\d+) characters\\.$")
	public void the_city_field_should_accept_to_characters(int arg1, int arg2) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		if (!((city.getAttribute("value").length()>0) && (city.getText().length()<20))) {
			 throw new AssertionError("City field should accept upto 19 characters");
		}

	}

	@When("^entering text in the Postal Code \"([^\"]*)\" field$")
	public void enteringTextInThePostalCodeField(String datapointer) throws Throwable {
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_InputData",testCaseID , datapointer);
		postalCode.sendKeys(value);
	}

	@Then("^the 'Postal Code' field should accept (\\d+) to (\\d+) characters\\.$")
	public void the_Postal_Code_field_should_accept_to_characters(int arg1, int arg2) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		if (!((postalCode.getAttribute("value").length()>0) && (postalCode.getText().length()<11))) {
			 throw new AssertionError("Postal Code should accept upto 10 characters");
		}
	}
	
	@Then("^the Country field should default to Canada and non-editable\\.$")
	public void the_Country_field_should_default_to_Canada_and_non_editable() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		if (!(country.getText().equals("Canada"))) {
			 throw new AssertionError("Country is not defaulted to Canada");
		}
		if (!(countryHidden.getAttribute("hidden").equals("true"))) {
			 throw new AssertionError("Country value is disabled");
		}
	}

	@When("^Clicking on Continue button from Manual address page and entering \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" and \"([^\"]*)\"$")
	public void clickingOnContinueButtonFromManualAddressPageAndEnteringAnd(String datapointer, String datapointer1, String datapointer2, String datapointer3, String datapointer4, String datapointer5) throws Throwable {

		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_InputData",testCaseID , datapointer);
		streetNumber.sendKeys(value);
		String value1=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_InputData",testCaseID , datapointer1);
		streetName.sendKeys(value1);
		String value2=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_InputData",testCaseID , datapointer2);
		unitnumber.sendKeys(value2);
		String value3=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_InputData",testCaseID , datapointer3);
		city.sendKeys(value3);
		String value4=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_InputData",testCaseID , datapointer4);
		Select provinceList = new Select(province);
		provinceList.selectByVisibleText(value4);
		String value5=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_InputData",testCaseID , datapointer5);
		postalCode.sendKeys(value5);

		continueWhattypeofproperty.click();
		wait.until(ExpectedConditions.elementToBeClickable(TypeofPropertyhouseselect));

	}

	@Then("^Should able to navigate to 'What type of property have you made an offer on\' page and verify \"([^\"]*)\" text and \"([^\"]*)\" text$")
	public void shouldAbleToNavigateToWhatTypeOfPropertyHaveYouMadeAnOfferOnPageAndVerifyTextAndText(String datapointer, String datapointer1) throws Throwable {
		//Assert.assertEquals(yournewhome.getText(), "Your new home.", "Couldn't find the Your new home.");
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_ExpectedData",testCaseID , datapointer);
		Assert.assertEquals(yournewhome.getText(), value,"Couldn't found expected header message");
		String value1=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_ExpectedData",testCaseID , datapointer1);
		Assert.assertEquals(propertyScreenHeader.getText(), value1,"Couldn't found expected header message");
	}


	@And("^\"([^\"]*)\", \"([^\"]*)\"City\"([^\"]*)\"Province\"([^\"]*)\"PostalCode\" fields should be mandatory$")
	public void cityProvincePostalCodeFieldsShouldBeMandatory(String arg0, String arg1, String arg2, String arg3) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		throw new PendingException();
	}

}
