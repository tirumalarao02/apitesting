package com.scotiabank.ehome.ui.steps;
import com.qmetry.qaf.automation.step.QAFTestStepProvider;
import com.qmetry.qaf.automation.ui.WebDriverTestBase;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebDriver;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.quantum.utils.ConfigurationUtils;
//import com.scotiabank.ehome.ui.steps.valueObjects.TypeOfRateVO;
import com.scotiabank.ehome.ui.steps.valueObjects.TypeOfRateVO;
import cucumber.api.PendingException;
import gherkin.lexer.Th;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.beans.PropertyChangeListener;

import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import static com.scotiabank.ehome.ui.steps.Utility.*;
import com.scotiabank.ehome.ui.steps.valueObjects.TypeOfRateVO;
import static com.scotiabank.ehome.ui.steps.BusinessCalculations.*;
@QAFTestStepProvider

public class Common {

	private QAFExtendedWebDriver webDriver = Utility.getDriver();
	public Actions action = null;
	public static WebDriverWait wait=Utility.getWait();
	public static String coApplicantFirstName="John";

	static String curDir = System.getProperty("user.dir");
	static String strfullPathToFile = curDir + "\\src\\main\\resources\\data\\eHomeTestData.xlsx"; // File Path
	static String  strStage2ToStage3Sheet = "E2EStages";

	public static void sessionBreakerContinueButtonClick() {
		//To click Continue in Section breaker
		QAFExtendedWebElement continueStage4Section= new QAFExtendedWebElement("ehome.Continue.SectionBreaker.button");
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(continueStage4Section));
		continueStage4Section.click();
	}
	//TO verify Scotiabank Logo
	@When("^Verify Scotiabank Logo should be on the screen$")
	public void verify_Scotiabank_Logo_should_be_on_the_screen() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		//To Check Scotiabank Logo image
		QAFExtendedWebElement scotiabankLogo= new QAFExtendedWebElement("ehome.scotiabanklogo.image");
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(scotiabankLogo));
		scotiabankLogo.assertPresent ("Couldn't find the ScotiaBank logo"  );
		if(!scotiabankLogo.verifyPresent())
			throw new AssertionError("Couldn't find the ScotiaBank logo");

		// Not working due to bio changes
		//To Check Scotiabank Logo should be on the left corner
	      /*  String result=scotiabankLogo.getCssValue("float");
	        System.out.println("result"+result);
	        Assert.assertEquals("left",result,"Logo is not in the left corner");
	        if(!scotiabankLogo.getCssValue("float").contentEquals( "left"  ))
	            throw new AssertionError("Logo is not in the left corner");*/
	}
	//TO verify Application status tracker
	@Then("^Verify Application status tracker on the screen$")
	public void verify_Application_status_tracker_on_the_screen() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		//To Check Application status tracker
		QAFExtendedWebElement applicationTracter= new QAFExtendedWebElement("//*[@id=\"progress-tracker\"]/div[1]/div[3]");
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(applicationTracter));
		applicationTracter.assertPresent ( "Application status tracker image is missing" );
		if(!applicationTracter.verifyPresent())
			throw new AssertionError("Couldn't find the Application status tracker");

	}
	//TO verify Application Login username
	@And("^Verify for the Login username on the screen$")
	public void verify_for_the_Login_username_on_the_screen() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		//Blocked Due to bio change username is not given until the stage -1
		/* //To Check Login username
		 QAFExtendedWebElement userloginname= new QAFExtendedWebElement("ehome.userloginname.image");
		 wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(userloginname));
	        userloginname.assertPresent (  );
	        if(!userloginname.verifyPresent())
	            throw new AssertionError("Couldn't find the Login username");

	      //To Check Login username should be on the Right corner
	        String result=userloginname.getCssValue("float");
	        Assert.assertEquals("right",result);
	        if(!userloginname.getCssValue("float").contentEquals( "right"  ))
	            throw new AssertionError("Userloginname is not in the right corner");*/

	}
	//TO verify chat icon functionality
	@And("^Verify the chat icon functionality on the screen$")
	public void verify_the_chat_icon_functionality_on_the_screen() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		//To Check chat icon functionality not yet implemented
	}
	//TO verify header text
	public static String headertext() {
		QAFExtendedWebElement headertext= new QAFExtendedWebElement("ehome.Header.text");
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(headertext));
		String headertextvalue=headertext.getText();
		return headertextvalue;

	}
	public static String headerMessage() {
		QAFExtendedWebElement headerMessage= new QAFExtendedWebElement("ehome.Header.Message");
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(headerMessage));
		String headerMessagevalue=headerMessage.getText();
		return headerMessagevalue;

	}

	//TO verify Back Button
	public static void backButtonClicked() throws InterruptedException {
		QAFExtendedWebElement backbutton= new QAFExtendedWebElement("ehome.Back.button");
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(backbutton));
		Thread.sleep(5000);
		backbutton.click();
	}
	@When("^Click on the Back button on the screen$")
	public void click_on_the_Back_button() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		backButtonClicked();

	}
	@And("^Back button should be there on the screen$")
	public void back_button_should_be_there_on_the_screen() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		QAFExtendedWebElement backbutton= new QAFExtendedWebElement("ehome.Back.button");
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(backbutton));
		Assert.assertEquals(backbutton.getText(), "Back", "Continue Button text does not matched");

	}
	public static void continueButtonClicked() throws InterruptedException {
//		 QAFExtendedWebElement headertext= new QAFExtendedWebElement("ehome.Header.text");
//	     wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(headertext));
//	     String headertextvalue=headertext.getText();
		QAFExtendedWebElement continuebutton= new QAFExtendedWebElement("ehome.Continue.button");
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(continuebutton));
		Thread.sleep(5000);
		continuebutton.click();
//		 Boolean equals=true;
//		while(equals)
//
//		{
//			QAFExtendedWebElement headertext1= new QAFExtendedWebElement("ehome.Header.text");
//			wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(headertext1));
//			String headertextvalue1=headertext1.getText();
//
//			if(headertextvalue.contentEquals(headertextvalue1))
//			{ equals=false;	}
//		}

	}

	@When("^Click on the Continue button on the screen$")
	public void click_on_the_Continue_button_on_the_screen() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		continueButtonClicked();

	}
	@And("^Continue button should not be there in screen$")
	public void continue_button_should_not_be_there_in_screen() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		QAFExtendedWebElement continuebutton = new QAFExtendedWebElement("ehome.Continue.button");
		continuebutton.assertNotVisible("Continue");

	}
	@And("^Continue button should be there on the screen$")
	public void continue_button_should_be_there_on_the_screen() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		QAFExtendedWebElement continuebutton = new QAFExtendedWebElement("ehome.Continue.button");
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(continuebutton));
		Assert.assertEquals(continuebutton.getText(), "Continue", "Continue Button text does not matched");
		Assert.assertEquals(convertRGBToHex(continuebutton.getCssValue("color")), "#ed722", "Continue button not in Red color");
	}
	//To enter address letter by letter and select the value from the dropdown
	public static void newhouseaddress(String address) throws InterruptedException {
		QAFExtendedWebElement Enteraddress= new QAFExtendedWebElement("ehome.Address.address.text");
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(Enteraddress));
		Enteraddress.clear();
		char[] addarr = address.toCharArray();
		for(char oneAt : addarr) {
			Enteraddress.sendKeys(oneAt+"");

		}																		
		QAFExtendedWebElement eleAddress = new QAFExtendedWebElement(By.xpath("ehome.Address.UL"));
		List<WebElement> liLi = eleAddress.findElements(By.tagName("li"));
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).ignoring(ArrayIndexOutOfBoundsException.class).until(ExpectedConditions.visibilityOf(liLi.get(1)));
		liLi.get(1).click();

	}
	public static void enterAddressManually() throws InterruptedException{
		QAFExtendedWebElement streetNumber= new QAFExtendedWebElement("ehome.enteraddressmanually.streetnumber");
		QAFExtendedWebElement streetName= new QAFExtendedWebElement("ehome.enteraddressmanually.streetname");
		QAFExtendedWebElement city= new QAFExtendedWebElement("ehome.enteraddressmanually.city");
		QAFExtendedWebElement province= new QAFExtendedWebElement("ehome.enteraddressmanually.province");
		QAFExtendedWebElement postalCode= new QAFExtendedWebElement("ehome.enteraddressmanually.postalCode");
		QAFExtendedWebElement EnteraddressManually= new QAFExtendedWebElement("ehome.Address.EnterManualaddress");
		EnteraddressManually.click();
		streetNumber.sendKeys("2201");
		streetName.sendKeys("EGLINTON AVE");
		city.sendKeys("TORONTO");
		Select provinceList = new Select(province);
		provinceList.selectByVisibleText("Ontario");
		postalCode.sendKeys("m1k2m1");
		continueButtonClicked();
		Thread.sleep(3000);
	}
	
	public static void skipQuestion() {
		QAFExtendedWebElement skipQuestion= new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[1]/section/div[2]/button");
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(skipQuestion));
		skipQuestion.click();
		

	}
	
	@When("^Click on the Skip question on the Co App screen$")
	public void click_on_the_Skip_question_on_the_Co_App_screen() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		skipQuestion();
		Thread.sleep(5000);
	    
	}
	
	public static void CoApplicantTraverseToNewHomeSection()throws InterruptedException {

		QAFExtendedWebElement coApplicantLoginName= new QAFExtendedWebElement("ehome.CoApplicantLoginName");
		QAFExtendedWebElement coApplicantLoginPassword= new QAFExtendedWebElement("ehome.CoApplicantLoginPassword");
		QAFExtendedWebElement coApplicantLoginSignIn= new QAFExtendedWebElement("ehome.coApplicantLoginSignIn");
		QAFExtendedWebElement coApplicantLoginContinue= new QAFExtendedWebElement("ehome.coApplicantLoginContinue");
		QAFExtendedWebElement continueYourAppliacant= new QAFExtendedWebElement("ehome.continueYourAppliacant");
		QAFExtendedWebElement closedate = new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[1]/section/div[3]/div/div[1]/button");
		QAFExtendedWebElement closedateSelection = new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[1]/section/div[3]/div/div[1]/div/div/div/div[2]/div[2]/div/div[2]/div/table/tbody/tr[5]/td[4]");
		QAFExtendedWebElement closedateSel = new QAFExtendedWebElement("ehome.loc.dateSelection.date");
		QAFExtendedWebElement ContinueButton= new QAFExtendedWebElement("ehome.Continue.button");
					

		Utility.launchURL(ConfigurationUtils.getBaseBundle().getPropertyValue ("env.baseurl5"));
		
		coApplicantLoginName.sendKeys("Karthik29");
		coApplicantLoginPassword.sendKeys("Scotia123");
		coApplicantLoginSignIn.click();
		Thread.sleep(3000);
		coApplicantLoginContinue.click();
		Thread.sleep(3000);
		continueYourAppliacant.click();
		Thread.sleep(3000);
		
//		Thread.sleep(1000);
//		closedate.click();
//		closedateSelection.click();
//		ContinueButton.click();
//		Thread.sleep(3000);
//		ContinueButton.click();
//		
//		Thread.sleep(10000);

	}
	public static void CoApplicantTraversesRatetoEmployment()throws InterruptedException {

		QAFExtendedWebElement continueButtonsectionbreaker= new QAFExtendedWebElement("ehome.Continue.SectionBreaker.button");
		QAFExtendedWebElement fixedButton= new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[1]/section/div[3]/div/fieldset/div/span[1]/label/span[3]");
		QAFExtendedWebElement twoyears= new QAFExtendedWebElement("ehome.termsofrate.2years.radio");
		QAFExtendedWebElement twoyearsRate= new QAFExtendedWebElement("ehome.ratepresentation.twoyears.select");
		QAFExtendedWebElement lockAndHold= new QAFExtendedWebElement("ehome.ratepresentation.twoyears.select");
		QAFExtendedWebElement ContinueButton= new QAFExtendedWebElement("ehome.Continue.button");
		
		continueButtonsectionbreaker.click();	
		Thread.sleep(3000);
		fixedButton.click();
		Thread.sleep(3000);
		twoyears.click();
		Thread.sleep(3000);
		twoyearsRate.click();
		Thread.sleep(3000);
		continueButtonsectionbreaker.click();
		Thread.sleep(3000);
		ContinueButton.click();
		Thread.sleep(3000);
		ContinueButton.click();
		Thread.sleep(3000);
		ContinueButton.click();
		Thread.sleep(10000);

	}
	
	public static void CoApplicantTraversesEmploymenttoAsserts()throws InterruptedException {

		QAFExtendedWebElement continueButtonsectionbreaker= new QAFExtendedWebElement("ehome.Continue.SectionBreaker.button");
		QAFExtendedWebElement ContinueButton= new QAFExtendedWebElement("ehome.Continue.button");
		QAFExtendedWebElement employed= new QAFExtendedWebElement("ehome.Continue.button");
		QAFExtendedWebElement Comm= new QAFExtendedWebElement("ehome.Continue.button");
		continueButtonsectionbreaker.click();	
		Thread.sleep(3000);
		employed.click();
		Thread.sleep(3000);
	
	}
	


	public static void stage2ToStage3(String testCaseID) throws InterruptedException{
		QAFExtendedWebDriver webDriver = Utility.getDriver();

		QAFExtendedWebElement TypeofPropertyhouseselect= new QAFExtendedWebElement("ehome.detailsofdownpayment.TypeofPropertyhouseselect");
		QAFExtendedWebElement Detached= new QAFExtendedWebElement("ehome.detailsofdownpayment.Detached");
		QAFExtendedWebElement ContinueButton= new QAFExtendedWebElement("ehome.detailsofdownpayment.ContinueButton");
		QAFExtendedWebElement ContinueButtonDetails= new QAFExtendedWebElement("ehome.detailsofdownpayment.ContinueButtonDetails");
		QAFExtendedWebElement sqft= new QAFExtendedWebElement("ehome.detailsofdownpayment.sqft");
		QAFExtendedWebElement purchasePrice= new QAFExtendedWebElement("ehome.detailsofdownpayment.purchasePrice");
		QAFExtendedWebElement downPayment= new QAFExtendedWebElement("ehome.detailsofdownpayment.downPayment");
		QAFExtendedWebElement bankAccountOption= new QAFExtendedWebElement("ehome.detailsofdownpayment.bankAccountOption");

		QAFExtendedWebElement closedate = new QAFExtendedWebElement("ehome.loc.datePicker");
		QAFExtendedWebElement closedateSelection = new QAFExtendedWebElement("ehome.loc.dateSelection.datePicker");
		QAFExtendedWebElement closedateSel = new QAFExtendedWebElement("ehome.loc.dateSelection.date");

		QAFExtendedWebElement bankAccountAmount= new QAFExtendedWebElement("ehome.detailsofdownpayment.bankAccountAmount");
		QAFExtendedWebElement Continue = new QAFExtendedWebElement("ehome.tellus.continue.button");
		QAFExtendedWebElement address = new QAFExtendedWebElement("ehome.whatstheaddress.addressList.list");
		QAFExtendedWebElement addressFirstOption = new QAFExtendedWebElement("ehome.whatstheaddress.addressList.firstOption");
		QAFExtendedWebElement continueWhattypeofproperty= new QAFExtendedWebElement("ehome.enteraddressmanually.continue.button");

		Utility.launchURL(ConfigurationUtils.getBaseBundle().getPropertyValue("env.baseurl1"));

		if ( ConfigurationUtils.getBaseBundle().getPropertyValue("driver.name").equals("perfectoRemoteDriver"))
			Continue = new QAFExtendedWebElement("ehome.tellus.continue.button.mobile");
		else
			Continue = new QAFExtendedWebElement("ehome.tellus.continue.button");
		Continue.click();

		QAFExtendedWebElement Enteraddress= new QAFExtendedWebElement("ehome.Address.address.text");
		String addressFromExcel = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage03_Rate_InputData",testCaseID , "Address");
		Common.enterValueinTextbox(addressFromExcel,Enteraddress);

		//wait.until(ExpectedConditions.elementToBeClickable(address)); //Commenting this line due to failure over Grid
		Thread.sleep(8000);
		addressFirstOption.click();
		//TO click on continue button is address screen
		wait.until(ExpectedConditions.visibilityOf(continueWhattypeofproperty));
		continueWhattypeofproperty.click();

		//wait.pollingEvery(30, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.elementToBeClickable(TypeofPropertyhouseselect));
		Thread.sleep(10000);
		TypeofPropertyhouseselect.click();

		Thread.sleep(3000);
		Detached.click();

		wait.pollingEvery(5, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(sqft));
		String sqftFromExcel = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage03_Rate_InputData",testCaseID , "SQFT");
		Common.enterValueinTextbox(sqftFromExcel,sqft);
		//sqft.sendKeys("1000");

		wait.until(ExpectedConditions.visibilityOf(ContinueButton));
		ContinueButton.click();

		wait.until(ExpectedConditions.visibilityOf(purchasePrice));
		String PurchasePriceFromExcel = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage03_Rate_InputData",testCaseID , "Purchase_Price");
		Common.enterValueinTextbox(PurchasePriceFromExcel,purchasePrice);
		ContinueButton.click();

		wait.until(ExpectedConditions.visibilityOf(downPayment));
		String DownPaymentFromExcel = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage03_Rate_InputData",testCaseID , "Down_Payment_Amount");
		Common.enterValueinTextbox(DownPaymentFromExcel,downPayment);

		wait.until(ExpectedConditions.visibilityOf(ContinueButton));
		ContinueButton.click();

		Thread.sleep(5000);
		bankAccountOption.click();

		ContinueButton.click();

		String BankAccountAmountFromExcel = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage03_Rate_InputData",testCaseID , "Bank_Account_Amount");
		bankAccountAmount.sendKeys(BankAccountAmountFromExcel);

		ContinueButtonDetails.click();

		Thread.sleep(1000);
		closedate.click();
		Select closedateSelect =  new Select(closedateSelection);
		closedateSelect.selectByIndex(2);
		closedateSel.click();

		ContinueButton.click();

		ContinueButtonDetails.click();

	}

	public static void TraverseToNewHomeSectionBreaker()throws InterruptedException {
		JavascriptExecutor js = (JavascriptExecutor) Utility.webDriver;
		js.executeScript("window.scrollBy(0,1000)");
		Utility.webDriver.findElement(By.xpath("//ul[@class='slick-dots']//button[contains(text(),'1')]")).click();
		Thread.sleep(5000);
		String value = Utility.webDriver.findElement(By.xpath("//div[@id='stage-card-0']//div[@class='stage-card__footer']")).getText();
		System.out.println("The Value is "+value);
		if ((Utility.webDriver.findElement(By.xpath("//div[@id='stage-card-0']//span[contains(text(),'What to expect') or contains(text(),'View details')]")).getText()).contentEquals("View details"))
		{
			Utility.webDriver.findElement(By.xpath("//div[@id='stage-card-0']//span[contains(text(),'What to expect') or contains(text(),'View details')]")).click();
			Utility.webDriver.findElement(By.xpath("//span[@class='button__content']/span[contains(text(),'Edit')]")).click();
			Utility.webDriver.findElement(By.xpath("//span[@class='button__content']/span[contains(text(),'Yes, continue to edit')]")).click();

		}
			else {

			QAFExtendedWebElement LetsGetStartedBtn = new QAFExtendedWebElement("ehome.hubPreIngestion.LetsGetStartedBtn");
			QAFExtendedWebElement SavecontinueBtn = new QAFExtendedWebElement("ehome.hubPreIngestion.SavecontinueBtn");
			QAFExtendedWebElement NoBtn = new QAFExtendedWebElement("ehome.hubPreIngestion.NoBtn");
			QAFExtendedWebElement YesBtn = new QAFExtendedWebElement("ehome.hubPreIngestion.YesBtn");
			QAFExtendedWebElement GotitBtn = new QAFExtendedWebElement("ehome.hubPreIngestion.GotitBtn");
			QAFExtendedWebElement StartYourApplication = new QAFExtendedWebElement("ehome.hubPreIngestion.StartYourApplication");
			QAFExtendedWebElement YesIConsent = new QAFExtendedWebElement("ehome.hubPreIngestion.YesIConsent");
			QAFExtendedWebElement coAppFirstName = new QAFExtendedWebElement("ehome.hubPreIngestion.coAppFirstName");
			QAFExtendedWebElement coAppLastName = new QAFExtendedWebElement("ehome.hubPreIngestion.coAppLastName");
			QAFExtendedWebElement coAppEmailAddress = new QAFExtendedWebElement("ehome.hubPreIngestion.coAppEmailAddress");
			QAFExtendedWebElement coAppSaveContinue = new QAFExtendedWebElement("ehome.hubPreIngestion.coAppSaveAndContinue");

			/*LetsGetStartedBtn.click();
			wait.until(ExpectedConditions.elementToBeClickable(SavecontinueBtn));
			SavecontinueBtn.click();
			wait.until(ExpectedConditions.elementToBeClickable(YesBtn));
			YesBtn.click();
			YesIConsent.click();
			coAppFirstName.sendKeys("Shankar");
			coApplicantFirstName = "Shankar";
			coAppLastName.sendKeys("M");
			coAppEmailAddress.sendKeys("shankar.madhira@scotiabank.com");
			coAppSaveContinue.click();
			wait.until(ExpectedConditions.elementToBeClickable(GotitBtn));
			GotitBtn.click();
			wait.until(ExpectedConditions.elementToBeClickable(LetsGetStartedBtn));
			LetsGetStartedBtn.click();
			Thread.sleep(5000);*/
			StartYourApplication.click();
		}
	}
	
	public static void TraverseFromNewHomeToRateSectionBreaker(String testCaseID, String sheetName) throws InterruptedException{

		QAFExtendedWebElement TypeofPropertyhouseselect= new QAFExtendedWebElement("ehome.detailsofdownpayment.TypeofPropertyhouseselect");
		QAFExtendedWebElement Detached= new QAFExtendedWebElement("ehome.detailsofdownpayment.Detached");
		QAFExtendedWebElement ContinueButton= new QAFExtendedWebElement("ehome.detailsofdownpayment.ContinueButton");
		QAFExtendedWebElement ContinueButtonDetails= new QAFExtendedWebElement("ehome.detailsofdownpayment.ContinueButtonDetails");
		QAFExtendedWebElement sqft= new QAFExtendedWebElement("ehome.detailsofdownpayment.sqft");
		QAFExtendedWebElement purchasePrice= new QAFExtendedWebElement("ehome.detailsofdownpayment.purchasePrice");
		QAFExtendedWebElement downPayment= new QAFExtendedWebElement("ehome.detailsofdownpayment.downPayment");
		QAFExtendedWebElement bankAccountOption= new QAFExtendedWebElement("ehome.detailsofdownpayment.bankAccountOption");

		QAFExtendedWebElement closedate = new QAFExtendedWebElement("ehome.loc.datePicker");
		QAFExtendedWebElement closedateMoveNextMonth = new QAFExtendedWebElement("ehome.loc.movenextmonth");
		QAFExtendedWebElement closedateSelection = new QAFExtendedWebElement("ehome.loc.dateSelection.datePicker");
		QAFExtendedWebElement closedateSel = new QAFExtendedWebElement("ehome.loc.dateSelection.date");

		QAFExtendedWebElement bankAccountAmount= new QAFExtendedWebElement("ehome.detailsofdownpayment.bankAccountAmount");
		QAFExtendedWebElement Continue = new QAFExtendedWebElement("ehome.tellus.continue.button");
		QAFExtendedWebElement address = new QAFExtendedWebElement("ehome.whatstheaddress.addressList.list");
		QAFExtendedWebElement addressFirstOption = new QAFExtendedWebElement("ehome.whatstheaddress.addressList.firstOption");
		QAFExtendedWebElement continueWhattypeofproperty= new QAFExtendedWebElement("ehome.enteraddressmanually.continue.button");

		if ( ConfigurationUtils.getBaseBundle().getPropertyValue("driver.name").equals("perfectoRemoteDriver"))
			Continue = new QAFExtendedWebElement("ehome.tellus.continue.button.mobile");
		else
			Continue = new QAFExtendedWebElement("ehome.tellus.continue.button");
		Continue.click();

		QAFExtendedWebElement Enteraddress= new QAFExtendedWebElement("ehome.Address.address.text");
		String addressFromExcel = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", sheetName,testCaseID , "Address");
		Common.enterValueinTextbox(addressFromExcel,Enteraddress);

		wait.until(ExpectedConditions.elementToBeClickable(address)); //Commenting this line due to failure over Grid
		//Thread.sleep(10000);
		addressFirstOption.click();
		//TO click on continue button is address screen
		wait.until(ExpectedConditions.visibilityOf(continueWhattypeofproperty));
		continueWhattypeofproperty.click();

		//wait.pollingEvery(30, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.elementToBeClickable(TypeofPropertyhouseselect));
		wait.until(ExpectedConditions.elementToBeClickable(TypeofPropertyhouseselect));
		//Thread.sleep(15000);
		TypeofPropertyhouseselect.click();

		wait.until(ExpectedConditions.elementToBeClickable(Detached));
		Detached.click();

		wait.pollingEvery(5, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(sqft));
		String sqftFromExcel = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", sheetName,testCaseID , "SQFT");
		Common.enterValueinTextbox(sqftFromExcel,sqft);

		wait.until(ExpectedConditions.visibilityOf(ContinueButton));
		ContinueButton.click();

		wait.until(ExpectedConditions.visibilityOf(purchasePrice));
		String PurchasePriceFromExcel = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", sheetName,testCaseID , "Purchase_Price");
		Common.enterValueinTextbox(PurchasePriceFromExcel,purchasePrice);
		ContinueButton.click();

		wait.until(ExpectedConditions.visibilityOf(downPayment));
		String DownPaymentFromExcel = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", sheetName,testCaseID , "Down_Payment_Amount");
		Common.enterValueinTextbox(DownPaymentFromExcel,downPayment);

		wait.until(ExpectedConditions.visibilityOf(ContinueButton));
		ContinueButton.click();

		wait.until(ExpectedConditions.elementToBeClickable(bankAccountOption));
		if(!bankAccountOption.isSelected()){
			bankAccountOption.click();
		}

		ContinueButton.click();

		wait.until(ExpectedConditions.elementToBeClickable(bankAccountAmount));
		String BankAccountAmountFromExcel = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", sheetName,testCaseID , "Bank_Account_Amount");
		bankAccountAmount.sendKeys(BankAccountAmountFromExcel);

		ContinueButtonDetails.click();

		//Thread.sleep(1000);
		wait.until(ExpectedConditions.elementToBeClickable(closedate));
		closedate.click();
		Thread.sleep(2000);
		closedateMoveNextMonth.click();
		Thread.sleep(2000);
		closedateSelection.click();


		ContinueButton.click();

		Thread.sleep(2000);
		ContinueButtonDetails.click();

	}
	
	public static void TraverseRateSectionToEmploymentSectionBreaker() throws Throwable {

		QAFExtendedWebElement Continue = new QAFExtendedWebElement("//button[@class='button button--primary']");
		QAFExtendedWebElement selectFixed = new QAFExtendedWebElement("ehome.whattypeofrate.selectfixed.radio");
		QAFExtendedWebElement twoyears = new QAFExtendedWebElement("ehome.termsofrate.2years.radio");
		QAFExtendedWebElement twoyear = new QAFExtendedWebElement("ehome.ratepresentation.twoyears.select");
		QAFExtendedWebElement LockandHold = new QAFExtendedWebElement("ehome.ratelock.LockandHold");
		QAFExtendedWebElement RateCustomizationContinuebutton = new QAFExtendedWebElement("//span[contains(text(),'Continue')]");
		QAFExtendedWebElement Continueinstep = new QAFExtendedWebElement("//span[contains(text(),'Continue')]");
		QAFExtendedWebElement YesIminterested = new QAFExtendedWebElement("//span[contains(text(),'interested!')]");
		QAFExtendedWebElement ContinueinLOCConfirmation = new QAFExtendedWebElement("//span[contains(text(),'Continue')]");

		Continue.click();

		if (!(selectFixed.isSelected()))
		{
			selectFixed.click();
		}

		Thread.sleep(3000);

		twoyears.click();

		twoyear.click();

		LockandHold.click();

		wait.until(ExpectedConditions.elementToBeClickable(RateCustomizationContinuebutton));
		RateCustomizationContinuebutton.click();

		//wait.until(ExpectedConditions.elementToBeClickable(Continueinstep));
		Thread.sleep(5000);
		Continueinstep.click();

		wait.until(ExpectedConditions.elementToBeClickable(YesIminterested));
		YesIminterested.click();

		wait.until(ExpectedConditions.elementToBeClickable(ContinueinLOCConfirmation));
		ContinueinLOCConfirmation.click();

		wait.until(ExpectedConditions.elementToBeClickable(ContinueinLOCConfirmation));
		ContinueinLOCConfirmation.click();

	}

	public static void TraverseFromEmploymentSectionToLandOnCoApplicantPage() throws InterruptedException {

		Common.sessionBreakerContinueButtonClick();
		CommonAppMethodsEmployment.SelectEmpStatus("Retired");
		Thread.sleep(1000);
		if (!(Utility.webDriver.findElement("ehome.employmentDuration.years").isPresent()))
		{
			continueButtonClicked();
		}
		CommonApplicationMethods.selectValuefromDropDownListBox("ehome.employmentDuration.years", "3 years");
		Thread.sleep(2000);
		CommonApplicationMethods.selectValuefromDropDownListBox("ehome.employmentDuration.months", "3 months");
		Utility.webDriver.findElement(By.xpath("//span[contains(text(),'Continue')]")).click();
		Thread.sleep(2000);
		Utility.webDriver.findElement(By.xpath("//span[contains(text(),'No sources of income')]")).click();

	}
	
	public static void enterValueinTextbox(String value, QAFExtendedWebElement element){
		QAFExtendedWebDriver webDriver = Utility.getDriver();
		switch (webDriver.getCapabilities().getPlatform().toString().toUpperCase()){
			case "XP":
			case "WIN10":
			case "VISTA":
				element.sendKeys(value);
				break;
			case "ANDROID":
				element.click();
				webDriver.getKeyboard().sendKeys(value);
				break;
			case "IOS":
				Assert.fail("UnderConstraction.....IOS not support, looking for solution along with TCOE");
				break;
			default:
				break;
		}
	}
	public static void loginToeHomeHub(String UserName, String Password) throws Throwable {

		Utility.webDriver.findElement(By.xpath(".//*[contains(@id,'username')]")).sendKeys(UserName);
		Utility.webDriver.findElement(By.xpath(".//*[contains(@id,'password')]")).sendKeys(Password);
		Utility.webDriver.findElement(By.xpath("//button[@id='signIn']")).click();
		Thread.sleep(3000);
		Utility.clickObject("ehome.eHomeLogin.Continue", "Continue Button in Redirect Screen");
		Thread.sleep(15000);

	}
}