package com.scotiabank.ehome.ui.steps.stage4;

import java.util.List;
import java.util.concurrent.TimeUnit;

import com.scotiabank.ehome.ui.steps.Common;
import com.scotiabank.ehome.ui.steps.coApp.CoAppIntro;
import cucumber.api.PendingException;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.qmetry.qaf.automation.step.QAFTestStepProvider;
import com.qmetry.qaf.automation.ui.WebDriverTestBase;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebDriver;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.quantum.utils.ConfigurationUtils;
import com.scotiabank.ehome.ui.steps.Utility;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

@QAFTestStepProvider
public class UnEmployedOtherIncomeSources {

    private  QAFExtendedWebDriver webDriver = new WebDriverTestBase().getDriver();
    public Actions action = null;
    WebDriverWait wait = new WebDriverWait(webDriver,50000);

    String testCaseID = Utility.getScenarioID();
    
    QAFExtendedWebElement employmentStatusUnEmployed= new QAFExtendedWebElement("ehome.UnEmployedOtherIncomeSource.employmentStatusUnEmployed");
    QAFExtendedWebElement employmentStatusRetired= new QAFExtendedWebElement("ehome.UnEmployedOtherIncomeSource.employmentStatusRetired");
    QAFExtendedWebElement employmentStatusRetiredYears= new QAFExtendedWebElement("ehome.UnEmployedOtherIncomeSource.employmentStatusRetiredYears");
    QAFExtendedWebElement employmentStatusRetiredMonths= new QAFExtendedWebElement("ehome.UnEmployedOtherIncomeSource.employmentStatusRetiredMonths");
    QAFExtendedWebElement ContinueButton= new QAFExtendedWebElement("ehome.UnEmployedOtherIncomeSource.ContinueButton");
    QAFExtendedWebElement Continue= new QAFExtendedWebElement("ehome.UnEmployedOtherIncomeSource.Continue");
    
    QAFExtendedWebElement Back= new QAFExtendedWebElement("ehome.UnEmployedOtherIncomeSource.Back");
    
    QAFExtendedWebElement scotiabankLogo = new QAFExtendedWebElement("ehome.scotiabanklogo.image");
    QAFExtendedWebElement applicationTracter= new QAFExtendedWebElement("ehome.applicationstatustracker.image");
	QAFExtendedWebElement userloginname= new QAFExtendedWebElement("ehome.userloginname.image");
	QAFExtendedWebElement doyouhaveanysourcesofincome= new QAFExtendedWebElement("ehome.UnEmployedOtherIncomeSource.doyouhaveanysourcesofincome");
    QAFExtendedWebElement coAppdoyouhaveanysourcesofincome= new QAFExtendedWebElement("ehome.CoAppUnEmployedOtherIncomeSource.doyouhaveanysourcesofincome");
	QAFExtendedWebElement pleaseselectallthatapply= new QAFExtendedWebElement("ehome.UnEmployedOtherIncomeSource.pleaseselectallthatapply");
	QAFExtendedWebElement howlonghaveyoubeenretiredtitle= new QAFExtendedWebElement("ehome.UnEmployedOtherIncomeSource.howlonghaveyoubeenretiredtitle");
	QAFExtendedWebElement Whatisyouremploymentstatustitle= new QAFExtendedWebElement("ehome.UnEmployedOtherIncomeSource.Whatisyouremploymentstatustitle");
	QAFExtendedWebElement Whattheannualincometitle= new QAFExtendedWebElement("ehome.UnEmployedOtherIncomeSource.Whattheannualincome");
	
	QAFExtendedWebElement Doyouhaveassetsoutsideofscotia= new QAFExtendedWebElement("ehome.UnEmployedOtherIncomeSource.Doyouhaveassetsoutsideofscotia");
	QAFExtendedWebElement unselectinvestments= new QAFExtendedWebElement("ehome.UnEmployedOtherIncomeSource.unselectinvestments");
	
	
	QAFExtendedWebElement childSupport= new QAFExtendedWebElement("ehome.UnEmployedOtherIncomeSource.childSupport");
	QAFExtendedWebElement investments= new QAFExtendedWebElement("ehome.UnEmployedOtherIncomeSource.investments");
    QAFExtendedWebElement NoOtherSourcesOfIncome= new QAFExtendedWebElement("ehome.UnEmployedOtherIncomeSource.NoOtherSoucesOfIncome");

    QAFExtendedWebElement EmploymentStatusTitle= new QAFExtendedWebElement("ehome.coAppOtherSrcsOfIncome.SrcOfIncomeTitle");
    QAFExtendedWebElement CoAppOtherIncomeSourcesDetailsTitle= new QAFExtendedWebElement("ehome.CoAppUnEmployedOtherIncomeSourceDetails.Title");

    @Given("^Customer should login and select 'Current Employment Status' as \"([^\"]*)\" and navigate to UnEmployed Other Income Sources screen$")
    public void customerShouldLoginAndSelectCurrentEmploymentStatusAsAndNavigateToUnEmployedOtherIncomeSourcesScreen(String Employment_Status) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        if (testCaseID.contains("CoApp"))
        {
            Common.TraverseToNewHomeSectionBreaker();
            Thread.sleep(2000);
            Common.TraverseFromNewHomeToRateSectionBreaker(testCaseID,"Co-App_InputData");
            Common.TraverseRateSectionToEmploymentSectionBreaker();
            Common.TraverseFromEmploymentSectionToLandOnCoApplicantPage();
            CoAppIntro.startSectionButtonClicked();
        }
        else {
            Utility.launchURL(ConfigurationUtils.getBaseBundle().getPropertyValue("env.baseurl2"));
            Continue.click();
        }
        if (Employment_Status.equals("Unemployed"))
        {
        	employmentStatusUnEmployed.click();
        }
        else if (Employment_Status.equals("Retired"))
        {
        	employmentStatusRetired.click();
        	Select employmentStatusRetiredYrs =  new Select(employmentStatusRetiredYears);
        	Thread.sleep(3000);
        	employmentStatusRetiredYrs.selectByIndex(4);

    	    Select employmentStatusRetiredMnths =  new Select(employmentStatusRetiredMonths);
            employmentStatusRetiredMnths.selectByIndex(3);

    	    wait.until(ExpectedConditions.visibilityOf(ContinueButton));
    	    ContinueButton.click();
        }
    }

    @Then("^Verify 'Scotia bank Logo' should be as \"([^\"]*)\" on the screen, Verify 'Application status' should be as \"([^\"]*)\" tracker on the screen, Verify for the 'Login username' as \"([^\"]*)\" on the screen, Verify the 'chat icon' functionality as \"([^\"]*)\" on the screen, 'Back' button should be as \"([^\"]*)\", 'No sources of income' button should be as \"([^\"]*)\"$")
    public void verify_Scotia_bank_Logo_should_be_as_on_the_screen_Verify_Application_status_should_be_as_tracker_on_the_screen_Verify_for_the_Login_username_as_on_the_screen_Verify_the_chat_icon_functionality_as_on_the_screen_Back_button_should_be_as_No_sources_of_income_button_should_be_as(String arg1, String arg2, String arg3, String arg4, String arg5, String arg6) throws Throwable {
        // Write code here that turns the phrase above into concrete actions

        scotiabankLogo.assertPresent ("Couldn't find the ScotiaBank logo"  );
        if(!scotiabankLogo.verifyPresent())
            throw new AssertionError("Couldn't find the ScotiaBank logo");

        //To Check Application status tracker
/*        applicationTracter.assertPresent ( "Application status tracker image is missing" );
        if(!applicationTracter.verifyPresent())
            throw new AssertionError("Couldn't find the Application status tracker");*/

        String Back_Text = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage04_Employment_ExpectedData",testCaseID , "Back_Button_Text");
        Assert.assertEquals(Back.getText(), Back_Text,"Couldn't found Back button, Back button should be present");

        Back.isPresent();
        ContinueButton.isPresent();
    }
    
    @Then("^Verify 'Do you have any sources of income' as \"([^\"]*)\" , 'Please select all that apply' as \"([^\"]*)\"$")
    public void verify_Do_you_have_any_sources_of_income_as_Please_select_all_that_apply_as(String doyouhaveanysourcesofincomeTxt, String pleaseselectallthatapplyTxt) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        if (testCaseID.contains("CoApp")){
            String CoApp_UnEmployed_Sources_Title = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage04_Employment_ExpectedData",testCaseID , "UnEmployed_Sources_Screen_Title");
            if ((!coAppdoyouhaveanysourcesofincome.getText().contains("other sources of income")))
                throw new AssertionError("CoApp Unemployed Title is not Correct");

            String UnEmployed_Sources_Message = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage04_Employment_ExpectedData",testCaseID , "UnEmployed_Sources_Screen_Message");
            Assert.assertEquals(pleaseselectallthatapply.getText(), UnEmployed_Sources_Message,"Please select all that apply text is not displayed");

        }
        else{
            String UnEmployed_Sources_Title = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage04_Employment_ExpectedData",testCaseID , "UnEmployed_Sources_Screen_Title");
            Assert.assertEquals(doyouhaveanysourcesofincome.getText(), UnEmployed_Sources_Title,"Do you have any sources of income text is not displayed");

            String UnEmployed_Sources_Message = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage04_Employment_ExpectedData",testCaseID , "UnEmployed_Sources_Screen_Message");
            Assert.assertEquals(pleaseselectallthatapply.getText(), UnEmployed_Sources_Message,"Please select all that apply text is not displayed");

        }
    }
    
    @When("^clicking on Back Button from UnEmployed Other Income Sources screen$")
    public void clicking_on_Back_Button_from_UnEmployed_Other_Income_Sources_screen() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        Back.click();
    }

    @Then("^Navigate to 'How long have you been retired\\?' screen$")
    public void navigate_to_How_long_have_you_been_retired_screen() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        String Retired_Years_Screen_Title = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage04_Employment_ExpectedData",testCaseID , "Retired_Years_Screen_Title");
    	Assert.assertEquals(howlonghaveyoubeenretiredtitle.getText(),Retired_Years_Screen_Title,"How long have you been retired? text is not displayed");
    }
    
    @Then("^Navigate to 'What is your employment status\\?' screen$")
    public void navigate_to_What_is_your_employment_status_screen() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        String Employment_Screen_Title = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage04_Employment_ExpectedData",testCaseID , "Employer_Screen_Title");
    	Assert.assertEquals(Whatisyouremploymentstatustitle.getText(), Employment_Screen_Title,"What is your employment status? text is not displayed");
    }
    
    @When("^clicking on \"([^\"]*)\" Button after selecting \"([^\"]*)\" from UnEmployed Other Income Sources screen$")
    public void clicking_on_Button_after_selecting_from_UnEmployed_Other_Income_Sources_screen(String arg1, String arg2) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
       	investments.click();
    	ContinueButton.click();
    }
    
    @When("^clicking on \"([^\"]*)\" Button without seleting any other sources from UnEmployed Other Income Sources screen$")
    public void clicking_on_Button_without_seleting_any_other_sources_from_UnEmployed_Other_Income_Sources_screen(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	ContinueButton.click();
    }

    @Then("^Navigate to 'What you Own and Owe' screen$")
    public void navigateToWhatYouOwnAndOweScreen() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        Thread.sleep(5000);
        String What_You_Owe_Header = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage04_Employment_ExpectedData",testCaseID , "What_You_Owe_Header");
    	Assert.assertEquals(NoOtherSourcesOfIncome.getText(),What_You_Owe_Header,"What you Own and Owe? text is not displayed");
    	
    }
    
    @Then("^Navigate to 'Whats the annual income for each source\\?' screen$")
    public void navigate_to_Whats_the_annual_income_for_each_source_screen() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    String Annual_Income_Screen_Title = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage04_Employment_ExpectedData",testCaseID , "Annual_Income_Screen_Title");
   	Assert.assertEquals(Whattheannualincometitle.getText(),Annual_Income_Screen_Title,"What's the annual income for each source? text is not displayed");
    	
    }

    @When("^select \"([^\"]*)\" from UnEmployed Other Income Sources screen$")
    public void select_from_UnEmployed_Other_Income_Sources_screen(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	investments.click();
    }

    @Then("^Unselect \"([^\"]*)\" from UnEmployed Other Income Sources screen$")
    public void unselect_from_UnEmployed_Other_Income_Sources_screen(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        webDriver.manage().timeouts().implicitlyWait(5000, TimeUnit.SECONDS);
    	unselectinvestments.click();
    }

    @Then("^Verify that the User is navigated back to Employment Status Screen$")
    public void verifyThatTheUserIsNavigatedBackToEmploymentStatusScreen() throws Throwable {

        if (!(EmploymentStatusTitle.getText().contains("current employment status")))
            throw new AssertionError("Employment Status Screen is not displayed");

    }

    @Then("^User should be navigated to Sources of Income Details Screen$")
    public void userShouldBeNavigatedToSourcesOfIncomeDetailsScreen() throws Throwable {

        if (!(CoAppOtherIncomeSourcesDetailsTitle.getText().contains("other sources of income")))
            throw new AssertionError("Other Income Source Details Screen is not present");

    }
}
