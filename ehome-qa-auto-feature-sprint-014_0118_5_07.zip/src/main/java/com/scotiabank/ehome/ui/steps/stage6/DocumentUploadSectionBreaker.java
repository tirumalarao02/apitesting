package com.scotiabank.ehome.ui.steps.stage6;
import com.qmetry.qaf.automation.step.QAFTestStepProvider;
import com.qmetry.qaf.automation.ui.WebDriverTestBase;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.quantum.java.pages.ExtentReportHelper;
import com.quantum.utils.ConfigurationUtils;
import com.scotiabank.ehome.ui.steps.Common;
import com.scotiabank.ehome.ui.steps.CommonAppMethodsAssetLiabilities;
import com.scotiabank.ehome.ui.steps.CommonAppMethodsEmployment;
import com.scotiabank.ehome.ui.steps.CommonApplicationMethods;
import com.scotiabank.ehome.ui.steps.Utility;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;

import java.util.Map;
import java.util.concurrent.TimeUnit;
import static com.scotiabank.ehome.ui.steps.Utility.*;

@QAFTestStepProvider

public class DocumentUploadSectionBreaker {
	
	  public static WebDriverWait wait=Utility.getWait();
	  static String curDir = System.getProperty("user.dir");
	  static String strfullPathToFile = curDir + "\\src\\main\\resources\\data\\eHomeTestData.xlsx"; // File Path
		
	  static String sheetStage06_InputData ="Stage06_DocUpload_InputData";
	  static String sheetStage06_ExpectedData ="Stage06_DocUpload_ExpectedData";
	  
	//  String strtestCaseID = "DocUpload-Section-Brkr-TC-005";
	  String strtestCaseID = Utility.getScenarioID();
	  
	  QAFExtendedWebElement strNoOtherLiabilities_Link= new QAFExtendedWebElement("ehome.liabilitySrcs.NoOtherLiabilities.Link");
	  QAFExtendedWebElement strdocUploadSectionBrk_ActualTitle= new QAFExtendedWebElement("ehome.docUploadSectionBrkr.Title");
	  QAFExtendedWebElement strStartBtn= new QAFExtendedWebElement("ehome.docUploadSectionBrkr.Start.Button");
	  QAFExtendedWebElement strBacktoeHomeHubBtn= new QAFExtendedWebElement("ehome.docUploadSectionBrkr.BacktoeHomeHub.Button");
	  QAFExtendedWebElement strDontHave_ActualContent= new QAFExtendedWebElement("ehome.docUploadSectionBrkr.DontHave.Content");
	  QAFExtendedWebElement strFileSize_ActualContent= new QAFExtendedWebElement("ehome.docUploadSectionBrkr.FileSize.Content");
	  QAFExtendedWebElement strHub_PostOnboarding_ActualTitle= new QAFExtendedWebElement("//*[@id=\"post-onboarding-application-steps\"]/div[1]/p");
	  QAFExtendedWebElement strdocUpload_ActualTitle= new QAFExtendedWebElement("ehome.docUpload.Title");
	  
		  
	  @When("^Customer should navigate to 'Document Upload Section Breaker' screen when select 'Any or No Other Liabilities'$")
		public void Customer_should_navigate_to_Document_Upload_Section_Breaker() throws Throwable {
		  
		  Map<String, String> Stage06_InputData =  Utility.readTestData(strfullPathToFile, sheetStage06_InputData,strtestCaseID);
		  
		  	String strCurrentEmpStatus	= Stage06_InputData.get("Empmt_Status");
			String strDurationYear=  Stage06_InputData.get("Years");
			String strDurationMonth=  Stage06_InputData.get("Months");
			String strInvestment_ExpectedInput	= Stage06_InputData.get("EmpOtherSrcsOfIncome_Investments"); 
			String strInvestmentAmt_ExpectedInput	= Stage06_InputData.get("EmpOtherSrcsOfIncome_Investments_Amt");
			
			String strAutomobile_Input = Stage06_InputData.get("AssetSources_Automobile");
			String strCash_Input = Stage06_InputData.get("AssetSources_Cash");
			String strGICTermDeposit_Input = Stage06_InputData.get("AssetSources_GICTermDeposit");
			String strPrimaryResidence_Input = Stage06_InputData.get("AssetSources_PrimaryResidence");
			String strRentalProperty_Input = Stage06_InputData.get("AssetSources_RentalProperty");
			String strRRSP_Input = Stage06_InputData.get("AssetSources_RRSP");
			String strSecondaryProperty_Input = Stage06_InputData.get("AssetSources_SecondaryProperty");
			String strStockBond_Input = Stage06_InputData.get("AssetSources_StockBond");
			String strOtherAssets_Input = Stage06_InputData.get("AssetSources_OtherAssets");
			String strNoOtherAssets_Input = Stage06_InputData.get("AssetSources_NoOtherAssets");
			
			String strAutomobileAmt = Stage06_InputData.get("AssetSources_Automobile_Amt");
			String strCashAmt = Stage06_InputData.get("AssetSources_Cash_Amt");
			String strGICTermDepositAmt = Stage06_InputData.get("AssetSources_GICTermDeposit_Amt");
			String strPrimaryResidenceAmt = Stage06_InputData.get("AssetSources_PrimaryResidence_Amt");
			String strRentalPropertyAmt = Stage06_InputData.get("AssetSources_RentalProperty_Amt");
			String strRRSPAmt = Stage06_InputData.get("AssetSources_RRSP_Amt");
			String strSecondaryPropertyAmt = Stage06_InputData.get("AssetSources_SecondaryProperty_Amt");
			String strStockBondAmt = Stage06_InputData.get("AssetSources_StockBond_Amt");
			String strOtherAssetsAmt = Stage06_InputData.get("AssetSources_OtherAssets_Amt");
			
			String strNoOtherLiabilities = Stage06_InputData.get("LiabilitySources_NoOtherLiabilities");
			
	
			Utility.launchURL(ConfigurationUtils.getBaseBundle().getPropertyValue ("env.baseurl2"));
			Common.sessionBreakerContinueButtonClick();
			CommonAppMethodsEmployment.SelectEmpStatus(strCurrentEmpStatus);
			Thread.sleep(1000);
				
			if (strDurationYear != "") {
				CommonApplicationMethods.selectValuefromDropDownListBox("ehome.employmentDuration.years", strDurationYear);
		 			Thread.sleep(250);
			}
			if (strDurationMonth != "") {
				CommonApplicationMethods.selectValuefromDropDownListBox("ehome.employmentDuration.months", strDurationMonth);
				Thread.sleep(250);
			}
			Common.continueButtonClicked();
			Thread.sleep(500);
			CommonAppMethodsEmployment.SelectRetiredSourcesOfIncome(strInvestment_ExpectedInput);
			Thread.sleep(500);
			Common.continueButtonClicked();
			if (strInvestment_ExpectedInput != "" | strInvestmentAmt_ExpectedInput != "") {
				CommonAppMethodsEmployment.EnterRetiredAnualIncomeSourceAmount(strInvestment_ExpectedInput, strInvestmentAmt_ExpectedInput);
					}
			Thread.sleep(250);
			Utility.clickObject("ehome.otherIncomeSrcDetails.Continue", "Continue Button in Other Income Src Details");
			Thread.sleep(250);
			Utility.clickObject("ehome.assetSectionBrkr.Continue", "Continue Button in Asset Section Breaker");
			Thread.sleep(250);
				
			if (strNoOtherAssets_Input.contentEquals("No assets")) {
				CommonAppMethodsAssetLiabilities.SelectAssetsSources(strNoOtherAssets_Input);
			}
			if (strAutomobile_Input.contentEquals("Automobile")) {
				CommonAppMethodsAssetLiabilities.SelectAssetsSources(strAutomobile_Input); 
			}
			if (strCash_Input.contentEquals("Cash")) {
				CommonAppMethodsAssetLiabilities.SelectAssetsSources(strCash_Input); 
			}
			if (strGICTermDeposit_Input.contentEquals("GIC/Term Deposit")) {
				CommonAppMethodsAssetLiabilities.SelectAssetsSources(strGICTermDeposit_Input); 
			}
			if (strPrimaryResidence_Input.contentEquals("Primary Residence")) {
				CommonAppMethodsAssetLiabilities.SelectAssetsSources(strPrimaryResidence_Input); 
			}
			
			if (strRentalProperty_Input.contentEquals("Rental Property")) {
				CommonAppMethodsAssetLiabilities.SelectAssetsSources(strRentalProperty_Input); 
			}
			if (strRRSP_Input.contentEquals("RRSP")) {
				CommonAppMethodsAssetLiabilities.SelectAssetsSources(strRRSP_Input); 
			}
			if (strSecondaryProperty_Input.contentEquals("Secondary Property")) {
				CommonAppMethodsAssetLiabilities.SelectAssetsSources(strSecondaryProperty_Input); 
			}
			if (strStockBond_Input.contentEquals("Stock/Bond")) {
				CommonAppMethodsAssetLiabilities.SelectAssetsSources(strStockBond_Input); 
			}
			if (strOtherAssets_Input.contentEquals("Other Assets")) {
				CommonAppMethodsAssetLiabilities.SelectAssetsSources(strOtherAssets_Input); 
			}
			if (strAutomobile_Input.contentEquals("No assets") | strCash_Input.contentEquals("No assets") | strGICTermDeposit_Input.contentEquals("No assets") | strPrimaryResidence_Input.contentEquals("No assets")| strRentalProperty_Input.contentEquals("No assets")| strRRSP_Input.contentEquals("No assets")| strSecondaryProperty_Input.contentEquals("No assets")| strStockBond_Input.contentEquals("No assets")| strOtherAssets_Input.contentEquals("No assets")) {
				CommonAppMethodsAssetLiabilities.SelectAssetsSources("No assets"); 
			}
			
			Thread.sleep(250);
			if (!strNoOtherAssets_Input.contentEquals("No assets")) {
				Common.continueButtonClicked();
				}

				//Do you have any of the following assets?
			if (strAutomobile_Input!= "" | strAutomobileAmt!= "") {
				CommonAppMethodsAssetLiabilities.EnterAssetCalculateAmount(strAutomobile_Input, strAutomobileAmt);
			}
			if (strCash_Input!= "" | strCashAmt.length()!= 0) {
					CommonAppMethodsAssetLiabilities.EnterAssetCalculateAmount(strCash_Input, strCashAmt);
					}
			if (strGICTermDeposit_Input!= "" | strGICTermDepositAmt!= "") {
				CommonAppMethodsAssetLiabilities.EnterAssetCalculateAmount(strGICTermDeposit_Input, strGICTermDepositAmt);
				}
			if (strPrimaryResidence_Input!= "" | strPrimaryResidenceAmt!= "") {
				CommonAppMethodsAssetLiabilities.EnterAssetCalculateAmount(strPrimaryResidence_Input, strPrimaryResidenceAmt );
				}
			if (strRentalProperty_Input!= "" | strRentalPropertyAmt!= "") {
				CommonAppMethodsAssetLiabilities.EnterAssetCalculateAmount(strRentalProperty_Input, strRentalPropertyAmt );
		 		}
			if (strRRSP_Input!= "" | strRRSPAmt!= "") {
				CommonAppMethodsAssetLiabilities.EnterAssetCalculateAmount(strRRSP_Input, strRRSPAmt);
				}
			if (strSecondaryProperty_Input!= "" | strSecondaryPropertyAmt!= "") {
				CommonAppMethodsAssetLiabilities.EnterAssetCalculateAmount(strSecondaryProperty_Input, strSecondaryPropertyAmt);
				}
			if (strStockBond_Input!= "" | strStockBondAmt!= "") {
				CommonAppMethodsAssetLiabilities.EnterAssetCalculateAmount(strStockBond_Input, strStockBondAmt);
				}
			if (strOtherAssets_Input!= "" | strOtherAssetsAmt!= "") {
				CommonAppMethodsAssetLiabilities.EnterAssetCalculateAmount(strOtherAssets_Input, strOtherAssetsAmt );
				}
			
			QAFExtendedWebElement continueBtn = new WebDriverTestBase().getDriver().findElement(By.xpath("//button[contains(@class,'nav-button nav-button--next nav-button--enabled')]"));
			continueBtn.click();
			 
			 if (strNoOtherLiabilities.contentEquals("No other liabilities"))
					 {
				 		strNoOtherLiabilities_Link.click();
				}
			 
			}
	
		
	@Then("^Verify 'Document Upload Section Breaker' Screen and presence of all objects on 'Document Upload Section Breaker' Screen$")
	public void Verify_document_upload_section_breaker_Screen_and_presence_of_all_objects_on_Document_Upload_Section_Breaker_Screen() throws Throwable {
		Map<String, String> Stage06_ExpectedData =  Utility.readTestData(strfullPathToFile, sheetStage06_ExpectedData,strtestCaseID);
			String strDocument_Upload_ExpectedTitle	= Stage06_ExpectedData.get("Document_Upload_Section_Breaker_Title"); 	
			String strDocument_Upload_DontHave_ExpectedContent	= Stage06_ExpectedData.get("Doc_Upload_Section_Brkr_DontHave_Content");
			String strDocument_Upload_FileSize_ExpectedContent	= Stage06_ExpectedData.get("Doc_Upload_Section_Brkr_FileSize_Content");
	
			if (strDocument_Upload_ExpectedTitle.contentEquals(strdocUploadSectionBrk_ActualTitle.getText())) {
    			ExtentReportHelper.StepPass(strDocument_Upload_ExpectedTitle + " Screen# is displayed.");
    		}
    		else
    		{
    			Assert.assertEquals(strdocUploadSectionBrk_ActualTitle.getText(), strDocument_Upload_ExpectedTitle,"'Document Upload Section Breaker' Screen is NOT as Expected.");
    		}	
    		

    		if (strDocument_Upload_DontHave_ExpectedContent.contentEquals(strDontHave_ActualContent.getText())) {
    			ExtentReportHelper.StepPass(strDocument_Upload_DontHave_ExpectedContent + " content# is displayed.");
    		}
    		else
    		{
    			Assert.assertEquals(strDontHave_ActualContent.getText(), strDocument_Upload_DontHave_ExpectedContent,"'Dont Have..' content is NOT as Expected.");
    		}	
    		
    		if (strDocument_Upload_FileSize_ExpectedContent.contentEquals(strFileSize_ActualContent.getText())) {
    			ExtentReportHelper.StepPass(strDocument_Upload_FileSize_ExpectedContent + " content# is displayed.");
    		}
    		else
    		{
    			Assert.assertEquals(strFileSize_ActualContent.getText(), strDocument_Upload_FileSize_ExpectedContent,"'File Size...' content is NOT as Expected.");
    		}	
    		
    		if(strStartBtn.isPresent())
			{
				ExtentReportHelper.StepPass("'" + strStartBtn.getText() + "' option button is displayed.");
			}
			else
			{
				ExtentReportHelper.StepFail("'" + strStartBtn.getText() + "' option button is NOT displayed.");
			}
    		if(strBacktoeHomeHubBtn.isPresent())
			{
				ExtentReportHelper.StepPass("'" + strBacktoeHomeHubBtn.getText() + "' option button is displayed.");
			}
			else
			{
				ExtentReportHelper.StepFail("'" + strBacktoeHomeHubBtn.getText() + "' option button is NOT displayed.");
			}
    		
 		}
	
	@Then("^Verify 'Hub PostOnboarding' Screen when Click on 'Back to eHome Hub' button on DocUpload when selects 'No other liabilities'$")
	public void Verify_Hub_Post_Onboarding_Screen_when_Click_on_Back_to_eHome_Hub_button_on_DocUpload_when_selects_No_other_liabilities() throws Throwable {
		Map<String, String> Stage06_ExpectedData =  Utility.readTestData(strfullPathToFile, sheetStage06_ExpectedData,strtestCaseID);
			String strHub_PostOnboarding_ExpectedTitle	= Stage06_ExpectedData.get("HubPostOnboard_HowYourMortJrny_Title"); 
				
			strBacktoeHomeHubBtn.click();
    		if (strHub_PostOnboarding_ExpectedTitle.contentEquals(strHub_PostOnboarding_ActualTitle.getText())) {
    			ExtentReportHelper.StepPass(strHub_PostOnboarding_ExpectedTitle + " Screen# is displayed.");
    		}
    		else
    		{
    			Assert.assertEquals(strHub_PostOnboarding_ActualTitle.getText(), strHub_PostOnboarding_ExpectedTitle,"'Hub Post Onboard sreen is NOT as Expected.");
    		}	
    		
 		}
	
	
	@Then("^Verify 'Hub PostOnboarding' Screen when Click on 'Back to eHome Hub' button when selects 'Any Liabilities'$")
	public void Verify_Liability_Source_Screen_when_Click_on_Back_button_when_selects_Any_Liabilities() throws Throwable {
		Map<String, String> Stage06_ExpectedData =  Utility.readTestData(strfullPathToFile, sheetStage06_ExpectedData,strtestCaseID);
		Map<String, String> Stage06_InputData =  Utility.readTestData(strfullPathToFile, sheetStage06_InputData,strtestCaseID);
			
		String strLiability_Details_ExpectedTitle	= Stage06_ExpectedData.get("Liability_Sources_Details_Title"); 
		String strAlimonyLiability	= Stage06_InputData.get("LiabilitySources_Alimony");
		String strAlimonyLiabilityMonthlyPaymt = Stage06_InputData.get("LiabilitySources_Alimony_Monthly_Pymt");
		String strHub_PostOnboarding_ExpectedTitle	= Stage06_ExpectedData.get("HubPostOnboard_HowYourMortJrny_Title"); 

		QAFExtendedWebElement strLiability_Details_ActualTitle= new QAFExtendedWebElement("ehome.liabilitySrcDetails.Title");
		
		CommonAppMethodsAssetLiabilities.SelectLiabilitySources(strAlimonyLiability); 
		Common.continueButtonClicked();
		CommonAppMethodsAssetLiabilities.EnterLiabilityCalculateAmount(strAlimonyLiability, strAlimonyLiabilityMonthlyPaymt);
		Utility.clickObject("//*[@id=\"app\"]/div/div[1]/div[4]/button[2]/span", "Button");
		
		
		strBacktoeHomeHubBtn.click();
		if (strHub_PostOnboarding_ExpectedTitle.contentEquals(strHub_PostOnboarding_ActualTitle.getText())) {
			ExtentReportHelper.StepPass(strHub_PostOnboarding_ExpectedTitle + " Screen# is displayed.");
		}
		else
		{
			Assert.assertEquals(strHub_PostOnboarding_ActualTitle.getText(), strHub_PostOnboarding_ExpectedTitle,"'Hub Post Onboard sreen is NOT as Expected.");
		}	
				
//		strBacktoeHomeHubBtn.click();
//		Thread.sleep(500);
//		if (strLiability_Details_ExpectedTitle.contentEquals(strLiability_Details_ActualTitle.getText())) {
//			ExtentReportHelper.StepPass(strLiability_Details_ExpectedTitle + " Screen# is displayed.");
//		}
//		else
//		{
//			Assert.assertEquals(strLiability_Details_ActualTitle.getText(), strLiability_Details_ExpectedTitle,"'Liability Source Detail sreen is NOT as Expected.");
//		}	
	}
	
	
	
	@Then("^Verify 'Document Upload' Screen when Click on 'Start' button when selects 'No other liabilities'$")
	public void Verify_Document_Upload_Screen_when_Click_on_Start_button_when_selects_No_other_liabilities() throws Throwable {
		Map<String, String> Stage06_ExpectedData =  Utility.readTestData(strfullPathToFile, sheetStage06_ExpectedData,strtestCaseID);
			String strDocument_Upload_ExpectedTitle	= Stage06_ExpectedData.get("Document_Upload_Title"); 
			strStartBtn.click();
    		if (strDocument_Upload_ExpectedTitle.contentEquals(strdocUpload_ActualTitle.getText())) {
    			ExtentReportHelper.StepPass(strDocument_Upload_ExpectedTitle + " Screen# is displayed.");
    		}
    		else
    		{
    			Assert.assertEquals(strdocUpload_ActualTitle.getText(), strDocument_Upload_ExpectedTitle,"'Document Upload sreen is NOT as Expected.");
    		}	
 		}
	
	
}
