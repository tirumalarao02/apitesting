package com.scotiabank.ehome.ui.steps.stage4;

import org.openqa.selenium.By;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.qmetry.qaf.automation.step.QAFTestStepProvider;
import com.qmetry.qaf.automation.ui.WebDriverTestBase;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebDriver;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.quantum.utils.ConfigurationUtils;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

@QAFTestStepProvider
public class AssetSources {
	
	private QAFExtendedWebDriver webDriver = null;
	public Actions action = null;
    public WebDriverWait wait=null;
    
	QAFExtendedWebElement employmentStatusUnEmployed= new QAFExtendedWebElement("ehome.AssetSources.employmentStatusUnEmployed");
	QAFExtendedWebElement employmentStatusRetired= new QAFExtendedWebElement("ehome.AssetSources.employmentStatusRetired");
	QAFExtendedWebElement employmentStatusRetiredYears= new QAFExtendedWebElement("ehome.AssetSources.employmentStatusRetiredYears");
	QAFExtendedWebElement employmentStatusRetiredMonths= new QAFExtendedWebElement("ehome.AssetSources.employmentStatusRetiredMonths");
	QAFExtendedWebElement Back= new QAFExtendedWebElement("ehome.AssetSources.Back");
	QAFExtendedWebElement ContinueButton= new QAFExtendedWebElement("ehome.AssetSources.ContinueButton");
	QAFExtendedWebElement Nosourcesofincome= new QAFExtendedWebElement("ehome.AssetSources.Nosourcesofincome");
	QAFExtendedWebElement Continue= new QAFExtendedWebElement("ehome.AssetSources.Continue");
	
	QAFExtendedWebElement scotiabankLogo = new QAFExtendedWebElement("ehome.scotiabanklogo.image");
	QAFExtendedWebElement applicationTracter= new QAFExtendedWebElement("ehome.applicationstatustracker.image");
	QAFExtendedWebElement userloginname= new QAFExtendedWebElement("ehome.userloginname.image");
		
	QAFExtendedWebElement childSupport= new QAFExtendedWebElement("ehome.AssetSources.childSupport");
	QAFExtendedWebElement header= new QAFExtendedWebElement("ehome.AssetSources.header");
	QAFExtendedWebElement doyouhaveanyassets= new QAFExtendedWebElement("ehome.AssetSources.doyouhaveanyassets");
	QAFExtendedWebElement plsselectall= new QAFExtendedWebElement("ehome.AssetSources.plsselectall");
	QAFExtendedWebElement SourcesOfIncomeHeader= new QAFExtendedWebElement("ehome.SourcesOfIncome.Header");
	QAFExtendedWebElement Automobiletext= new QAFExtendedWebElement("ehome.AssetSources.Automobiletext");
	QAFExtendedWebElement Cashtext= new QAFExtendedWebElement("ehome.AssetSources.Cashtext");
	QAFExtendedWebElement AutomobiletextSelected= new QAFExtendedWebElement("ehome.AssetSources.AutomobiletextSelected");
	QAFExtendedWebElement CashtextSelected= new QAFExtendedWebElement("ehome.AssetSources.CashtextSelected");
	QAFExtendedWebElement AssestsOutsideScotiaHeader= new QAFExtendedWebElement("ehome.AssestsOutsideScotia.Header");
	QAFExtendedWebElement DoyouhaveanyassetsHeader= new QAFExtendedWebElement("ehome.Doyouhaveanyassets.DoyouhaveanyassetsHeader");
	
	@Given("^Customer should login and select 'current employment status' as \"([^\"]*)\" and navigate to Asset Sources screen$")
	public void customer_should_login_and_select_current_employment_status_as_and_navigate_to_Asset_Sources_screen(String employmentStatus) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		webDriver = new WebDriverTestBase().getDriver();
        webDriver.get(ConfigurationUtils.getBaseBundle().getPropertyValue("env.baseurl3"));
        webDriver.manage().window().maximize();
        int waitTime=10000;
        Continue.click();
        Thread.sleep(5000);
        WebDriverWait wait = new WebDriverWait(webDriver, 10);	
                
        if (employmentStatus.equals("Unemployed"))
        {
        	employmentStatusUnEmployed.click();
        	childSupport.waitForVisible(waitTime);
        //	childSupport.click();
        //	investments.waitForPresent(waitTime);
        //   investments.click();
        //    pension.waitForPresent(waitTime);
        //    pension.click();
            
        }
        else if (employmentStatus.equals("Retired"))
        {
        	employmentStatusRetired.click();
        	Thread.sleep(5000);
        	Select employmentStatusRetiredYrs =  new Select(employmentStatusRetiredYears);
    	    employmentStatusRetiredYrs.selectByIndex(3);
    	    
    	    Select employmentStatusRetiredMnths =  new Select(employmentStatusRetiredMonths);
    	    employmentStatusRetiredMnths.selectByIndex(3);
        	Thread.sleep(5000);
        	
        }
        Nosourcesofincome.click();
        
	}

	@Then("^Verify 'Scotia bank Logo' should be as \"([^\"]*)\" on the screen, Verify 'Application status' should be as \"([^\"]*)\" tracker on the screen, Verify for the 'Login username' as \"([^\"]*)\" on the screen, Verify the 'chat icon' functionality as \"([^\"]*)\" on the screen, 'Back' button should be as \"([^\"]*)\", 'No Other Assets' button as \"([^\"]*)\" in Asset Sources screen$")
	public void verify_Scotia_bank_Logo_should_be_as_on_the_screen_Verify_Application_status_should_be_as_tracker_on_the_screen_Verify_for_the_Login_username_as_on_the_screen_Verify_the_chat_icon_functionality_as_on_the_screen_Back_button_should_be_as_No_Other_Assets_button_as_in_Asset_Sources_screen(String arg1, String arg2, String arg3, String arg4, String arg5, String arg6) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		 // Write code here that turns the phrase above into concrete actions
    	scotiabankLogo.assertPresent ("Couldn't find the ScotiaBank logo"  );
 	     if(!scotiabankLogo.verifyPresent())
 	            throw new AssertionError("Couldn't find the ScotiaBank logo");
 	 	//To Check Application status tracker
 		 
 	        applicationTracter.assertPresent ( "Application status tracker image is missing" );
 	        if(!applicationTracter.verifyPresent())
 	            throw new AssertionError("Couldn't find the Application status tracker");
 	   	 
// 	        userloginname.assertPresent (  );
// 	        if(!userloginname.verifyPresent())
// 	            throw new AssertionError("Couldn't find the Login username");
 	        
 	      //To Check Login username should be on the Right corner
// 	        String result=userloginname.getCssValue("float");
// 	        Assert.assertEquals("right",result);
// 	        if(!userloginname.getCssValue("float").contentEquals( "right"  ))
// 	            throw new AssertionError("Userloginname is not in the right corner");
 	        Back.isPresent();
	}
	

	@Then("^Verify content 'Message' as \"([^\"]*)\" , 'Do you have any assets outside of Scotiabank\\?' as \"([^\"]*)\" , 'Please select all that apply' as \"([^\"]*)\"$")
	public void verify_content_Message_as_Do_you_have_any_assets_outside_of_Scotiabank_as_Please_select_all_that_apply_as(String messagetxt, String doyouhaveanyassetstxt, String plsselectalltxt) throws Throwable {
    // Write code here that turns the phrase above into concrete actions
		header.waitForVisible(2000);
		Assert.assertEquals(header.getText(), messagetxt,"Message text");
		Assert.assertEquals(doyouhaveanyassets.getText(), doyouhaveanyassetstxt,"Do you have any Assets outside of Scotibank text");
		Assert.assertEquals(plsselectall.getText(), plsselectalltxt,"Please select all that apply");
		
	}

	@When("^Click on Back button in Asset Sources screen$")
	public void click_on_Back_button_in_Asset_Sources_screen() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Back.waitForVisible(2000);
		Back.click();
	}
	
	@Then("^navigate to 'Do you have any sources of income\\?' page\\.$")
	public void navigate_to_Do_you_have_any_sources_of_income_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		SourcesOfIncomeHeader.assertPresent ("Couldn't find the Header"  );
	     if(!SourcesOfIncomeHeader.verifyPresent())
	            throw new AssertionError("Couldn't find the Header");
	}
	
	@When("^Selecting \"([^\"]*)\" , \"([^\"]*)\" in Asset Sources screen$")
	public void selecting_in_Asset_Sources_screen(String arg1, String arg2) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Automobiletext.click();
		Cashtext.click();
	}

	@Then("^\"([^\"]*)\" , \"([^\"]*)\" should be selected in Asset Sources screen$")
	public void should_be_selected_in_Asset_Sources_screen(String arg1, String arg2) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		
		AutomobiletextSelected.assertPresent ("Couldn't find the Automobile Selected"  );
	     if(!AutomobiletextSelected.verifyPresent())
	            throw new AssertionError("Couldn't find the Automobile Selected");

	     CashtextSelected.assertPresent ("Couldn't find the Cash Selected"  );
	     if(!CashtextSelected.verifyPresent())
	            throw new AssertionError("Couldn't find the Cash Selected");
	}
	
	@When("^Click on Continue button in Asset Sources screen$")
	public void click_on_Continue_button_in_Asset_Sources_screen() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Nosourcesofincome.click();
		Thread.sleep(2000);
		ContinueButton.click();
	}

	@Then("^navigate to 'Do you have any assets outside of Scotiabank\\?' page.$")
	public void navigate_to_Do_you_have_any_assets_outside_of_Scotiabank_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		DoyouhaveanyassetsHeader.waitForVisible(2000);
		DoyouhaveanyassetsHeader.assertPresent ("Couldn't find the Header"  );
	     if(!DoyouhaveanyassetsHeader.verifyPresent())
	            throw new AssertionError("Couldn't find the Header");
	}

}
