package com.scotiabank.ehome.ui.steps.stage1;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.step.QAFTestStepProvider;
import com.qmetry.qaf.automation.ui.WebDriverTestBase;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebDriver;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.quantum.utils.ConfigurationUtils;
import com.scotiabank.ehome.ui.steps.Common;
import com.scotiabank.ehome.ui.steps.ExcelDataToDataTable;
import com.scotiabank.ehome.ui.steps.Utility;
import com.scotiabank.ehome.ui.steps.valueObjects.Tuple;
import com.scotiabank.ehome.ui.steps.valueObjects.TypeOfRateVO;
import com.thoughtworks.qdox.model.expression.Add;

import org.junit.runner.RunWith;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;

import cucumber.api.CucumberOptions;
import cucumber.api.DataTable;
import cucumber.api.PendingException;
import cucumber.api.Transform;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import cucumber.api.junit.Cucumber;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import static com.scotiabank.ehome.ui.steps.BusinessCalculations.*;
import static com.scotiabank.ehome.ui.steps.Utility.*;

import org.openqa.selenium.Keys;
@QAFTestStepProvider

public class SOLCustomerQuestion {
	public static WebDriverWait wait=Utility.getWait();	
	@Given("^Customer should login and navigates to SOL Customer Question Screen$")
	public void customer_should_login_and_navigates_to_SOL_Customer_Question_Screen() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Utility.launchURL(ConfigurationUtils.getBaseBundle().getPropertyValue ("env.baseurl0"));
		Welcome.viewOurPrivacyAgreementButtonClicked();
		PrivacyAgreement.acceptAndContinuetButtonClicked();
		triageQuestionsButtonClicked();
		
	}

	@When("^Verify \"([^\"]*)\" message should be on the SOL Customer Question Screen$")
	public void verify_message_should_be_on_the_SOL_Customer_Question_Screen(String dataPointer) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String testCaseID = Utility.getScenarioID();
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage01_Registration_ExpectedDa", testCaseID, dataPointer);
		QAFExtendedWebElement message= new QAFExtendedWebElement("ehome.SOL.message");
		 wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(message));
		Assert.assertEquals(message.getText(), value,"Couldn't found expected header message");
	    
	}
	@Then("^Verify \"([^\"]*)\" headertext should be on SOL Customer Question Screen$")
	public void verify_headertext_should_be_on_the_SOL_Customer_Question_Screen(String dataPointer) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String testCaseID = Utility.getScenarioID();
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage01_Registration_ExpectedDa", testCaseID, dataPointer);
		QAFExtendedWebElement title= new QAFExtendedWebElement("ehome.SOL.title");
		 wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(title));
		Assert.assertEquals(title.getText(), value,"Couldn't found expected header message");
			    
	}
	
	

	@Then("^It should navigate to triage questions screen$")
	public void it_should_navigate_to_triage_questions_screen() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    Thread.sleep(5000);
	}
	public static void triageQuestionsButtonClicked() throws Exception{
		Thread.sleep(5000);
    	QAFExtendedWebElement yes= new QAFExtendedWebElement("ehome.Triage.yes");
	    wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(yes));
	    QAFExtendedWebElement no= new QAFExtendedWebElement("ehome.Triage.no");
	    wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(no));
	    yes.click();
	    QAFExtendedWebElement oneFront = new QAFExtendedWebElement("//*[@id='prompt-card-1']");
	    wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.attributeToBe(oneFront, "class", "prompt-card prompt-card--animate prompt-card--hide-back prompt-card--stack-front"));
	    no.click();
	    oneFront = new QAFExtendedWebElement("//*[@id='prompt-card-2']");
	    wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.attributeToBe(oneFront, "class", "prompt-card prompt-card--animate prompt-card--hide-back prompt-card--stack-front"));
	    yes.click();
	    oneFront = new QAFExtendedWebElement("//*[@id='prompt-card-3']");
	    wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.attributeToBe(oneFront, "class", "prompt-card prompt-card--animate prompt-card--hide-back prompt-card--stack-front"));
	    no.click();
	    oneFront = new QAFExtendedWebElement("//*[@id='prompt-card-4']");
	    wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.attributeToBe(oneFront, "class", "prompt-card prompt-card--animate prompt-card--hide-back prompt-card--stack-front"));
	    yes.click();
	    oneFront = new QAFExtendedWebElement("//*[@id='prompt-card-5']");
	    wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.attributeToBe(oneFront, "class", "prompt-card prompt-card--animate prompt-card--hide-back prompt-card--stack-front"));
	    no.click();
	    
	}
	
	@When("^Click triage questions screen$")
	public void click_triage_questions_screen() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		triageQuestionsButtonClicked();
	    
	}

	
	public static void yesButtonClicked() throws Exception{	
		QAFExtendedWebElement yes= new QAFExtendedWebElement("ehome.SOL.yes");
	    wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(yes));
		yes.click();
		
	}
	public static void noButtonClicked() throws Exception{	
		QAFExtendedWebElement no= new QAFExtendedWebElement("ehome.SOL.no");
	    wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(no));
		no.click();
		
	}
	@When("^Click on the \"([^\"]*)\" button on SOL Customer Question Screen$")
	public void click_on_the_button_on_SOL_Customer_Question_Screen(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		if(arg1.contentEquals("Yes")) {
			yesButtonClicked();
			
			
		}
		else if (arg1.contentEquals("No")) {
			noButtonClicked();
					
		}
		
	    
	}

	@Then("^It should navigate to Phonics screen$")
	public void it_should_navigate_to_Phonics_screen() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    
	}

	@Then("^It should navigate to legal name screen$")
	public void it_should_navigate_to_legal_name_screen() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    
	}

}
