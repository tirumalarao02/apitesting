package com.scotiabank.ehome.ui.steps.stage3;
import com.qmetry.qaf.automation.step.QAFTestStepProvider;
import com.qmetry.qaf.automation.ui.WebDriverTestBase;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebDriver;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.quantum.utils.ConfigurationUtils;
import com.scotiabank.ehome.ui.steps.Common;
import com.scotiabank.ehome.ui.steps.ExcelDataToDataTable;
import com.scotiabank.ehome.ui.steps.Utility;
import com.scotiabank.ehome.ui.steps.valueObjects.Tuple;
import com.scotiabank.ehome.ui.steps.valueObjects.TypeOfRateVO;

import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;

import cucumber.api.DataTable;
import cucumber.api.Transform;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import static com.scotiabank.ehome.ui.steps.BusinessCalculations.*;
import static com.scotiabank.ehome.ui.steps.Utility.*;
@QAFTestStepProvider
public class TypeOfRate {
	private QAFExtendedWebDriver webDriver = new WebDriverTestBase().getDriver();
    public Actions action = null;
    WebDriverWait wait = new WebDriverWait(webDriver,50000);

    //Scenario: Type_Of_Rate_001
    String testCaseID = Utility.getScenarioID();

    @Given("^Customer should login and navigates to Stage 3 Type of Rate$")
    public void Customer_should_login_and_navigates_to_Stage_3_RateType_of_Rate() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	 Utility.launchURL(ConfigurationUtils.getBaseBundle().getPropertyValue("env.baseurl"));
        QAFExtendedWebElement buttonContinue= new QAFExtendedWebElement("ehome.rate.continue.button");
        wait.until(ExpectedConditions.visibilityOf(buttonContinue));
        buttonContinue.click();
        
     }
    //Scenario: Type_Of_Rate_002
    @When("^Verify \"([^\"]*)\" in Type of Rate Screen$")
    public void VerifyLetsgetstartedinRateTypeScreen(String dataPointer) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	String testCaseID = Utility.getScenarioID();
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage03_Rate_ExpectedData", testCaseID, dataPointer);
		Assert.assertEquals(Common.headerMessage(), value,"Couldn't found expected header text");
    }

    @Then("^\"([^\"]*)\" text should be displayed in Type of Rate Screen$")
    public void WhattypeofrateareyoulookingfortextshouldbedisplayedinRateTypeScreen(String dataPointer) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage03_Rate_ExpectedData", testCaseID, dataPointer);
		QAFExtendedWebElement headertext= new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[1]/section/div[2]/p");
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(headertext));
		Thread.sleep(2000);
		Assert.assertEquals(headertext.getText(), value,"Couldn't found expected header text");
    }
    //Scenario: Type_Of_Rate_003
    @When("^Verify \"([^\"]*)\" and \"([^\"]*)\" text in a separate Box in Type of Rate Screen$")
    public void verify_and_text_in_a_separate_Box_in_Type_of_Rate_Screen(String dataPointer1, String dataPointer2) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage03_Rate_ExpectedData", testCaseID, dataPointer1);
		QAFExtendedWebElement fixedText= new QAFExtendedWebElement("ehome.typeofrate.fixed.text");
        Assert.assertEquals(fixedText.getText(), value,"Couldn't find the Fixed text");
        
        String value1=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage03_Rate_ExpectedData", testCaseID, dataPointer2);
		QAFExtendedWebElement contentInFixedBox= new QAFExtendedWebElement("ehome.typeofrate.contentinfixedbox.text");
        Assert.assertEquals(contentInFixedBox.getText(), value1,"Interest rate won’t change for the term of your mortgage is not displayed");
    }
   

    @Then("^Check the \"([^\"]*)\" radio button in Type of Rate screen$")
    public void check_the_select_fixed_radio_button_in_Type_of_Rate_screen(String dataPointer) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        //To check the select text
    	QAFExtendedWebElement SelectFixed= new QAFExtendedWebElement("ehome.typeofrate.selectfixed.radio");
        String value1=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage03_Rate_ExpectedData", testCaseID, dataPointer);
		Assert.assertEquals(SelectFixed.getText(), value1,"Fixed select didn't matched");
        //SelectFixed.assertText("Select");
        //To check the select deselected by default
        String result=SelectFixed.getCssValue("color");
        Assert.assertEquals("rgba(117, 117, 117, 1)",result);
        //To check On hover on the select button
        webDriver = new WebDriverTestBase().getDriver();
        Actions action = new Actions(webDriver);
        action = new Actions(webDriver);
        action.moveToElement (SelectFixed).build ().perform ();
        //TO check Select button should be highlighted
        action.moveToElement (SelectFixed).build ().perform ();
        QAFExtendedWebElement selectFixedUpt= new QAFExtendedWebElement("ehome.typeofrate.selectfixed.background");
        String color=selectFixedUpt.getCssValue("background-color");
        String hex = convertRGBToHex(color);
        Assert.assertEquals("#8230df",hex);
        if(!hex.contentEquals("#8230df"))
            throw new AssertionError("Select on hover is not highlighted with #8230df color");

    }
    @When("^click on radio button Select in Fixed Screen Select label should be disappeared and the radio button Select should be highlighted and checked$")
    public void click_on_radio_button_Select_in_Fixed_Screen_Select_label_should_be_disappeared_and_the_radio_button_Select_should_be_highlighted_and_checked() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        QAFExtendedWebElement selectFixed= new QAFExtendedWebElement("ehome.typeofrate.selectfixed.radio");
        selectFixed.click ();
        TypeOfRateVO.getInstance().setTypeOfRate(TypeOfRateVO.TYPE_OF_RATE_FIXED_RATE);
        Thread.sleep(3000);
        QAFExtendedWebElement backButtontermofrate = new QAFExtendedWebElement("ehome.termofrate.back.button");
        Assert.assertEquals(backButtontermofrate.getText(), "Back", "Back Button text does not matched");
        backButtontermofrate.click ();
        Thread.sleep(3000);
        QAFExtendedWebElement selectchecked= new QAFExtendedWebElement("ehome.typeofrateselectchecked.input");
        String checked=selectchecked.getAttribute("checked");
        if(checked==null || !checked.contentEquals("true"))
            throw new AssertionError("Couldn't find the checked");
        QAFExtendedWebElement selectFixedUpt= new QAFExtendedWebElement("ehome.typeofrate.selectfixed.background");
        String color=selectFixedUpt.getCssValue("background-color");
        String hex = convertRGBToHex(color);
        Assert.assertEquals("#8230df",hex);
        if(!hex.contentEquals("#8230df"))
            throw new AssertionError("Select on hover is not highlighted with #8230df color");
        //To check the continue button is there and it should be in red color and click on the continue button
        QAFExtendedWebElement continuewhaytypeofrate = new QAFExtendedWebElement("ehome.typeofrate.continue.button");
        Assert.assertEquals(continuewhaytypeofrate.getText(), "Continue", "Contnue Button text does not matched");
        Assert.assertEquals(convertRGBToHex(continuewhaytypeofrate.getCssValue("color")), "#ed722", "Continue button not in Red color");
        continuewhaytypeofrate.click();
    }

    @Then("^It should navigate to Term of Rate screen$")
    public void ItshouldnavigatetoTermofRatescreen() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        Thread.sleep(3000);
        QAFExtendedWebElement termofrate = new QAFExtendedWebElement("ehome.termofrate.header");
        Assert.assertEquals(termofrate.getText(), "What mortgage term are you looking for?","Not able to launch screen What mortgage term are you looking for?");


    }
    //Scenario: Type_Of_Rate_004
    @When("^Verify \"([^\"]*)\" text and \"([^\"]*)\" text in a separate Box in Type of Rate Screen$")
    public void verify_text_and_text_in_a_separate_Box_in_Type_of_Rate_Screen(String dataPointer1, String dataPointer2) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	String value1=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage03_Rate_ExpectedData", testCaseID, dataPointer1);
        QAFExtendedWebElement variableText = new QAFExtendedWebElement("ehome.typeofrate.variable.text");
        Assert.assertEquals(variableText.getText(),value1,"Couldn't find the variable text");
        String value2=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage03_Rate_ExpectedData", testCaseID, dataPointer2);
        QAFExtendedWebElement contentinvariablebox = new QAFExtendedWebElement("ehome.typeofrate.contentinvariablebox.text");
        Assert.assertEquals(contentinvariablebox.getText(), value2,"Content in the variable box din't matched");
    }

    @Then("^Check the \"([^\"]*)\" radio button in Type of Rate screen$")
    public void check_the_select_variable_radio_button_in_Type_of_Rate_screen(String dataPointer) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        //To check the select text
    	  QAFExtendedWebElement selectVariable= new QAFExtendedWebElement("ehome.typeofrate.selectvariable.radio");
        String value1=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage03_Rate_ExpectedData", testCaseID, dataPointer);
		Assert.assertEquals(selectVariable.getText(), value1,"Fixed select didn't matched");
		        
        //To check the select deselected by default
        String result=selectVariable.getCssValue("color");
        Assert.assertEquals("rgba(117, 117, 117, 1)",result);
        if(!selectVariable.getCssValue("color").contentEquals( "rgba(117, 117, 117, 1)"  ))
            throw new AssertionError("Variable select is not deselected");
        //To check On hover on the select button
        QAFExtendedWebElement selectVarible= new QAFExtendedWebElement("ehome.typeofrate.selectvariable.background");
        webDriver = new WebDriverTestBase().getDriver();
        Actions action = new Actions(webDriver);
        action = new Actions(webDriver);
        action.moveToElement (selectVarible).build ().perform ();
        String color=selectVarible.getCssValue("background-color");
        String hex = convertRGBToHex(color);
        Assert.assertEquals("#8230df",hex);
        if(!hex.contentEquals("#8230df"))
            throw new AssertionError("Select on hover is not highlighted with #8230df color");


    }
    @When("^click on radio button Select in variable Screen Select label should be disappeared and the radio button Select should be highlighted and checked$")
    public void click_on_radio_button_Select_for_the_Type_Of_Rate_Variable_component_in_What_type_of_Rate_you_are_looking_for_Screen() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        QAFExtendedWebElement selectVariable= new QAFExtendedWebElement("ehome.typeofrate.selectvariable.radio");
        selectVariable.click ();
        TypeOfRateVO.getInstance().setTypeOfRate(TypeOfRateVO.TYPE_OF_RATE_VARIABLE_RATE);
        Thread.sleep(3000);
        //To click on the back button
        QAFExtendedWebElement backButtonYouSelectVariablePage = new QAFExtendedWebElement("ehome.onlineExclusiveMorgage.back.button");
        Assert.assertEquals(backButtonYouSelectVariablePage.getText(), "Back", "Back Button text does not matched");
        backButtonYouSelectVariablePage.click ();
        Thread.sleep(3000);
        //To check Select label should be disappeared and the radio button Select should be highlighted and checked
        QAFExtendedWebElement selectchecked= new QAFExtendedWebElement("ehome.typeofrateselectvariblechecked.input");
        String checked=selectchecked.getAttribute("checked");
        if(checked==null || !checked.contentEquals("true"))
            throw new AssertionError("Couldn't find the checked");
        QAFExtendedWebElement selectFixedUpt= new QAFExtendedWebElement("ehome.typeofrate.selectvariable.background");
        String color=selectFixedUpt.getCssValue("background-color");
        String hex = convertRGBToHex(color);
        Assert.assertEquals("#8230df",hex);
        System.out.println("HEX"+hex);
        if(!hex.contentEquals("#8230df"))
            throw new AssertionError("Select when cliked is not highlighted with #8230df color");
        //To check the continue button is there and it should be in red color and click on the continue button
        QAFExtendedWebElement continuewhaytypeofrate = new QAFExtendedWebElement("ehome.typeofrate.continue.button");
        Assert.assertEquals(continuewhaytypeofrate.getText(), "Continue", "Contnue Button text does not matched");
        Assert.assertEquals(convertRGBToHex(continuewhaytypeofrate.getCssValue("color")), "#ed722", "Continue button not in Red color");
        continuewhaytypeofrate.click();

    }
    @Then("^It should navigate to rate Presentation screen$")
    public void ItshouldnavigatetoratePresentationscreen() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        QAFExtendedWebElement ratepresentationHeader = new QAFExtendedWebElement("ehome.ratepresentation.header.Text");
        Assert.assertEquals(ratepresentationHeader, "Choose from these online exclusive mortgage offers we have just for you!","Not able to launch screen 'Choose from these online exclusive mortgage offers we have just for you!");

    }

    //Scenario: Type_Of_Rate_005

    @When("^Click on Back button in Type of Rate screen$")
    public void ClickonBackbuttoninRatetypescreen() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        QAFExtendedWebElement backButtontypeofrate = new QAFExtendedWebElement("ehome.typeofrate.back.button");
        backButtontypeofrate.click ();

    }

    @Then("^Back button should return to the previous sectionbreaker3 screen$")
    public void Backbuttonshouldreturntotheprevioussectionbreaker3screen() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        Thread.sleep(3000);
        QAFExtendedWebElement sectionbreaker3= new QAFExtendedWebElement("ehome.rate.Header.text");
        Assert.assertEquals(sectionbreaker3.getText(), "Exclusive Online Offers","Not able to launch screen We have some amazing online-only mortgage rates to offer you!");
    }

    //Scenario: Type_Of_Rate_006
   
    @When("^Click on continue button in Type of Rate screen$")
    public void ClickoncontinuebuttoninTypeofRatescreen() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        QAFExtendedWebElement continuewhaytypeofrate = new QAFExtendedWebElement("ehome.typeofrate.continue.button");
        Assert.assertEquals(continuewhaytypeofrate.getText(), "Continue", "Continue Button text does not matched");
        Assert.assertEquals(convertRGBToHex(continuewhaytypeofrate.getCssValue("color")), "#ed722", "Continue button not in Red color");
        continuewhaytypeofrate.click();

    }

    @Then("^Screen will be navigated to Screen \"([^\"]*)\" and the radio button fixed_select still should be highlighted and checked$")
    public void screen_will_be_navigated_to_Screen_and_the_radio_button_fixed_select_still_should_be_highlighted_and_checked(String dataPointer) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage03_Rate_ExpectedData", testCaseID, dataPointer);
		QAFExtendedWebElement headertext= new QAFExtendedWebElement("ehome.Header1.text");
		Assert.assertEquals(headertext.getText(), value,"Couldn't found expected header text");
        QAFExtendedWebElement radioButtonSelected = new QAFExtendedWebElement("ehome.typeofrate.selectfixed.radio.button");
        //System.out.println("Checked Value: "+radioButtonSelected.getAttribute("checked"));
        Assert.assertEquals(radioButtonSelected.getAttribute("checked"), "true", "Variable Value Radio button not selected");

    }
    
    @Then("^Screen will be navigated to Screen \"([^\"]*)\" and the radio button variable_select still should be highlighted and checked$")
    public void screen_will_be_navigated_to_Screen_and_the_radio_button_variable_select_still_should_be_highlighted_and_checked(String dataPointer) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage03_Rate_ExpectedData", testCaseID, dataPointer);
		QAFExtendedWebElement headertext= new QAFExtendedWebElement("ehome.Header1.text");
		Assert.assertEquals(headertext.getText(), value,"Couldn't found expected header text");
        QAFExtendedWebElement radioButtonSelected = new QAFExtendedWebElement("ehome.whattypeofrate.selectvariable.radio.button");
        //System.out.println("Checked Value: "+radioButtonSelected.getAttribute("checked"));
        Assert.assertEquals(radioButtonSelected.getAttribute("checked"), "true", "Variable Value Radio button not selected");

    }



    //Scenario: Type_Of_Rate_007

    @And ("^Verify Tell me more hyperlink and Overlay icon in the Type of Rate screen$")
    public void VerifyTellmemorehyperlinkandOverlayiconintheTypeofRatescreen() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        //To check Tell me more hyperlink
        QAFExtendedWebElement Tellmemore= new QAFExtendedWebElement("ehome.tellmemore.button");
        webDriver = new WebDriverTestBase().getDriver();
        Actions action = new Actions(webDriver);
        action = new Actions(webDriver);
        action.moveToElement (Tellmemore).build ().perform ();
        Boolean cursor= Tellmemore.getCssValue("cursor").contentEquals("pointer");
        if(!Tellmemore.getCssValue("cursor").contentEquals( "pointer"  ))
            throw new AssertionError("NO handicon on hover");
        //To check Overlay icon
        QAFExtendedWebElement overlayIcon = new QAFExtendedWebElement("ehome.tellmemoreoverlay.icon");
        overlayIcon.assertPresent (  );
        if(!overlayIcon.isDisplayed())
            throw new AssertionError(" overlay icon beside Tell me more is not displayed");
    }

    @When("^Click on the Tell me more hyperlink in Type of Rate screen$")
    public void ClickontheTellmemorehyperlinkinTypeofRatescreen() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        QAFExtendedWebElement tellmemore = new QAFExtendedWebElement("ehome.tellmemore.button");
        //Thread.sleep ( 5000 );
        tellmemore.click ();
        if(!tellmemore.verifyText("Tell me more"))
            throw new AssertionError("Not able to see Tell me more");
    }

    @Then("^It should navigate to More about Fixed and variable Rates page$")
    public void it_should_navigate_to_More_about_Fixed_and_variable_Rates_page() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        QAFExtendedWebElement moreaboutfixedandvariablerates = new QAFExtendedWebElement("ehome.moreaboutfixedandvariablerates.header");
        moreaboutfixedandvariablerates.assertText ( "More about fixed and variable rates" );
        if(!moreaboutfixedandvariablerates.verifyText("More about fixed and variable rates"))
            throw new AssertionError("Not able to see More about fixed and variable rates");
        //To check Select an option
        QAFExtendedWebElement consideryouroptions= new QAFExtendedWebElement("ehome.moreaboutfixedandvariablerates.consideryouroptions.select");
        consideryouroptions.assertPresent (  );
        if(!consideryouroptions.verifyPresent())
            throw new AssertionError("Couldn't find the consider your option");
    }
    @When("^Click on the close button in More about Fixed and variable Rates Screen$")
    public void ClickontheclosebuttoninMoreaboutFixedandvariableRatesScreen() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        QAFExtendedWebElement closeInMoreAboutFixedAndVariableRates = new QAFExtendedWebElement("ehome.moreaboutfixedandvariablerates.close.button");
        closeInMoreAboutFixedAndVariableRates.click ();
    }

    @Then("^More about Fixed and variable Rates page should be closed and back to Type of Rate screen$")
    public void  MoreaboutFixedandvariableRatespageshouldbeclosedandbacktoTypeofRatescreen() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        QAFExtendedWebElement typeofrate= new QAFExtendedWebElement("ehome.typeofrate.header");
        typeofrate.assertText ( "What type of rate are you looking for?"  );
        if(!typeofrate.verifyText( "What type of rate are you looking for?"  ))
            throw new AssertionError("Not able to see What type of rate are you looking for? page");


    }

    //Scenario: Type_Of_Rate_008
    @When("^Verify \"([^\"]*)\" in the select option$")
    public void VerifyConsideryourOptionintheselectoption(String dataPointer1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        QAFExtendedWebElement consideryouroptions= new QAFExtendedWebElement("ehome.moreaboutfixedandvariablerates.consideryouroptions.Fixed.li");
        String value1=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage03_Rate_ExpectedData", testCaseID, dataPointer1);
        Assert.assertEquals(consideryouroptions.getText(),value1,"Couldn't find the Fixed text");

    }

    @Then ("^Verify Fixed Box \"([^\"]*)\" and Fixed content Description text in a separate Box as \"([^\"]*)\"$")
    public void  VerifyFixedBoxFixedandFixedcontentDescriptiontextinaseparateBoxasYouwantthesecurityofknowingexactlywhatyourinterestrateandmortgagepaymentwillbeoverthetermofyourmortgage(String dataPointer1, String dataPointer2) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	String value1=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage03_Rate_ExpectedData", testCaseID, dataPointer1);
    	QAFExtendedWebElement FixedHeading= new QAFExtendedWebElement("ehome.moreaboutfixedandvariablerates.consideryouroptions.Fixed.text");
        Assert.assertEquals(FixedHeading.getText(),value1,"Couldn't find the Fixed text");
        String value2=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage03_Rate_ExpectedData", testCaseID, dataPointer2);
        QAFExtendedWebElement FixedContent= new QAFExtendedWebElement("ehome.moreaboutfixedandvariablerates.consideryouroptions.Fixed.Content");
        Assert.assertEquals(FixedContent.getText(), value2, "Couldn't find the Fixed content");

    }
    @And ("^Verify Variable Box as \"([^\"]*)\" and Variable content Description text in a separate Box as \"([^\"]*)\"$")
    public void  VerifyVariableBoxasVariableandVariablecontentDescriptiontextinaseparateBoxasYourecomfortablewithfluctuationsinyourinterestrateandmortgagepayment(String dataPointer1, String dataPointer2) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	String value1=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage03_Rate_ExpectedData", testCaseID, dataPointer1);
        QAFExtendedWebElement variableHeading= new QAFExtendedWebElement("ehome.moreaboutfixedandvariablerates.consideryouroptions.variable.text");
        Assert.assertEquals(variableHeading.getText(), value1, "variable Box not present on 'More about fixed and variable rates'");
        String value2=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage03_Rate_ExpectedData", testCaseID, dataPointer2);
        QAFExtendedWebElement variableContent= new QAFExtendedWebElement("ehome.moreaboutfixedandvariablerates.consideryouroptions.variable.Content");
        Assert.assertEquals(variableContent.getText(), value2, "Couldn't find the Fixed content");

    }
    @When("^Verify \"([^\"]*)\" features in the select option$")
    public void VerifyDiscoverKeyfeaturesintheselectoption(String dataPointer1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        //To check Discover Key features
    	String value1=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage03_Rate_ExpectedData", testCaseID, dataPointer1);
        QAFExtendedWebElement discoverKeyFeatures= new QAFExtendedWebElement("ehome.moreaboutfixedandvariablerates.discoverKeyFeatures.Fixed.li");
         Assert.assertEquals(discoverKeyFeatures.getText(), value1, "Not able to see Discover key features");
        
        QAFExtendedWebElement discoverKeyFeaturesclick= new QAFExtendedWebElement("ehome.moreaboutfixedandvariablerates.discoverKeyFeatures.Fixed.li");
        discoverKeyFeaturesclick.click();

        QAFExtendedWebElement discoverKeyFeatures1= new QAFExtendedWebElement("//*[@id=\"mortgage-rate-tab-1\"]");
        discoverKeyFeatures1.click();
        

    }
    @Then ("^Verify Fixed Box \"([^\"]*)\" and Fixed content Description text in a separate Box as \"([^\"]*)\" and \"([^\"]*)\"$")
    public void  VerifyFixedBoxFixedandFixedcontentDescriptiontextinaseparateBoxasEvenwheninterestrateschangeyourpaymentswillnotchangeyourrateandpaymentamountisfixedforthetermofyourmortgageandIfyoupayoutthemortgagebeforetheendofthetermthismayresultinaprepaymentchargeifyourtermisclosed(String dataPointer1, String dataPointer2, String dataPointer3) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	String value1=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage03_Rate_ExpectedData", testCaseID, dataPointer1);
        QAFExtendedWebElement discoverKeyFeaturesFixedheading= new QAFExtendedWebElement("//*[@id=\"mortgage-rate-pane-1\"]/div/div/div/div[1]/div/div/div/div[1]/h3");
        Assert.assertEquals(discoverKeyFeaturesFixedheading.getText(), value1, "Fixed Box not present on discoverKeyFeatures of 'More about fixed and variable rates'");
        String value2=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage03_Rate_ExpectedData", testCaseID, dataPointer2);
        QAFExtendedWebElement discoverKeyFeaturesFixedContentP1= new QAFExtendedWebElement("ehome.moreaboutfixedandvariablerates.discoverKeyFeatures.Fixed.ContentP1");
        Assert.assertEquals(discoverKeyFeaturesFixedContentP1.getText(), value2, "Even when interest rates change, your payments will not change - your rate and payment amount is fixed for the term of your mortgage.. not present onFixed box of 'More about fixed and variable rates'");
        String value3=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage03_Rate_ExpectedData", testCaseID, dataPointer3);
        QAFExtendedWebElement discoverKeyFeaturesFixedContentP2= new QAFExtendedWebElement("ehome.moreaboutfixedandvariablerates.discoverKeyFeatures.Fixed.ContentP2");
        Assert.assertEquals(discoverKeyFeaturesFixedContentP2.getText(), value3, "If you pay out the mortgage before the end of the term, this may result in a prepayment charge if your term is closed. not present onFixed box of 'More about fixed and variable rates'");

    }
    
    
   
    @Then("^Verify Variable Box as \"([^\"]*)\" and Variable content Description text in a separate Box as \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
    public void verify_Variable_Box_as_and_Variable_content_Description_text_in_a_separate_Box_as_and_and(String dataPointer1, String dataPointer2, String dataPointer3, String dataPointer4) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	String value1=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage03_Rate_ExpectedData", testCaseID, dataPointer1);
        QAFExtendedWebElement discoverKeyFeaturesvariableheading= new QAFExtendedWebElement("//*[@id=\"mortgage-rate-pane-1\"]/div/div/div/div[2]/div/div/div/div[1]/h3");
        Assert.assertEquals(discoverKeyFeaturesvariableheading.getText(), value1, "Fixed Box not present on discoverKeyFeatures of 'More about fixed and variable rates'");
        String value2=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage03_Rate_ExpectedData", testCaseID, dataPointer2);
        QAFExtendedWebElement discoverKeyFeaturesVariableContentP1= new QAFExtendedWebElement("//*[@id=\"mortgage-rate-pane-1\"]/div/div/div/div[2]/div/div/div/div[2]/p[1]");
        Assert.assertEquals(discoverKeyFeaturesVariableContentP1.getText(), value2, "Even when interest rates change, your payments will not change - your rate and payment amount is fixed for the term of your mortgage.. not present onFixed box of 'More about fixed and variable rates'");
        String value3=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage03_Rate_ExpectedData", testCaseID, dataPointer3);
        QAFExtendedWebElement discoverKeyFeaturesVariableContentP2= new QAFExtendedWebElement("//*[@id=\"mortgage-rate-pane-1\"]/div/div/div/div[2]/div/div/div/div[2]/p[2]");
        Assert.assertEquals(discoverKeyFeaturesVariableContentP2.getText(), value3, "If you pay out the mortgage before the end of the term, this may result in a prepayment charge if your term is closed. not present onFixed box of 'More about fixed and variable rates'");
        String value4=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage03_Rate_ExpectedData", testCaseID, dataPointer4);
        QAFExtendedWebElement discoverKeyFeaturesVariableContentP3= new QAFExtendedWebElement("//*[@id=\"mortgage-rate-pane-1\"]/div/div/div/div[2]/div/div/div/div[2]/p[3]");
        Assert.assertEquals(discoverKeyFeaturesVariableContentP3.getText(), value4, "If you pay out the mortgage before the end of the term, this may result in a prepayment charge if your term is closed. not present onFixed box of 'More about fixed and variable rates'");

   
    }
}

