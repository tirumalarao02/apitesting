package com.scotiabank.ehome.ui.steps.stage2;

import com.scotiabank.ehome.ui.steps.Common;
import com.scotiabank.ehome.ui.steps.Utility;
import cucumber.api.PendingException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;


import com.qmetry.qaf.automation.step.QAFTestStepProvider;
import com.qmetry.qaf.automation.ui.WebDriverTestBase;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebDriver;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.quantum.utils.ConfigurationUtils;


import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;


import org.testng.Assert;

import java.awt.*;
import java.awt.event.KeyEvent;
import java.util.HashMap;
import java.util.Map;

@QAFTestStepProvider
public class Addressofyournewhome {
	
	private QAFExtendedWebDriver webDriver = new WebDriverTestBase().getDriver();
	public Actions action = null;

    QAFExtendedWebElement addressLookUp= new QAFExtendedWebElement("ehome.whatstheaddress.addresslookup");
    QAFExtendedWebElement enteraddressmanually= new QAFExtendedWebElement("ehome.whatstheaddress.enteraddressmanually");
    QAFExtendedWebElement Continue= new QAFExtendedWebElement("ehome.tellus.continue.button");
    QAFExtendedWebElement firstthingsfirst= new QAFExtendedWebElement("ehome.whatstheaddress.firstthingsfirst");
    QAFExtendedWebElement Whatstheaddressofyournewhome= new QAFExtendedWebElement("ehome.whatstheaddress.Whatstheaddressofyournewhome");
    QAFExtendedWebElement backbutton= new QAFExtendedWebElement("ehome.whatstheaddress.backbutton");
	QAFExtendedWebElement addressLookupResults= new QAFExtendedWebElement("ehome.whatstheaddress.addresslookupresults");
	QAFExtendedWebElement ContinueAddressPage = new QAFExtendedWebElement("ehome.whatstheaddress.continue.button");
	QAFExtendedWebElement searchForYourAddress = new QAFExtendedWebElement("ehome.whatstheaddress.searchForYourAddress.link");
    QAFExtendedWebElement TypeofPropertyhouseselect= new QAFExtendedWebElement("ehome.whenistheclosingdate.TypeofPropertyhouseselect");

    WebDriverWait wait = new WebDriverWait(webDriver, 50000);

    String testCaseID = Utility.getScenarioID();
	 
    @Given("^Customer Should able to navigate to 'Now tell us about your new home' page\\.$")
    public void customer_Should_able_to_navigate_to_Now_tell_us_about_your_new_home_page() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	Utility.launchURL(ConfigurationUtils.getBaseBundle().getPropertyValue("env.baseurl1"));
     }

    @When("^Click on Continue button from 'Now tell us about your new home' page\\.$")
    public void click_on_Continue_button_from_Now_tell_us_about_your_new_home_page() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	if ( ConfigurationUtils.getBaseBundle().getPropertyValue("driver.name").equals("perfectoRemoteDriver")) 
    		Continue = new QAFExtendedWebElement("ehome.tellus.continue.button.mobile");
    	else
    		Continue = new QAFExtendedWebElement("ehome.tellus.continue.button");  
    	Continue.click();
    }

    @Then("^Verify ScotiaBank Logo is present and Application Tracker is present and Login UserName and Login Chat Icon and Login Chat Icon functionality is present and \"([^\"]*)\" text and \"([^\"]*)\" text and place holder for \"([^\"]*)\" text and \"([^\"]*)\" hyperlink text and \"([^\"]*)\" text$")
    public void verifyScotiaBankLogoIsPresentAndApplicationTrackerIsPresentAndLoginUserNameAndLoginChatIconAndLoginChatIconFunctionalityIsPresentAndTextAndTextAndPlaceHolderForTextAndHyperlinkTextAndText(String datapointer, String datapointer1, String datapointer2, String datapointer3, String datapointer4) throws Throwable {
        String testCaseID = Utility.getScenarioID();
        String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_ExpectedData",testCaseID , datapointer);
        Assert.assertEquals(firstthingsfirst.getText(), value,"Couldn't found expected header message");

        String value1=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_ExpectedData",testCaseID , datapointer1);
        Assert.assertEquals(Whatstheaddressofyournewhome.getText(), value1,"Couldn't found expected header message for the Address Screen");

        String value2=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_ExpectedData",testCaseID , datapointer2);
        Assert.assertEquals(addressLookUp.getAttribute("placeholder"), value2,"Couldn't found expected Place Holder for the Address Input box");

        String value3=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_ExpectedData",testCaseID , datapointer3);
        Assert.assertEquals(enteraddressmanually.getText(), value3,"Couldn't found expected text for Enter Address Manually Link");

        String value4=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_ExpectedData",testCaseID , datapointer4);
        Assert.assertEquals(backbutton.getText(), value4,"Couldn't found expected header for Back Button");
    }

    @When("^customer enters the address \"([^\"]*)\" of the new home in free format text field$")
    public void customerEntersTheAddressOfTheNewHomeInFreeFormatTextField(String datapointer) throws Throwable {

        String value = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_InputData", testCaseID, datapointer);

        if (ConfigurationUtils.getBaseBundle().getPropertyValue("driver.name").equals("perfectoRemoteDriver")) {
        //Common.enterAddressManually();
            addressLookUp.click();
            webDriver.getKeyboard().sendKeys(value);
        }
        else
        {

            addressLookUp.sendKeys(value);

        }
    }

    @Then("^should able to view auto suggest search result in free format text field$")
    public void shouldAbleToViewAutoSuggestSearchResultInFreeFormatTextField() throws Throwable {
        //wait.until(ExpectedConditions.visibilityOf(addressLookupResults));

    }

    @When("^Select the \"([^\"]*)\" received from DMTI Service$")
    public void selectTheReceivedFromDMTIService(String datapointer) throws Throwable {

        }

    @Then("^Should able to save the 'address details' in the below fields 'Street number field' as \"([^\"]*)\", 'Street name field' as \"([^\"]*)\", 'Direction field' as \"([^\"]*)\" , 'Unit Number field' as \"([^\"]*)\", 'City' field as \"([^\"]*)\" , 'Province' field as \"([^\"]*)\" , 'Postal Code' field as \"([^\"]*)\", 'Country' field as \"([^\"]*)\"$")
    public void should_able_to_save_the_address_details_in_the_below_fields_Street_number_field_as_Street_name_field_as_Direction_field_as_Unit_Number_field_as_City_field_as_Province_field_as_Postal_Code_field_as_Country_field_as(String arg1, String arg2, String arg3, String arg4, String arg5, String arg6, String arg7, String arg8) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        
    }
    
    @Then("^'Continue' button should be enabled\\.$")
    public void continue_button_should_be_enabled() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	 //ContinueAddressPage.isEnabled();
    	 ContinueAddressPage.click();
    	 //wait.until(ExpectedConditions.elementToBeClickable(TypeofPropertyhouseselect));
    	 Thread.sleep(10000);
    }
    
    
    @When("^Clicking on 'Enter address manually' link from 'What's the address of your new home' page\\.$")
    public void clicking_on_Enter_address_manually_link_from_What_s_the_address_of_your_new_home_page() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	enteraddressmanually.click();
    }

    @Then("^Should able to navigate to 'Manual address page'\\.$")
    public void should_able_to_navigate_to_Manual_address_page() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	 searchForYourAddress.isPresent();	 
    }

}
