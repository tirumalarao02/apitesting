package com.scotiabank.ehome.ui.steps.stage2;
import com.qmetry.qaf.automation.step.QAFTestStepProvider;
import com.qmetry.qaf.automation.ui.WebDriverTestBase;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebDriver;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.quantum.utils.ConfigurationUtils;
import com.scotiabank.ehome.ui.steps.Common;
import com.scotiabank.ehome.ui.steps.ExcelDataToDataTable;
import com.scotiabank.ehome.ui.steps.Utility;
import com.scotiabank.ehome.ui.steps.valueObjects.Tuple;
import com.scotiabank.ehome.ui.steps.valueObjects.TypeOfRateVO;
import com.thoughtworks.qdox.model.expression.Add;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;

import cucumber.api.DataTable;
import cucumber.api.Transform;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import static com.scotiabank.ehome.ui.steps.BusinessCalculations.*;
import static com.scotiabank.ehome.ui.steps.Utility.*;
@QAFTestStepProvider

public class PropertyType {
	
    public static WebDriverWait wait=Utility.getWait();
    
    private Map<String,Map<String,Boolean>> propertyTypeDataset = getScreenDataset(Utility.getExcelFilePath("eHomeTestData.xlsx"), "Property_Type");
    
    @Given("^Customer should login and navigates to Property Type screen from Address$")
    public void Customer_should_login_and_navigates_to_Property_Type_screen() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	Utility.launchURL(ConfigurationUtils.getBaseBundle().getPropertyValue ("env.baseurl1"));
        //To click Continue in Section breaker
        Common.sessionBreakerContinueButtonClick();
        //To enter address and select the value from the dropdown 
       	Common.newhouseaddress("4 king west");
	    Common.continueButtonClicked();
 
          
    }
    @Given("^Customer should login and navigates to Property Type screen from Manual Address$")
    public void Customer_should_login_and_navigates_to_Property_Type_screen_from_manual_address() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	Utility.launchURL(ConfigurationUtils.getBaseBundle().getPropertyValue ("env.baseurl1"));
        //To click Continue in Section breaker
        Common.sessionBreakerContinueButtonClick();
        //To enter address and select the value from the dropdown 
       	Common.enterAddressManually();
	             
    }
  //Scenario: Property_Type_002
    @When("^Verify \"([^\"]*)\" in Property Type screen$")
    public void Verify_Your_new_in_Property_Type_screen(String dataPointer) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	//TO Check the header message
    	String testCaseID = Utility.getScenarioID();
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_ExpectedData", testCaseID, dataPointer);
		Assert.assertEquals(Common.headerMessage(), value,"Couldn't found expected header text");
    }

    @Then("^\"([^\"]*)\" should be displayed in Property Type screen$")
    public void What_type_of_property_have_you_made_an_offer_on_should_be_displayed_in_Property_Type_screen(String dataPointer) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	//TO Check the header text 
    	String testCaseID = Utility.getScenarioID();
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_ExpectedData", testCaseID, dataPointer);
		Assert.assertEquals(Common.headertext(), value,"Couldn't found expected header text");
    }
    //Scenario: Property_Type_003
    public static void houseButtonClicked() {
    	QAFExtendedWebElement typeofPropertyhouseselect= new QAFExtendedWebElement("ehome.Propertytype.House.Select");
        wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(typeofPropertyhouseselect));
        typeofPropertyhouseselect.click();
	}

    @When("^verify House image and select button then click on the \"([^\"]*)\" select button in Property Type screen$")
    public void verify_House_image_and_select_button_then_click_on_the_house_select_button_in_Property_Type_screen(String dataPointer) throws Throwable {  
        // Write code here that turns the phrase above into concrete actions
    	 QAFExtendedWebElement houseimage= new QAFExtendedWebElement("ehome.Propertytype.House.image");
    	 wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(houseimage));
    	 houseimage.isPresent();
    	 QAFExtendedWebElement housetitle= new QAFExtendedWebElement("ehome.Propertytype.House.Title");
    	 wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(housetitle));
    	 String testCaseID = Utility.getScenarioID();
 		 String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_ExpectedData", testCaseID, dataPointer);
 		 Assert.assertEquals( housetitle.getText(), value,"Couldn't found expected header text");
 		 houseButtonClicked();
     } 
    @Then("^It should navigate to Type of house screen$")
    public void It_should_navigate_to_Type_of_house_screen() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	Thread.sleep(2000);
    	String testCaseID = Utility.getScenarioID();
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_ExpectedData", testCaseID, "Type_of_House_Header");
		Assert.assertEquals(Common.headertext(), value,"Couldn't found expected header text");
        
        
        //To click on back button in type of house
        QAFExtendedWebElement BackTypeofHouse= new QAFExtendedWebElement("ehome.Back.button");
        BackTypeofHouse.click();
        Thread.sleep(2000);
      
        // TO Check House is highlighted with a check mark
        QAFExtendedWebElement houseBg= new QAFExtendedWebElement("ehome.Propertytype.House.BG");
        String color = houseBg.getCssValue("background-color");
        String hex = Utility.convertRGBToHex(color);
        Assert.assertEquals("#8230df", hex);
        if (!hex.contentEquals("#8230df"))
            throw new AssertionError("houseSelect is not highlighted with #8230df color");
      
    }
    @Then("^check the continue button on the Property type screen$")
    public void check_the_continue_button_on_the_Type_of_house_screen() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	//To check the continue button is there and it should be in red color and click on the continue button
    	Thread.sleep(2000);
	       QAFExtendedWebElement continuebutton = new QAFExtendedWebElement("ehome.Continue.button");
	       Assert.assertEquals(continuebutton.getText(), "Continue", "Continue Button text does not matched");
	       Assert.assertEquals(convertRGBToHex(continuebutton.getCssValue("color")), "#ed722", "Continue button not in Red color");
	       continuebutton.click();
	       Thread.sleep(2000);
	       
	     //To click on back button in type of house
	        QAFExtendedWebElement BackTypeofHouse= new QAFExtendedWebElement("ehome.Back.button");
	        BackTypeofHouse.click();
	        Thread.sleep(5000);
     
    }
    public static void condoButtonClicked() {
    	QAFExtendedWebElement typeofPropertyCondoselect= new QAFExtendedWebElement("ehome.Propertytype.Condo.Select");
    	wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(typeofPropertyCondoselect));
    	typeofPropertyCondoselect.click();	
        
	}
    @When("^verify Condo image and select button then click on the \"([^\"]*)\" select button in Property Type screen$")
    public void verify_Condo_image_and_select_button_then_click_on_the_Condo_select_button_in_Property_Type_screen(String dataPointer) throws Throwable {  
        // Write code here that turns the phrase above into concrete actions
    	 QAFExtendedWebElement condoimage= new QAFExtendedWebElement("ehome.Propertytype.Condo.image");
    	 wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(condoimage));
    	 condoimage.isPresent();
    	 QAFExtendedWebElement condotitle= new QAFExtendedWebElement("ehome.Propertytype.Condo.Title");
    	 wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(condotitle));
    	 String testCaseID = Utility.getScenarioID();
 		 String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_ExpectedData", testCaseID, dataPointer);
 		 Assert.assertEquals(condotitle.getText(), value,"Couldn't found expected header text");
         condoButtonClicked();
         
           }
    @Then("^It should navigate to Condo Fees screen$")
    public void It_should_navigate_to_Condo_Fees_screen() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	Thread.sleep(5000);
        
        //To click on back button in type of house
        QAFExtendedWebElement BackTypeofCondo= new QAFExtendedWebElement("ehome.Back.button");
        BackTypeofCondo.click();
        Thread.sleep(5000);
      
        // TO Check the highlighted withSelect House
        QAFExtendedWebElement CondoBg= new QAFExtendedWebElement("ehome.Propertytype.Condo.BG");
        String color = CondoBg.getCssValue("background-color");
        String hex = Utility.convertRGBToHex(color);
        Assert.assertEquals("#8230df", hex);
        if (!hex.contentEquals("#8230df"))
            throw new AssertionError("CondoSelect is not highlighted with #8230df color");
    
    }
    //Scenario: Property_Type_004
    
    @Then("^It should navigate to Manual Address screen and check the header \"([^\"]*)\"$")
    public void it_should_navigate_to_Manual_Address_screen(String dataPointer) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	QAFExtendedWebElement headertext= new QAFExtendedWebElement("ehome.Header.text");
        wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(headertext));
        String testCaseID = Utility.getScenarioID();
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_ExpectedData", testCaseID, dataPointer);
		Assert.assertEquals(Common.headertext(), value,"Couldn't found expected header text");
        QAFExtendedWebElement streetnumber= new QAFExtendedWebElement("ehome.enteraddressmanually.streetnumber");
        wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(streetnumber));
        streetnumber.isPresent();
        
    }
    @Then("^It should navigate to Address screen and check the header \"([^\"]*)\"$")
    public void it_should_navigate_to_Address_screen1(String dataPointer) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	QAFExtendedWebElement headertext= new QAFExtendedWebElement("ehome.Header.text");
        wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(headertext));
        String testCaseID = Utility.getScenarioID();
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_ExpectedData", testCaseID, dataPointer);
        QAFExtendedWebElement addresstext= new QAFExtendedWebElement("ehome.Address.address.text");
        wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(addresstext));
        addresstext.isPresent();
    }	
		
    
}
