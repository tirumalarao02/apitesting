package com.scotiabank.ehome.ui.steps.hub;

import static com.scotiabank.ehome.ui.steps.Utility.getScreenDataset;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.qmetry.qaf.automation.step.QAFTestStepProvider;
import com.qmetry.qaf.automation.ui.WebDriverTestBase;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebDriver;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.quantum.utils.ConfigurationUtils;
import com.scotiabank.ehome.ui.steps.Common;
import com.scotiabank.ehome.ui.steps.Utility;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.openqa.selenium.support.ui.Select;

@QAFTestStepProvider
public class HubPostIngestion {
	
	private static QAFExtendedWebDriver webDriver = Utility.getDriver();
    public Actions action = null;
    public static WebDriverWait wait=Utility.getWait();	
    String ColoPickerStr;
    private Map<String,Map<String,Boolean>> HubPostIngestion_ExpectedData = getScreenDataset(Utility.getExcelFilePath("eHomeTestData.xlsx"), "HubPostIngestion_ExpectedData");
    //private Map<String,Map<String,Boolean>> emailAddressDataset = getScreenDataset(Utility.getExcelFilePath("eHomeTestDatastage-4.xlsx"), "IndustryAndJobTitle");
    
    QAFExtendedWebElement sidebar= new QAFExtendedWebElement("ehome.hubPostIngestion.sidebar");
    QAFExtendedWebElement ScotiaBankLogo= new QAFExtendedWebElement("ehome.hubPostIngestion.ScotiaBankLogo");
    QAFExtendedWebElement EditPersonalDetails= new QAFExtendedWebElement("ehome.hubPostIngestion.EditPersonalDetails");
    QAFExtendedWebElement SidebarNotifications= new QAFExtendedWebElement("ehome.hubPostIngestion.sidebarNotifications");    
    QAFExtendedWebElement FAQ= new QAFExtendedWebElement("ehome.hubPostIngestion.FAQ");
    QAFExtendedWebElement MortgageSummary= new QAFExtendedWebElement("ehome.hubPostIngestion.MortgageSummary");
    QAFExtendedWebElement MortgageSupport= new QAFExtendedWebElement("ehome.hubPostIngestion.MortgageSupport");
    QAFExtendedWebElement Logout= new QAFExtendedWebElement("ehome.hubPostIngestion.Logout");  
    
    QAFExtendedWebElement NotificationsHeader= new QAFExtendedWebElement("ehome.hubPostIngestion.NotificationsHeader");
    QAFExtendedWebElement NotificationsContent= new QAFExtendedWebElement("ehome.hubPostIngestion.NotificationsContent");

    QAFExtendedWebElement MortgageSummaryHeader= new QAFExtendedWebElement("ehome.hubPostIngestion.MortgageSummaryHeader");
    QAFExtendedWebElement MortgageSummaryRateExpiryDateText= new QAFExtendedWebElement("ehome.hubPostIngestion.MortgageSummaryRateExpiryDateText");
    QAFExtendedWebElement MortgageSummaryRateExpiryDate= new QAFExtendedWebElement("ehome.hubPostIngestion.MortgageSummaryRateExpiryDate");
    QAFExtendedWebElement MortgageRequestedText= new QAFExtendedWebElement("ehome.hubPostIngestion.MortgageRequestedText");
    QAFExtendedWebElement MortgageRequestedContent= new QAFExtendedWebElement("ehome.hubPostIngestion.MortgageRequestedContent");
    QAFExtendedWebElement MortgageFixedRateText= new QAFExtendedWebElement("ehome.hubPostIngestion.MortgageFixedRateText");
    QAFExtendedWebElement MortgageFixedRateContent= new QAFExtendedWebElement("ehome.hubPostIngestion.MortgageFixedRateContent");
    QAFExtendedWebElement MortgageTermText= new QAFExtendedWebElement("ehome.hubPostIngestion.MortgageTermText");
    QAFExtendedWebElement MortgageTermContent= new QAFExtendedWebElement("ehome.hubPostIngestion.MortgageTermContent");
    QAFExtendedWebElement MortgagePaymentAmountText= new QAFExtendedWebElement("ehome.hubPostIngestion.MortgagePaymentAmountText");
    QAFExtendedWebElement MortgagePaymentAmountContent= new QAFExtendedWebElement("ehome.hubPostIngestion.MortgagePaymentAmountContent");
    QAFExtendedWebElement MortgageFirstPaymentDateText= new QAFExtendedWebElement("ehome.hubPostIngestion.MortgageFirstPaymentDateText");
    QAFExtendedWebElement MortgageFirstPaymentDateContent= new QAFExtendedWebElement("ehome.hubPostIngestion.MortgageFirstPaymentDateContent");
    QAFExtendedWebElement MortgageAmortizationPeriodText= new QAFExtendedWebElement("ehome.hubPostIngestion.MortgageAmortizationPeriodText");
    QAFExtendedWebElement MortgageAmortizationPeriodContent= new QAFExtendedWebElement("ehome.hubPostIngestion.MortgageAmortizationPeriodContent");
    QAFExtendedWebElement MortgageSummrayI= new QAFExtendedWebElement("ehome.hubPostIngestion.MortgageSummrayI");
    QAFExtendedWebElement MortgageSummrayIContent= new QAFExtendedWebElement("ehome.hubPostIngestion.MortgageSummrayIContent");

    QAFExtendedWebElement MortgageSupportHeader= new QAFExtendedWebElement("ehome.hubPostIngestion.MortgageSupportHeader");
    QAFExtendedWebElement eHOMEreferenceText= new QAFExtendedWebElement("ehome.hubPostIngestion.eHOMEreferenceText");
    QAFExtendedWebElement eHOMEreferenceNo= new QAFExtendedWebElement("ehome.hubPostIngestion.eHOMEreferenceNo");
    QAFExtendedWebElement ForQuick= new QAFExtendedWebElement("ehome.hubPostIngestion.ForQuick");
    QAFExtendedWebElement CanText= new QAFExtendedWebElement("ehome.hubPostIngestion.CanText");
    QAFExtendedWebElement OurMortgageAgents= new QAFExtendedWebElement("ehome.hubPostIngestion.OurMortgageAgents");
    QAFExtendedWebElement MortgageSupportPhone= new QAFExtendedWebElement("ehome.hubPostIngestion.MortgageSupportPhone");
    QAFExtendedWebElement MortgageSupportMonThursday= new QAFExtendedWebElement("ehome.hubPostIngestion.MortgageSupportMonThursday");
    QAFExtendedWebElement MortgageSupportFriday= new QAFExtendedWebElement("ehome.hubPostIngestion.MortgageSupportFriday");
    QAFExtendedWebElement MortgageSupportSaturday= new QAFExtendedWebElement("ehome.hubPostIngestion.MortgageSupportSaturday");
    QAFExtendedWebElement MortgageSupport9to11= new QAFExtendedWebElement("ehome.hubPostIngestion.MortgageSupport9to11");
    QAFExtendedWebElement MortgageSupport9to10= new QAFExtendedWebElement("ehome.hubPostIngestion.MortgageSupport9to10");
    QAFExtendedWebElement MortgageSupport10to6= new QAFExtendedWebElement("ehome.hubPostIngestion.MortgageSupport10to6");
    QAFExtendedWebElement MortgageSupportOnceYouSubmit= new QAFExtendedWebElement("ehome.hubPostIngestion.MortgageSupportOnceYouSubmit");
    
    @Given("^Customer should login and navigates to HUB PostIngestion Screen$")
    public void customer_should_login_and_navigates_to_HUB_PostIngestion_Screen() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	Utility.launchURL(ConfigurationUtils.getBaseBundle().getPropertyValue ("env.baseurl4"));
    	//ValidHubStart();
    	Login();
    }
    
    public static void ValidHubStart() throws InterruptedException, AWTException{
    	
    	QAFExtendedWebElement LetsGetStartedBtn= new QAFExtendedWebElement("ehome.hubPostIngestion.LetsGetStartedBtn");
    	
        Robot a = new Robot();
    	a.keyPress(KeyEvent.VK_Q);
    	Thread.sleep(1000);
    	a.keyPress(KeyEvent.VK_Q);
    	Thread.sleep(3000);
    	a.keyPress(KeyEvent.VK_ENTER);
    	Thread.sleep(5000);
    	a.keyPress(KeyEvent.VK_0);
    	a.keyPress(KeyEvent.VK_1);
    	a.keyPress(KeyEvent.VK_9);
    	a.keyPress(KeyEvent.VK_0);
    	a.keyPress(KeyEvent.VK_1);
    	a.keyPress(KeyEvent.VK_0);
    	a.keyPress(KeyEvent.VK_2);
    	a.keyPress(KeyEvent.VK_3);
    	a.keyPress(KeyEvent.VK_0);
    	a.keyPress(KeyEvent.VK_7);
    	a.keyPress(KeyEvent.VK_5);
    	a.keyPress(KeyEvent.VK_0);
    	Thread.sleep(2000);
    	a.keyPress(KeyEvent.VK_0);
    	a.keyPress(KeyEvent.VK_4);
    	a.keyPress(KeyEvent.VK_5);
    	Thread.sleep(3000);
    	a.keyPress(KeyEvent.VK_ENTER);
    	Thread.sleep(3000);
    	LetsGetStartedBtn.click();
    	Thread.sleep(4000);
    }
    
    public static void Login() throws InterruptedException {
    	webDriver.findElement(By.xpath(".//*[contains(@id,'username')]")).sendKeys("4536000008459500");
        webDriver.findElement(By.xpath(".//*[contains(@id,'password')]")).sendKeys("a123456a");
        webDriver.findElement(By.xpath("//button[@id='signIn']")).click();
        Thread.sleep(3000);
        Utility.clickObject("ehome.eHomeLogin.Continue", "Continue Button in Redirect Screen");
        Thread.sleep(5000); 
	}
    
    @Then("^Verify Scotiabank Logo should be on the Hub PostIngestion screen$")
    public void verify_Scotiabank_Logo_should_be_on_the_Hub_PostIngestion_screen() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	sidebar.click();
    	wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(ScotiaBankLogo));
 		if(!ScotiaBankLogo.isPresent())
 			throw new AssertionError("Scotia Bank Logo is not Postsent");
    }

    @Then("^Verify \"([^\"]*)\" , \"([^\"]*)\" , \"([^\"]*)\" , \"([^\"]*)\" , \"([^\"]*)\" , \"([^\"]*)\" message should be on side pane of HUB PostIngestion screen$")
    public void verify_message_should_be_on_side_pane_of_HUB_PostIngestion_screen(String arg1, String arg2, String arg3, String arg4, String arg5, String arg6) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	String testCaseID = Utility.getScenarioID();
		String editPersonalDetails=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "HubPostIngestion_ExpectedData", testCaseID, arg1);
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(EditPersonalDetails));
		Assert.assertEquals(EditPersonalDetails.getText(), editPersonalDetails,"Couldn't found expected message");
		
		String sidebarNotifications=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "HubPostIngestion_ExpectedData", testCaseID, arg2);
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(SidebarNotifications));
		Assert.assertEquals(SidebarNotifications.getText(), sidebarNotifications,"Couldn't found expected message");

		String faq=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "HubPostIngestion_ExpectedData", testCaseID, arg3);
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(FAQ));
		Assert.assertEquals(FAQ.getText(), faq,"Couldn't found expected message");

		String mortgageSummary=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "HubPostIngestion_ExpectedData", testCaseID, arg4);
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(MortgageSummary));
		Assert.assertEquals(MortgageSummary.getText(), mortgageSummary,"Couldn't found expected message");
		
		String mortgageSupport=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "HubPostIngestion_ExpectedData", testCaseID, arg5);
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(MortgageSupport));
		Assert.assertEquals(MortgageSupport.getText(), mortgageSupport,"Couldn't found expected message");
		
		String logout=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "HubPostIngestion_ExpectedData", testCaseID, arg6);
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(Logout));
		Assert.assertEquals(Logout.getText(), logout,"Couldn't found expected message");
    }
    
    @When("^customer clicks on PostIngestion notifications$")
    public void customer_clicks_on_PostIngestion_notifications() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	sidebar.click();
    	SidebarNotifications.click();
    	Thread.sleep(2000);
    }

    @Then("^Verify \"([^\"]*)\" header in notifications$")
    public void verify_header_in_notifications(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	String testCaseID = Utility.getScenarioID();
		String notHeaderDetails=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "HubPostIngestion_ExpectedData", testCaseID, arg1);
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(NotificationsHeader));
		Assert.assertEquals(NotificationsHeader.getText(), notHeaderDetails,"Couldn't found expected message");
    }

    @Then("^Verify \"([^\"]*)\" content in notifications$")
    public void verify_content_in_notifications(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	String testCaseID = Utility.getScenarioID();
		String notContentDetails=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "HubPostIngestion_ExpectedData", testCaseID, arg1);
    	wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(NotificationsContent));
		Assert.assertEquals(NotificationsContent.getText(), notContentDetails,"Couldn't found expected message");
    }
    
    @When("^customer clicks on mortgage summary from PostIngestion Mortgage Summary$")
    public void customer_clicks_on_mortgage_summary_from_PostIngestion_Mortgage_Summary() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	Thread.sleep(5000);
    	sidebar.click();
    	MortgageSummary.click();
    	Thread.sleep(2000);
    }

    @Then("^Verify \"([^\"]*)\" Header in Mortgage Summary$")
    public void verify_Header_in_Mortgage_Summary(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	String testCaseID = Utility.getScenarioID();
		String MortgageSummaryHeaderText=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "HubPostIngestion_ExpectedData", testCaseID, arg1);
    	wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(MortgageSummaryHeader));
		Assert.assertEquals(MortgageSummaryHeader.getText(), MortgageSummaryHeaderText,"Couldn't found expected message");
    }
    
    @Then("^Verify \"([^\"]*)\" Rate Expiry Date Text in Mortgage Summary$")
    public void verify_Rate_Expiry_Date_Text_in_Mortgage_Summary(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	String testCaseID = Utility.getScenarioID();
		String MortgageSummaryRateExpiryDateTxt=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "HubPostIngestion_ExpectedData", testCaseID, arg1);
    	wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(MortgageSummaryRateExpiryDateText));
		Assert.assertEquals(MortgageSummaryRateExpiryDateText.getText(), MortgageSummaryRateExpiryDateTxt,"Couldn't found expected message");
    }

    @Then("^Verify \"([^\"]*)\" Rate Expiry Date in Mortgage Summary$")
    public void verify_Rate_Expiry_Date_in_Mortgage_Summary(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	String testCaseID = Utility.getScenarioID();
		String MortgageSummaryRateExpiryDateTxt=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "HubPostIngestion_ExpectedData", testCaseID, arg1);
    	wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(MortgageSummaryRateExpiryDate));
		Assert.assertEquals(MortgageSummaryRateExpiryDate.getText(), MortgageSummaryRateExpiryDateTxt,"Couldn't found expected message");
    }

    @Then("^Verify \"([^\"]*)\" Mortgage Requested Text in Mortgage Summary$")
    public void verify_Mortgage_Requested_Text_in_Mortgage_Summary(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	String testCaseID = Utility.getScenarioID();
		String MortgageRequestedTxt=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "HubPostIngestion_ExpectedData", testCaseID, arg1);
    	wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(MortgageRequestedText));
		Assert.assertEquals(MortgageRequestedText.getText(), MortgageRequestedTxt,"Couldn't found expected message");
    }

    @Then("^Verify \"([^\"]*)\" Mortgage Requested Content in Mortgage Summary$")
    public void verify_Mortgage_Requested_Content_in_Mortgage_Summary(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	String testCaseID = Utility.getScenarioID();
		String MortgageRequestedContentTxt=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "HubPostIngestion_ExpectedData", testCaseID, arg1);
    	wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(MortgageRequestedContent));
		Assert.assertEquals(MortgageRequestedContent.getText(), MortgageRequestedContentTxt,"Couldn't found expected message");
    }

    @Then("^Verify \"([^\"]*)\" Mortgage Fixed Rate Text in Mortgage Summary$")
    public void verify_Mortgage_Fixed_Rate_Text_in_Mortgage_Summary(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	String testCaseID = Utility.getScenarioID();
		String MortgageFixedRateTxt=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "HubPostIngestion_ExpectedData", testCaseID, arg1);
    	wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(MortgageFixedRateText));
		Assert.assertEquals(MortgageFixedRateText.getText(), MortgageFixedRateTxt,"Couldn't found expected message");
    }

    @Then("^Verify \"([^\"]*)\" Mortgage Fixed Rate Content in Mortgage Summary$")
    public void verify_Mortgage_Fixed_Rate_Content_in_Mortgage_Summary(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	String testCaseID = Utility.getScenarioID();
		String MortgageFixedRateContentTxt=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "HubPostIngestion_ExpectedData", testCaseID, arg1);
    	wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(MortgageFixedRateContent));
		Assert.assertEquals(MortgageFixedRateContent.getText(), MortgageFixedRateContentTxt,"Couldn't found expected message");
    }

    @Then("^Verify \"([^\"]*)\" Mortgage Term Text in Mortgage Summary$")
    public void verify_Mortgage_Term_Text_in_Mortgage_Summary(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	String testCaseID = Utility.getScenarioID();
		String MortgageTermTxt=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "HubPostIngestion_ExpectedData", testCaseID, arg1);
    	wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(MortgageTermText));
		Assert.assertEquals(MortgageTermText.getText(), MortgageTermTxt,"Couldn't found expected message");
     }

    @Then("^Verify \"([^\"]*)\" Mortgage Term Content in Mortgage Summary$")
    public void verify_Mortgage_Term_Content_in_Mortgage_Summary(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	String testCaseID = Utility.getScenarioID();
		String MortgageTermContentTxt=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "HubPostIngestion_ExpectedData", testCaseID, arg1);
    	wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(MortgageTermContent));
		Assert.assertEquals(MortgageTermContent.getText(), MortgageTermContentTxt,"Couldn't found expected message");
    }

    @Then("^Verify \"([^\"]*)\" Mortgage Payment Amount Text in Mortgage Summary$")
    public void verify_Mortgage_Payment_Amount_Text_in_Mortgage_Summary(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	String testCaseID = Utility.getScenarioID();
		String MortgagePaymentAmountTxt=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "HubPostIngestion_ExpectedData", testCaseID, arg1);
    	wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(MortgagePaymentAmountText));
		Assert.assertEquals(MortgagePaymentAmountText.getText(), MortgagePaymentAmountTxt,"Couldn't found expected message");
    }

    @Then("^Verify \"([^\"]*)\" Mortgage Payment Amount Content in Mortgage Summary$")
    public void verify_Mortgage_Payment_Amount_Content_in_Mortgage_Summary(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	String testCaseID = Utility.getScenarioID();
		String MortgagePaymentAmountContentTxt=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "HubPostIngestion_ExpectedData", testCaseID, arg1);
    	wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(MortgagePaymentAmountContent));
		Assert.assertEquals(MortgagePaymentAmountContent.getText(), MortgagePaymentAmountContentTxt,"Couldn't found expected message");
    }

    @Then("^Verify \"([^\"]*)\" Mortgage First Payment Date Text in Mortgage Summary$")
    public void verify_Mortgage_First_Payment_Date_Text_in_Mortgage_Summary(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	String testCaseID = Utility.getScenarioID();
		String MortgageFirstPaymentDateTxt=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "HubPostIngestion_ExpectedData", testCaseID, arg1);
    	wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(MortgageFirstPaymentDateText));
		Assert.assertEquals(MortgageFirstPaymentDateText.getText(), MortgageFirstPaymentDateTxt,"Couldn't found expected message");
    }

    @Then("^Verify \"([^\"]*)\" Mortgage First Payment Date Content in Mortgage Summary$")
    public void verify_Mortgage_First_Payment_Date_Content_in_Mortgage_Summary(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	String testCaseID = Utility.getScenarioID();
		String MortgageFirstPaymentDateContentTxt=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "HubPostIngestion_ExpectedData", testCaseID, arg1);
    	wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(MortgageFirstPaymentDateContent));
		Assert.assertEquals(MortgageFirstPaymentDateContent.getText(), MortgageFirstPaymentDateContentTxt,"Couldn't found expected message");
    }

    @Then("^Verify \"([^\"]*)\" Mortgage Amortization Period Text in Mortgage Summary$")
    public void verify_Mortgage_Amortization_Period_Text_in_Mortgage_Summary(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	String testCaseID = Utility.getScenarioID();
		String MortgageAmortizationPeriodTxt=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "HubPostIngestion_ExpectedData", testCaseID, arg1);
    	wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(MortgageAmortizationPeriodText));
		Assert.assertEquals(MortgageAmortizationPeriodText.getText(), MortgageAmortizationPeriodTxt,"Couldn't found expected message");
    }

    @Then("^Verify \"([^\"]*)\" Mortgage Amortization Period Content in Mortgage Summary$")
    public void verify_Mortgage_Amortization_Period_Content_in_Mortgage_Summary(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	String testCaseID = Utility.getScenarioID();
		String MortgageAmortizationPeriodContentTxt=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "HubPostIngestion_ExpectedData", testCaseID, arg1);
    	wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(MortgageAmortizationPeriodContent));
		Assert.assertEquals(MortgageAmortizationPeriodContent.getText(), MortgageAmortizationPeriodContentTxt,"Couldn't found expected message");
    }
    
    @When("^Click on I under Mortgage Summary in HUB PostIngestion Screen$")
    public void click_on_I_under_Mortgage_Summary_in_HUB_PostIngestion_Screen() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	Thread.sleep(5000);
    	sidebar.click();
    	MortgageSummary.click();
    	Thread.sleep(2000);
    	MortgageSummrayI.click();
    }

    @Then("^Verify the \"([^\"]*)\" content for I under Mortgage Summary in HUB PostIngestion Screen$")
    public void verify_the_content_for_I_under_Mortgage_Summary_in_HUB_PostIngestion_Screen(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	String testCaseID = Utility.getScenarioID();
		String MortgageSummrayIContentTxt=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "HubPostIngestion_ExpectedData", testCaseID, arg1);
    	wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(MortgageSummrayIContent));
		Assert.assertEquals(MortgageSummrayIContent.getText(), MortgageSummrayIContentTxt,"Couldn't found expected message");
    }
    
    @When("^customer clicks on mortgage Support from PostIngestion$")
    public void customer_clicks_on_mortgage_Support_from_PostIngestion() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
     	Thread.sleep(5000);
    	sidebar.click();
    	MortgageSupport.click();
    	Thread.sleep(2000);
    }

    @Then("^Verify the \"([^\"]*)\" Header in Mortgage Support from PostIngestion$")
    public void verify_the_Header_in_Mortgage_Support_from_PostIngestion(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	String testCaseID = Utility.getScenarioID();
		String MortgageSupportHeaderTxt=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "HubPostIngestion_ExpectedData", testCaseID, arg1);
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(MortgageSupportHeader));
		Assert.assertEquals(MortgageSupportHeader.getText(), MortgageSupportHeaderTxt,"Couldn't found expected message");
    }

    @Then("^Verify the \"([^\"]*)\" reference number text in Mortgage Support from PostIngestion$")
    public void verify_the_reference_number_text_in_Mortgage_Support_from_PostIngestion(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	String testCaseID = Utility.getScenarioID();
		String eHOMEreferenceTxt=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "HubPostIngestion_ExpectedData", testCaseID, arg1);
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(eHOMEreferenceText));
		Assert.assertEquals(eHOMEreferenceText.getText(), eHOMEreferenceTxt,"Couldn't found expected message");
    }

    @Then("^Verify the \"([^\"]*)\" reference number in Mortgage Support from PostIngestion$")
    public void verify_the_reference_number_in_Mortgage_Support_from_PostIngestion(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	String testCaseID = Utility.getScenarioID();
		String eHOMEreferenceNoVal=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "HubPostIngestion_ExpectedData", testCaseID, arg1);
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(eHOMEreferenceNo));
		Assert.assertEquals(eHOMEreferenceNo.getText(), eHOMEreferenceNoVal,"Couldn't found expected message");
    }

    @Then("^Verify the \"([^\"]*)\" FAQ text in Mortgage Support from PostIngestion$")
    public void verify_the_FAQ_text_in_Mortgage_Support_from_PostIngestion(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	String testCaseID = Utility.getScenarioID();
		String ForQuickTxt=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "HubPostIngestion_ExpectedData", testCaseID, arg1);
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(ForQuick));
		Assert.assertEquals(ForQuick.getText(), ForQuickTxt,"Couldn't found expected message");
    }

    @Then("^Verify the \"([^\"]*)\" cant find text in Mortgage Support from PostIngestion$")
    public void verify_the_cant_find_text_in_Mortgage_Support_from_PostIngestion(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	String testCaseID = Utility.getScenarioID();
		String CanTxt=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "HubPostIngestion_ExpectedData", testCaseID, arg1);
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(CanText));
		Assert.assertEquals(CanText.getText(), CanTxt,"Couldn't found expected message");
    }

    @Then("^Verify the \"([^\"]*)\" our mortgage text in Mortgage Support from PostIngestion$")
    public void verify_the_our_mortgage_text_in_Mortgage_Support_from_PostIngestion(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	String testCaseID = Utility.getScenarioID();
    	String OurMortgageAgentsTxt=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "HubPostIngestion_ExpectedData", testCaseID, arg1);
    	wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(OurMortgageAgents));
    	Assert.assertEquals(OurMortgageAgents.getText(), OurMortgageAgentsTxt,"Couldn't found expected message");
    }

    @Then("^Verify the \"([^\"]*)\" mortgage support no in Mortgage Support from PostIngestion$")
    public void verify_the_mortgage_support_no_in_Mortgage_Support_from_PostIngestion(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	String testCaseID = Utility.getScenarioID();
    	String MortgageSupportPhoneVal=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "HubPostIngestion_ExpectedData", testCaseID, arg1);
    	wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(MortgageSupportPhone));
    	Assert.assertEquals(MortgageSupportPhone.getText(), MortgageSupportPhoneVal,"Couldn't found expected message");
    }

    @Then("^Verify the \"([^\"]*)\" mon to thur text in Mortgage Support from PostIngestion$")
    public void verify_the_mon_to_thur_text_in_Mortgage_Support_from_PostIngestion(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	String testCaseID = Utility.getScenarioID();
    	String MortgageSupportMonThursdayTxt=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "HubPostIngestion_ExpectedData", testCaseID, arg1);
    	wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(MortgageSupportMonThursday));
    	Assert.assertEquals(MortgageSupportMonThursday.getText(), MortgageSupportMonThursdayTxt,"Couldn't found expected message");
    }

    @Then("^Verify the \"([^\"]*)\" friday text in Mortgage Support from PostIngestion$")
    public void verify_the_friday_text_in_Mortgage_Support_from_PostIngestion(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	String testCaseID = Utility.getScenarioID();
    	String MortgageSupportFridayTxt=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "HubPostIngestion_ExpectedData", testCaseID, arg1);
    	wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(MortgageSupportFriday));
    	Assert.assertEquals(MortgageSupportFriday.getText(), MortgageSupportFridayTxt,"Couldn't found expected message");
    }

    @Then("^Verify the \"([^\"]*)\" sat text in Mortgage Support from PostIngestion$")
    public void verify_the_sat_text_in_Mortgage_Support_from_PostIngestion(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	String testCaseID = Utility.getScenarioID();
    	String MortgageSupportSaturdayTxt=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "HubPostIngestion_ExpectedData", testCaseID, arg1);
    	wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(MortgageSupportSaturday));
    	Assert.assertEquals(MortgageSupportSaturday.getText(), MortgageSupportSaturdayTxt,"Couldn't found expected message");
    }

    @Then("^Verify the \"([^\"]*)\" monday nine time text in Mortgage Support from PostIngestion$")
    public void verify_the_monday_nine_time_text_in_Mortgage_Support_from_PostIngestion(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	String testCaseID = Utility.getScenarioID();
    	String MortgageSupport9to11Txt=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "HubPostIngestion_ExpectedData", testCaseID, arg1);
    	wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(MortgageSupport9to11));
    	Assert.assertEquals(MortgageSupport9to11.getText(), MortgageSupport9to11Txt,"Couldn't found expected message");
    }

    @Then("^Verify the \"([^\"]*)\" friday nine to ten text in Mortgage Support from PostIngestion$")
    public void verify_the_friday_nine_to_ten_text_in_Mortgage_Support_from_PostIngestion(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	String testCaseID = Utility.getScenarioID();
    	String MortgageSupport9to10Txt=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "HubPostIngestion_ExpectedData", testCaseID, arg1);
    	wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(MortgageSupport9to10));
    	Assert.assertEquals(MortgageSupport9to10.getText(), MortgageSupport9to10Txt,"Couldn't found expected message");
    }

    @Then("^Verify the \"([^\"]*)\" saturday ten in Mortgage Support from PostIngestion$")
    public void verify_the_saturday_ten_in_Mortgage_Support_from_PostIngestion(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	String testCaseID = Utility.getScenarioID();
    	String MortgageSupport10to6Txt=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "HubPostIngestion_ExpectedData", testCaseID, arg1);
    	wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(MortgageSupport10to6));
    	Assert.assertEquals(MortgageSupport10to6.getText(), MortgageSupport10to6Txt,"Couldn't found expected message");
    }

    @Then("^Verify the \"([^\"]*)\" once you submit text in Mortgage Support from PostIngestion$")
    public void verify_the_once_you_submit_text_in_Mortgage_Support_from_PostIngestion(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	String testCaseID = Utility.getScenarioID();
    	String MortgageSupportOnceYouSubmitTxt=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "HubPostIngestion_ExpectedData", testCaseID, arg1);
    	wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(MortgageSupportOnceYouSubmit));
    	Assert.assertEquals(MortgageSupportOnceYouSubmit.getText(), MortgageSupportOnceYouSubmitTxt,"Couldn't found expected message");
    }
}





