package com.scotiabank.ehome.ui.steps.stage1;

import static com.scotiabank.ehome.ui.steps.Utility.getScreenDataset;

import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.qmetry.qaf.automation.step.QAFTestStepProvider;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebDriver;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.quantum.utils.ConfigurationUtils;
import com.scotiabank.ehome.ui.steps.Common;
import com.scotiabank.ehome.ui.steps.Utility;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

@QAFTestStepProvider

public class TriageStartWithQuestion {
	public static WebDriverWait wait=Utility.getWait();	
	  String testCaseID = Utility.getScenarioID();
	
	@Given("^Customer should login and navigate to triage start with questions screen$")
	public void customer_should_login_and_navigate_to_triage_start_with_questions_screen() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Utility.launchURL(ConfigurationUtils.getBaseBundle().getPropertyValue ("env.baseurl0"));
		Welcome.viewOurPrivacyAgreementButtonClicked();
		PrivacyAgreement.acceptAndContinuetButtonClicked();
	    
	}

	@When("^Verify \"([^\"]*)\" message should be on the triage start with questions screen$")
	public void verify_message_should_be_on_the_triage_start_with_questions_screen(String dataPointer) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage01_Registration_ExpectedDa", testCaseID, dataPointer);
		Assert.assertEquals(Common.headerMessage(), value,"Couldn't found expected header text");
	    
	}

	@Then("^Verify \"([^\"]*)\" headertext should be on triage start with questions screen$")
	public void verify_headertext_should_be_on_triage_start_with_questions_screen(String dataPointer) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage01_Registration_ExpectedDa", testCaseID, dataPointer);
		Assert.assertEquals(Common.headertext(), value,"Couldn't found expected header text");
    
	}

	@Then("^Verify \"([^\"]*)\" co-applicant information should be on triage start with questions screen$")
	public void verify_co_applicant_information_should_be_on_triage_start_with_questions_screen(String dataPointer) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage01_Registration_ExpectedDa", testCaseID, dataPointer);
		QAFExtendedWebElement coapplicantinformation= new QAFExtendedWebElement("ehome.TriageStartQuestion.coapplicantinformation");
		 wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(coapplicantinformation));
		 Assert.assertEquals(coapplicantinformation.getText(), value,"Couldn't found expected header message");
	    
	}
	// Triage-StartWith-Questions-TC-002
	@When("^Click on the Back button on the privacy agreement screen$")
	public void click_on_the_Back_button_on_the_privacy_agreement_screen() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		QAFExtendedWebElement backbutton= new QAFExtendedWebElement("ehome.TriageStartQuestion.Back.button");
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(backbutton));
		backbutton.click();
	   
	}
	
	@When("^Click on the Start with question button in triage questions screen$")
	public void click_on_the_Start_with_question_button_in_triage_questions_screen() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		QAFExtendedWebElement startQuestion= new QAFExtendedWebElement("ehome.TriageStartQuestion.Start.button");
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(startQuestion));
		startQuestion.click();
	   
	}



}
