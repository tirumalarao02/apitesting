package com.scotiabank.ehome.ui.steps.coApp;
import com.qmetry.qaf.automation.step.QAFTestStepProvider;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.quantum.utils.ConfigurationUtils;
import com.scotiabank.ehome.ui.steps.Common;
import com.scotiabank.ehome.ui.steps.Utility;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import java.util.List;
import java.util.concurrent.TimeUnit;
import static com.scotiabank.ehome.ui.steps.Utility.*;

@QAFTestStepProvider
public class CoApplicantflow {
	public static WebDriverWait wait=Utility.getWait();	
	  String testCaseID = Utility.getScenarioID();
	  @Given("^Customer should login as a CoApplicant and navigate to CoApp details$")
	  public void customer_should_login_as_a_CoApplicant_and_navigate_to_CoApp_details() throws Throwable {
	      // Write code here that turns the phrase above into concrete actions
		  Common.CoApplicantTraverseToNewHomeSection();
		  Common.CoApplicantTraversesRatetoEmployment();
		  Common.CoApplicantTraversesEmploymenttoAsserts();
	      
	  }


}
