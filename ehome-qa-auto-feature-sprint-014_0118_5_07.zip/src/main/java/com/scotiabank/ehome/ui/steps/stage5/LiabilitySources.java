package com.scotiabank.ehome.ui.steps.stage5;
import com.qmetry.qaf.automation.step.QAFTestStepProvider;
import com.qmetry.qaf.automation.ui.WebDriverTestBase;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.quantum.java.pages.ExtentReportHelper;
import com.quantum.utils.ConfigurationUtils;
import com.scotiabank.ehome.ui.steps.Common;
import com.scotiabank.ehome.ui.steps.CommonAppMethodsAssetLiabilities;
import com.scotiabank.ehome.ui.steps.CommonAppMethodsEmployment;
import com.scotiabank.ehome.ui.steps.CommonApplicationMethods;
import com.scotiabank.ehome.ui.steps.Utility;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;

import java.util.Map;
import java.util.concurrent.TimeUnit;
import static com.scotiabank.ehome.ui.steps.Utility.*;

@QAFTestStepProvider

public class LiabilitySources {
	
	  public static WebDriverWait wait=Utility.getWait();
	  static String curDir = System.getProperty("user.dir");
	  static String strfullPathToFile = curDir + "\\src\\main\\resources\\data\\eHomeTestData.xlsx"; // File Path
		
	  static String sheetStage05_InputData ="Stage05_AssetLiabilty_InputData";
	  static String sheetStage05_ExpectedData ="Stage05_AsetLiblty_ExpectedData";
	  
	  	//String strtestCaseID = "LiabilitySources-Retirement-TC-014";
	  
	 // String strtestCaseID = "LiabilitySourcesDetails-Retired-TC-005";
	  
	String strtestCaseID = Utility.getScenarioID();
	
	  QAFExtendedWebElement srcOfLiabilityAlimony = new QAFExtendedWebElement("ehome.liabilitySrcs.Alimony.Btn");
	  QAFExtendedWebElement srcOfLiabilityChildsupport = new QAFExtendedWebElement("ehome.liabilitySrcs.ChildSupport.Btn");
	  QAFExtendedWebElement srcOfLiabilityPrivateDebt = new QAFExtendedWebElement("ehome.liabilitySrcs.PrivateDebt.Btn");
	  
	  QAFExtendedWebElement strAlimonyActualRemove= new QAFExtendedWebElement("ehome.liabilitySrcs.AlimonyRemove.Btn");
	  QAFExtendedWebElement strChildSupportActualRemove= new QAFExtendedWebElement("ehome.liabilitySrcs.ChildSupportRemove.Btn");
	  QAFExtendedWebElement strPrivateDebtActualRemove= new QAFExtendedWebElement("ehome.liabilitySrcs.PrivateDebtRemove.Btn");
	  
	  QAFExtendedWebElement strAlimonyActualSelect= new QAFExtendedWebElement("ehome.liabilitySrcs.AlimonySelect.Btn");
	  QAFExtendedWebElement strChildSupportActualSelect= new QAFExtendedWebElement("ehome.liabilitySrcs.ChildSupportSelect.Btn");
	  QAFExtendedWebElement strPrivateDebtActualSelect= new QAFExtendedWebElement("ehome.liabilitySrcs.PrivateDebtSelect.Btn");
	  
	  QAFExtendedWebElement strLiablity_ContinueBtn= new QAFExtendedWebElement("ehome.liabilitySrcs.Continue.Btn");
	  QAFExtendedWebElement strLiablity_BackBtn= new QAFExtendedWebElement("ehome.liabilitySrcs.Back.Btn");
	  QAFExtendedWebElement strNoOtherLiabilities_Link= new QAFExtendedWebElement("ehome.liabilitySrcs.NoOtherLiabilities.Link");
			  
		  @When("^Customer should navigate to 'Liability Sources' screen with 'Asset Sources'$")
			public void Customer_should_navigate_to_Liability_Sources_screen_with_Asset_Sources() throws Throwable {
			  
			  Map<String, String> Stage05_InputData =  Utility.readTestData(strfullPathToFile, sheetStage05_InputData,strtestCaseID);
			  
			  	String strCurrentEmpStatus	= Stage05_InputData.get("Empmt_Status");
				String strDurationYear=  Stage05_InputData.get("Years");
				String strDurationMonth=  Stage05_InputData.get("Months");
				String strInvestment_ExpectedInput	= Stage05_InputData.get("EmpOtherSrcsOfIncome_Investments"); 
				String strInvestmentAmt_ExpectedInput	= Stage05_InputData.get("EmpOtherSrcsOfIncome_Investments_Amt");
				
				String strAutomobile_Input = Stage05_InputData.get("AssetSources_Automobile");
				String strCash_Input = Stage05_InputData.get("AssetSources_Cash");
				String strGICTermDeposit_Input = Stage05_InputData.get("AssetSources_GICTermDeposit");
				String strPrimaryResidence_Input = Stage05_InputData.get("AssetSources_PrimaryResidence");
				String strRentalProperty_Input = Stage05_InputData.get("AssetSources_RentalProperty");
				String strRRSP_Input = Stage05_InputData.get("AssetSources_RRSP");
				String strSecondaryProperty_Input = Stage05_InputData.get("AssetSources_SecondaryProperty");
				String strStockBond_Input = Stage05_InputData.get("AssetSources_StockBond");
				String strOtherAssets_Input = Stage05_InputData.get("AssetSources_OtherAssets");
				String strNoOtherAssets_Input = Stage05_InputData.get("AssetSources_NoOtherAssets");
				
				String strAutomobileAmt = Stage05_InputData.get("AssetSources_Automobile_Amt");
				String strCashAmt = Stage05_InputData.get("AssetSources_Cash_Amt");
				String strGICTermDepositAmt = Stage05_InputData.get("AssetSources_GICTermDeposit_Amt");
				String strPrimaryResidenceAmt = Stage05_InputData.get("AssetSources_PrimaryResidence_Amt");
				String strRentalPropertyAmt = Stage05_InputData.get("AssetSources_RentalProperty_Amt");
				String strRRSPAmt = Stage05_InputData.get("AssetSources_RRSP_Amt");
				String strSecondaryPropertyAmt = Stage05_InputData.get("AssetSources_SecondaryProperty_Amt");
				String strStockBondAmt = Stage05_InputData.get("AssetSources_StockBond_Amt");
				String strOtherAssetsAmt = Stage05_InputData.get("AssetSources_OtherAssets_Amt");
	
	 			Utility.launchURL(ConfigurationUtils.getBaseBundle().getPropertyValue ("env.baseurl2"));
				Common.sessionBreakerContinueButtonClick();
				CommonAppMethodsEmployment.SelectEmpStatus(strCurrentEmpStatus);
				Thread.sleep(1000);
					
				if (strDurationYear != "") {
					CommonApplicationMethods.selectValuefromDropDownListBox("ehome.employmentDuration.years", strDurationYear);
			 			Thread.sleep(250);
				}
				if (strDurationMonth != "") {
					CommonApplicationMethods.selectValuefromDropDownListBox("ehome.employmentDuration.months", strDurationMonth);
					Thread.sleep(250);
				}
				Common.continueButtonClicked();
				Thread.sleep(500);
				CommonAppMethodsEmployment.SelectRetiredSourcesOfIncome(strInvestment_ExpectedInput);
				Thread.sleep(500);
				Common.continueButtonClicked();
				if (strInvestment_ExpectedInput != "" | strInvestmentAmt_ExpectedInput != "") {
					CommonAppMethodsEmployment.EnterRetiredAnualIncomeSourceAmount(strInvestment_ExpectedInput, strInvestmentAmt_ExpectedInput);
						}
				Thread.sleep(250);
				Utility.clickObject("ehome.otherIncomeSrcDetails.Continue", "Continue Button in Other Income Src Details");
				Thread.sleep(250);
				Utility.clickObject("ehome.assetSectionBrkr.Continue", "Continue Button in Asset Section Breaker");
				Thread.sleep(250);
					
				if (strNoOtherAssets_Input.contentEquals("No assets")) {
					CommonAppMethodsAssetLiabilities.SelectAssetsSources(strNoOtherAssets_Input);
				}
				if (strAutomobile_Input.contentEquals("Automobile")) {
					CommonAppMethodsAssetLiabilities.SelectAssetsSources(strAutomobile_Input); 
				}
				if (strCash_Input.contentEquals("Cash")) {
					CommonAppMethodsAssetLiabilities.SelectAssetsSources(strCash_Input); 
				}
				if (strGICTermDeposit_Input.contentEquals("GIC/Term deposit")) {
					CommonAppMethodsAssetLiabilities.SelectAssetsSources(strGICTermDeposit_Input); 
				}
				if (strPrimaryResidence_Input.contentEquals("Primary residence")) {
					CommonAppMethodsAssetLiabilities.SelectAssetsSources(strPrimaryResidence_Input); 
				}
				
				if (strRentalProperty_Input.contentEquals("Rental property")) {
					CommonAppMethodsAssetLiabilities.SelectAssetsSources(strRentalProperty_Input); 
				}
				if (strRRSP_Input.contentEquals("RRSP")) {
					CommonAppMethodsAssetLiabilities.SelectAssetsSources(strRRSP_Input); 
				}
				if (strSecondaryProperty_Input.contentEquals("Secondary property")) {
					CommonAppMethodsAssetLiabilities.SelectAssetsSources(strSecondaryProperty_Input); 
				}
				if (strStockBond_Input.contentEquals("Stock/Bond")) {
					CommonAppMethodsAssetLiabilities.SelectAssetsSources(strStockBond_Input); 
				}
				if (strOtherAssets_Input.contentEquals("Other assets")) {
					CommonAppMethodsAssetLiabilities.SelectAssetsSources(strOtherAssets_Input); 
				}
				if (strAutomobile_Input.contentEquals("No assets") | strCash_Input.contentEquals("No assets") | strGICTermDeposit_Input.contentEquals("No assets") | strPrimaryResidence_Input.contentEquals("No assets")| strRentalProperty_Input.contentEquals("No assets")| strRRSP_Input.contentEquals("No assets")| strSecondaryProperty_Input.contentEquals("No assets")| strStockBond_Input.contentEquals("No assets")| strOtherAssets_Input.contentEquals("No assets")) {
					CommonAppMethodsAssetLiabilities.SelectAssetsSources("No assets"); 
				}
				
				Thread.sleep(250);
				if (!strNoOtherAssets_Input.contentEquals("No assets")) {
					Common.continueButtonClicked();
					}
	
					//Do you have any of the following assets?
				if (strAutomobile_Input!= "" | strAutomobileAmt!= "") {
					CommonAppMethodsAssetLiabilities.EnterAssetCalculateAmount(strAutomobile_Input, strAutomobileAmt);
				}
				if (strCash_Input!= "" | strCashAmt.length()!= 0) {
						CommonAppMethodsAssetLiabilities.EnterAssetCalculateAmount(strCash_Input, strCashAmt);
						}
				if (strGICTermDeposit_Input!= "" | strGICTermDepositAmt!= "") {
					CommonAppMethodsAssetLiabilities.EnterAssetCalculateAmount(strGICTermDeposit_Input, strGICTermDepositAmt);
					}
				if (strPrimaryResidence_Input!= "" | strPrimaryResidenceAmt!= "") {
					CommonAppMethodsAssetLiabilities.EnterAssetCalculateAmount(strPrimaryResidence_Input, strPrimaryResidenceAmt );
					}
				if (strRentalProperty_Input!= "" | strRentalPropertyAmt!= "") {
					CommonAppMethodsAssetLiabilities.EnterAssetCalculateAmount(strRentalProperty_Input, strRentalPropertyAmt );
			 		}
				if (strRRSP_Input!= "" | strRRSPAmt!= "") {
					CommonAppMethodsAssetLiabilities.EnterAssetCalculateAmount(strRRSP_Input, strRRSPAmt);
					}
				if (strSecondaryProperty_Input!= "" | strSecondaryPropertyAmt!= "") {
					CommonAppMethodsAssetLiabilities.EnterAssetCalculateAmount(strSecondaryProperty_Input, strSecondaryPropertyAmt);
					}
				if (strStockBond_Input!= "" | strStockBondAmt!= "") {
					CommonAppMethodsAssetLiabilities.EnterAssetCalculateAmount(strStockBond_Input, strStockBondAmt);
					}
				if (strOtherAssets_Input!= "" | strOtherAssetsAmt!= "") {
					CommonAppMethodsAssetLiabilities.EnterAssetCalculateAmount(strOtherAssets_Input, strOtherAssetsAmt );
					}
				QAFExtendedWebElement continueBtn = new WebDriverTestBase().getDriver().findElement(By.xpath("//button[contains(@class,'nav-button nav-button--next nav-button--enabled')]"));
				 continueBtn.click();
				}
		  
	 @Then("^Verify 'Liability Sources' Screen and presence of all objects on 'Liability Sources' Screen$")
	 	public void Verify_Liability_Sources_Screen_and_presence_of_all_objects_on_Liability_Sources_Screen() throws Throwable {
				
		 Map<String, String> Stage05_ExpectedData =  Utility.readTestData(strfullPathToFile, sheetStage05_ExpectedData,strtestCaseID);
			String strLiability_Sources_ExpectedTitle			= Stage05_ExpectedData.get("Liability_Sources_Title"); 	
			String strLiability_Sources_Noted_ExpectedLabel	= Stage05_ExpectedData.get("Liability_Sources_Noted_Lable");
			String strLiability_Sources_PleaseSelectAll_ExpectedLabel	= Stage05_ExpectedData.get("Liability_Noted_PleaseSelectAll_Lable");
					
			QAFExtendedWebElement strLiability_Sources_ActualTitle= new QAFExtendedWebElement("ehome.liabilitySrcs.Title");
			QAFExtendedWebElement strLiability_Sources_Noted_ActualLabel= new QAFExtendedWebElement("ehome.liabilitySrcs.Noted.Lable");
			QAFExtendedWebElement strLiability_Sources_PleaseSelectAll_ActualLabel= new QAFExtendedWebElement("ehome.liabilitySrcs.PleaseSelectAll.Lable");
				
			Thread.sleep(500);
			
	  		if (strLiability_Sources_ExpectedTitle.contentEquals(strLiability_Sources_ActualTitle.getText())) {
	  			ExtentReportHelper.StepPass("'" + strLiability_Sources_ExpectedTitle + " Screen# is displayed.");
	  		}
	  		else
	  		{
	  			Assert.assertEquals(strLiability_Sources_ActualTitle.getText(), strLiability_Sources_ExpectedTitle,"'Liability Sources Title' Screen is NOT as Expected.");
	  		}
	 			
	  		if (strLiability_Sources_Noted_ExpectedLabel.contentEquals(strLiability_Sources_Noted_ActualLabel.getText())) {
	  			ExtentReportHelper.StepPass("'" + strLiability_Sources_Noted_ExpectedLabel + " Label# is displayed.");
	  		}
	  		else
	  		{
	  			Assert.assertEquals(strLiability_Sources_Noted_ActualLabel.getText(), strLiability_Sources_Noted_ExpectedLabel,"'Noted, thank you.' Lable is NOT as Expected.");
	  		}
	    		
	  		if (strLiability_Sources_PleaseSelectAll_ExpectedLabel.contentEquals(strLiability_Sources_PleaseSelectAll_ActualLabel.getText())) {
	  			ExtentReportHelper.StepPass("'" + strLiability_Sources_PleaseSelectAll_ExpectedLabel + " Label# is displayed.");
	  		}
	  		else
	  		{
	  			Assert.assertEquals(strLiability_Sources_PleaseSelectAll_ActualLabel.getText(), strLiability_Sources_PleaseSelectAll_ExpectedLabel,"'Please select all sole and jointly held liabilities that are in your or John's name(s).' Label is NOT as Expected.");
	  		}
	  		
			if(srcOfLiabilityAlimony.isPresent())
			{
				ExtentReportHelper.StepPass("'" + srcOfLiabilityAlimony.getText() + "' option button is displayed.");
			}
			else
				{
					ExtentReportHelper.StepFail("'" + srcOfLiabilityAlimony.getText() + "' option button is NOT displayed.");
				}
			if(srcOfLiabilityChildsupport.isPresent())
				{
					ExtentReportHelper.StepPass("'" + srcOfLiabilityChildsupport.getText() + "' option button is displayed.");
				}
			else
				{
					ExtentReportHelper.StepFail("'" + srcOfLiabilityChildsupport.getText() + "' option button is NOT displayed.");
				}	
			if(srcOfLiabilityPrivateDebt.isPresent())
				{
					ExtentReportHelper.StepPass("'" + srcOfLiabilityPrivateDebt.getText() + "' option button is displayed.");
				}
			else
				{
					ExtentReportHelper.StepFail("'" + srcOfLiabilityPrivateDebt.getText() + "' option button is NOT displayed.");
				}	
			if(strLiablity_ContinueBtn.isPresent())
				{
				ExtentReportHelper.StepPass("'" + strLiablity_ContinueBtn.getText() + "' button is displayed.");
				}
			else
				{
				ExtentReportHelper.StepFail("'" + strLiablity_ContinueBtn.getText() + "' button is NOT displayed.");
				}	
			if(strNoOtherLiabilities_Link.isPresent())
				{
				ExtentReportHelper.StepPass("'" + strNoOtherLiabilities_Link.getText() + "' Link is displayed.");
				}
			else
				{
				ExtentReportHelper.StepFail("'" + strNoOtherLiabilities_Link.getText() + "' Link is NOT displayed.");
				}	
	 }	  
		    
	@Then("^Verify 'Asset Details' Screen when Click on 'Back' button on 'Liability Sources' Screen$")
	public void Verify_Asset_Details_Screen_when_Click_on_Back_button_on_Liability_Sources() throws Throwable {
		Map<String, String> Stage05_ExpectedData =  Utility.readTestData(strfullPathToFile, sheetStage05_ExpectedData,strtestCaseID);
			String strAsset_Details_ExpectedTitle	= Stage05_ExpectedData.get("Asset_Details_Title");
			Thread.sleep(1000);
			strLiablity_BackBtn.click();
			Thread.sleep(2000);
			QAFExtendedWebElement strAsset_Details_ActualTitle= new QAFExtendedWebElement("ehome.assetDetails.Title");
    		if (strAsset_Details_ExpectedTitle.contentEquals(strAsset_Details_ActualTitle.getText())) {
    			ExtentReportHelper.StepPass(strAsset_Details_ExpectedTitle + " Screen# is displayed.");
    		}
    		else
    		{
    			Assert.assertEquals(strAsset_Details_ActualTitle.getText(), strAsset_Details_ExpectedTitle,"'Asset Details' Screen is NOT as Expected.");
    		}	
		}
	
	@Then("^Verify 'document upload section breaker' Screen when select 'No other liabilities' on 'Liability Sources' Screen$")
	public void Verify_document_upload_section_breaker_Screen_when_Click_on_No_other_liabilities_button_on_Liability_Sources() throws Throwable {
		Map<String, String> Stage05_ExpectedData =  Utility.readTestData(strfullPathToFile, sheetStage05_ExpectedData,strtestCaseID);
			String strDocument_Upload_ExpectedTitle	= Stage05_ExpectedData.get("Document_Upload_Section_Breaker_Title"); 	
			strNoOtherLiabilities_Link.click();
			Thread.sleep(2000);
			QAFExtendedWebElement strdocUploadSectionBrk_ActualTitle= new QAFExtendedWebElement("ehome.docUploadSectionBrkr.Title");
    		if (strDocument_Upload_ExpectedTitle.contentEquals(strdocUploadSectionBrk_ActualTitle.getText())) {
    			ExtentReportHelper.StepPass(strDocument_Upload_ExpectedTitle + " Screen# is displayed.");
    		}
    		else
    		{
    			Assert.assertEquals(strdocUploadSectionBrk_ActualTitle.getText(), strDocument_Upload_ExpectedTitle,"'Document Upload Section Breaker' Screen is NOT as Expected.");
    		}	
		}
	
	
	@Then("^Verify Presence and Default selections of Liabilities Sources options 'Alimony' 'Child Support','Private Debt'on 'Liabilities Sources' Screen$")
	public void Verify_Presence_and_Default_selections_of_Sources_Of_Liabilities_options_SourcesOfLiabilities_Screen() throws Throwable {

		if(!srcOfLiabilityAlimony.isSelected())
			{
				ExtentReportHelper.StepPass("'" + srcOfLiabilityAlimony.getText() + "' option button is NOT selected by default.");
			}
		else
			{
				ExtentReportHelper.StepFail("'" + srcOfLiabilityAlimony.getText() + "' option button is selected by default.");
			}
		if(!srcOfLiabilityChildsupport.isSelected())
			{
				ExtentReportHelper.StepPass("'" + srcOfLiabilityChildsupport.getText() + "' option button is NOT selected by default.");
			}
		else
			{
				ExtentReportHelper.StepFail("'" + srcOfLiabilityChildsupport.getText() + "' option button is selected by default.");
			}	
		if(!srcOfLiabilityPrivateDebt.isSelected())
			{
				ExtentReportHelper.StepPass("'" + srcOfLiabilityPrivateDebt.getText() + "' option button is NOT selected by default.");
			}
		else
			{
				ExtentReportHelper.StepFail("'" + srcOfLiabilityPrivateDebt.getText() + "' option button is selected by default");
			}	
	}
	
	
	@When("^Select Liability Sources 'No other liabilities' or 'Any Liability Sources' on 'Liability Sources' Screen$")
	public void Select_Liability_Sources_No_other_liabilities_or_Any_Liability_Sources_on_Liability_Sources_Screen() throws Throwable {
		
		Map<String, String> Stage05_InputData =  Utility.readTestData(strfullPathToFile, sheetStage05_InputData,strtestCaseID);
		
		String strAlimonyLiability	= Stage05_InputData.get("LiabilitySources_Alimony");
		String strChildSupportLiability	= Stage05_InputData.get("LiabilitySources_ChildSupport");
		String strPrivateDebtLiability	= Stage05_InputData.get("LiabilitySources_PrivateDebt");
		
		if (strAlimonyLiability.contentEquals("Alimony")) {
			CommonAppMethodsAssetLiabilities.SelectLiabilitySources(strAlimonyLiability); 
		}
		if (strChildSupportLiability.contentEquals("Child support")) {
			CommonAppMethodsAssetLiabilities.SelectLiabilitySources(strChildSupportLiability); 
		}
		if (strPrivateDebtLiability .contentEquals("Private debt")) {
			CommonAppMethodsAssetLiabilities.SelectLiabilitySources(strPrivateDebtLiability ); 
		}
			
		if (strAlimonyLiability.contentEquals("No liabilities") | strChildSupportLiability.contentEquals("No liabilities") | strPrivateDebtLiability.contentEquals("No liabilities")) {
			CommonAppMethodsAssetLiabilities.SelectLiabilitySources("No liabilities"); 
		}
		//Common.continueButtonClicked();
		
		}
	
	@When("^Verify 'Liability-Sources-Details' Screen when select 'Any Liabilities' on 'Liability Sources' Screen$")
	public void Verify_Liability_Sources_Details_Screen_when_select_Any_Liabilities_on_Liability_Sources_Screen() throws Throwable {
		Map<String, String> Stage05_ExpectedData =  Utility.readTestData(strfullPathToFile, sheetStage05_ExpectedData,strtestCaseID);
		Map<String, String> Stage05_InputData =  Utility.readTestData(strfullPathToFile, sheetStage05_InputData,strtestCaseID);
		
			String strLiability_Details_ExpectedTitle	= Stage05_ExpectedData.get("Liability_Sources_Details_Title"); 
			String strNoOtherLiability_Input = Stage05_InputData.get("LiabilitySources_NoOtherLiabilities");
			QAFExtendedWebElement strLiability_Details_ActualTitle= new QAFExtendedWebElement("ehome.liabilitySrcDetails.Title");
			
			if (!strNoOtherLiability_Input.contentEquals("No liabilities")) {
				Common.continueButtonClicked();
				}
			
    		if (strLiability_Details_ExpectedTitle.contentEquals(strLiability_Details_ActualTitle.getText())) {
    			ExtentReportHelper.StepPass(strLiability_Details_ExpectedTitle + " Screen# is displayed.");
    		}
    		else
    		{
    			Assert.assertEquals(strLiability_Details_ActualTitle.getText(), strLiability_Details_ExpectedTitle,"'Liability Details' Screen is NOT as Expected.");
    		}	
		}
	
	//LiabilitySources-Retirement-TC-012_Verify presence of 'Remove' 'Continue' 'Select' 'No other liabilities' Options when 'Select' and 'UnSelect' 'Liabilities Sources'- 'Alimony' on 'Liabilities Source' Screen
		@Then("^Verify presence of 'Remove' 'Continue' and 'Select' 'No other liabilities' Options when 'Select' and 'UnSelect' 'Liabilities Sources'- 'Alimony' on 'Liabilities Sources' Screen$")
		public void Verify_presence_of_Remove_Continue_Select_No_other_liabilities_Options_when_Select_and_UnSelect_liabilities_Sources_Alimony_on_liabilities_Screen() throws Throwable {
			
			if (strAlimonyActualRemove.getText().contentEquals("Remove")) {
				ExtentReportHelper.StepPass("'" + strAlimonyActualRemove.getText() + "' option changed from 'Select' option when select Liabilities Source.");
			}
			else
			{
				ExtentReportHelper.StepFail("'" + strAlimonyActualRemove.getText() + "' option is NOT changed from 'Select' option when select Liabilities Source.");
			}
			Thread.sleep(250);
			if (strLiablity_ContinueBtn.getText().contentEquals("Continue")) {
				ExtentReportHelper.StepPass("'" + strLiablity_ContinueBtn.getText() + "' Button changed from 'No other Liabilities' Button when select Liabilities Source.");
			}
			else
			{
				ExtentReportHelper.StepFail("'" + strLiablity_ContinueBtn.getText() + "' Button is NOT changed from 'No other Liabilities' Button when select Liabilities Source.");
			}
			strAlimonyActualRemove.click();
			Thread.sleep(250);
			if (strAlimonyActualSelect.getText().contentEquals("Select")) {
				ExtentReportHelper.StepPass("'" + strAlimonyActualSelect.getText() + "' option changed from 'Remove' option when UnSelect Liabilities Source.");
			}
			else
			{
				ExtentReportHelper.StepFail("'" + strAlimonyActualSelect.getText() + "' option is NOT changed from 'Remove' option when UnSelect Liabilities Source.");
			}
			if (strNoOtherLiabilities_Link.getText().contentEquals("No other liabilities")) {
				ExtentReportHelper.StepPass("'" + strNoOtherLiabilities_Link.getText() + "' Button changed from 'Continue' Button when UnSelect Liabilities Source.");
			}
			else
			{
				ExtentReportHelper.StepFail("'" + strNoOtherLiabilities_Link.getText() + "' Button is NOT changed from 'Continue' Button when UnSelect Liabilities Source.");
			}
		}
		
	
		//LiabilitySources-Retirement-TC-013_Verify presence of 'Remove' 'Continue' 'Select' 'No other liabilities' Options when 'Select' and 'UnSelect' 'Liabilities Sources'- 'Child Support' on 'Liabilities Source' Screen
			@Then("^Verify presence of 'Remove' 'Continue' and 'Select' 'No other liabilities' Options when 'Select' and 'UnSelect' 'Liabilities Sources'- 'Child Support' on 'Liabilities Sources' Screen$")
			public void Verify_presence_of_Remove_Continue_Select_No_other_liabilities_Options_when_Select_and_UnSelect_liabilities_Sources_Child_Support_on_liabilities_Screen() throws Throwable {
				
				if (strChildSupportActualRemove.getText().contentEquals("Remove")) {
					ExtentReportHelper.StepPass("'" + strChildSupportActualRemove.getText() + "' option changed from 'Select' option when select Liabilities Source.");
				}
				else
				{
					ExtentReportHelper.StepFail("'" + strChildSupportActualRemove.getText() + "' option is NOT changed from 'Select' option when select Liabilities Source.");
				}
				Thread.sleep(250);
				if (strLiablity_ContinueBtn.getText().contentEquals("Continue")) {
					ExtentReportHelper.StepPass("'" + strLiablity_ContinueBtn.getText() + "' Button changed from 'No other Liabilities' Button when select Liabilities Source.");
				}
				else
				{
					ExtentReportHelper.StepFail("'" + strLiablity_ContinueBtn.getText() + "' Button is NOT changed from 'No other Liabilities' Button when select Liabilities Source.");
				}
				strChildSupportActualRemove.click();
				Thread.sleep(250);
				if (strChildSupportActualSelect.getText().contentEquals("Select")) {
					ExtentReportHelper.StepPass("'" + strChildSupportActualSelect.getText() + "' option changed from 'Remove' option when UnSelect Liabilities Source.");
				}
				else
				{
					ExtentReportHelper.StepFail("'" + strChildSupportActualSelect.getText() + "' option is NOT changed from 'Remove' option when UnSelect Liabilities Source.");
				}
				if (strNoOtherLiabilities_Link.getText().contentEquals("No other liabilities")) {
					ExtentReportHelper.StepPass("'" + strNoOtherLiabilities_Link.getText() + "' Button changed from 'Continue' Button when UnSelect Liabilities Source.");
				}
				else
				{
					ExtentReportHelper.StepFail("'" + strNoOtherLiabilities_Link.getText() + "' Button is NOT changed from 'Continue' Button when UnSelect Liabilities Source.");
				}
			}
	
	//LiabilitySources-Retirement-TC-014_Verify presence of 'Remove' 'Continue' 'Select' 'No other liabilities' Options when 'Select' and 'UnSelect' 'Liabilities Sources'- 'Private Debt' on 'Liabilities Source' Screen
			@Then("^Verify presence of 'Remove' 'Continue' and 'Select' 'No other liabilities' Options when 'Select' and 'UnSelect' 'Liabilities Sources'- 'Private Debt' on 'Liabilities Sources' Screen$")
			public void Verify_presence_of_Remove_Continue_Select_No_other_liabilities_Options_when_Select_and_UnSelect_liabilities_Sources_PrivateDebt_on_liabilities_Screen() throws Throwable {
				
				if (strPrivateDebtActualRemove.getText().contentEquals("Remove")) {
					ExtentReportHelper.StepPass("'" + strPrivateDebtActualRemove.getText() + "' option changed from 'Select' option when select Liabilities Source.");
				}
				else
				{
					ExtentReportHelper.StepFail("'" + strPrivateDebtActualRemove.getText() + "' option is NOT changed from 'Select' option when select Liabilities Source.");
				}
				Thread.sleep(250);
				if (strLiablity_ContinueBtn.getText().contentEquals("Continue")) {
					ExtentReportHelper.StepPass("'" + strLiablity_ContinueBtn.getText() + "' Button changed from 'No other Liabilities' Button when select Liabilities Source.");
				}
				else
				{
					ExtentReportHelper.StepFail("'" + strLiablity_ContinueBtn.getText() + "' Button is NOT changed from 'No other Liabilities' Button when select Liabilities Source.");
				}
				strPrivateDebtActualRemove.click();
				Thread.sleep(250);
				if (strPrivateDebtActualSelect.getText().contentEquals("Select")) {
					ExtentReportHelper.StepPass("'" + strPrivateDebtActualSelect.getText() + "' option changed from 'Remove' option when UnSelect Liabilities Source.");
				}
				else
				{
					ExtentReportHelper.StepFail("'" + strPrivateDebtActualSelect.getText() + "' option is NOT changed from 'Remove' option when UnSelect Liabilities Source.");
				}
				if (strNoOtherLiabilities_Link.getText().contentEquals("No other liabilities")) {
					ExtentReportHelper.StepPass("'" + strNoOtherLiabilities_Link.getText() + "' Button changed from 'Continue' Button when UnSelect Liabilities Source.");
				}
				else
				{
					ExtentReportHelper.StepFail("'" + strNoOtherLiabilities_Link.getText() + "' Button is NOT changed from 'Continue' Button when UnSelect Liabilities Source.");
				}
			}	

			//LiabilitySources-Retirement-TC-015_Verify presence of 'Remove' 'Continue' 'Select' 'No other liabilities' Options when 'Select' and 'UnSelect' 'Liabilities Sources'- 'Alimony' on 'Liabilities Source' Screen
			@Then("^Verify presence of 'Remove' 'Continue' and 'Select' 'No other liabilities' Options when 'Select' and 'UnSelect' 'Liabilities Sources'- 'Alimony' 'Child Support' on 'Liabilities Sources' Screen$")
			public void Verify_presence_of_Remove_Continue_Select_No_other_liabilities_Options_when_Select_and_UnSelect_liabilities_Sources_Alimony_Child_Support_on_liabilities_Screen() throws Throwable {
				
				if (strAlimonyActualRemove.getText().contentEquals("Remove")) {
					ExtentReportHelper.StepPass("'" + strAlimonyActualRemove.getText() + "' option changed from 'Select' option when select Liabilities Source.");
				}
				else
				{
					ExtentReportHelper.StepFail("'" + strAlimonyActualRemove.getText() + "' option is NOT changed from 'Select' option when select Liabilities Source.");
				}
				
				if (strChildSupportActualRemove.getText().contentEquals("Remove")) {
					ExtentReportHelper.StepPass("'" + strChildSupportActualRemove.getText() + "' option changed from 'Select' option when select Liabilities Source.");
				}
				else
				{
					ExtentReportHelper.StepFail("'" + strChildSupportActualRemove.getText() + "' option is NOT changed from 'Select' option when select Liabilities Source.");
				}
				
				
				Thread.sleep(250);
				if (strLiablity_ContinueBtn.getText().contentEquals("Continue")) {
					ExtentReportHelper.StepPass("'" + strLiablity_ContinueBtn.getText() + "' Button changed from 'No other Liabilities' Button when select Liabilities Source.");
				}
				else
				{
					ExtentReportHelper.StepFail("'" + strLiablity_ContinueBtn.getText() + "' Button is NOT changed from 'No other Liabilities' Button when select Liabilities Source.");
				}
				strAlimonyActualRemove.click();
				strChildSupportActualRemove.click();
				Thread.sleep(250);
				if (strAlimonyActualSelect.getText().contentEquals("Select")) {
					ExtentReportHelper.StepPass("'" + strAlimonyActualSelect.getText() + "' option changed from 'Remove' option when UnSelect Liabilities Source.");
				}
				else
				{
					ExtentReportHelper.StepFail("'" + strAlimonyActualSelect.getText() + "' option is NOT changed from 'Remove' option when UnSelect Liabilities Source.");
				}
				
				if (strChildSupportActualSelect.getText().contentEquals("Select")) {
					ExtentReportHelper.StepPass("'" + strChildSupportActualSelect.getText() + "' option changed from 'Remove' option when UnSelect Liabilities Source.");
				}
				else
				{
					ExtentReportHelper.StepFail("'" + strChildSupportActualSelect.getText() + "' option is NOT changed from 'Remove' option when UnSelect Liabilities Source.");
				}
				if (strNoOtherLiabilities_Link.getText().contentEquals("No other liabilities")) {
					ExtentReportHelper.StepPass("'" + strNoOtherLiabilities_Link.getText() + "' Button changed from 'Continue' Button when UnSelect Liabilities Source.");
				}
				else
				{
					ExtentReportHelper.StepFail("'" + strNoOtherLiabilities_Link.getText() + "' Button is NOT changed from 'Continue' Button when UnSelect Liabilities Source.");
				}
			}	

			//LiabilitySources-Retirement-TC-016_Verify presence of 'Remove' 'Continue' 'Select' 'No other liabilities' Options when 'Select' and 'UnSelect' 'Liabilities Sources'- 'Child Support' 'Private Debt' on 'Liabilities Source' Screen
			@Then("^Verify presence of 'Remove' 'Continue' and 'Select' 'No other liabilities' Options when 'Select' and 'UnSelect' 'Liabilities Sources'- 'Child Support' 'Private Debt' on 'Liabilities Sources' Screen$")
			public void Verify_presence_of_Remove_Continue_Select_No_other_liabilities_Options_when_Select_and_UnSelect_liabilities_Sources_Private_Debt_Child_Support_on_liabilities_Screen() throws Throwable {
				
				
				if (strChildSupportActualRemove.getText().contentEquals("Remove")) {
					ExtentReportHelper.StepPass("'" + strChildSupportActualRemove.getText() + "' option changed from 'Select' option when select Liabilities Source.");
				}
				else
				{
					ExtentReportHelper.StepFail("'" + strChildSupportActualRemove.getText() + "' option is NOT changed from 'Select' option when select Liabilities Source.");
				}
				
				if (strPrivateDebtActualRemove.getText().contentEquals("Remove")) {
					ExtentReportHelper.StepPass("'" + strPrivateDebtActualRemove.getText() + "' option changed from 'Select' option when select Liabilities Source.");
				}
				else
				{
					ExtentReportHelper.StepFail("'" + strPrivateDebtActualRemove.getText() + "' option is NOT changed from 'Select' option when select Liabilities Source.");
				}
				
				Thread.sleep(250);
				if (strLiablity_ContinueBtn.getText().contentEquals("Continue")) {
					ExtentReportHelper.StepPass("'" + strLiablity_ContinueBtn.getText() + "' Button changed from 'No other Liabilities' Button when select Liabilities Source.");
				}
				else
				{
					ExtentReportHelper.StepFail("'" + strLiablity_ContinueBtn.getText() + "' Button is NOT changed from 'No other Liabilities' Button when select Liabilities Source.");
				}
				strChildSupportActualRemove.click();
				strPrivateDebtActualRemove.click();
				Thread.sleep(250);
				
				if (strChildSupportActualSelect.getText().contentEquals("Select")) {
					ExtentReportHelper.StepPass("'" + strChildSupportActualSelect.getText() + "' option changed from 'Remove' option when UnSelect Liabilities Source.");
				}
				else
				{
					ExtentReportHelper.StepFail("'" + strChildSupportActualSelect.getText() + "' option is NOT changed from 'Remove' option when UnSelect Liabilities Source.");
				}
				
				if (strPrivateDebtActualSelect.getText().contentEquals("Select")) {
					ExtentReportHelper.StepPass("'" + strPrivateDebtActualSelect.getText() + "' option changed from 'Remove' option when UnSelect Liabilities Source.");
				}
				else
				{
					ExtentReportHelper.StepFail("'" + strPrivateDebtActualSelect.getText() + "' option is NOT changed from 'Remove' option when UnSelect Liabilities Source.");
				}
			
				if (strNoOtherLiabilities_Link.getText().contentEquals("No other liabilities")) {
					ExtentReportHelper.StepPass("'" + strNoOtherLiabilities_Link.getText() + "' Button changed from 'Continue' Button when UnSelect Liabilities Source.");
				}
				else
				{
					ExtentReportHelper.StepFail("'" + strNoOtherLiabilities_Link.getText() + "' Button is NOT changed from 'Continue' Button when UnSelect Liabilities Source.");
				}
			}	

			//LiabilitySources-Retirement-TC-017_Verify presence of 'Remove' 'Continue' 'Select' 'No other liabilities' Options when 'Select' and 'UnSelect' 'Liabilities Sources'- 'Alimony' 'Private Debt' on 'Liabilities Source' Screen
			@Then("^Verify presence of 'Remove' 'Continue' and 'Select' 'No other liabilities' Options when 'Select' and 'UnSelect' 'Liabilities Sources'- 'Alimony' 'Private Debt' on 'Liabilities Sources' Screen$")
			public void Verify_presence_of_Remove_Continue_Select_No_other_liabilities_Options_when_Select_and_UnSelect_liabilities_Sources_Private_Debt_Alimony_on_liabilities_Screen() throws Throwable {
				
				
				if (strAlimonyActualRemove.getText().contentEquals("Remove")) {
					ExtentReportHelper.StepPass("'" + strAlimonyActualRemove.getText() + "' option changed from 'Select' option when select Liabilities Source.");
				}
				else
				{
					ExtentReportHelper.StepFail("'" + strAlimonyActualRemove.getText() + "' option is NOT changed from 'Select' option when select Liabilities Source.");
				}
				
				if (strPrivateDebtActualRemove.getText().contentEquals("Remove")) {
					ExtentReportHelper.StepPass("'" + strPrivateDebtActualRemove.getText() + "' option changed from 'Select' option when select Liabilities Source.");
				}
				else
				{
					ExtentReportHelper.StepFail("'" + strPrivateDebtActualRemove.getText() + "' option is NOT changed from 'Select' option when select Liabilities Source.");
				}
				
				
				
				Thread.sleep(250);
				if (strLiablity_ContinueBtn.getText().contentEquals("Continue")) {
					ExtentReportHelper.StepPass("'" + strLiablity_ContinueBtn.getText() + "' Button changed from 'No other Liabilities' Button when select Liabilities Source.");
				}
				else
				{
					ExtentReportHelper.StepFail("'" + strLiablity_ContinueBtn.getText() + "' Button is NOT changed from 'No other Liabilities' Button when select Liabilities Source.");
				}
				strAlimonyActualRemove.click();
				strPrivateDebtActualRemove.click();
				Thread.sleep(250);
				
				if (strAlimonyActualSelect.getText().contentEquals("Select")) {
					ExtentReportHelper.StepPass("'" + strAlimonyActualSelect.getText() + "' option changed from 'Remove' option when UnSelect Liabilities Source.");
				}
				else
				{
					ExtentReportHelper.StepFail("'" + strAlimonyActualSelect.getText() + "' option is NOT changed from 'Remove' option when UnSelect Liabilities Source.");
				}
				
				if (strPrivateDebtActualSelect.getText().contentEquals("Select")) {
					ExtentReportHelper.StepPass("'" + strPrivateDebtActualSelect.getText() + "' option changed from 'Remove' option when UnSelect Liabilities Source.");
				}
				else
				{
					ExtentReportHelper.StepFail("'" + strPrivateDebtActualSelect.getText() + "' option is NOT changed from 'Remove' option when UnSelect Liabilities Source.");
				}
			
				if (strNoOtherLiabilities_Link.getText().contentEquals("No other liabilities")) {
					ExtentReportHelper.StepPass("'" + strNoOtherLiabilities_Link.getText() + "' Button changed from 'Continue' Button when UnSelect Liabilities Source.");
				}
				else
				{
					ExtentReportHelper.StepFail("'" + strNoOtherLiabilities_Link.getText() + "' Button is NOT changed from 'Continue' Button when UnSelect Liabilities Source.");
				}
			}	

			//LiabilitySources-Retirement-TC-018_Verify presence of 'Remove' 'Continue' 'Select' 'No other liabilities' Options when 'Select' and 'UnSelect' 'Liabilities Sources'- 'Alimony' 'Child Support' 'Private Debt' on 'Liabilities Source' Screen
			@Then("^Verify presence of 'Remove' 'Continue' and 'Select' 'No other liabilities' Options when 'Select' and 'UnSelect' 'Liabilities Sources'- 'Alimony' 'Child Support' 'Private Debt' on 'Liabilities Sources' Screen$")
			public void Verify_presence_of_Remove_Continue_Select_No_other_liabilities_Options_when_Select_and_UnSelect_liabilities_Sources_Alimony_Child_Support_Private_Debt_on_liabilities_Screen() throws Throwable {
				
				if (strAlimonyActualRemove.getText().contentEquals("Remove")) {
					ExtentReportHelper.StepPass("'" + strAlimonyActualRemove.getText() + "' option changed from 'Select' option when select Liabilities Source.");
				}
				else
				{
					ExtentReportHelper.StepFail("'" + strAlimonyActualRemove.getText() + "' option is NOT changed from 'Select' option when select Liabilities Source.");
				}
				
				if (strChildSupportActualRemove.getText().contentEquals("Remove")) {
					ExtentReportHelper.StepPass("'" + strChildSupportActualRemove.getText() + "' option changed from 'Select' option when select Liabilities Source.");
				}
				else
				{
					ExtentReportHelper.StepFail("'" + strChildSupportActualRemove.getText() + "' option is NOT changed from 'Select' option when select Liabilities Source.");
				}
				
				if (strPrivateDebtActualRemove.getText().contentEquals("Remove")) {
					ExtentReportHelper.StepPass("'" + strPrivateDebtActualRemove.getText() + "' option changed from 'Select' option when select Liabilities Source.");
				}
				else
				{
					ExtentReportHelper.StepFail("'" + strPrivateDebtActualRemove.getText() + "' option is NOT changed from 'Select' option when select Liabilities Source.");
				}
				
				
				Thread.sleep(250);
				if (strLiablity_ContinueBtn.getText().contentEquals("Continue")) {
					ExtentReportHelper.StepPass("'" + strLiablity_ContinueBtn.getText() + "' Button changed from 'No other Liabilities' Button when select Liabilities Source.");
				}
				else
				{
					ExtentReportHelper.StepFail("'" + strLiablity_ContinueBtn.getText() + "' Button is NOT changed from 'No other Liabilities' Button when select Liabilities Source.");
				}
				strAlimonyActualRemove.click();
				strChildSupportActualRemove.click();
				strPrivateDebtActualRemove.click();
				Thread.sleep(250);
				if (strAlimonyActualSelect.getText().contentEquals("Select")) {
					ExtentReportHelper.StepPass("'" + strAlimonyActualSelect.getText() + "' option changed from 'Remove' option when UnSelect Liabilities Source.");
				}
				else
				{
					ExtentReportHelper.StepFail("'" + strAlimonyActualSelect.getText() + "' option is NOT changed from 'Remove' option when UnSelect Liabilities Source.");
				}
				
				if (strChildSupportActualSelect.getText().contentEquals("Select")) {
					ExtentReportHelper.StepPass("'" + strChildSupportActualSelect.getText() + "' option changed from 'Remove' option when UnSelect Liabilities Source.");
				}
				else
				{
					ExtentReportHelper.StepFail("'" + strChildSupportActualSelect.getText() + "' option is NOT changed from 'Remove' option when UnSelect Liabilities Source.");
				}
				
				
				if (strPrivateDebtActualSelect.getText().contentEquals("Select")) {
					ExtentReportHelper.StepPass("'" + strPrivateDebtActualSelect.getText() + "' option changed from 'Remove' option when UnSelect Liabilities Source.");
				}
				else
				{
					ExtentReportHelper.StepFail("'" + strPrivateDebtActualSelect.getText() + "' option is NOT changed from 'Remove' option when UnSelect Liabilities Source.");
				}
				if (strNoOtherLiabilities_Link.getText().contentEquals("No other liabilities")) {
					ExtentReportHelper.StepPass("'" + strNoOtherLiabilities_Link.getText() + "' Button changed from 'Continue' Button when UnSelect Liabilities Source.");
				}
				else
				{
					ExtentReportHelper.StepFail("'" + strNoOtherLiabilities_Link.getText() + "' Button is NOT changed from 'Continue' Button when UnSelect Liabilities Source.");
				}
			}	
	
	
	
}
