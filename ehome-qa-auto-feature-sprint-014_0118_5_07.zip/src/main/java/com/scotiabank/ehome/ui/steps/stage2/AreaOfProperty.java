package com.scotiabank.ehome.ui.steps.stage2;

import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.step.QAFTestStepProvider;
import com.qmetry.qaf.automation.ui.WebDriverTestBase;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebDriver;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.quantum.utils.ConfigurationUtils;
import com.scotiabank.ehome.ui.steps.Common;
import com.scotiabank.ehome.ui.steps.ExcelDataToDataTable;
import com.scotiabank.ehome.ui.steps.Utility;
import com.scotiabank.ehome.ui.steps.valueObjects.Tuple;
import com.scotiabank.ehome.ui.steps.valueObjects.TypeOfRateVO;

import org.junit.runner.RunWith;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;

import cucumber.api.CucumberOptions;
import cucumber.api.DataTable;
import cucumber.api.Transform;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import cucumber.api.junit.Cucumber;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import static com.scotiabank.ehome.ui.steps.BusinessCalculations.*;
import static com.scotiabank.ehome.ui.steps.Utility.*;

@QAFTestStepProvider
public class AreaOfProperty {

	 public static WebDriverWait wait=Utility.getWait();

	// Scenario:Area_of_Property_001

	@Given("^Customer should login and navigates to Area of Property screen with condo as type of Property$")
	public void customer_should_login_and_navigates_to_Area_of_Property_screenwith_condo_as_type_of_Property() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
				Utility.launchURL(ConfigurationUtils.getBaseBundle().getPropertyValue ("env.baseurl1"));
		    	//To click Continue in Section breaker
		        Common.sessionBreakerContinueButtonClick();
		        //To enter manual address 
		       	Common.enterAddressManually();
		       	//To select house
		 	     PropertyType.condoButtonClicked();
		         Thread.sleep(2000); 
		         String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_InputData", "Condo-Fees-TC-006", "Condo-Fees");
				CondoFees.condoFees(value);
				Common.continueButtonClicked();

	}
	@Given("^Customer should login and navigates to Area of Property screen with house as type of Property$")
	public void customer_should_login_and_navigates_to_Area_of_Property_screen_with_house_as_type_of_Property() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
				Utility.launchURL(ConfigurationUtils.getBaseBundle().getPropertyValue ("env.baseurl1"));
		    	//To click Continue in Section breaker
		        Common.sessionBreakerContinueButtonClick();
		        //To enter manual address 
		       	Common.enterAddressManually();
		       	//To select house
		 	     PropertyType.houseButtonClicked();
		         Thread.sleep(2000); 
		         String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_InputData", "Type-Of-House-TC-004", "Detached");
		         TypeOfHouse.typeOfHouseButtonClicked(value);

	}

	// Scenario: Area_of_Property_002
	@When("^verify \"([^\"]*)\" in Area of Property screen$")
	public void Verify_Your_new_in_Area_of_Property_screen(String dataPointer) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		String testCaseID = Utility.getScenarioID();
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_ExpectedData", testCaseID, dataPointer);
		Assert.assertEquals(Common.headerMessage(), value,"Couldn't found expected header text");
	}

	@Then("^\"([^\"]*)\" should be displayed in Area of Property screen$")
	public void should_be_displayed_in_Area_of_Property_screen(String dataPointer) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		String testCaseID = Utility.getScenarioID();
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_ExpectedData", testCaseID, dataPointer);
		Assert.assertEquals(Common.headertext(), value,"Couldn't found expected header text");
	}
	@And("^\"([^\"]*)\" displayed in Area of Property screen$")
	public void displayed_in_Area_of_Property_screen(String dataPointer) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		String testCaseID = Utility.getScenarioID();
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_ExpectedData", testCaseID, dataPointer);
		QAFExtendedWebElement areaSqFt= new QAFExtendedWebElement("ehome.areaOfProp.areaSqFt");
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(areaSqFt));
		Assert.assertEquals(areaSqFt.getText(), value,"Couldn't found expected header text");
	}
	// Scenario: Area_of_Property_003

	@When("^Enter \"([^\"]*)\" in Area of Property screen$")
	public void enter_in_Area_of_Property_screen(String dataPointer) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "CommonErrorMessages",dataPointer, "InputValues" );
		QAFExtendedWebElement areainsqft= new QAFExtendedWebElement("ehome.areaOfProp.sqft.value");
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(areainsqft));
		areainsqft.clear();
		areainsqft.sendKeys(value);
	   
	}

	@Then("^Error message \"([^\"]*)\" should be displayed Area of Property screen$")
	public void error_message_should_be_displayed_in_Area_of_Property_screen(String dataPointer) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		String testCaseID = Utility.getScenarioID();
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_ExpectedData", testCaseID, dataPointer);
		QAFExtendedWebElement errormsg = new QAFExtendedWebElement("ehome.areaOfProp.errormsg");
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(errormsg));
		Assert.assertEquals(errormsg.getText(), value,"Couldn't found expected header text");
	}

	// Scenario: Area_of_Property_004
	@When("^Click on back button button in Area of Property screen$")
	public void click_on_back_button_button_in_Area_of_Property_screen() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		Common.backButtonClicked();
	}

	// Scenario: Area_of_Property_005
	 public static void squarefeet(String value) {
		 QAFExtendedWebElement areainsqft= new QAFExtendedWebElement("//*[@id=\"sqFeet\"]");
			wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(areainsqft));
			areainsqft.clear();
			areainsqft.sendKeys(value);
	        
		}
	@When("^Enter \"([^\"]*)\" square feet in Area of Property screen$")
	public void enter_square_feet_in_Area_of_Property_screen(String dataPointer) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String testCaseID = Utility.getScenarioID();
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_InputData", testCaseID, dataPointer);
		squarefeet(value);
	   
	}
	
	@Then("^\"([^\"]*)\" header should be displayed in Purchase Price screen$")
	public void header_should_be_displayed_in_Purchase_Price_screen(String dataPointer) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		String testCaseID = Utility.getScenarioID();
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_ExpectedData", testCaseID, dataPointer);
		Assert.assertEquals(Common.headertext(), value,"Couldn't found expected header text");
	}

		
	@Then("^It should navigate to Area of Property screen$")
	public void It_should_navigate_to_Area_of_Property_screen() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		QAFExtendedWebElement AreaofPropertyheader = new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[1]/section/div[2]/div/p");
		AreaofPropertyheader.isPresent();
	}

	
}
