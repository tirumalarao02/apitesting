package com.scotiabank.ehome.ui.steps;

import java.util.HashMap;
import java.util.Map;

import org.testng.Assert;

import com.qmetry.qaf.automation.step.QAFTestStepProvider;
import com.quantum.utils.ConfigurationUtils;

import cucumber.api.java.en.Given;

@QAFTestStepProvider
public class SampleTest {
	
	@Given("^eHome Appium Test$")
	public void ehome_Appium_Test() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Utility.launchURL(ConfigurationUtils.getBaseBundle().getPropertyValue ("env.baseurl1"));
		Thread.sleep(5000);
		
		Object ops = null;
		Map<String, Object> continueBtnClick = new HashMap<>();
		continueBtnClick.put("label", "Continue");
		continueBtnClick.put("threshold", "80");
		continueBtnClick.put("operation", "single");
		//ops = DriverUtils.getAppiumDriver().executeScript("mobile:button-text:click", continueBtnClick);
		Utility.webDriver.executeScript("mobile:button-text:click", continueBtnClick);
		Thread.sleep(5000);
		
		Map<String, Object> address = new HashMap<>();
		address.put("label", "No., Street name, Postal code");
		address.put("text", "2021 EGLINTON AVE E TORONTO ON M1L2M9");
		address.put("operation", "single");
		address.put("threshold", "80");
		//ops = DriverUtils.getAppiumDriver().executeScript("mobile:edit-text:set", address);
		Utility.webDriver.executeScript("mobile:edit-text:set", address);
		Thread.sleep(5000);
		
		Map<String, Object> addressSelect = new HashMap<>();
		addressSelect.put("label", "2021 EGLINTON AVE E TORONTO ON M1L2M9");
		addressSelect.put("threshold", "80");
		addressSelect.put("operation", "single");
		//ops = DriverUtils.getAppiumDriver().executeScript("mobile:button-text:click", addressSelect);
		Utility.webDriver.executeScript("mobile:button-text:click", addressSelect);
		Thread.sleep(5000);
		
		Map<String, Object> doneBtnClick = new HashMap<>();
		doneBtnClick.put("label", "Done");
		doneBtnClick.put("threshold", "80");
		doneBtnClick.put("operation", "single");
		//ops = DriverUtils.getAppiumDriver().executeScript("mobile:button-text:click", doneBtnClick);
		Utility.webDriver.executeScript("mobile:button-text:click", doneBtnClick);
		Thread.sleep(5000);
		
		Map<String, Object> continueBtnClick1 = new HashMap<>();
		continueBtnClick1.put("label", "Continue");
		continueBtnClick1.put("threshold", "80");
		continueBtnClick1.put("operation", "single");
		//ops = DriverUtils.getAppiumDriver().executeScript("mobile:button-text:click", continueBtnClick1);
		Utility.webDriver.executeScript("mobile:button-text:click", continueBtnClick1);
		Thread.sleep(5000);
		
		Map<String, Object> houseSelect = new HashMap<>();
		houseSelect.put("label", "House");
		houseSelect.put("threshold", "80");
		houseSelect.put("operation", "single");
		//ops = DriverUtils.getAppiumDriver().executeScript("mobile:button-text:click", houseSelect);
		Utility.webDriver.executeScript("mobile:button-text:click", houseSelect);
		Thread.sleep(5000);
		
		Map<String, Object> typeOfHouseSelect = new HashMap<>();
		typeOfHouseSelect.put("label", "semi-detached");
		typeOfHouseSelect.put("threshold", "80");
		typeOfHouseSelect.put("operation", "single");
		//ops = DriverUtils.getAppiumDriver().executeScript("mobile:button-text:click", typeOfHouseSelect);
		Utility.webDriver.executeScript("mobile:button-text:click", typeOfHouseSelect);
		Thread.sleep(5000);
		
		Map<String, Object> areaSqft = new HashMap<>();
		areaSqft.put("label", "PRIVATE:script/Apple_iPhone-X_181219_192947.png");
		areaSqft.put("text", "1000");
		areaSqft.put("operation", "single");
		areaSqft.put("threshold", "80");
		areaSqft.put("image.top", "778");
		areaSqft.put("image.height", "159");
		areaSqft.put("image.left", "89");
		areaSqft.put("image.width", "945");
		//ops = DriverUtils.getAppiumDriver().executeScript("mobile:edit-image:set", areaSqft);
		Utility.webDriver.executeScript("mobile:edit-image:set", areaSqft);
		Thread.sleep(5000);
		
		Map<String, Object> doneBtnClick1 = new HashMap<>();
		doneBtnClick1.put("label", "Done");
		doneBtnClick1.put("threshold", "80");
		doneBtnClick1.put("operation", "single");
		//ops = DriverUtils.getAppiumDriver().executeScript("mobile:button-text:click", doneBtnClick1);
		Utility.webDriver.executeScript("mobile:button-text:click", doneBtnClick1);
		Thread.sleep(5000);
		
		Map<String, Object> continueBtnClick2 = new HashMap<>();
		continueBtnClick2.put("label", "Continue");
		continueBtnClick2.put("threshold", "80");
		continueBtnClick2.put("operation", "single");
		//ops = DriverUtils.getAppiumDriver().executeScript("mobile:button-text:click", continueBtnClick2);
		Utility.webDriver.executeScript("mobile:button-text:click", continueBtnClick2);
		
		Assert.assertTrue(true);
		
				
		
		
		
		
		
		
		
		
		
		
	}

}
