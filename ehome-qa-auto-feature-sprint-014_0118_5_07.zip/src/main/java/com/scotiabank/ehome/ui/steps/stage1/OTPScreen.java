package com.scotiabank.ehome.ui.steps.stage1;

import static com.scotiabank.ehome.ui.steps.Utility.getScreenDataset;

import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.qmetry.qaf.automation.step.QAFTestStepProvider;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebDriver;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.quantum.utils.ConfigurationUtils;
import com.scotiabank.ehome.ui.steps.Common;
import com.scotiabank.ehome.ui.steps.Utility;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

@QAFTestStepProvider
public class OTPScreen {

	private QAFExtendedWebDriver webDriver = Utility.getDriver();
    public Actions action = null;
    public static WebDriverWait wait=Utility.getWait();	
    
    private Map<String,Map<String,Boolean>> emailAddressExcel = getScreenDataset(Utility.getExcelFilePath("eHomeTestDatastage-4.xlsx"), "MobilePhoneNumber");
    //private Map<String,Map<String,Boolean>> emailAddressDataset = getScreenDataset(Utility.getExcelFilePath("eHomeTestDatastage-4.xlsx"), "IndustryAndJobTitle");
    
    QAFExtendedWebElement otpScreenHeaderTitle= new QAFExtendedWebElement("ehome.otpScreen.headerTitle");
    QAFExtendedWebElement otpScreenHeaderText= new QAFExtendedWebElement("ehome.otpScreen.headerText");
    QAFExtendedWebElement hyperlink= new QAFExtendedWebElement("ehome.otpScreen.hyperlink");
    QAFExtendedWebElement mobilePhoneNumberTxt= new QAFExtendedWebElement("ehome.mobilePhoneNumber.headerText");
    QAFExtendedWebElement timetocreateusernameHeaderTxt= new QAFExtendedWebElement("ehome.otpScreen.timetocreateusernameHeader");
    QAFExtendedWebElement emptySecurityCodeError= new QAFExtendedWebElement("ehome.otpScreen.emptySecurityCodeError");
    
	@Given("^Customer should login and navigates to OTP Screen$")
	public void customer_should_login_and_navigates_to_OTP_Screen() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    // Write code here that turns the phrase above into concrete actions
		Utility.launchURL(ConfigurationUtils.getBaseBundle().getPropertyValue ("env.baseurl0"));
		Welcome.viewOurPrivacyAgreementButtonClicked();
		PrivacyAgreement.acceptAndContinuetButtonClicked();
		SOLCustomerQuestion.triageQuestionsButtonClicked();
		SOLCustomerQuestion.noButtonClicked();
		LegalName.validlegalname("Mrs", "Delna", "Dr", "Press");
		Common.continueButtonClicked();
		MaritalStatus.maritalstatusselect("Married");
		Common.continueButtonClicked();
		DateOfBirth.dateOfBirth("20", "Mar", "1998");
		Common.continueButtonClicked();
		WhatsYourAddress.ValidWhatsYourAddressValues("2201", "EGLINTON AVE", "TORONTO", "ONTARIO","M1K2M1");
		Common.continueButtonClicked();
		Thread.sleep(4000);
		EmailAddress.ValidEmailAddress("test@test.com", "test@test.com");
		Common.continueButtonClicked();
		Thread.sleep(4000);
		MobilePhoneNumber.ValidMobilePhoneNumber("616", "237", "2324");
		Common.continueButtonClicked();
		Thread.sleep(4000);
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(otpScreenHeaderTitle));
	}
	
	@Then("^Verify \"([^\"]*)\" message should be on OTP Screen$")
	public void verify_message_should_be_on_OTP_Screen(String dataPointer) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String testCaseID = Utility.getScenarioID();
		String otpScreenHeaderTitleText=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage01_Registration_ExpectedDa", testCaseID, dataPointer);
		 wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(otpScreenHeaderTitle));
		 Assert.assertEquals(otpScreenHeaderTitle.getText(), otpScreenHeaderTitleText,"Couldn't find expected header message");
	}

	@Then("^Verify \"([^\"]*)\" headertext should be on OTP Screen$")
	public void verify_headertext_should_be_on_OTP_Screen(String dataPointer) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String testCaseID = Utility.getScenarioID();
		String otpScreenHeaderTxt=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage01_Registration_ExpectedDa", testCaseID, dataPointer);
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(otpScreenHeaderText));
		Assert.assertEquals(otpScreenHeaderText.getText(), otpScreenHeaderTxt,"Couldn't find expected header text message");
	}

	@Then("^Verify \"([^\"]*)\" hyperlink should be on OTP Screen$")
	public void verify_hyperlink_should_be_on_OTP_Screen(String dataPointer) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String testCaseID = Utility.getScenarioID();
		String hyperText=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage01_Registration_ExpectedDa", testCaseID, dataPointer);
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(hyperlink));
		Assert.assertEquals(hyperlink.getText(), hyperText,"Couldn't find expected hyper text message");
	}
	
	@When("^Back button is clicked on OTP Screen$")
	public void back_button_is_clicked_on_OTP_Screen() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Common.backButtonClicked();
	}

	@Then("^should able to navigate to \"([^\"]*)\" on OTP Screen$")
	public void should_able_to_navigate_to_on_OTP_Screen(String dataPointer) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String testCaseID = Utility.getScenarioID();
		String mobilePhoneNumberText=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage01_Registration_ExpectedDa", testCaseID, dataPointer);
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(mobilePhoneNumberTxt));
		Assert.assertEquals(mobilePhoneNumberTxt.getText(), mobilePhoneNumberText,"Couldn't find expected hyper text message");
	}
	
	public static void ValidOTPCode(String OTPText1,String OTPText2,String OTPText3,String OTPText4,String OTPText5,String OTPText6) throws InterruptedException {
		 QAFExtendedWebElement OTPNumberText1= new QAFExtendedWebElement("ehome.otpScreen.OTPNumberText1");
		 QAFExtendedWebElement OTPNumberText2= new QAFExtendedWebElement("ehome.otpScreen.OTPNumberText2");
		 QAFExtendedWebElement OTPNumberText3= new QAFExtendedWebElement("ehome.otpScreen.OTPNumberText3");
		 QAFExtendedWebElement OTPNumberText4= new QAFExtendedWebElement("ehome.otpScreen.OTPNumberText4");
		 QAFExtendedWebElement OTPNumberText5= new QAFExtendedWebElement("ehome.otpScreen.OTPNumberText5");
		 QAFExtendedWebElement OTPNumberText6= new QAFExtendedWebElement("ehome.otpScreen.OTPNumberText6");
		 OTPNumberText1.sendKeys(OTPText1);
		 OTPNumberText2.sendKeys(OTPText2);
		 OTPNumberText3.sendKeys(OTPText3);
		 OTPNumberText4.sendKeys(OTPText4);
		 OTPNumberText5.sendKeys(OTPText5);
		 OTPNumberText6.sendKeys(OTPText6);
	}
	
	@When("^Continue button is clicked on OTP Screen$")
	public void continue_button_is_clicked_on_OTP_Screen() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   // Common.continueButtonClicked();
		ValidOTPCode("1","2","3","4","5","6");//THIS SHOULD BE REMOVED
	    Thread.sleep(4000);//THIS SHOULD BE REMOVED
	    Common.backButtonClicked();//THIS SHOULD BE REMOVED
	    Thread.sleep(4000);//THIS SHOULD BE REMOVED
	    Common.continueButtonClicked();//THIS SHOULD BE REMOVED
	    Common.continueButtonClicked();//THIS SHOULD BE REMOVED
	}

	@Then("^should able to navigate to \"([^\"]*)\" from OTP Screen\\.$")
	public void should_able_to_navigate_to_from_OTP_Screen(String dataPointer) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String testCaseID = Utility.getScenarioID();
		String timeToCreateUserNameText=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage01_Registration_ExpectedDa", testCaseID, dataPointer);
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(timetocreateusernameHeaderTxt));
		Assert.assertEquals(timetocreateusernameHeaderTxt.getText(), timeToCreateUserNameText,"Couldn't find expected Time to create user name page");
	}
	
	@When("^Empty security code is entered on OTP Screen$")
	public void empty_security_code_is_entered_on_OTP_Screen() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		ValidOTPCode("","","","","","");
	}

	@Then("^Should throw an error \"([^\"]*)\" on OTP Screen$")
	public void should_throw_an_error_on_OTP_Screen(String dataPointer) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String testCaseID = Utility.getScenarioID();
		String emptySecurityCodeErrorText=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage01_Registration_ExpectedDa", testCaseID, dataPointer);
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(emptySecurityCodeError));
		Assert.assertEquals(emptySecurityCodeError.getText(), emptySecurityCodeErrorText,"Couldn't find expected Error");
		
	}

}
