package com.scotiabank.ehome.ui.steps;
import org.apache.poi.ss.formula.functions.Column;
import org.apache.poi.ss.usermodel.*;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.qmetry.qaf.automation.step.QAFTestStepProvider;
import com.qmetry.qaf.automation.ui.WebDriverTestBase;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebDriver;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.quantum.utils.ConfigurationUtils;

import cucumber.api.java.en.Given;

import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;
@QAFTestStepProvider

public class CommonAppMethodsGettingNewRate {
     
	  /* *************************************************************************************************************************************************
	 Author: 	  RameshChalumuri
	 Stage:       Stage 03
	 Method Name: selectRateType
	 Purpose: 	  This method is for selecting Rate Type "Fixed" or "Variable"
	 Created on:  18-September-2018  
	 Updated By: 
	 Updated on:
	 *************************************************************************************************************************************************** */
   public static void selectRateType(String RateType) throws InterruptedException{
    	switch(RateType) {
          case "Fixed" : 															   
       	   QAFExtendedWebElement RateTypeFixedRadioBtn= new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[1]/section/div[3]/div/fieldset/div/span[1]/label/span[3]/span");
        	   RateTypeFixedRadioBtn.click (); // Click on rate type "Fixed"
             break;
          case "Variable" : 																
       	   QAFExtendedWebElement RateTypeVariableRadioBtn= new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[1]/section/div[3]/div/fieldset/div/span[2]/label/span[3]/span");
       	   RateTypeVariableRadioBtn.click (); // Click on rate type "Variable"
             break;
             default :
             System.out.println("Invalid Rate Type");
       }
  }
   
   /* *************************************************************************************************************************************************
	 Author: 	  RameshChalumuri
	 Stage:       Stage 03
	 Method Name: selectRateType
	 Purpose: 	  This method is for selecting Mortgage Term "2 year" or "3 year" or "4 year" or "5 year" or "6 year" 
	 Created on:  18-September-2018  
	 Updated By: 
	 Updated on:
	 *************************************************************************************************************************************************** */
  public static void selectMortgageTerm(String MortgageTerm) throws InterruptedException{
       
   	switch(MortgageTerm) {
   	 case "2 year" :
   		 																		   
     	   QAFExtendedWebElement MortgTerm2YrRadioBtn= new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[1]/section/div[3]/div/fieldset/div/span[1]/label");
     	   MortgTerm2YrRadioBtn.click (); // Click on Mortgage Term "2 year"
           break;
   	 case "3 year" :
       	   QAFExtendedWebElement MortgTerm3YrRadioBtn= new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[1]/section/div[3]/div/fieldset/div/span[2]/label");
       	   MortgTerm3YrRadioBtn.click (); // Click on Mortgage Term "3 year"
             break;
        case "4 year" :
       	   QAFExtendedWebElement MortgTerm4YrRadioBtn= new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[1]/section/div[3]/div/fieldset/div/span[3]/label");
       	   MortgTerm4YrRadioBtn.click (); // Click on Mortgage Term "4 year"
             break;
        case "5 year" :
       	   QAFExtendedWebElement MortgTerm5YrRadioBtn= new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[1]/section/div[3]/div/fieldset/div/span[4]/label");
       	   MortgTerm5YrRadioBtn.click (); // Click on Mortgage Term "5 year"
             break;
             default :
             System.out.println("Invalid Mortgage Term");
        }
   }
  
  /* *************************************************************************************************************************************************
	 Author: 	  RameshChalumuri
	 Stage:       Stage 03
	 Method Name: chooseRatesfromRatePresentment
	 Purpose: 	  This method is for selecting Rates from Rate Present screen 
	 Created on:  18-September-2018  
	 Updated By: 
	 Updated on:
	 *************************************************************************************************************************************************** */
   public static void chooseRatesfromRatePresentment(String RateType,String MortgageTerm ) throws InterruptedException{
   	
   	String strRates = RateType +MortgageTerm;
    
   	switch(strRates) {
          case "Fixed2 year" :
       	   QAFExtendedWebElement RatesFixed2yearBtn= new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[2]/div[7]/div[1]/button[2]");
       	   RatesFixed2yearBtn.click (); // Choose Rates  "Fixed 2 year"
              break;
          case "Fixed3 year" :
       	   QAFExtendedWebElement RatesFixed3yearBtn= new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[2]/div[7]/div[2]/button[2]");
       	   RatesFixed3yearBtn.click (); // Choose Rates  "Fixed 3 year"
    	   break;
          case "Fixed4 year" :
       	   QAFExtendedWebElement RatesFixed4yearBtn= new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[2]/div[7]/div[3]/button[2]");
       	   RatesFixed4yearBtn.click (); // Choose Rates  "Fixed 4 year"
             break;
          case "Fixed5 year" :
       	   QAFExtendedWebElement RatesFixed5yearBtn= new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[2]/div[7]/div[4]/button[2]");
       	   RatesFixed5yearBtn.click (); // Choose Rates  "Fixed 5 year"
             break;
          case "Variable5 year" :
       	   QAFExtendedWebElement RatesVariable5yearBtn= new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[2]/div[10]/div/button[2]");
       	   RatesVariable5yearBtn.click (); // Choose Rates  "Variable 5 year"
             break;
             default :
             System.out.println("Invalid Rates");
       }
  }
  
}
   
   
   
   
