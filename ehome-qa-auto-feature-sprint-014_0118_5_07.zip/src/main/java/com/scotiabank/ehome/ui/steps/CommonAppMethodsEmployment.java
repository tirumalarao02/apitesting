package com.scotiabank.ehome.ui.steps;
import org.apache.poi.ss.formula.functions.Column;
import org.apache.poi.ss.usermodel.*;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.qmetry.qaf.automation.step.QAFTestStepProvider;
import com.qmetry.qaf.automation.ui.WebDriverTestBase;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebDriver;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.quantum.utils.ConfigurationUtils;

import cucumber.api.java.en.Given;

import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;
@QAFTestStepProvider

public class CommonAppMethodsEmployment {
  	
	/* *************************************************************************************************************************************************
	 Author: 	  RameshChalumuri
	 Stage:       Stage 04
	 Method Name: selectEmploymentStatus
	 Purpose: 	  This method is for selecting employment status "Employed" or "UnEmployed" or "Retired"
	 Created on:  18-September-2018  
	 Updated By: 
	 Updated on:
	 *************************************************************************************************************************************************** */
   public static void SelectEmpStatus(String empStatus) throws InterruptedException{
   	switch(empStatus) {
           case "Employed" :
       	   Utility.clickObject("ehome.empstatus.EmployedRdBtn","Button"); // Click on "Employed"
              break;
          case "UnEmployed" :
       	   Utility.clickObject("ehome.empstatus.UnEmployedRdBtn","Button"); // Click on "UnEmployed"
              break;
          case "Retired" :
       	   Utility.clickObject("ehome.empstatus.RetiredRdBtn","Button");  // Click on "Retired"
              break;
             default :
             System.out.println("Invalid Employement Status");
        }
  }
   
   /* *************************************************************************************************************************************************
	 Author: 	  RameshChalumuri
	 Stage:       Stage 04
	 Method Name: selectEmploymentType
	 Purpose: 	  This method is for selecting Employment Type "Commissioned sales" or "Contract" or "Full time" or "Part time" or "Seasonal" or "Self employed"
	 Created on:  4-October-2018  
	 Updated By: 
	 Updated on:
	 *************************************************************************************************************************************************** */
    public static void SelectEmpType(String empType) throws InterruptedException{
    	switch(empType) {
           case "Commissioned sales" :
           	 Utility.clickObject("ehome.empType.CommissionedsalesRdBtn","Button"); 
        	     break;
           case "Contract" :
           	 Utility.clickObject("ehome.empType.ContractRdBtn","Button"); 
                break;
           case "Full Time" :
           	Utility.clickObject("ehome.empType.FulltimeRdBtn","Button"); 
               break;
           case "Part Time" :
           	Utility.clickObject("ehome.empType.ParttimeRdBtn","Button"); 
               break;
           case "Seasonal" :
           	Utility.clickObject("ehome.empType.SeasonalRdBtn","Button"); 
               break;
           case "Self Employed" :
           	Utility.clickObject("ehome.empType.SelfemployedRdBtn","Button"); 
               break;
              default :
              System.out.println("Invalid Employement Type");
         }
   }
    
    /* *************************************************************************************************************************************************
	 Author: 	  RameshChalumuri
	 Stage:       Stage 04
	 Method Name: selectEmploymentSourceofIncome
	 Purpose: 	  This method is for selecting sources of income "Child Support" or "Investments" or "Pension/Disability" or "Spousal Support"
	 Created on:  08-October-2018  
	 Updated By: 
	 Updated on:
	 *************************************************************************************************************************************************** */
   public static void SelectEmpSrcOfIncome(String sourceofEmpIncome) throws InterruptedException{
   	switch(sourceofEmpIncome) {
          case "Child Support" :
       	   Utility.clickObject("ehome.AssetSources.childSupport","Button"); // Click on "Child Support"
              break;
          case "Investments" :
       	   Utility.clickObject("","Button"); // Click on "Investments"
              break;
          case "PensionorDisability" :
       	   Utility.clickObject("","Button"); // Click on "PensionorDisability"
              break;
          case "Spousal Support" :
       	   Utility.clickObject("","Button");  // Click on "Spousal Support"
              break;
             default :
             System.out.println("Invalid Source of Employment Income");
       }
  }
   
   
   /* *************************************************************************************************************************************************
	 Author: 	  RameshChalumuri
	 Stage:       Stage 04
	 Method Name: employmentSelectOtherSourcesOfIncome
	 Purpose: 	  This method is for selecting Other Sources Of Income
	 Created on:  16-October-2018
	 Updated By: 
	 Updated on:
	 *************************************************************************************************************************************************** */
	// static int  counter=1;
 public static void SelectOtherSourcesOfIncome(String EmpOtherSrcsOfIncome) throws InterruptedException{

	 switch(EmpOtherSrcsOfIncome) { 
	   	case "Child support" :
	   		Utility.clickObject("ehome.otherSrcsOfInc.ChildSupport", "ChildSupport Button");
	   		Thread.sleep(500);
	   		break;
	   	case "Commission" :
	   		Utility.clickObject("ehome.otherSrcsOfInc.Commission","Commission Button");
	   		Thread.sleep(500);
	   		break;
	   	case "Investments" : 
	   		Utility.clickObject("ehome.otherSrcsOfInc.Investments", "Investments Button");
	   		Thread.sleep(500);
	   		break;
	   	case "Part time work" :
	   		Utility.clickObject("ehome.otherSrcsOfInc.PartTimeWork","PartTimeWork Button");
	   		Thread.sleep(500);
	   		break;
	   	case "Pension/Disability" :
	   		Utility.clickObject("ehome.otherSrcsOfInc.PensionDisability","PensionDisability Button");
	   		Thread.sleep(500);
	   		break;
	     case "RIF/LIF" :
	      	Utility.clickObject("ehome.otherSrcsOfInc.RIFLIF","RIFLIF Button");
	      	break;
	     case "Seasonal work" :
	      	Utility.clickObject("ehome.otherSrcsOfInc.SeasonalWork","SeasonalWork Button");
	      	Thread.sleep(500);
	      	break;
	     case "Spousal support" :
	      	Utility.clickObject("ehome.otherSrcsOfInc.SpousalSupport","SpousalSupport Button");
	      	Thread.sleep(500);
	      	break;
	     case "No other sources of income" :
	  		Utility.clickObject("ehome.otherSrcsOfInc.NoSrcOfInc.Link", "NoSrcOfInc Link");
	   		Thread.sleep(500);
	   		break;
      default :
            System.out.println("Invalid Employment Other Sources Of Income");
      }
 }
 
 
		 /* *************************************************************************************************************************************************
		 Author: 	  RameshChalumuri
		 Stage:       Stage 04
		 Method Name: employmentSelectOtherSourcesOfIncome
		 Purpose: 	  This method is for selecting Other Sources Of Income
		 Created on:  16-October-2018
		 Updated By: 
		 Updated on:
		 *************************************************************************************************************************************************** */
		// static int  counter=1;
		public static void UnSelectOtherSourcesOfIncome(String EmpOtherSrcsOfIncome) throws InterruptedException{
		
		 switch(EmpOtherSrcsOfIncome) { 
		   	case "Child support" :
		Utility.clickObject("ehome.otherSrcsOfInc.ChildSupportRemove", "ChildSupport Remove Button");
			Thread.sleep(500);
			break;
		case "Commission" :
		Utility.clickObject("ehome.otherSrcsOfInc.CommissionRemove","Commission Remove Button");
			Thread.sleep(500);
			break;
		case "Investments" : 
		Utility.clickObject("ehome.otherSrcsOfInc.InvestmentsRemove", "Investments Remove Button");
			Thread.sleep(500);
			break;
		case "Part time work" :
		Utility.clickObject("ehome.otherSrcsOfInc.PartTimeWorkRemove","PartTimeWork Remove Button");
			Thread.sleep(500);
			break;
		case "Pension/Disability" :
		Utility.clickObject("ehome.otherSrcsOfInc.PensionDisabilityRemove","PensionDisability Remove Button");
			Thread.sleep(500);
			break;
		 case "RIF/LIF" :
		Utility.clickObject("ehome.otherSrcsOfInc.RIFLIFRemove","RIFLIF Remove Button");
		  	break;
		 case "Seasonal work" :
		Utility.clickObject("ehome.otherSrcsOfInc.SeasonalWorkRemove","SeasonalWork Remove Button");
		  	Thread.sleep(500);
		  	break;
		 case "Spousal support" :
		Utility.clickObject("ehome.otherSrcsOfInc.SpousalSupportRemove","SpousalSupport Remove Button");
		  	Thread.sleep(500);
		  	break;
		 case "No other sources of income" :
		Utility.clickObject("ehome.otherSrcsOfInc.NoSrcOfInc.Link", "NoSrcOfInc Link");
		   		Thread.sleep(500);
		   		break;
		  default :
		        System.out.println("Invalid Employment Other Sources Of Income");
		  }
		}
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
  
 /* *************************************************************************************************************************************************
	 Author: 	  RameshChalumuri
	 Stage:       Stage 04
	 Method Name: employmentEnterAnualIncomeSourceAmount
	 Purpose: 	  This method is for entering Annual Income Source Amount
	 Created on:  16-October-2018  
	 Updated By: 
	 Updated on:
	 *************************************************************************************************************************************************** */
public static void EnterAnualIncomeSourceAmount(String OtherSrcs,String OtherSrcsOfIncomeAmount) throws InterruptedException{

	  	switch(OtherSrcs) {
       	case "Child support" :
       		Utility.sendKeys("ehome.otherSrcsOfIncDetails.ChildSupport", OtherSrcsOfIncomeAmount);
       		break;
       	case "Commission" :
       		Utility.clickObject("//*[@id=\"app\"]/div/div[1]/div[2]/div/div[1]/div[2]/button", "Button");
       		Thread.sleep(500);
       		Utility.sendKeys("ehome.otherSrcsOfIncDetails.Commission", OtherSrcsOfIncomeAmount);
       		break;
       	case "Investments" :
       		Utility.clickObject("//*[@id=\"app\"]/div/div[1]/div[2]/div/div[1]/div[3]/button", "Button");
       		Thread.sleep(500);
       		Utility.sendKeys("ehome.otherSrcsOfIncDetails.Investments", OtherSrcsOfIncomeAmount);
       		break;
       	case "Part time work" :
       		Utility.clickObject("//*[@id=\"app\"]/div/div[1]/div[2]/div/div[1]/div[4]/button", "Button");
       		Thread.sleep(500);
       		Utility.sendKeys("ehome.otherSrcsOfIncDetails.PartTimeWork", OtherSrcsOfIncomeAmount);
       		break;
       	case "Pension/Disability" :
       		Utility.clickObject("//*[@id=\"app\"]/div/div[1]/div[2]/div/div[1]/div[5]/button", "Button");
       		Thread.sleep(500);
       		Utility.sendKeys("ehome.otherSrcsOfIncDetails.PensionDisability", OtherSrcsOfIncomeAmount);
       		break;
       	case "RIF/LIF" :
       		Utility.clickObject("//*[@id=\"app\"]/div/div[1]/div[2]/div/div[1]/div[6]/button", "Button");
       		Thread.sleep(500);
       		Utility.sendKeys("ehome.otherSrcsOfIncDetails.RIFLIF", OtherSrcsOfIncomeAmount);
       		break;
       	case "Seasonal work" :
       		Utility.clickObject("//*[@id=\"app\"]/div/div[1]/div[2]/div/div[1]/div[7]/button", "Button");
       		Thread.sleep(500);
       		Utility.sendKeys("ehome.otherSrcsOfIncDetails.SeasonalWork", OtherSrcsOfIncomeAmount);
       		break;
       	case "Spousal support" :
       		Utility.clickObject("//*[@id=\"app\"]/div/div[1]/div[2]/div/div[1]/div[8]/button", "Button");
       		Thread.sleep(500);
       		Utility.sendKeys("ehome.otherSrcsOfIncDetails.SpousalSupport", OtherSrcsOfIncomeAmount);
       		break;
      	
       	default :
       		System.out.println("Invalid Annual Income Source Amount");
       
    }
}
 
	/* *************************************************************************************************************************************************
	Author: 	  RameshChalumuri
	Stage:       	Stage 04
	Method Name:  SelectRetiredSourcesOfIncome
	Purpose: 	  This method is for Retirement Source of Income
	Created on:  16-October-2018
	Updated By:   RameshChalumuri 
	Updated on:   07-November-2018
	 ************************************************************************************************************************************************** */

	public static void SelectRetiredSourcesOfIncome(String RetiredSrcsOfIncome) throws InterruptedException{

		switch(RetiredSrcsOfIncome) { 
  	
		case "Investments" : 
			Utility.clickObject("//*[@id=\"app\"]/div/div[1]/div[1]/section/div[4]/div/div/div/fieldset/div/div[1]/label/span[1]", "Button");
			Thread.sleep(500);
			break;
		case "Pension/Disability" :
			Utility.clickObject("//*[@id=\"app\"]/div/div[1]/div[1]/section/div[4]/div/div/div/fieldset/div/span[2]/label/span[2]/span[2]","Button");
			Thread.sleep(500);
			break;
		case "RIF/LIF" :
			Utility.clickObject("//*[@id=\"app\"]/div/div[1]/div[1]/section/div[4]/div/div/div/fieldset/div/span[3]/label/span[2]/span[2]","Button");
			break;
		case "No sources of income"	:
			Utility.clickObject("//*[@id=\"app\"]/div/div[1]/div[2]/button[2]/span","Button");
			break;
		default :
			System.out.println("Invalid Retired Sources Of Income");
 }
}
	
	/* *************************************************************************************************************************************************
	 Author: 	  RameshChalumuri
	 Stage:       Stage 04
	 Method Name: RetirementEnterAnualIncomeSourceAmount
	 Purpose: 	  This method is for entering Annual Income Source Amount
	 Created on:  16-October-2018  
	 Updated By: 
	 Updated on:
	 *************************************************************************************************************************************************** */
public static void EnterRetiredAnualIncomeSourceAmount(String OtherSrcs,String OtherSrcsOfIncomeAmount) throws InterruptedException{

	  	switch(OtherSrcs) {
      	case "Investments" :
      		Thread.sleep(500);
      		Utility.sendKeys("//*[@id=\"investments-investments-0\"]", OtherSrcsOfIncomeAmount);
      		break;
       	case "Pension/Disability" :
      		Utility.clickObject("//*[@id=\"app\"]/div/div[1]/div[2]/div/div[1]/div[2]/button", "Button");
      		Thread.sleep(500);
      		Utility.sendKeys("//*[@id=\"pension-disability-pension-disability-0\"]", OtherSrcsOfIncomeAmount);
      		break;
      	case "RIF/LIF" :
      		Utility.clickObject("//*[@id=\"app\"]/div/div[1]/div[2]/div/div[1]/div[3]/button", "Button");
      		Thread.sleep(500);
      		Utility.sendKeys("//*[@id=\"rif-lif-rif-lif-0\"]", OtherSrcsOfIncomeAmount);
      		break;
      	default :
      		System.out.println("Invalid Annual Income Source Amount");
      
   }
}

}
   