package com.scotiabank.ehome.ui.steps.stage1;

import static com.scotiabank.ehome.ui.steps.Utility.getScreenDataset;

import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.qmetry.qaf.automation.step.QAFTestStepProvider;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebDriver;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.quantum.utils.ConfigurationUtils;
import com.scotiabank.ehome.ui.steps.Common;
import com.scotiabank.ehome.ui.steps.CommonApplicationMethods;
import com.scotiabank.ehome.ui.steps.Utility;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
@QAFTestStepProvider
public class EmailAddress {
	
	private QAFExtendedWebDriver webDriver = Utility.getDriver();
    public Actions action = null;
    public static WebDriverWait wait=Utility.getWait();	
    
    private Map<String,Map<String,Boolean>> emailAddressExcel = getScreenDataset(Utility.getExcelFilePath("eHomeTestDatastage-4.xlsx"), "EmailAddress");
    //private Map<String,Map<String,Boolean>> emailAddressDataset = getScreenDataset(Utility.getExcelFilePath("eHomeTestDatastage-4.xlsx"), "IndustryAndJobTitle");
    
    QAFExtendedWebElement headerTitle= new QAFExtendedWebElement("ehome.emailAddress.headerTitle");
    QAFExtendedWebElement headerText= new QAFExtendedWebElement("ehome.emailAddress.headerText");
    QAFExtendedWebElement footerText= new QAFExtendedWebElement("ehome.emailAddress.footerText");
    QAFExtendedWebElement emailAddressText= new QAFExtendedWebElement("ehome.emailAddress.emailAddressText");
    QAFExtendedWebElement confirmEmailAddressText= new QAFExtendedWebElement("ehome.emailAddress.confirmEmailAddressText");
    QAFExtendedWebElement validEmailAddress= new QAFExtendedWebElement("ehome.emailAddress.validEmailAddress");
    QAFExtendedWebElement EmailAddressMustMatch= new QAFExtendedWebElement("ehome.emailAddress.EmailAddressMustMatch");
    QAFExtendedWebElement whatsYourAddressheaderTitle= new QAFExtendedWebElement("ehome.whatsYourAddress.headerTitle");
    QAFExtendedWebElement MobilePhoneNumberHeader= new QAFExtendedWebElement("ehome.emailAddress.MobilePhoneNumberHeader");
    
	@Given("^Customer should login and navigates to Email Address screen$")
	public void customer_should_login_and_navigates_to_Email_Address_screen() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Utility.launchURL(ConfigurationUtils.getBaseBundle().getPropertyValue ("env.baseurl0"));
		Welcome.viewOurPrivacyAgreementButtonClicked();
		PrivacyAgreement.acceptAndContinuetButtonClicked();
		SOLCustomerQuestion.triageQuestionsButtonClicked();
		SOLCustomerQuestion.noButtonClicked();
		LegalName.validlegalname("Mrs", "Delna", "Dr", "Press");
		Common.continueButtonClicked();
		MaritalStatus.maritalstatusselect("Married");
		Common.continueButtonClicked();
		DateOfBirth.dateOfBirth("20", "Mar", "1998");
		Common.continueButtonClicked();
		WhatsYourAddress.ValidWhatsYourAddressValues("2201", "EGLINTON AVE", "TORONTO", "ONTARIO","M1K2M1");
		Common.continueButtonClicked();
		Thread.sleep(10000);
	}
	
	@Then("^Verify \"([^\"]*)\" message should be on Email Address screen$")
	public void verify_message_should_be_Email_Address_screen(String dataPointer) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String testCaseID = Utility.getScenarioID();
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage01_Registration_ExpectedDa", testCaseID, dataPointer);
		 wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(headerTitle));
		 Assert.assertEquals(headerTitle.getText(), value,"Couldn't found expected header message");
	}
	
	@Then("^Verify \"([^\"]*)\" headertext should be on Email Address screen$")
	public void verify_headertext_should_be_Email_Address_screen(String dataPointer) throws Throwable {
		   // Write code here that turns the phrase above into concrete actions
				String testCaseID = Utility.getScenarioID();
				String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage01_Registration_ExpectedDa", testCaseID, dataPointer);
				wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(headerText));
				Assert.assertEquals(headerText.getText(), value,"Couldn't found expected header text message");
	   
	}
	
	@Then("^Verify \"([^\"]*)\" footertext should be on Email Address screen$")
	public void verify_footertext_should_be_Email_Address_screen(String dataPointer) throws Throwable {
		   // Write code here that turns the phrase above into concrete actions
				String testCaseID = Utility.getScenarioID();
				String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage01_Registration_ExpectedDa", testCaseID, dataPointer);
				wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(footerText));
				Assert.assertEquals(footerText.getText(), value,"Couldn't found expected header text message");
	   
	}
	
	@Then("^Verify Invalid \"([^\"]*)\" email address on Email Address screen$")
	public void verify_invalid_email_address_on_Email_Address_screen(String dataPointer) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String testCaseID = Utility.getScenarioID();
		String emailAddText=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage01_Registration_InputData", testCaseID, dataPointer);
		 emailAddressText.sendKeys(emailAddText);
		 wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(validEmailAddress));    
		 Assert.assertEquals(validEmailAddress.getText(), "Please enter your email address","Couldn't found expected error message");
	}
	
	@When("^Back Button is clicked on Email Address screen$")
	public void back_button_is_clicked_on_email_address_screen() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    Common.backButtonClicked();
	}
	
	@Then("^'Whats your address?' screen should be displayed$")
	public void Whats_your_address_screen_should_be_displayed() throws Throwable {
		if(!whatsYourAddressheaderTitle.isPresent())
			throw new AssertionError("Not navigated to Whats Your Address screen");
	}
	
	public static void ValidEmailAddress(String emailAddress, String confirmEmailAddress) throws InterruptedException {
	 	QAFExtendedWebElement emailAddressText= new QAFExtendedWebElement("ehome.emailAddress.emailAddressText");
	    QAFExtendedWebElement confirmEmailAddressText= new QAFExtendedWebElement("ehome.emailAddress.confirmEmailAddressText");
		emailAddressText.sendKeys(emailAddress);
		confirmEmailAddressText.sendKeys(confirmEmailAddress);
	}
	
	@When("^Continue button is clicked on email address screen after entering valid \"([^\"]*)\" email address and valid \"([^\"]*)\" confirm email address$")
	public void Continue_button_is_clicked_on_email_address_screen_after_entering_valid_email_address_and_valid_confirm_email_address(String dataPointer1, String dataPointer2) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String testCaseID = Utility.getScenarioID();
		String emailAddressText=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage01_Registration_InputData", testCaseID, dataPointer1);
		String confirmEmailAddressText=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage01_Registration_InputData", testCaseID, dataPointer2);
		ValidEmailAddress(emailAddressText,confirmEmailAddressText);
		Thread.sleep(2000);
		Common.continueButtonClicked();

	}
	
	@Then("^'Whats your mobile phone number' screen should be displayed$")
	public void Whats_your_mobile_phone_number_screen_should_be_displayed() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		 wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(MobilePhoneNumberHeader));
		if(!MobilePhoneNumberHeader.isPresent())
			throw new AssertionError("Not navigated to Whats Your Mobile Phone Number screen");
	}
	
}
