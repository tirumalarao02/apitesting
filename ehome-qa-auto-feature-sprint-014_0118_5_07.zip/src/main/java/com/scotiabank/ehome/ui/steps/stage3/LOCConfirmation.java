package com.scotiabank.ehome.ui.steps.stage3;
import com.qmetry.qaf.automation.step.QAFTestStepProvider;
import com.qmetry.qaf.automation.ui.WebDriverTestBase;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebDriver;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.quantum.utils.ConfigurationUtils;

import com.scotiabank.ehome.ui.steps.Common;
import com.scotiabank.ehome.ui.steps.Utility;
import cucumber.api.PendingException;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.FluentWait;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.beans.PropertyChangeListener;

import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.Date;
import static com.scotiabank.ehome.ui.steps.Utility.*;
@QAFTestStepProvider

public class LOCConfirmation {
    private QAFExtendedWebDriver webDriver = new WebDriverTestBase().getDriver();
    public Actions action = null;
    WebDriverWait wait = new WebDriverWait(webDriver,50000);

    String testCaseID = Utility.getScenarioID();

    QAFExtendedWebElement Continue = new QAFExtendedWebElement("ehome.tellus.continue.button");
    QAFExtendedWebElement ContinueInLOCConfirmation = new QAFExtendedWebElement("ehome.locConfirmation.Continue");
    QAFExtendedWebElement Back= new QAFExtendedWebElement("ehome.locConfirmation.Back");
    QAFExtendedWebElement eHomeHeader= new QAFExtendedWebElement("ehome.rate.Header.text");
    QAFExtendedWebElement selectFixed= new QAFExtendedWebElement("ehome.typeofrate.selectfixed.radio");
    QAFExtendedWebElement twoyears= new QAFExtendedWebElement("ehome.termsofrate.2years.radio");
    QAFExtendedWebElement twoyear= new QAFExtendedWebElement("ehome.ratepresentation.twoyears.select");
    QAFExtendedWebElement LockandHold= new QAFExtendedWebElement("ehome.ratelock.LockandHold");
    QAFExtendedWebElement RateCustomizationContinuebutton= new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[7]/div/button[2]");
    QAFExtendedWebElement Continueinstep= new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[3]/div/button[2]");
    QAFExtendedWebElement YesIminterested= new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[4]/div[2]/button");

    QAFExtendedWebElement LOCConfirmationMessage = new QAFExtendedWebElement("ehome.locConfirmation.Message");
    QAFExtendedWebElement LOCConfirmationHeader = new QAFExtendedWebElement("ehome.locConfirmation.Header");

    //1
    @Given("^Customer should login and navigates to LOC Confirmation Screen$")
    public void customerShouldLoginAndNavigatesToLOCConfirmationScreen() throws Throwable {
    	// Write code here that turns the phrase above into concrete actions
    	Common.stage2ToStage3(testCaseID);
        wait.until(ExpectedConditions.visibilityOf(eHomeHeader));
        Continue.click();
        selectFixed.click ();
        if(!twoyears.verifyPresent())
            throw new AssertionError("Couldn't find 2 years button");
        Thread.sleep(2000);
        twoyears.click();

        if(!twoyear.verifyPresent())
            throw new AssertionError("Couldn't find 2 years button");
        wait.until(ExpectedConditions.elementToBeClickable(twoyear));
        twoyear.click();

        if(!LockandHold.verifyPresent())
            throw new AssertionError("Couldn't find Lock & Hold on the screen");
        Thread.sleep(2000);
        wait.until(ExpectedConditions.elementToBeClickable(LockandHold));
        LockandHold.click();
        RateCustomizationContinuebutton.click();

        Continueinstep.isPresent();
        Continueinstep.click();

		YesIminterested.isPresent();
		YesIminterested.click();
    } 
    
  //2
  @When("^Verify 'LOC Confirmation Message and Header' in LOC Confirmation Screen$")
  public void verifyLOCConfirmationMessageAndHeaderInLOCConfirmationScreen() throws Throwable {
      // Write code here that turns the phrase above into concrete actions
      String LOC_Confirmation_Message = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage03_Rate_ExpectedData", testCaseID, "LOC_Confirmation_Message");
      Assert.assertEquals(LOCConfirmationMessage.getText(),LOC_Confirmation_Message,"LOC Confirmation Message is not present");

      String LOC_Confirmation_Header = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage03_Rate_ExpectedData", testCaseID, "LOC_Confirmation_Header");
      Assert.assertEquals(LOCConfirmationHeader.getText(),LOC_Confirmation_Header,"LOC Confirmation Header is not present");

  }
    //3
    @When("^Customer click on continue button in LOC Confirmation Screen$")
    public void Verify_Back_button_navigation_on_STEP_screen() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        ContinueInLOCConfirmation.isPresent();
        ContinueInLOCConfirmation.click();
    }
    
    @Then("^It should navigate to Mortgage Summary screen or rate-equity screen$")
    public void itShouldNavigateToMortgageSummaryScreenOrRateEquityScreen() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
       QAFExtendedWebElement MortgageSummaryHeader= new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[2]/div/h2");
       Assert.assertEquals(MortgageSummaryHeader.getText(), "Let's review your eHOME request");
        
    }
  //4
    @When("^Customer click on Back button in LOC Confirmation Screen$")
    public void customerClickOnBackButtonInStepScreen() throws Throwable {
        // Write code here that turns the phrase above into concrete actions

        Back.isPresent();
        Back.click();
    	

    }
    
    @Then("^It should navigate to LOC screen$")
    public void itShouldNavigateToLOCScreen() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	QAFExtendedWebElement LOCHeader= new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[2]/div[2]/h2");
        Assert.assertEquals(LOCHeader.getText(), "With the Scotia Total Equity ® Plan, you may be eligible for a $20,000.00 secured line of credit1");
        
    }

}
