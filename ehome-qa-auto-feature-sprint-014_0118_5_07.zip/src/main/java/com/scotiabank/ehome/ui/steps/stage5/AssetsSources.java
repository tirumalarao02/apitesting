package com.scotiabank.ehome.ui.steps.stage5;
import com.qmetry.qaf.automation.step.QAFTestStepProvider;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebDriver;
import com.quantum.java.pages.ExtentReportHelper;
import com.quantum.utils.ConfigurationUtils;
import com.scotiabank.ehome.ui.steps.Common;
import com.scotiabank.ehome.ui.steps.CommonAppMethodsAssetLiabilities;
import com.scotiabank.ehome.ui.steps.CommonAppMethodsEmployment;
import com.scotiabank.ehome.ui.steps.CommonApplicationMethods;
import com.scotiabank.ehome.ui.steps.Utility;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.support.ui.WebDriverWait;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;

import java.util.Map;
import java.util.concurrent.TimeUnit;
import static com.scotiabank.ehome.ui.steps.Utility.*;

@QAFTestStepProvider

public class AssetsSources {
	public static WebDriverWait wait=Utility.getWait();
	  static String curDir = System.getProperty("user.dir");
	  static String strfullPathToFile = curDir + "\\src\\main\\resources\\data\\eHomeTestData.xlsx"; // File Path
		
	  static String sheetStage05_InputData ="Stage05_AssetLiabilty_InputData";
	  static String sheetStage05_ExpectedData ="Stage05_AsetLiblty_ExpectedData";
	  static String sheetStage04_ExpectedData ="Stage04_Employment_ExpectedData";
	  
	  //String strtestCaseID = "AssetDetails-Retired-TC-015";
	  String strtestCaseID = Utility.getScenarioID();
	
	  QAFExtendedWebElement Automobile = new QAFExtendedWebElement("ehome.assetSrcs.Automobile");
	  QAFExtendedWebElement Cash = new QAFExtendedWebElement("ehome.assetSrcs.Cash");
	  QAFExtendedWebElement GICTermDeposit = new QAFExtendedWebElement("ehome.assetSrcs.GICTermDeposit");
	  QAFExtendedWebElement PrimaryResidence = new QAFExtendedWebElement("ehome.assetSrcs.PrimaryResidence");
	  QAFExtendedWebElement RentalProperty = new QAFExtendedWebElement("ehome.assetSrcs.RentalProperty");
	  QAFExtendedWebElement RRSP = new QAFExtendedWebElement("ehome.assetSrcs.RRSP");
	  QAFExtendedWebElement SecondaryProperty = new QAFExtendedWebElement("ehome.assetSrcs.SecondaryProperty");
	  QAFExtendedWebElement StockBond = new QAFExtendedWebElement("ehome.assetSrcs.StockBond");
	  QAFExtendedWebElement OtherAssets = new QAFExtendedWebElement("ehome.assetSrcs.OtherAssets");
	    
	  QAFExtendedWebElement strAutomobileRemove_Btn= new QAFExtendedWebElement("ehome.assetSrcs.AutomobileRemove");
	  QAFExtendedWebElement strCashRemove_Btn= new QAFExtendedWebElement("ehome.assetSrcs.CashRemove");
	  QAFExtendedWebElement strGICTermDepRemove_Btn= new QAFExtendedWebElement("ehome.assetSrcs.GICTermDepositRemove");
	  QAFExtendedWebElement PrimaryResidenceRemove_Btn = new QAFExtendedWebElement("ehome.assetSrcs.PrimaryResidenceRemove");
	  QAFExtendedWebElement RentalPropertyRemove_Btn = new QAFExtendedWebElement("ehome.assetSrcs.RentalPropertyRemove");
	  QAFExtendedWebElement RRSPRemove_Btn = new QAFExtendedWebElement("ehome.assetSrcs.RRSPRemove");
	  QAFExtendedWebElement SecondaryPropertyRemove_Btn = new QAFExtendedWebElement("ehome.assetSrcs.SecondaryPropertyRemove");
	  QAFExtendedWebElement StockBondRemove_Btn = new QAFExtendedWebElement("ehome.assetSrcs.StockBondRemove");
	  QAFExtendedWebElement OtherAssetsRemove_Btn = new QAFExtendedWebElement("ehome.assetSrcs.OtherAssetsRemove");
	  
	  QAFExtendedWebElement strAutomobileSelect_Btn= new QAFExtendedWebElement("ehome.assetSrcs.AutomobileSelect");
	  QAFExtendedWebElement strCashSelect_Btn= new QAFExtendedWebElement("ehome.assetSrcs.CashSelect");
	  QAFExtendedWebElement strGICTermDepSelect_Btn= new QAFExtendedWebElement("ehome.assetSrcs.GICTermDepositSelect");
	  QAFExtendedWebElement PrimaryResidenceSelect_Btn = new QAFExtendedWebElement("ehome.assetSrcs.PrimaryResidenceSelect");
	  QAFExtendedWebElement RentalPropertySelect_Btn = new QAFExtendedWebElement("ehome.assetSrcs.RentalPropertySelect");
	  QAFExtendedWebElement RRSPSelect_Btn = new QAFExtendedWebElement("ehome.assetSrcs.RRSPSelect");
	  QAFExtendedWebElement SecondaryPropertySelect_Btn = new QAFExtendedWebElement("ehome.assetSrcs.SecondaryPropertySelect");
	  QAFExtendedWebElement StockBondSelect_Btn = new QAFExtendedWebElement("ehome.assetSrcs.StockBondSelect");
	  QAFExtendedWebElement OtherAssetsSelect_Btn = new QAFExtendedWebElement("ehome.assetSrcs.OtherAssetsSelect");
	  
	  
	  QAFExtendedWebElement strContinueAssets_Btn= new QAFExtendedWebElement("ehome.assetSrcs.Continue");
	  QAFExtendedWebElement strBackBtnAssets_Btn= new QAFExtendedWebElement("ehome.assetSrcs.Back");
	  QAFExtendedWebElement strNoAssets_Link= new QAFExtendedWebElement("ehome.assetSrcs.NoAssets.Link");
	
	  
	  @Given("^Customer should login and navigates to 'Asset-Section-Breaker' Screen and select 'Continue'$")
		public void customer_should_login_and_navigates_to_Asset_Section_Breaker() throws Throwable {
		  Map<String, String> Stage05_InputData =  Utility.readTestData(strfullPathToFile, sheetStage05_InputData,strtestCaseID);
			  
		  	String strCurrentEmpStatus	= Stage05_InputData.get("Empmt_Status");
			String strDurationYear=  Stage05_InputData.get("Years");
			String strDurationMonth=  Stage05_InputData.get("Months");
			String strInvestment_ExpectedInput	= Stage05_InputData.get("EmpOtherSrcsOfIncome_Investments"); 
			String strInvestmentAmt_ExpectedInput	= Stage05_InputData.get("EmpOtherSrcsOfIncome_Investments_Amt");
		
			Utility.launchURL(ConfigurationUtils.getBaseBundle().getPropertyValue ("env.baseurl2"));
			Common.sessionBreakerContinueButtonClick();
			CommonAppMethodsEmployment.SelectEmpStatus(strCurrentEmpStatus);
			Thread.sleep(1000);
				
			if (strDurationYear != "") {
				CommonApplicationMethods.selectValuefromDropDownListBox("ehome.employmentDuration.years", strDurationYear);
		 			Thread.sleep(250);
			}
			if (strDurationMonth != "") {
				CommonApplicationMethods.selectValuefromDropDownListBox("ehome.employmentDuration.months", strDurationMonth);
				Thread.sleep(250);
			}
			
			Common.continueButtonClicked();
			Thread.sleep(250);
			CommonAppMethodsEmployment.SelectRetiredSourcesOfIncome(strInvestment_ExpectedInput);
			Thread.sleep(250);
			Common.continueButtonClicked();
			Thread.sleep(500);
			if (strInvestment_ExpectedInput != "" | strInvestmentAmt_ExpectedInput != "") {
				CommonAppMethodsEmployment.EnterRetiredAnualIncomeSourceAmount(strInvestment_ExpectedInput, strInvestmentAmt_ExpectedInput);
					}
			Utility.clickObject("ehome.otherIncomeSrcDetails.Continue", "Continue Button in Other Income Src Details");
			Utility.clickObject("ehome.assetSectionBrkr.Continue", "Continue Button in Asset Section Breaker");
		}
	  
	  
	  @Given("^Customer should login and navigates to 'Asset Sources' Screen$")
		public void Customer_should_login_and_navigates_to_AssetSources_Screen() throws Throwable {
		  Map<String, String> Stage05_InputData =  Utility.readTestData(strfullPathToFile, sheetStage05_InputData,strtestCaseID);
			  
		  	String strCurrentEmpStatus	= Stage05_InputData.get("Empmt_Status");
			String strDurationYear=  Stage05_InputData.get("Years");
			String strDurationMonth=  Stage05_InputData.get("Months");
			String strInvestment_ExpectedInput	= Stage05_InputData.get("EmpOtherSrcsOfIncome_Investments"); 
			String strInvestmentAmt_ExpectedInput	= Stage05_InputData.get("EmpOtherSrcsOfIncome_Investments_Amt");
				
  			Utility.launchURL(ConfigurationUtils.getBaseBundle().getPropertyValue ("env.baseurl2"));
			Common.sessionBreakerContinueButtonClick();
			CommonAppMethodsEmployment.SelectEmpStatus(strCurrentEmpStatus);
			Thread.sleep(1000);
				
			if (strDurationYear != "") {
				CommonApplicationMethods.selectValuefromDropDownListBox("ehome.employmentDuration.years", strDurationYear);
		 			Thread.sleep(250);
			}
			if (strDurationMonth != "") {
				CommonApplicationMethods.selectValuefromDropDownListBox("ehome.employmentDuration.months", strDurationMonth);
				Thread.sleep(250);
			}
			
			Common.continueButtonClicked();
			Thread.sleep(500);
			CommonAppMethodsEmployment.SelectRetiredSourcesOfIncome(strInvestment_ExpectedInput);
			Thread.sleep(500);
			Common.continueButtonClicked();
			Thread.sleep(500);
			if (strInvestment_ExpectedInput != "" | strInvestmentAmt_ExpectedInput != "") {
				CommonAppMethodsEmployment.EnterRetiredAnualIncomeSourceAmount(strInvestment_ExpectedInput, strInvestmentAmt_ExpectedInput);
					}
			
			Thread.sleep(1000);
			Utility.clickObject("ehome.otherIncomeSrcDetails.Continue", "Continue Button in Other Income Src Details");
			Thread.sleep(500);
			Utility.clickObject("ehome.assetSectionBrkr.Continue", "Continue Button in Asset Section Breaker");
		
			Thread.sleep(500);
			
		}
	  
	  
	  @When("^Select Asset Sources 'No assets' or 'Any Asset Sources' on 'AssetSources' Screen$")
		public void Select_Asset_Sources_Nootherassets_or_Any_Asset_Sources_on_AssetSources_Screen() throws Throwable {
		  Map<String, String> Stage05_InputData =  Utility.readTestData(strfullPathToFile, sheetStage05_InputData,strtestCaseID);
		 	
			String strAutomobile_Input = Stage05_InputData.get("AssetSources_Automobile");
			String strCash_Input = Stage05_InputData.get("AssetSources_Cash");
			String strGICTermDeposit_Input = Stage05_InputData.get("AssetSources_GICTermDeposit");
			String strPrimaryResidence_Input = Stage05_InputData.get("AssetSources_PrimaryResidence");
			String strRentalProperty_Input = Stage05_InputData.get("AssetSources_RentalProperty");
			String strRRSP_Input = Stage05_InputData.get("AssetSources_RRSP");
			String strSecondaryProperty_Input = Stage05_InputData.get("AssetSources_SecondaryProperty");
			String strStockBond_Input = Stage05_InputData.get("AssetSources_StockBond");
			String strOtherAssets_Input = Stage05_InputData.get("AssetSources_OtherAssets");
			String strNoOtherAssets_Input = Stage05_InputData.get("AssetSources_NoOtherAssets");
  			
			if (strNoOtherAssets_Input.contentEquals("No assets")) {
				CommonAppMethodsAssetLiabilities.SelectAssetsSources(strNoOtherAssets_Input);
			}
			if (strAutomobile_Input.contentEquals("Automobile")) {
				CommonAppMethodsAssetLiabilities.SelectAssetsSources(strAutomobile_Input); 
			}
			if (strCash_Input.contentEquals("Cash")) {
				CommonAppMethodsAssetLiabilities.SelectAssetsSources(strCash_Input); 
			}
			if (strGICTermDeposit_Input.contentEquals("GIC/Term deposit")) {
				CommonAppMethodsAssetLiabilities.SelectAssetsSources(strGICTermDeposit_Input); 
			}
			if (strPrimaryResidence_Input.contentEquals("Primary residence")) {
				CommonAppMethodsAssetLiabilities.SelectAssetsSources(strPrimaryResidence_Input); 
			}
			
			if (strRentalProperty_Input.contentEquals("Rental property")) {
				CommonAppMethodsAssetLiabilities.SelectAssetsSources(strRentalProperty_Input); 
			}
			if (strRRSP_Input.contentEquals("RRSP")) {
				CommonAppMethodsAssetLiabilities.SelectAssetsSources(strRRSP_Input); 
			}
			if (strSecondaryProperty_Input.contentEquals("Secondary property")) {
				CommonAppMethodsAssetLiabilities.SelectAssetsSources(strSecondaryProperty_Input); 
			}
			if (strStockBond_Input.contentEquals("Stock/Bond")) {
				CommonAppMethodsAssetLiabilities.SelectAssetsSources(strStockBond_Input); 
			}
			if (strOtherAssets_Input.contentEquals("Other assets")) {
				CommonAppMethodsAssetLiabilities.SelectAssetsSources(strOtherAssets_Input); 
			}
			if (strAutomobile_Input.contentEquals("No assets") | strCash_Input.contentEquals("No assets") | strGICTermDeposit_Input.contentEquals("No assets") | strPrimaryResidence_Input.contentEquals("No assets")| strRentalProperty_Input.contentEquals("No assets")| strRRSP_Input.contentEquals("No assets")| strSecondaryProperty_Input.contentEquals("No assets")| strStockBond_Input.contentEquals("No assets")| strOtherAssets_Input.contentEquals("No assets")) {
				CommonAppMethodsAssetLiabilities.SelectAssetsSources("No assets"); 
			}
			
			Thread.sleep(250);
		}
	  
	  
	  @Then("^Verify 'Liability-Sources' Screen when select 'No assets' on 'Asset Sources' Screen$")
		public void Verify_Liability_Sources_Screen_and_select_No_Source_of_income_on_Asset_Sources_Screen() throws Throwable {
		  Map<String, String> Stage05_ExpectedData =  Utility.readTestData(strfullPathToFile, sheetStage05_ExpectedData,strtestCaseID);
		  String strLiability_sources_ExpectedTitle	= Stage05_ExpectedData.get("Liability_Sources_Title"); 	

		  Thread.sleep(500);
		  QAFExtendedWebElement strLiability_sources_ActualTitle= new QAFExtendedWebElement("ehome.liabilitySrcs.Title");
		  Thread.sleep(250);
			
		  if (strLiability_sources_ExpectedTitle.contentEquals(strLiability_sources_ActualTitle.getText())) {
			  ExtentReportHelper.StepPass("'" + strLiability_sources_ExpectedTitle + "' Screen# is displayed.");
		  }
		  else
		  {
			  Assert.assertEquals(strLiability_sources_ActualTitle.getText(), strLiability_sources_ExpectedTitle,"'Liability-Sources' Screen is NOT as Expected.");
		  }
	  }
	  
	  
	  @Then("^Verify 'Asset-Sources-Detail' Screen when select 'Any Assets' on 'Asset Sources' Screen$")
		public void Verify_Asset_Details_Screen_and_select_Any_Assets_on_Asset_Sources_Screen() throws Throwable {
		  Map<String, String> Stage05_ExpectedData =  Utility.readTestData(strfullPathToFile, sheetStage05_ExpectedData,strtestCaseID);
		  Map<String, String> Stage05_InputData =  Utility.readTestData(strfullPathToFile, sheetStage05_InputData,strtestCaseID);
			
		  String strAssetDetails_ExpectedTitle	= Stage05_ExpectedData.get("Asset_Details_Title"); 
		  String strNoOtherAssets_Input = Stage05_InputData.get("AssetSources_NoOtherAssets");
		  
		  if (!strNoOtherAssets_Input.contentEquals("No assets")) {
				Common.continueButtonClicked();
				}
		  
		  QAFExtendedWebElement strAssetDetails_ActualTitle= new QAFExtendedWebElement("ehome.assetDetails.Title");
		  Thread.sleep(250);
		  if (strAssetDetails_ExpectedTitle.contentEquals(strAssetDetails_ActualTitle.getText())) {
			  ExtentReportHelper.StepPass("'" + strAssetDetails_ExpectedTitle + "' Screen# is displayed.");
		  }
		  else
		  {
			  Assert.assertEquals(strAssetDetails_ActualTitle.getText(), strAssetDetails_ExpectedTitle,"'Asset-Details' Screen is NOT as Expected.");
		  }
	  }

		
	@Then("^Verify 'Asset Sources' Screen and presence of all objects on 'Asset Sources' Screen$")
	public void Verify_Asset_Sources_Screen_and_presence_of_all_objects_on_Asset_Sources_Screen() throws Throwable {
		Map<String, String> Stage05_ExpectedData =  Utility.readTestData(strfullPathToFile, sheetStage05_ExpectedData,strtestCaseID);
		
		String strAssets_NextStep_Label_ExpectedTitle			= Stage05_ExpectedData.get("Assets_NextStep_Label"); 	
		String strAssets_FollowingAssets_Label_ExpectedTitle	= Stage05_ExpectedData.get("Assets_FollowingAssets_Label");
		String strAssets_PleaseSelectAll_Label_ExpectedTitle	= Stage05_ExpectedData.get("Assets_PleaseSelectAll_Label");
				
		QAFExtendedWebElement strAssets_NextStep_Label_ActualTitle= new QAFExtendedWebElement("ehome.assetSrcs.NextStep_Label");
		QAFExtendedWebElement strAssets_FollowingAssets_Label_ActualTitle= new QAFExtendedWebElement("ehome.assetSrcs.FollowingAssets_Label");
		QAFExtendedWebElement strAssets_PleaseSelectAll_Label_ActualTitle= new QAFExtendedWebElement("ehome.assetSrcs.PleaseSelectAll_Label");
			
		Thread.sleep(500);
		
//  		if (strAssets_NextStep_Label_ExpectedTitle.contentEquals(strAssets_NextStep_Label_ActualTitle.getText())) {
//  			ExtentReportHelper.StepPass("'" + strAssets_NextStep_Label_ExpectedTitle + " Screen# is displayed.");
//  		}
//  		else
//  		{
//  			Assert.assertEquals(strAssets_NextStep_Label_ActualTitle.getText(), strAssets_NextStep_Label_ExpectedTitle,"'Asset-Sources' Screen is NOT as Expected.");
//  		}
 			
  		if (strAssets_FollowingAssets_Label_ExpectedTitle.contentEquals(strAssets_FollowingAssets_Label_ActualTitle.getText())) {
  			ExtentReportHelper.StepPass("'" + strAssets_FollowingAssets_Label_ExpectedTitle + " Label# is displayed.");
  		}
  		else
  		{
  			Assert.assertEquals(strAssets_FollowingAssets_Label_ActualTitle.getText(), strAssets_FollowingAssets_Label_ExpectedTitle,"'Do you have any of the following assets?' Label is NOT as Expected.");
  		}
    		
//  		if (strAssets_PleaseSelectAll_Label_ExpectedTitle.contentEquals(strAssets_PleaseSelectAll_Label_ActualTitle.getText())) {
//  			ExtentReportHelper.StepPass("'" + strAssets_PleaseSelectAll_Label_ExpectedTitle + " Label# is displayed.");
//  		}
//  		else
//  		{
//  			Assert.assertEquals(strAssets_PleaseSelectAll_Label_ActualTitle.getText(), strAssets_PleaseSelectAll_Label_ExpectedTitle,"'Please select all sole and jointly held assets that are in your or John's name' Label is NOT as Expected.");
//  		}
  		
  		
		if(Automobile.isPresent())
		{
			ExtentReportHelper.StepPass("'" + Automobile.getText() + "' option button is displayed.");
		}
		else
		{
			ExtentReportHelper.StepFail("'" + Automobile.getText() + "' option button is NOT displayed.");
		}
		if(Cash.isPresent())
		{
			ExtentReportHelper.StepPass("'" + Cash.getText() + "' option button is displayed.");
		}
		else
		{
			ExtentReportHelper.StepFail("'" + Cash.getText() + "' option button is NOT displayed.");
		}	
		if(GICTermDeposit.isPresent())
		{
			ExtentReportHelper.StepPass("'" + GICTermDeposit.getText() + "' option button is displayed.");
		}
		else
		{
			ExtentReportHelper.StepFail("'" + GICTermDeposit.getText() + "' option button is NOT displayed.");
		}	
  		
		if(PrimaryResidence.isPresent())
		{
			ExtentReportHelper.StepPass("'" + PrimaryResidence.getText() + "' option button is displayed.");
		}
		else
		{
			ExtentReportHelper.StepFail("'" + PrimaryResidence.getText() + "' option button is NOT displayed.");
		}
		if(RentalProperty.isPresent())
		{
			ExtentReportHelper.StepPass("'" + RentalProperty.getText() + "' option button is displayed.");
		}
		else
		{
			ExtentReportHelper.StepFail("'" + RentalProperty.getText() + "' option button is NOT displayed.");
		}
		if(RRSP.isPresent())
		{
			ExtentReportHelper.StepPass("'" + RRSP.getText() + "' option button is displayed.");
		}
		else
		{
			ExtentReportHelper.StepFail("'" + RRSP.getText() + "' option button is NOT displayed.");
		}
		
		System.err.println("RAM>>>" + SecondaryProperty.isPresent());
		
		if(SecondaryProperty.isPresent())
		{
			ExtentReportHelper.StepPass("'" + SecondaryProperty.getText() + "' option button is displayed.");
		}
		else
		{
			ExtentReportHelper.StepFail("'" + SecondaryProperty.getText() + "' option button is NOT displayed.");
		}
		if(StockBond.isPresent())
		{
			ExtentReportHelper.StepPass("'" + StockBond.getText() + "' option button is displayed.");
		}
		else
		{
			ExtentReportHelper.StepFail("'" + StockBond.getText() + "' option button is NOT displayed.");
		}
		if(OtherAssets.isPresent())
		{
			ExtentReportHelper.StepPass("'" + OtherAssets.getText() + "' option button is displayed.");
		}
		else
		{
			ExtentReportHelper.StepFail("'" + OtherAssets.getText() + "' option button is NOT displayed.");
		}
		
		if(strBackBtnAssets_Btn.isPresent())
		{
			ExtentReportHelper.StepPass("'" + strBackBtnAssets_Btn.getText() + "' option button is displayed.");
		}
		else
		{
			ExtentReportHelper.StepFail("'" + strBackBtnAssets_Btn.getText() + "' option button is NOT displayed.");
		}
		
		if(strNoAssets_Link.isPresent())
		{
			ExtentReportHelper.StepPass("'" + strNoAssets_Link.getText() + "' option button is displayed.");
		}
		else
		{
			ExtentReportHelper.StepFail("'" + strNoAssets_Link.getText() + "' option button is NOT displayed.");
		}
		
	 		}
	
	@Then("^Verify 'Asset-section-breaker' Screen when Click on 'Back' button on 'Asset Sources' Screen$")
	public void Verify_Asset_section_breaker_Screen_when_Click_on_Back_button_on_Asset_Sources_Screen() throws Throwable {
		
		Map<String, String> Stage05_ExpectedData =  Utility.readTestData(strfullPathToFile, sheetStage05_ExpectedData,strtestCaseID);
			String strassetSectionBrk_ExpectedTitle	= Stage05_ExpectedData.get("Asset_Section_Breaker_Title"); 	
			
			Utility.clickObject("ehome.assetSrcs.Back", "Back Button in Asset Sources");
			Thread.sleep(1000);
		
			QAFExtendedWebElement strAssetSectionBrk_ActualTitle= new QAFExtendedWebElement("ehome.assetSectionBrkr.Title");
			if (strassetSectionBrk_ExpectedTitle.contentEquals(strAssetSectionBrk_ActualTitle.getText())) {
    			ExtentReportHelper.StepPass(strassetSectionBrk_ExpectedTitle + " Screen# is displayed.");
    		}
    		else
    		{
    			Assert.assertEquals(strAssetSectionBrk_ActualTitle.getText(), strassetSectionBrk_ExpectedTitle,"'Asset-section-breaker' Screen is NOT as Expected.");
    		}	
    		
		}

		
	//AssetSources-Retirement-TC-017_Verify presence of 'Remove' 'Continue' 'Select' 'No assets' Options when 'Select' and 'UnSelect' 'Asset Sources-' 'Automobile' on 'Assets' Screen
	@Then("^Verify presence of 'Remove' 'Continue' and 'Select' 'No assets' Options when 'Select' and 'UnSelect' 'Asset Sources' on 'Assets' Screen$")
	public void Verify_presence_of_Remove_Continue_Select_No_other_assets_Options_when_Select_and_UnSelect_Asset_Sources_on_Assets_Screen() throws Throwable {
		
		if (strAutomobileRemove_Btn.getText().contentEquals("Remove")) {
			ExtentReportHelper.StepPass("'" + strAutomobileRemove_Btn.getText() + "' option changed from 'Select' option when select Asset Source.");
		}
		else
		{
			ExtentReportHelper.StepFail("'" + strAutomobileRemove_Btn.getText() + "' option is NOT changed from 'Select' option when select Asset Source.");
		}
		Thread.sleep(250);
		if (strContinueAssets_Btn.getText().contentEquals("Continue")) {
			ExtentReportHelper.StepPass("'" + strContinueAssets_Btn.getText() + "' Button changed from 'No assets' Button when select Asset Source.");
		}
		else
		{
			ExtentReportHelper.StepFail("'" + strContinueAssets_Btn.getText() + "' Button is NOT changed from 'No assets' Button when select Asset Source.");
		}
		strAutomobileRemove_Btn.click();
		Thread.sleep(250);
		if (strAutomobileSelect_Btn.getText().contentEquals("Select")) {
			ExtentReportHelper.StepPass("'" + strAutomobileSelect_Btn.getText() + "' option changed from 'Remove' option when UnSelect Asset Source.");
		}
		else
		{
			ExtentReportHelper.StepFail("'" + strAutomobileSelect_Btn.getText() + "' option is NOT changed from 'Remove' option when UnSelect Asset Source.");
		}
		if (strNoAssets_Link.getText().contentEquals("No assets")) {
			ExtentReportHelper.StepPass("'" + strNoAssets_Link.getText() + "' Button changed from 'Continue' Button when UnSelect Asset Source.");
		}
		else
		{
			ExtentReportHelper.StepFail("'" + strNoAssets_Link.getText() + "' Button is NOT changed from 'Continue' Button when UnSelect Asset Source.");
		}
	}
	
	//AssetSources-Retirement-TC-018_Verify presence of 'Remove' 'Continue' 'Select' 'No assets' Options when 'Select' and 'UnSelect' 'Asset Sources-' 'Cash' on 'Assets' Screen
	@Then("^Verify presence of 'Remove' 'Continue' and 'Select' 'No assets' Options when 'Select' and 'UnSelect' 'Cash Sources' on 'Assets' Screen$")
	public void Verify_presence_of_Remove_Continue_Select_No_other_assets_Options_when_Select_and_UnSelect_Cash_Sources_on_Assets_Screen() throws Throwable {
		
		if (strCashRemove_Btn.getText().contentEquals("Remove")) {
			ExtentReportHelper.StepPass("'" + strCashRemove_Btn.getText() + "' option changed from 'Select' option when select Asset Source.");
		}
		else
		{
			ExtentReportHelper.StepFail("'" + strCashRemove_Btn.getText() + "' option is NOT changed from 'Select' option when select Asset Source.");
		}
		
		Thread.sleep(250);

		if (strContinueAssets_Btn.getText().contentEquals("Continue")) {
			ExtentReportHelper.StepPass("'" + strContinueAssets_Btn.getText() + "' Button changed from 'No assets' Button when select Asset Source.");
		}
		else
		{
			ExtentReportHelper.StepFail("'" + strContinueAssets_Btn.getText() + "' Button is NOT changed from 'No assets' Button when select Asset Source.");
		}
		
		strCashRemove_Btn.click();
		Thread.sleep(250);
		
		if (strCashSelect_Btn.getText().contentEquals("Select")) {
			ExtentReportHelper.StepPass("'" + strCashSelect_Btn.getText() + "' option changed from 'Remove' option when UnSelect Asset Source.");
		}
		else
		{
			ExtentReportHelper.StepFail("'" + strCashSelect_Btn.getText() + "' option is NOT changed from 'Remove' option when UnSelect Asset Source.");
		}
		if (strNoAssets_Link.getText().contentEquals("No assets")) {
			ExtentReportHelper.StepPass("'" + strNoAssets_Link.getText() + "' Button changed from 'Continue' Button when UnSelect Asset Source.");
		}
		else
		{
			ExtentReportHelper.StepFail("'" + strNoAssets_Link.getText() + "' Button is NOT changed from 'Continue' Button when UnSelect Asset Source.");
		}
	}
	
	
	//AssetSources-Retirement-TC-019_Verify presence of 'Remove' 'Continue' 'Select' 'No assets' Options when 'Select' and 'UnSelect' 'Asset Sources-' 'GIC/Term Deposit' on 'Assets' Screen
	@Then("^Verify presence of 'Remove' 'Continue' and 'Select' 'No assets' Options when 'Select' and 'UnSelect' 'GICTerm Deposit Sources' on 'Assets' Screen$")
	public void Verify_presence_of_Remove_Continue_Select_No_other_assets_Options_when_Select_and_UnSelect_GICTerm_Deposit_Sources_on_Assets_Screen() throws Throwable {
		
		if (strGICTermDepRemove_Btn.getText().contentEquals("Remove")) {
			ExtentReportHelper.StepPass("'" + strGICTermDepRemove_Btn.getText() + "' option changed from 'Select' option when select Asset Source.");
		}
		else
		{
			ExtentReportHelper.StepFail("'" + strGICTermDepRemove_Btn.getText() + "' option is NOT changed from 'Select' option when select Asset Source.");
		}
		
		Thread.sleep(250);

		if (strContinueAssets_Btn.getText().contentEquals("Continue")) {
			ExtentReportHelper.StepPass("'" + strContinueAssets_Btn.getText() + "' Button changed from 'No assets' Button when select Asset Source.");
		}
		else
		{
			ExtentReportHelper.StepFail("'" + strContinueAssets_Btn.getText() + "' Button is NOT changed from 'No assets' Button when select Asset Source.");
		}
		
		strGICTermDepRemove_Btn.click();
		Thread.sleep(250);
		
		if (strGICTermDepSelect_Btn.getText().contentEquals("Select")) {
			ExtentReportHelper.StepPass("'" + strGICTermDepSelect_Btn.getText() + "' option changed from 'Remove' option when UnSelect Asset Source.");
		}
		else
		{
			ExtentReportHelper.StepFail("'" + strGICTermDepSelect_Btn.getText() + "' option is NOT changed from 'Remove' option when UnSelect Asset Source.");
		}
		if (strNoAssets_Link.getText().contentEquals("No assets")) {
			ExtentReportHelper.StepPass("'" + strNoAssets_Link.getText() + "' Button changed from 'Continue' Button when UnSelect Asset Source.");
		}
		else
		{
			ExtentReportHelper.StepFail("'" + strNoAssets_Link.getText() + "' Button is NOT changed from 'Continue' Button when UnSelect Asset Source.");
		}
	}
	
	//AssetSources-Retirement-TC-020_Verify presence of 'Remove' 'Continue' and 'Select' 'No assets' Options when 'Select' and 'UnSelect' 'Primary Residence Sources' on 'Assets' Screen
	@Then("^Verify presence of 'Remove' 'Continue' and 'Select' 'No assets' Options when 'Select' and 'UnSelect' 'Primary Residence Sources' on 'Assets' Screen$")
	public void Verify_presence_of_Remove_Continue_Select_No_other_assets_Options_when_Select_and_UnSelect_Primary_Residence_Sources_on_Assets_Screen() throws Throwable {
	
		if (PrimaryResidenceRemove_Btn.getText().contentEquals("Remove")) {
			ExtentReportHelper.StepPass("'" + PrimaryResidenceRemove_Btn.getText() + "' option changed from 'Select' option when select Asset Source.");
		}
		else
		{
			ExtentReportHelper.StepFail("'" + PrimaryResidenceRemove_Btn.getText() + "' option is NOT changed from 'Select' option when select Asset Source.");
		}
		
		Thread.sleep(250);
	
		if (strContinueAssets_Btn.getText().contentEquals("Continue")) {
			ExtentReportHelper.StepPass("'" + strContinueAssets_Btn.getText() + "' Button changed from 'No assets' Button when select Asset Source.");
		}
		else
		{
			ExtentReportHelper.StepFail("'" + strContinueAssets_Btn.getText() + "' Button is NOT changed from 'No assets' Button when select Asset Source.");
		}
		
		PrimaryResidenceRemove_Btn.click();
		Thread.sleep(250);
		
		if (PrimaryResidenceSelect_Btn.getText().contentEquals("Select")) {
			ExtentReportHelper.StepPass("'" + PrimaryResidenceSelect_Btn.getText() + "' option changed from 'Remove' option when UnSelect Asset Source.");
		}
		else
		{
			ExtentReportHelper.StepFail("'" + PrimaryResidenceSelect_Btn.getText() + "' option is NOT changed from 'Remove' option when UnSelect Asset Source.");
		}
		if (strNoAssets_Link.getText().contentEquals("No assets")) {
			ExtentReportHelper.StepPass("'" + strNoAssets_Link.getText() + "' Button changed from 'Continue' Button when UnSelect Asset Source.");
		}
		else
		{
			ExtentReportHelper.StepFail("'" + strNoAssets_Link.getText() + "' Button is NOT changed from 'Continue' Button when UnSelect Asset Source.");
		}
	}

	//AssetSources-Retirement-TC-021_Verify presence of 'Remove' 'Continue' and 'Select' 'No assets' Options when 'Select' and 'UnSelect' 'Rental Property Sources' on 'Assets' Screen
	@Then("^Verify presence of 'Remove' 'Continue' and 'Select' 'No assets' Options when 'Select' and 'UnSelect' 'Rental Property Sources' on 'Assets' Screen$")
	public void Verify_presence_of_Remove_Continue_Select_No_other_assets_Options_when_Select_and_UnSelect_RentalProperty_Sources_on_Assets_Screen() throws Throwable {
	
		if (RentalPropertyRemove_Btn.getText().contentEquals("Remove")) {
			ExtentReportHelper.StepPass("'" + RentalPropertyRemove_Btn.getText() + "' option changed from 'Select' option when select Asset Source.");
		}
		else
		{
			ExtentReportHelper.StepFail("'" + RentalPropertyRemove_Btn.getText() + "' option is NOT changed from 'Select' option when select Asset Source.");
		}
		
		Thread.sleep(250);
	
		if (strContinueAssets_Btn.getText().contentEquals("Continue")) {
			ExtentReportHelper.StepPass("'" + strContinueAssets_Btn.getText() + "' Button changed from 'No assets' Button when select Asset Source.");
		}
		else
		{
			ExtentReportHelper.StepFail("'" + strContinueAssets_Btn.getText() + "' Button is NOT changed from 'No assets' Button when select Asset Source.");
		}
		
		RentalPropertyRemove_Btn.click();
		Thread.sleep(250);
		
		if (RentalPropertySelect_Btn.getText().contentEquals("Select")) {
			ExtentReportHelper.StepPass("'" + RentalPropertySelect_Btn.getText() + "' option changed from 'Remove' option when UnSelect Asset Source.");
		}
		else
		{
			ExtentReportHelper.StepFail("'" + RentalPropertySelect_Btn.getText() + "' option is NOT changed from 'Remove' option when UnSelect Asset Source.");
		}
		if (strNoAssets_Link.getText().contentEquals("No assets")) {
			ExtentReportHelper.StepPass("'" + strNoAssets_Link.getText() + "' Button changed from 'Continue' Button when UnSelect Asset Source.");
		}
		else
		{
			ExtentReportHelper.StepFail("'" + strNoAssets_Link.getText() + "' Button is NOT changed from 'Continue' Button when UnSelect Asset Source.");
		}
	}
	
	
		//AssetSources-Retirement-TC-022_Verify presence of 'Remove' 'Continue' 'Select' 'No assets' Options when 'Select' and 'UnSelect' 'Asset Sources-' 'RRSP' on 'Assets' Screen
		@Then("^Verify presence of 'Remove' 'Continue' and 'Select' 'No assets' Options when 'Select' and 'UnSelect' 'RRSP Sources' on 'Assets' Screen$")
		public void Verify_presence_of_Remove_Continue_Select_No_other_assets_Options_when_Select_and_UnSelect_RRSP_Sources_on_Assets_Screen() throws Throwable {
		
			Thread.sleep(250);
			if (RRSPRemove_Btn.getText().contentEquals("Remove")) {
				ExtentReportHelper.StepPass("'" + RRSPRemove_Btn.getText() + "' option changed from 'Select' option when select Asset Source.");
			}
			else
			{
				ExtentReportHelper.StepFail("'" + RRSPRemove_Btn.getText() + "' option is NOT changed from 'Select' option when select Asset Source.");
			}
			
			Thread.sleep(250);
		
			if (strContinueAssets_Btn.getText().contentEquals("Continue")) {
				ExtentReportHelper.StepPass("'" + strContinueAssets_Btn.getText() + "' Button changed from 'No assets' Button when select Asset Source.");
			}
			else
			{
				ExtentReportHelper.StepFail("'" + strContinueAssets_Btn.getText() + "' Button is NOT changed from 'No assets' Button when select Asset Source.");
			}
			
			RRSPRemove_Btn.click();
			Thread.sleep(250);
			
			if (RRSPSelect_Btn.getText().contentEquals("Select")) {
				ExtentReportHelper.StepPass("'" + RRSPSelect_Btn.getText() + "' option changed from 'Remove' option when UnSelect Asset Source.");
			}
			else
			{
				ExtentReportHelper.StepFail("'" + RRSPSelect_Btn.getText() + "' option is NOT changed from 'Remove' option when UnSelect Asset Source.");
			}
			if (strNoAssets_Link.getText().contentEquals("No assets")) {
				ExtentReportHelper.StepPass("'" + strNoAssets_Link.getText() + "' Button changed from 'Continue' Button when UnSelect Asset Source.");
			}
			else
			{
				ExtentReportHelper.StepFail("'" + strNoAssets_Link.getText() + "' Button is NOT changed from 'Continue' Button when UnSelect Asset Source.");
			}
		}
	
	
		//AssetSources-Retirement-TC-023_Verify presence of 'Remove' 'Continue' 'Select' 'No assets' Options when 'Select' and 'UnSelect' 'Asset Sources-' 'Secondary Property' on 'Assets' Screen
		@Then("^Verify presence of 'Remove' 'Continue' and 'Select' 'No assets' Options when 'Select' and 'UnSelect' 'Secondary Property Sources' on 'Assets' Screen$")
		public void Verify_presence_of_Remove_Continue_Select_No_other_assets_Options_when_Select_and_UnSelect_SecondaryProperty_Sources_on_Assets_Screen() throws Throwable {
		
			if (SecondaryPropertyRemove_Btn.getText().contentEquals("Remove")) {
				ExtentReportHelper.StepPass("'" + SecondaryPropertyRemove_Btn.getText() + "' option changed from 'Select' option when select Asset Source.");
			}
			else
			{
				ExtentReportHelper.StepFail("'" + SecondaryPropertyRemove_Btn.getText() + "' option is NOT changed from 'Select' option when select Asset Source.");
			}
			
			Thread.sleep(250);
		
			if (strContinueAssets_Btn.getText().contentEquals("Continue")) {
				ExtentReportHelper.StepPass("'" + strContinueAssets_Btn.getText() + "' Button changed from 'No assets' Button when select Asset Source.");
			}
			else
			{
				ExtentReportHelper.StepFail("'" + strContinueAssets_Btn.getText() + "' Button is NOT changed from 'No assets' Button when select Asset Source.");
			}
			
			SecondaryPropertyRemove_Btn.click();
			Thread.sleep(250);
			
			if (SecondaryPropertySelect_Btn.getText().contentEquals("Select")) {
				ExtentReportHelper.StepPass("'" + SecondaryPropertySelect_Btn.getText() + "' option changed from 'Remove' option when UnSelect Asset Source.");
			}
			else
			{
				ExtentReportHelper.StepFail("'" + SecondaryPropertySelect_Btn.getText() + "' option is NOT changed from 'Remove' option when UnSelect Asset Source.");
			}
			if (strNoAssets_Link.getText().contentEquals("No assets")) {
				ExtentReportHelper.StepPass("'" + strNoAssets_Link.getText() + "' Button changed from 'Continue' Button when UnSelect Asset Source.");
			}
			else
			{
				ExtentReportHelper.StepFail("'" + strNoAssets_Link.getText() + "' Button is NOT changed from 'Continue' Button when UnSelect Asset Source.");
			}
		}
	
		//AssetSources-Retirement-TC-024_Verify presence of 'Remove' 'Continue' 'Select' 'No assets' Options when 'Select' and 'UnSelect' 'Asset Sources-' 'Stock/Bond' on 'Assets' Screen
		@Then("^Verify presence of 'Remove' 'Continue' and 'Select' 'No assets' Options when 'Select' and 'UnSelect' 'StockBond Sources' on 'Assets' Screen$")
		public void Verify_presence_of_Remove_Continue_Select_No_other_assets_Options_when_Select_and_UnSelect_StockBond_Sources_on_Assets_Screen() throws Throwable {
		
			if (StockBondRemove_Btn.getText().contentEquals("Remove")) {
				ExtentReportHelper.StepPass("'" + StockBondRemove_Btn.getText() + "' option changed from 'Select' option when select Asset Source.");
			}
			else
			{
				ExtentReportHelper.StepFail("'" + StockBondRemove_Btn.getText() + "' option is NOT changed from 'Select' option when select Asset Source.");
			}
			Thread.sleep(250);
			if (strContinueAssets_Btn.getText().contentEquals("Continue")) {
				ExtentReportHelper.StepPass("'" + strContinueAssets_Btn.getText() + "' Button changed from 'No assets' Button when select Asset Source.");
			}
			else
			{
				ExtentReportHelper.StepFail("'" + strContinueAssets_Btn.getText() + "' Button is NOT changed from 'No assets' Button when select Asset Source.");
			}
			StockBondRemove_Btn.click();
			Thread.sleep(250);
			if (StockBondSelect_Btn.getText().contentEquals("Select")) {
				ExtentReportHelper.StepPass("'" + StockBondSelect_Btn.getText() + "' option changed from 'Remove' option when UnSelect Asset Source.");
			}
			else
			{
				ExtentReportHelper.StepFail("'" + StockBondSelect_Btn.getText() + "' option is NOT changed from 'Remove' option when UnSelect Asset Source.");
			}
			if (strNoAssets_Link.getText().contentEquals("No assets")) {
				ExtentReportHelper.StepPass("'" + strNoAssets_Link.getText() + "' Button changed from 'Continue' Button when UnSelect Asset Source.");
			}
			else
			{
				ExtentReportHelper.StepFail("'" + strNoAssets_Link.getText() + "' Button is NOT changed from 'Continue' Button when UnSelect Asset Source.");
			}
		}
	
		//AssetSources-Retirement-TC-025_Verify presence of 'Remove' 'Continue' 'Select' 'No assets' Options when 'Select' and 'UnSelect' 'Asset Sources-' 'Other Assets' on 'Assets' Screen
		@Then("^Verify presence of 'Remove' 'Continue' and 'Select' 'No assets' Options when 'Select' and 'UnSelect' 'Other Assets Sources' on 'Assets' Screen$")
		public void Verify_presence_of_Remove_Continue_Select_No_other_assets_Options_when_Select_and_UnSelect_OtherAssets_Sources_on_Assets_Screen() throws Throwable {
		
			if (OtherAssetsRemove_Btn.getText().contentEquals("Remove")) {
				ExtentReportHelper.StepPass("'" + OtherAssetsRemove_Btn.getText() + "' option changed from 'Select' option when select Asset Source.");
			}
			else
			{
				ExtentReportHelper.StepFail("'" + OtherAssetsRemove_Btn.getText() + "' option is NOT changed from 'Select' option when select Asset Source.");
			}
			
			Thread.sleep(250);
		
			if (strContinueAssets_Btn.getText().contentEquals("Continue")) {
				ExtentReportHelper.StepPass("'" + strContinueAssets_Btn.getText() + "' Button changed from 'No assets' Button when select Asset Source.");
			}
			else
			{
				ExtentReportHelper.StepFail("'" + strContinueAssets_Btn.getText() + "' Button is NOT changed from 'No assets' Button when select Asset Source.");
			}
			
			OtherAssetsRemove_Btn.click();
			Thread.sleep(250);
			
			if (OtherAssetsSelect_Btn.getText().contentEquals("Select")) {
				ExtentReportHelper.StepPass("'" + OtherAssetsSelect_Btn.getText() + "' option changed from 'Remove' option when UnSelect Asset Source.");
			}
			else
			{
				ExtentReportHelper.StepFail("'" + OtherAssetsSelect_Btn.getText() + "' option is NOT changed from 'Remove' option when UnSelect Asset Source.");
			}
			if (strNoAssets_Link.getText().contentEquals("No assets")) {
				ExtentReportHelper.StepPass("'" + strNoAssets_Link.getText() + "' Button changed from 'Continue' Button when UnSelect Asset Source.");
			}
			else
			{
				ExtentReportHelper.StepFail("'" + strNoAssets_Link.getText() + "' Button is NOT changed from 'Continue' Button when UnSelect Asset Source.");
			}
		}
	
		//AssetSources-Retirement-TC-026_Verify presence of 'Remove' 'Continue' 'Select' 'No assets' Options when 'Select' and 'UnSelect' 'Asset Sources-' 'Automobile' 'Cash' 'GIC/Term Deposit' 'Primary Residence' 'Rental Property' 'RRSP' 'Secondary Property' 'Stock/Bond' 'Other Assets' on 'Assets' Screen
		@Then("^Verify presence of 'Remove' 'Continue' 'Select' 'No assets' Options when 'Select' and 'UnSelect' 'Asset Sources-' 'Automobile' 'Cash' 'GIC/Term Deposit' 'Primary Residence' 'Rental Property' 'RRSP' 'Secondary Property' 'Stock/Bond' 'Other Assets' on 'Assets' Screen$")
		public void Verify_presence_of_Remove_Continue_Select_No_other_assets_Options_when_Select_and_UnSelect_AllAssets_Sources_on_Assets_Screen() throws Throwable {

			if (strAutomobileRemove_Btn.getText().contentEquals("Remove")) {
				ExtentReportHelper.StepPass("'" + strAutomobileRemove_Btn.getText() + "' option changed from 'Select' option when select Asset Source.");
			}
			else
			{
				ExtentReportHelper.StepFail("'" + strAutomobileRemove_Btn.getText() + "' option is NOT changed from 'Select' option when select Asset Source.");
			}
			if (strCashRemove_Btn.getText().contentEquals("Remove")) {
				ExtentReportHelper.StepPass("'" + strCashRemove_Btn.getText() + "' option changed from 'Select' option when select Asset Source.");
			}
			else
			{
				ExtentReportHelper.StepFail("'" + strCashRemove_Btn.getText() + "' option is NOT changed from 'Select' option when select Asset Source.");
			}
			if (strGICTermDepRemove_Btn.getText().contentEquals("Remove")) {
				ExtentReportHelper.StepPass("'" + strGICTermDepRemove_Btn.getText() + "' option changed from 'Select' option when select Asset Source.");
			}
			else
			{
				ExtentReportHelper.StepFail("'" + strGICTermDepRemove_Btn.getText() + "' option is NOT changed from 'Select' option when select Asset Source.");
			}
			if (PrimaryResidenceRemove_Btn.getText().contentEquals("Remove")) {
				ExtentReportHelper.StepPass("'" + PrimaryResidenceRemove_Btn.getText() + "' option changed from 'Select' option when select Asset Source.");
			}
			else
			{
				ExtentReportHelper.StepFail("'" + PrimaryResidenceRemove_Btn.getText() + "' option is NOT changed from 'Select' option when select Asset Source.");
			}
			if (RentalPropertyRemove_Btn.getText().contentEquals("Remove")) {
				ExtentReportHelper.StepPass("'" + RentalPropertyRemove_Btn.getText() + "' option changed from 'Select' option when select Asset Source.");
			}
			else
			{
				ExtentReportHelper.StepFail("'" + RentalPropertyRemove_Btn.getText() + "' option is NOT changed from 'Select' option when select Asset Source.");
			}
			if (RRSPRemove_Btn.getText().contentEquals("Remove")) {
				ExtentReportHelper.StepPass("'" + RRSPRemove_Btn.getText() + "' option changed from 'Select' option when select Asset Source.");
			}
			else
			{
				ExtentReportHelper.StepFail("'" + RRSPRemove_Btn.getText() + "' option is NOT changed from 'Select' option when select Asset Source.");
			}
			if (SecondaryPropertyRemove_Btn.getText().contentEquals("Remove")) {
			ExtentReportHelper.StepPass("'" + SecondaryPropertyRemove_Btn.getText() + "' option changed from 'Select' option when select Asset Source.");
			}
			else
			{
				ExtentReportHelper.StepFail("'" + SecondaryPropertyRemove_Btn.getText() + "' option is NOT changed from 'Select' option when select Asset Source.");
			}
			if (StockBondRemove_Btn.getText().contentEquals("Remove")) {
				ExtentReportHelper.StepPass("'" + StockBondRemove_Btn.getText() + "' option changed from 'Select' option when select Asset Source.");
			}
			else
			{
				ExtentReportHelper.StepFail("'" + StockBondRemove_Btn.getText() + "' option is NOT changed from 'Select' option when select Asset Source.");
			}
			if (OtherAssetsRemove_Btn.getText().contentEquals("Remove")) {
				ExtentReportHelper.StepPass("'" + OtherAssetsRemove_Btn.getText() + "' option changed from 'Select' option when select Asset Source.");
			}
			else
			{
				ExtentReportHelper.StepFail("'" + OtherAssetsRemove_Btn.getText() + "' option is NOT changed from 'Select' option when select Asset Source.");
			}
			Thread.sleep(250);
			if (strContinueAssets_Btn.getText().contentEquals("Continue")) {
				ExtentReportHelper.StepPass("'" + strContinueAssets_Btn.getText() + "' Button changed from 'No assets' Button when select Asset Source.");
			}
			else
			{
				ExtentReportHelper.StepFail("'" + strContinueAssets_Btn.getText() + "' Button is NOT changed from 'No assets' Button when select Asset Source.");
			}
			strAutomobileRemove_Btn.click();
			strCashRemove_Btn.click();
			strGICTermDepRemove_Btn.click();
			PrimaryResidenceRemove_Btn.click();
			RentalPropertyRemove_Btn.click();
			RRSPRemove_Btn.click();
			SecondaryPropertyRemove_Btn.click();
			StockBondRemove_Btn.click();
			OtherAssetsRemove_Btn.click();

			if (strAutomobileSelect_Btn.getText().contentEquals("Select")) {
				ExtentReportHelper.StepPass("'" + strAutomobileSelect_Btn.getText() + "' option changed from 'Remove' option when UnSelect Asset Source.");
			}
			else
			{
				ExtentReportHelper.StepFail("'" + strAutomobileSelect_Btn.getText() + "' option is NOT changed from 'Remove' option when UnSelect Asset Source.");
			}
			if (strNoAssets_Link.getText().contentEquals("No assets")) {
				ExtentReportHelper.StepPass("'" + strNoAssets_Link.getText() + "' Button changed from 'Continue' Button when UnSelect Asset Source.");
			}
			else
			{
				ExtentReportHelper.StepFail("'" + strNoAssets_Link.getText() + "' Button is NOT changed from 'Continue' Button when UnSelect Asset Source.");
			}

			if (strCashSelect_Btn.getText().contentEquals("Select")) {
				ExtentReportHelper.StepPass("'" + strCashSelect_Btn.getText() + "' option changed from 'Remove' option when UnSelect Asset Source.");
			}
			else
			{
				ExtentReportHelper.StepFail("'" + strCashSelect_Btn.getText() + "' option is NOT changed from 'Remove' option when UnSelect Asset Source.");
			}
			if (strNoAssets_Link.getText().contentEquals("No assets")) {
				ExtentReportHelper.StepPass("'" + strNoAssets_Link.getText() + "' Button changed from 'Continue' Button when UnSelect Asset Source.");
			}
			else
			{
				ExtentReportHelper.StepFail("'" + strNoAssets_Link.getText() + "' Button is NOT changed from 'Continue' Button when UnSelect Asset Source.");
			}
			if (strGICTermDepSelect_Btn.getText().contentEquals("Select")) {
				ExtentReportHelper.StepPass("'" + strGICTermDepSelect_Btn.getText() + "' option changed from 'Remove' option when UnSelect Asset Source.");
			}
			else
			{
				ExtentReportHelper.StepFail("'" + strGICTermDepSelect_Btn.getText() + "' option is NOT changed from 'Remove' option when UnSelect Asset Source.");
			}
			if (strNoAssets_Link.getText().contentEquals("No assets")) {
				ExtentReportHelper.StepPass("'" + strNoAssets_Link.getText() + "' Button changed from 'Continue' Button when UnSelect Asset Source.");
			}
			else
			{
				ExtentReportHelper.StepFail("'" + strNoAssets_Link.getText() + "' Button is NOT changed from 'Continue' Button when UnSelect Asset Source.");
			}
			if (PrimaryResidenceSelect_Btn.getText().contentEquals("Select")) {
				ExtentReportHelper.StepPass("'" + PrimaryResidenceSelect_Btn.getText() + "' option changed from 'Remove' option when UnSelect Asset Source.");
			}
			else
			{
				ExtentReportHelper.StepFail("'" + PrimaryResidenceSelect_Btn.getText() + "' option is NOT changed from 'Remove' option when UnSelect Asset Source.");
			}
			if (strNoAssets_Link.getText().contentEquals("No assets")) {
				ExtentReportHelper.StepPass("'" + strNoAssets_Link.getText() + "' Button changed from 'Continue' Button when UnSelect Asset Source.");
			}
			else
			{
				ExtentReportHelper.StepFail("'" + strNoAssets_Link.getText() + "' Button is NOT changed from 'Continue' Button when UnSelect Asset Source.");
			}
			if (RentalPropertySelect_Btn.getText().contentEquals("Select")) {
				ExtentReportHelper.StepPass("'" + RentalPropertySelect_Btn.getText() + "' option changed from 'Remove' option when UnSelect Asset Source.");
			}
			else
			{
				ExtentReportHelper.StepFail("'" + RentalPropertySelect_Btn.getText() + "' option is NOT changed from 'Remove' option when UnSelect Asset Source.");
			}
			if (strNoAssets_Link.getText().contentEquals("No assets")) {
				ExtentReportHelper.StepPass("'" + strNoAssets_Link.getText() + "' Button changed from 'Continue' Button when UnSelect Asset Source.");
			}
			else
			{
				ExtentReportHelper.StepFail("'" + strNoAssets_Link.getText() + "' Button is NOT changed from 'Continue' Button when UnSelect Asset Source.");
			}

			if (RRSPSelect_Btn.getText().contentEquals("Select")) {
				ExtentReportHelper.StepPass("'" + RRSPSelect_Btn.getText() + "' option changed from 'Remove' option when UnSelect Asset Source.");
			}
			else
			{
				ExtentReportHelper.StepFail("'" + RRSPSelect_Btn.getText() + "' option is NOT changed from 'Remove' option when UnSelect Asset Source.");
			}
			if (strNoAssets_Link.getText().contentEquals("No assets")) {
				ExtentReportHelper.StepPass("'" + strNoAssets_Link.getText() + "' Button changed from 'Continue' Button when UnSelect Asset Source.");
			}
			else
			{
				ExtentReportHelper.StepFail("'" + strNoAssets_Link.getText() + "' Button is NOT changed from 'Continue' Button when UnSelect Asset Source.");
			}
			if (SecondaryPropertySelect_Btn.getText().contentEquals("Select")) {
				ExtentReportHelper.StepPass("'" + SecondaryPropertySelect_Btn.getText() + "' option changed from 'Remove' option when UnSelect Asset Source.");
			}
			else
			{
				ExtentReportHelper.StepFail("'" + SecondaryPropertySelect_Btn.getText() + "' option is NOT changed from 'Remove' option when UnSelect Asset Source.");
			}
			if (strNoAssets_Link.getText().contentEquals("No assets")) {
				ExtentReportHelper.StepPass("'" + strNoAssets_Link.getText() + "' Button changed from 'Continue' Button when UnSelect Asset Source.");
			}
			else
			{
				ExtentReportHelper.StepFail("'" + strNoAssets_Link.getText() + "' Button is NOT changed from 'Continue' Button when UnSelect Asset Source.");
			}
			if (StockBondSelect_Btn.getText().contentEquals("Select")) {
				ExtentReportHelper.StepPass("'" + StockBondSelect_Btn.getText() + "' option changed from 'Remove' option when UnSelect Asset Source.");
			}
			else
			{
				ExtentReportHelper.StepFail("'" + StockBondSelect_Btn.getText() + "' option is NOT changed from 'Remove' option when UnSelect Asset Source.");
			}
			if (strNoAssets_Link.getText().contentEquals("No assets")) {
				ExtentReportHelper.StepPass("'" + strNoAssets_Link.getText() + "' Button changed from 'Continue' Button when UnSelect Asset Source.");
			}
			else
			{
				ExtentReportHelper.StepFail("'" + strNoAssets_Link.getText() + "' Button is NOT changed from 'Continue' Button when UnSelect Asset Source.");
			}
			if (OtherAssetsSelect_Btn.getText().contentEquals("Select")) {
				ExtentReportHelper.StepPass("'" + OtherAssetsSelect_Btn.getText() + "' option changed from 'Remove' option when UnSelect Asset Source.");
			}
			else
			{
				ExtentReportHelper.StepFail("'" + OtherAssetsSelect_Btn.getText() + "' option is NOT changed from 'Remove' option when UnSelect Asset Source.");
			}
			if (strNoAssets_Link.getText().contentEquals("No assets")) {
				ExtentReportHelper.StepPass("'" + strNoAssets_Link.getText() + "' Button changed from 'Continue' Button when UnSelect Asset Source.");
			}
			else
			{
				ExtentReportHelper.StepFail("'" + strNoAssets_Link.getText() + "' Button is NOT changed from 'Continue' Button when UnSelect Asset Source.");
			}
		}
	
	
		//AssetSources-Retirement-TC-027_Verify presence of 'Remove' 'Continue' 'Select' 'No assets' Options when 'Select' and 'UnSelect' 'Asset Sources-' 'Cash' 'Primary Residence' 'RRSP' 'Stock/Bond' on 'Assets' Screen
		@Then("^Verify presence of 'Remove' 'Continue' 'Select' 'No assets' Options when 'Select' and 'UnSelect' 'Asset Sources-' 'Cash' 'Primary Residence' 'RRSP' 'Stock/Bond' on 'Assets' Screen$")
		public void Verify_presence_of_Remove_Continue_Select_No_assets_Options_when_Select_and_UnSelect_Asset_Sources_Cash_Primary_Residence_RRSP_StockBond_on_Assets_Screen () throws Throwable {


			if (strCashRemove_Btn.getText().contentEquals("Remove")) {
				ExtentReportHelper.StepPass("'" + strCashRemove_Btn.getText() + "' option changed from 'Select' option when select Asset Source.");
			}
			else
			{
				ExtentReportHelper.StepFail("'" + strCashRemove_Btn.getText() + "' option is NOT changed from 'Select' option when select Asset Source.");
			}
			
			if (PrimaryResidenceRemove_Btn.getText().contentEquals("Remove")) {
				ExtentReportHelper.StepPass("'" + PrimaryResidenceRemove_Btn.getText() + "' option changed from 'Select' option when select Asset Source.");
			}
			else
			{
				ExtentReportHelper.StepFail("'" + PrimaryResidenceRemove_Btn.getText() + "' option is NOT changed from 'Select' option when select Asset Source.");
			}
			
			if (RRSPRemove_Btn.getText().contentEquals("Remove")) {
				ExtentReportHelper.StepPass("'" + RRSPRemove_Btn.getText() + "' option changed from 'Select' option when select Asset Source.");
			}
			else
			{
				ExtentReportHelper.StepFail("'" + RRSPRemove_Btn.getText() + "' option is NOT changed from 'Select' option when select Asset Source.");
			}
			
			if (StockBondRemove_Btn.getText().contentEquals("Remove")) {
				ExtentReportHelper.StepPass("'" + StockBondRemove_Btn.getText() + "' option changed from 'Select' option when select Asset Source.");
			}
			else
			{
				ExtentReportHelper.StepFail("'" + StockBondRemove_Btn.getText() + "' option is NOT changed from 'Select' option when select Asset Source.");
			}
			
			Thread.sleep(250);
			if (strContinueAssets_Btn.getText().contentEquals("Continue")) {
				ExtentReportHelper.StepPass("'" + strContinueAssets_Btn.getText() + "' Button changed from 'No assets' Button when select Asset Source.");
			}
			else
			{
				ExtentReportHelper.StepFail("'" + strContinueAssets_Btn.getText() + "' Button is NOT changed from 'No assets' Button when select Asset Source.");
			}
			Thread.sleep(250);
			strCashRemove_Btn.click();
			PrimaryResidenceRemove_Btn.click();
			RRSPRemove_Btn.click();
			StockBondRemove_Btn.click();
			Thread.sleep(250);
		
			if (strCashSelect_Btn.getText().contentEquals("Select")) {
				ExtentReportHelper.StepPass("'" + strCashSelect_Btn.getText() + "' option changed from 'Remove' option when UnSelect Asset Source.");
			}
			else
			{
				ExtentReportHelper.StepFail("'" + strCashSelect_Btn.getText() + "' option is NOT changed from 'Remove' option when UnSelect Asset Source.");
			}
			if (strNoAssets_Link.getText().contentEquals("No assets")) {
				ExtentReportHelper.StepPass("'" + strNoAssets_Link.getText() + "' Button changed from 'Continue' Button when UnSelect Asset Source.");
			}
			else
			{
				ExtentReportHelper.StepFail("'" + strNoAssets_Link.getText() + "' Button is NOT changed from 'Continue' Button when UnSelect Asset Source.");
			}
			if (PrimaryResidenceSelect_Btn.getText().contentEquals("Select")) {
				ExtentReportHelper.StepPass("'" + PrimaryResidenceSelect_Btn.getText() + "' option changed from 'Remove' option when UnSelect Asset Source.");
			}
			else
			{
				ExtentReportHelper.StepFail("'" + PrimaryResidenceSelect_Btn.getText() + "' option is NOT changed from 'Remove' option when UnSelect Asset Source.");
			}
			if (strNoAssets_Link.getText().contentEquals("No assets")) {
				ExtentReportHelper.StepPass("'" + strNoAssets_Link.getText() + "' Button changed from 'Continue' Button when UnSelect Asset Source.");
			}
			else
			{
				ExtentReportHelper.StepFail("'" + strNoAssets_Link.getText() + "' Button is NOT changed from 'Continue' Button when UnSelect Asset Source.");
			}
		
			if (RRSPSelect_Btn.getText().contentEquals("Select")) {
				ExtentReportHelper.StepPass("'" + RRSPSelect_Btn.getText() + "' option changed from 'Remove' option when UnSelect Asset Source.");
			}
			else
			{
				ExtentReportHelper.StepFail("'" + RRSPSelect_Btn.getText() + "' option is NOT changed from 'Remove' option when UnSelect Asset Source.");
			}
			if (strNoAssets_Link.getText().contentEquals("No assets")) {
				ExtentReportHelper.StepPass("'" + strNoAssets_Link.getText() + "' Button changed from 'Continue' Button when UnSelect Asset Source.");
			}
			else
			{
				ExtentReportHelper.StepFail("'" + strNoAssets_Link.getText() + "' Button is NOT changed from 'Continue' Button when UnSelect Asset Source.");
			}
			if (StockBondSelect_Btn.getText().contentEquals("Select")) {
				ExtentReportHelper.StepPass("'" + StockBondSelect_Btn.getText() + "' option changed from 'Remove' option when UnSelect Asset Source.");
			}
			else
			{
				ExtentReportHelper.StepFail("'" + StockBondSelect_Btn.getText() + "' option is NOT changed from 'Remove' option when UnSelect Asset Source.");
			}
			if (strNoAssets_Link.getText().contentEquals("No assets")) {
				ExtentReportHelper.StepPass("'" + strNoAssets_Link.getText() + "' Button changed from 'Continue' Button when UnSelect Asset Source.");
			}
			else
			{
				ExtentReportHelper.StepFail("'" + strNoAssets_Link.getText() + "' Button is NOT changed from 'Continue' Button when UnSelect Asset Source.");
			}
		
		}
	
	
		//AssetSources-Retirement-TC-028_Verify presence of 'Remove' 'Continue' 'Select' 'No assets' Options when 'Select' and 'UnSelect' 'Asset Sources-' 'Automobile' 'GIC/Term Deposit''Rental Property''Secondary Property''Other Assets' on 'Assets' Screen
		@Then("^Verify presence of 'Remove' 'Continue' 'Select' 'No assets' Options when 'Select' and 'UnSelect' 'Asset Sources-' 'Automobile' 'GIC/Term Deposit''Rental Property''Secondary Property''Other Assets' on 'Assets' Screen$")
		public void Verify_presence_of_Remove_Continue_Select_No_assets_Options_when_Select_and_UnSelect_Asset_Sources_Automobile_GICTerm_Deposit_Rental_Property_Secondary_Property_Other_Assets_on_Assets_Screen() throws Throwable {

			if (strAutomobileRemove_Btn.getText().contentEquals("Remove")) {
				ExtentReportHelper.StepPass("'" + strAutomobileRemove_Btn.getText() + "' option changed from 'Select' option when select Asset Source.");
			}
			else
			{
				ExtentReportHelper.StepFail("'" + strAutomobileRemove_Btn.getText() + "' option is NOT changed from 'Select' option when select Asset Source.");
			}
				if (strGICTermDepRemove_Btn.getText().contentEquals("Remove")) {
				ExtentReportHelper.StepPass("'" + strGICTermDepRemove_Btn.getText() + "' option changed from 'Select' option when select Asset Source.");
			}
			else
			{
				ExtentReportHelper.StepFail("'" + strGICTermDepRemove_Btn.getText() + "' option is NOT changed from 'Select' option when select Asset Source.");
			}
			if (RentalPropertyRemove_Btn.getText().contentEquals("Remove")) {
				ExtentReportHelper.StepPass("'" + RentalPropertyRemove_Btn.getText() + "' option changed from 'Select' option when select Asset Source.");
			}
			else
			{
				ExtentReportHelper.StepFail("'" + RentalPropertyRemove_Btn.getText() + "' option is NOT changed from 'Select' option when select Asset Source.");
			}
				if (SecondaryPropertyRemove_Btn.getText().contentEquals("Remove")) {
			ExtentReportHelper.StepPass("'" + SecondaryPropertyRemove_Btn.getText() + "' option changed from 'Select' option when select Asset Source.");
			}
			else
			{
				ExtentReportHelper.StepFail("'" + SecondaryPropertyRemove_Btn.getText() + "' option is NOT changed from 'Select' option when select Asset Source.");
			}
			if (OtherAssetsRemove_Btn.getText().contentEquals("Remove")) {
				ExtentReportHelper.StepPass("'" + OtherAssetsRemove_Btn.getText() + "' option changed from 'Select' option when select Asset Source.");
			}
			else
			{
				ExtentReportHelper.StepFail("'" + OtherAssetsRemove_Btn.getText() + "' option is NOT changed from 'Select' option when select Asset Source.");
			}
			Thread.sleep(250);
			if (strContinueAssets_Btn.getText().contentEquals("Continue")) {
				ExtentReportHelper.StepPass("'" + strContinueAssets_Btn.getText() + "' Button changed from 'No assets' Button when select Asset Source.");
			}
			else
			{
				ExtentReportHelper.StepFail("'" + strContinueAssets_Btn.getText() + "' Button is NOT changed from 'No assets' Button when select Asset Source.");
			}
			Thread.sleep(250);
			strAutomobileRemove_Btn.click();
			strGICTermDepRemove_Btn.click();
			RentalPropertyRemove_Btn.click();
			SecondaryPropertyRemove_Btn.click();
			OtherAssetsRemove_Btn.click();
			Thread.sleep(250);

			if (strAutomobileSelect_Btn.getText().contentEquals("Select")) {
				ExtentReportHelper.StepPass("'" + strAutomobileSelect_Btn.getText() + "' option changed from 'Remove' option when UnSelect Asset Source.");
			}
			else
			{
				ExtentReportHelper.StepFail("'" + strAutomobileSelect_Btn.getText() + "' option is NOT changed from 'Remove' option when UnSelect Asset Source.");
			}
			if (strNoAssets_Link.getText().contentEquals("No assets")) {
				ExtentReportHelper.StepPass("'" + strNoAssets_Link.getText() + "' Button changed from 'Continue' Button when UnSelect Asset Source.");
			}
			else
			{
				ExtentReportHelper.StepFail("'" + strNoAssets_Link.getText() + "' Button is NOT changed from 'Continue' Button when UnSelect Asset Source.");
			}

			if (strGICTermDepSelect_Btn.getText().contentEquals("Select")) {
				ExtentReportHelper.StepPass("'" + strGICTermDepSelect_Btn.getText() + "' option changed from 'Remove' option when UnSelect Asset Source.");
			}
			else
			{
				ExtentReportHelper.StepFail("'" + strGICTermDepSelect_Btn.getText() + "' option is NOT changed from 'Remove' option when UnSelect Asset Source.");
			}
			if (strNoAssets_Link.getText().contentEquals("No assets")) {
				ExtentReportHelper.StepPass("'" + strNoAssets_Link.getText() + "' Button changed from 'Continue' Button when UnSelect Asset Source.");
			}
			else
			{
				ExtentReportHelper.StepFail("'" + strNoAssets_Link.getText() + "' Button is NOT changed from 'Continue' Button when UnSelect Asset Source.");
			}
			if (RentalPropertySelect_Btn.getText().contentEquals("Select")) {
				ExtentReportHelper.StepPass("'" + RentalPropertySelect_Btn.getText() + "' option changed from 'Remove' option when UnSelect Asset Source.");
			}
			else
			{
				ExtentReportHelper.StepFail("'" + RentalPropertySelect_Btn.getText() + "' option is NOT changed from 'Remove' option when UnSelect Asset Source.");
			}
			if (strNoAssets_Link.getText().contentEquals("No assets")) {
				ExtentReportHelper.StepPass("'" + strNoAssets_Link.getText() + "' Button changed from 'Continue' Button when UnSelect Asset Source.");
			}
			else
			{
				ExtentReportHelper.StepFail("'" + strNoAssets_Link.getText() + "' Button is NOT changed from 'Continue' Button when UnSelect Asset Source.");
			}

			if (SecondaryPropertySelect_Btn.getText().contentEquals("Select")) {
				ExtentReportHelper.StepPass("'" + SecondaryPropertySelect_Btn.getText() + "' option changed from 'Remove' option when UnSelect Asset Source.");
			}
			else
			{
				ExtentReportHelper.StepFail("'" + SecondaryPropertySelect_Btn.getText() + "' option is NOT changed from 'Remove' option when UnSelect Asset Source.");
			}
			if (strNoAssets_Link.getText().contentEquals("No assets")) {
				ExtentReportHelper.StepPass("'" + strNoAssets_Link.getText() + "' Button changed from 'Continue' Button when UnSelect Asset Source.");
			}
			else
			{
				ExtentReportHelper.StepFail("'" + strNoAssets_Link.getText() + "' Button is NOT changed from 'Continue' Button when UnSelect Asset Source.");
			}
			if (OtherAssetsSelect_Btn.getText().contentEquals("Select")) {
				ExtentReportHelper.StepPass("'" + OtherAssetsSelect_Btn.getText() + "' option changed from 'Remove' option when UnSelect Asset Source.");
			}
			else
			{
				ExtentReportHelper.StepFail("'" + OtherAssetsSelect_Btn.getText() + "' option is NOT changed from 'Remove' option when UnSelect Asset Source.");
			}
			if (strNoAssets_Link.getText().contentEquals("No assets")) {
				ExtentReportHelper.StepPass("'" + strNoAssets_Link.getText() + "' Button changed from 'Continue' Button when UnSelect Asset Source.");
			}
			else
			{
				ExtentReportHelper.StepFail("'" + strNoAssets_Link.getText() + "' Button is NOT changed from 'Continue' Button when UnSelect Asset Source.");
			}
		
		}
}
