package com.scotiabank.ehome.ui.steps.stage4;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.step.QAFTestStepProvider;
import com.qmetry.qaf.automation.ui.WebDriverTestBase;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebDriver;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.quantum.utils.ConfigurationUtils;
import com.scotiabank.ehome.ui.steps.Common;
import com.scotiabank.ehome.ui.steps.ExcelDataToDataTable;
import com.scotiabank.ehome.ui.steps.Utility;
import com.scotiabank.ehome.ui.steps.valueObjects.Tuple;
import com.scotiabank.ehome.ui.steps.valueObjects.TypeOfRateVO;
import com.thoughtworks.qdox.model.expression.Add;

import org.junit.runner.RunWith;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;

import cucumber.api.CucumberOptions;
import cucumber.api.DataTable;
import cucumber.api.PendingException;
import cucumber.api.Transform;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import cucumber.api.junit.Cucumber;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import static com.scotiabank.ehome.ui.steps.BusinessCalculations.*;
import static com.scotiabank.ehome.ui.steps.Utility.*;

import org.openqa.selenium.Keys;
@QAFTestStepProvider
public class EmpAddress {
	public static WebDriverWait wait=Utility.getWait();
	  String testCaseID = Utility.getScenarioID();
  
    @Given("^Customer should login and navigates to Employer address$")
    public void customer_should_login_and_navigates_to_Employer_address() throws Throwable {
    	// Write code here that turns the phrase above into concrete actions
    	Utility.launchURL(ConfigurationUtils.getBaseBundle().getPropertyValue ("env.baseurl2"));
		Common.sessionBreakerContinueButtonClick();
        EmpStatus.employedButtonClicked();
        EmpType.commissionedSalesButtonClicked();
        Thread.sleep(3000);
        String jobField=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage04_Employment_InputData", testCaseID, "Industry_JobTitle_Field_of_work");
        IndustryAndJobTitle.jobField(jobField);
        Thread.sleep(3000);
        String jobTitle=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage04_Employment_InputData", testCaseID, "Industry_JobTitle_Job_Title");
        IndustryAndJobTitle.jobTitle(jobTitle);
        Common.continueButtonClicked();
        String employername=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage04_Employment_InputData", testCaseID, "Employer_Details_employername");
        EmployerDetails.employername(employername);
        String employerphone=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage04_Employment_InputData", testCaseID, "Employer_Details_employerphone");
        EmployerDetails.employerphone(employerphone);
        Common.continueButtonClicked();
		
 	}

     //Employer_address_TC-002

    @When("^Verify \"([^\"]*)\" message should be on the Employer address screen$")
    public void verify_should_be_on_the_Employer_address_screen(String dataPointer) throws Throwable {
		 // Write code here that turns the phrase above into concrete actions
    	Thread.sleep(3000);
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage04_Employment_ExpectedData", testCaseID, dataPointer);
		QAFExtendedWebElement message= new QAFExtendedWebElement("ehome.employeraddress.message");
		Assert.assertEquals(message.getText(), value,"Couldn't found expected message text");
    }

    @Then("^Verify \"([^\"]*)\" header should be on the Employer address screen$")
    public void verify_should_be_on_the_Employer_address_screen1(String dataPointer) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	//TO Check the header text 
    	String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage04_Employment_ExpectedData", testCaseID, dataPointer);
		QAFExtendedWebElement headertext= new QAFExtendedWebElement("ehome.employeraddress.headertext");
    	Assert.assertEquals(headertext.getText(), value,"Couldn't found expected header text");
    }

    //Employer_address_TC-004
    
    @When("^Enter \"([^\"]*)\" invalid address in the Employer address screen$")
    public void enter_invalid_address_in_the_Employer_address_screen(String dataPointer) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
    	String col="InputValues";
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "CommonErrorMessages", dataPointer,col);
		QAFExtendedWebElement addresss = new QAFExtendedWebElement("ehome.employeraddress.address");
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(addresss));
		addresss.clear();
		addresss.sendKeys(value);
	}
    
    @Then("^\"([^\"]*)\" Should be displayed in the Employer address screen$")
    public void should_be_displayed_in_the_Employer_address_screen(String dataPointer) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	Thread.sleep(3000);
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage04_Employment_ExpectedData", testCaseID, dataPointer);
		QAFExtendedWebElement errormessage= new QAFExtendedWebElement("ehome.employeraddress.errormessage");
		Assert.assertEquals(errormessage.getText(), value,"Couldn't found error text");
    }
  
    //Employer_address_TC-005
    public static void employeraddress(String address) throws InterruptedException {
    	Thread.sleep(3000);
    	QAFExtendedWebElement Enteraddress= new QAFExtendedWebElement("ehome.employeraddress.address");
    	Enteraddress.clear();
    	char[] addarr = address.toCharArray();
    	for(char oneAt : addarr) {
    		Enteraddress.sendKeys(oneAt+"");
    		Thread.sleep(2000);
    	}	
    	Thread.sleep(5000);
    	  QAFExtendedWebElement eleAddress = new QAFExtendedWebElement(By.xpath("//*[@id='address-lookup__results-list']"));
          List<WebElement> liLi = eleAddress.findElements(By.tagName("li"));
         wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).ignoring(ArrayIndexOutOfBoundsException.class).until(ExpectedConditions.visibilityOf(liLi.get(1)));
          Thread.sleep(2000);
          liLi.get(1).click();
          Thread.sleep(3000);
          
   	 }
    
    @When("^Enter \"([^\"]*)\" in Employer address screen$")
    public void enter_valid_address_in_Employer_address_screen(String dataPointer) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage04_Employment_InputData", testCaseID, dataPointer);
		employeraddress(value);
          
    }

    
 
    

}
