package com.scotiabank.ehome.ui.steps;

import org.openqa.selenium.support.ui.Select;

import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;

public class RatePresentment {
	private Double purchasePrice;
	private Double downPayment;
	private Integer amortizationYears;
	private Integer amortizationMonth;
	private Integer amortizationPeriod;
	private PaymentScheduleEnum paymentSchedule;
	
	public RatePresentment() { 
		onInit();
	}
	public void onInit() {
		QAFExtendedWebElement Purchasepricevalue= new QAFExtendedWebElement("ehome.ratepresentation.purchaseprice.span");
		String  purchasePriceStr=Purchasepricevalue.getText();
		System.out.println(purchasePriceStr + "Price...");
		this.purchasePrice = Utility.convertCurrencyToDouble.apply(purchasePriceStr);
		System.out.println(this.purchasePrice + "Price Double...");
		
		QAFExtendedWebElement downpaymentvalue= new QAFExtendedWebElement("ehome.ratepresentation.downpayment.span");
		String  downpaymentStr=downpaymentvalue.getText();
		System.out.println(downpaymentStr + "Price...");
		this.downPayment = Utility.convertCurrencyToDouble.apply(downpaymentStr);
		System.out.println(this.downPayment + "DownPayment Double...");
		
		
		QAFExtendedWebElement Amortizationperiod25years= new QAFExtendedWebElement("ehome.ratepresentation.amortizationperiod.25years");
        if(!Amortizationperiod25years.verifyPresent())
            throw new AssertionError("Couldn't find Amortization period 25 years");
        Select selectyears = new Select(Amortizationperiod25years);
        String amortizationYearStr=selectyears.getFirstSelectedOption().getAttribute("value");
        System.out.println(amortizationYearStr + "Years...");
        System.out.println(Utility.getNumberOfYearsFromString(amortizationYearStr) + "Years in Int...");
        amortizationYears=Utility.getNumberOfYearsFromString(amortizationYearStr);
        
        QAFExtendedWebElement Amortizationperiod12months= new QAFExtendedWebElement("ehome.ratepresentation.amortizationperiod.months");
         if(!Amortizationperiod12months.verifyPresent())
            throw new AssertionError("Couldn't find Amortization period 12 months");
         Select selectmonths = new Select(Amortizationperiod12months);
         String Amortizationperiod12monthsStr=selectmonths.getFirstSelectedOption().getAttribute("value");
         System.out.println(Amortizationperiod12monthsStr + "Months...");
         System.out.println(Utility.getNumberOfMonthsFromString(Amortizationperiod12monthsStr) + "Months in Int...");
         amortizationMonth=Utility.getNumberOfMonthsFromString(Amortizationperiod12monthsStr);
        
         amortizationPeriod=(amortizationYears*12)+amortizationMonth;
         System.out.println(amortizationPeriod + "amortizationPeriod....");
         
         QAFExtendedWebElement Paymentschedule= new QAFExtendedWebElement("//*[@id=\"mortgage-schedule\"]");
         if(!Paymentschedule.verifyPresent())
             throw new AssertionError("Couldn't find Paymentschedule");
         Select selectschedule = new Select(Paymentschedule);
         String selectscheduleStr=selectschedule.getFirstSelectedOption().getAttribute("value");
         System.out.println(selectscheduleStr + "schedule...");
         paymentSchedule = PaymentScheduleEnum.getByString(selectscheduleStr);
//         System.out.println(Utility.getNumberOfMonthsFromString(selectscheduleStr) + "schedule in Int...");
//         amortizationMonth=Utility.getNumberOfMonthsFromString(selectscheduleStr);
		
	}
	public Double getPurchasePrice() {
		return purchasePrice;
	}
	public Double getDownPayment() {
		return downPayment;
	}  
	public Integer getAmortizationPeriod() {
		return amortizationPeriod;
	}
	public PaymentScheduleEnum getPaymentSchedule() {
		return paymentSchedule;
	}
	
	
}
