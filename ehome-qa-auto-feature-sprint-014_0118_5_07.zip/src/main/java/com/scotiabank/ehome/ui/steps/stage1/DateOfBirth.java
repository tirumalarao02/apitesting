package com.scotiabank.ehome.ui.steps.stage1;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.step.QAFTestStepProvider;
import com.qmetry.qaf.automation.ui.WebDriverTestBase;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebDriver;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.quantum.utils.ConfigurationUtils;
import com.scotiabank.ehome.ui.steps.Common;
import com.scotiabank.ehome.ui.steps.ExcelDataToDataTable;
import com.scotiabank.ehome.ui.steps.Utility;
import com.scotiabank.ehome.ui.steps.valueObjects.Tuple;
import com.scotiabank.ehome.ui.steps.valueObjects.TypeOfRateVO;
import com.thoughtworks.qdox.model.expression.Add;

import org.junit.runner.RunWith;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;

import cucumber.api.CucumberOptions;
import cucumber.api.DataTable;
import cucumber.api.PendingException;
import cucumber.api.Transform;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import cucumber.api.junit.Cucumber;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import static com.scotiabank.ehome.ui.steps.BusinessCalculations.*;
import static com.scotiabank.ehome.ui.steps.Utility.*;

import org.openqa.selenium.Keys;
@QAFTestStepProvider

public class DateOfBirth {
	public static WebDriverWait wait=Utility.getWait();	
	@Given("^Customer should login and navigates to date of birth screen$")
	public void customer_should_login_and_navigates_to_date_of_birth_screen() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    Utility.launchURL(ConfigurationUtils.getBaseBundle().getPropertyValue ("env.baseurl0"));
		Welcome.viewOurPrivacyAgreementButtonClicked();
		PrivacyAgreement.acceptAndContinuetButtonClicked();
		SOLCustomerQuestion.triageQuestionsButtonClicked();
	    SOLCustomerQuestion.noButtonClicked();
	    LegalName.validlegalname("Mrs", "Delna", "Dr", "Press");
	    Common.continueButtonClicked();
	    MaritalStatus.maritalstatusselect("Married");
	    Common.continueButtonClicked();
	}
	
	
	@When("^Verify \"([^\"]*)\" message should be on the date of birth screen$")
	public void verify_message_should_be_on_the_date_of_birth_screen(String dataPointer) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String testCaseID = Utility.getScenarioID();
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage01_Registration_ExpectedDa", testCaseID, dataPointer);
		QAFExtendedWebElement message= new QAFExtendedWebElement("ehome.DOB.message");
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(message));
		 Assert.assertEquals(message.getText(), value,"Couldn't found expected header message");
	   
	}
	
	@Then("^Verify \"([^\"]*)\" headertext should be on date of birth screen$")
	public void verify_headertext_should_be_on_date_of_birth_screen(String dataPointer) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String testCaseID = Utility.getScenarioID();
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage01_Registration_ExpectedDa", testCaseID, dataPointer);
		QAFExtendedWebElement title= new QAFExtendedWebElement("ehome.DOB.Title");
		 wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(title));
		Assert.assertEquals(title.getText(), value,"Couldn't found expected header message");
	   
	}
	
	public static void dateOfBirth(String day, String month,String year) throws InterruptedException {
		
		QAFExtendedWebElement daybutton= new QAFExtendedWebElement("ehome.DOB.Day");
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(daybutton));
		daybutton.click();
		Thread.sleep(5000);
		Select daySelect = new Select(daybutton);
		daySelect.selectByVisibleText(day);
    	
		QAFExtendedWebElement monthbutton= new QAFExtendedWebElement("ehome.DOB.Month");
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(monthbutton));
		monthbutton.click();
		Thread.sleep(5000);
		Select monthSelect = new Select(monthbutton);
		monthSelect.selectByVisibleText(month);
		
		QAFExtendedWebElement yearbutton= new QAFExtendedWebElement("ehome.DOB.Year");
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(yearbutton));
		yearbutton.click();
		Select yearSelect = new Select(yearbutton);
		yearSelect.selectByVisibleText(year);
		
		 
		 }
	
	
	@When("^Select \"([^\"]*)\" \"([^\"]*)\" and \"([^\"]*)\" from the drop down in date of birth screen$")
	public void select_DOB_from_the_drop_down_in_date_of_birth_screen(String dataPointer1,String dataPointer2,String dataPointer3) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String testCaseID = Utility.getScenarioID();
		String value1=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage01_Registration_ExpectedDa", testCaseID, dataPointer1);
		String value2=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage01_Registration_ExpectedDa", testCaseID, dataPointer2);
		String value3=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage01_Registration_ExpectedDa", testCaseID, dataPointer3);
		dateOfBirth(value1, value2, value3);
		   
	}
	
	
	}
