package com.scotiabank.ehome.ui.steps.stage1;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.step.QAFTestStepProvider;
import com.qmetry.qaf.automation.ui.WebDriverTestBase;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebDriver;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.quantum.utils.ConfigurationUtils;
import com.scotiabank.ehome.ui.steps.Common;
import com.scotiabank.ehome.ui.steps.ExcelDataToDataTable;
import com.scotiabank.ehome.ui.steps.Utility;
import com.scotiabank.ehome.ui.steps.valueObjects.Tuple;
import com.scotiabank.ehome.ui.steps.valueObjects.TypeOfRateVO;
import com.thoughtworks.qdox.model.expression.Add;

import org.junit.runner.RunWith;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;

import cucumber.api.CucumberOptions;
import cucumber.api.DataTable;
import cucumber.api.PendingException;
import cucumber.api.Transform;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import cucumber.api.junit.Cucumber;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import static com.scotiabank.ehome.ui.steps.BusinessCalculations.*;
import static com.scotiabank.ehome.ui.steps.Utility.*;

import org.openqa.selenium.Keys;
@QAFTestStepProvider

public class WhatsYourAddress {
	
	
	
	QAFExtendedWebElement headerTitle= new QAFExtendedWebElement("ehome.whatsYourAddress.headerTitle");
	QAFExtendedWebElement headerText= new QAFExtendedWebElement("ehome.whatsYourAddress.headerText");
	QAFExtendedWebElement streetNumber= new QAFExtendedWebElement("ehome.whatsYourAddress.streetnumber");
	QAFExtendedWebElement streetName= new QAFExtendedWebElement("ehome.whatsYourAddress.streetname");
	QAFExtendedWebElement city= new QAFExtendedWebElement("ehome.whatsYourAddress.city");
	QAFExtendedWebElement unitnumber= new QAFExtendedWebElement("ehome.whatsYourAddress.unitnumber");
	QAFExtendedWebElement province= new QAFExtendedWebElement("ehome.whatsYourAddress.province");
	QAFExtendedWebElement postalCode= new QAFExtendedWebElement("ehome.whatsYourAddress.postalCode");
	QAFExtendedWebElement country= new QAFExtendedWebElement("ehome.whatsYourAddress.country");
	QAFExtendedWebElement countryHidden= new QAFExtendedWebElement("ehome.whatsYourAddress.countryHidden");
	
	QAFExtendedWebElement streetNumberError= new QAFExtendedWebElement("ehome.whatsYourAddress.streetnumberError");
	QAFExtendedWebElement streetNameError= new QAFExtendedWebElement("ehome.whatsYourAddress.streetnameError");
	QAFExtendedWebElement cityError= new QAFExtendedWebElement("ehome.whatsYourAddress.cityError");
	QAFExtendedWebElement provinceError= new QAFExtendedWebElement("ehome.whatsYourAddress.provinceError");
	QAFExtendedWebElement postalCodeError= new QAFExtendedWebElement("ehome.whatsYourAddress.postalCodeError");
	QAFExtendedWebElement BackButton= new QAFExtendedWebElement("ehome.whatsYourAddress.BackButton");
	QAFExtendedWebElement DOBtitle= new QAFExtendedWebElement("ehome.DateOfBirth.headertitle");
	QAFExtendedWebElement whatsyouremailaddresstitle= new QAFExtendedWebElement("ehome.whatsyouremailaddress.headertitle");
	
	
	public static WebDriverWait wait=Utility.getWait();	
	@Given("^Customer should login and navigates to address screen$")
	public void customer_should_login_and_navigates_to_address_screen() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    Utility.launchURL(ConfigurationUtils.getBaseBundle().getPropertyValue ("env.baseurl0"));
		Welcome.viewOurPrivacyAgreementButtonClicked();
		PrivacyAgreement.acceptAndContinuetButtonClicked();
		SOLCustomerQuestion.triageQuestionsButtonClicked();
	    SOLCustomerQuestion.noButtonClicked();
	    LegalName.validlegalname("Mrs", "Delna", "Dr", "Press");
	    Common.continueButtonClicked();
	    MaritalStatus.maritalstatusselect("Married");
	    Common.continueButtonClicked();
	    DateOfBirth.dateOfBirth("1","Jan", "2000");
	    Common.continueButtonClicked();
	}
	
	@Then("^Verify \"([^\"]*)\" message should be on address screen$")
	public void verify_message_should_be_on_address_screen(String dataPointer) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String testCaseID = Utility.getScenarioID();
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage01_Registration_ExpectedDa", testCaseID, dataPointer);
		 wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(headerTitle));
		 Assert.assertEquals(headerTitle.getText(), value,"Couldn't found expected header message");
	}
	
	@Then("^Verify \"([^\"]*)\" headertext should be on address screen$")
	public void verify_headertext_should_be_on_address_screen(String dataPointer) throws Throwable {
		   // Write code here that turns the phrase above into concrete actions
				String testCaseID = Utility.getScenarioID();
				String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage01_Registration_ExpectedDa", testCaseID, dataPointer);
				wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(headerText));
				Assert.assertEquals(headerText.getText(), value,"Couldn't found expected header text message");
	   
	}
	
	@Then("^'Street number' field should be mandatory, 'Street name' field should be mandatory, 'City' field should be mandatory, 'Province' field should be mandatory, 'PostalCode' field should be mandatory, 'Country' field should be mandatory on address screen\"$")
	public void streetNumberFieldShouldBeMandatoryStreetNameFieldShouldBeMandatoryCityFieldShouldBeMandatoryProvinceFieldShouldBeMandatoryPostalCodeFieldShouldBeMandatoryCountryFieldShouldBeMandatoryonaddressscreen() throws Throwable {	    // Write code here that turns the phrase above into concrete actions
		streetNumber.sendKeys(Keys.TAB);
		Thread.sleep(1000);
		Assert.assertEquals(streetNumberError.getText(), "Please enter a valid street number","'Street number field' should be mandatory");
		
		streetName.sendKeys(Keys.TAB);
		Thread.sleep(10000);
		Assert.assertEquals(streetNameError.getText(), "Please enter a valid street name","'Street name field' should be mandatory");
		
		city.sendKeys(Keys.TAB);
		Thread.sleep(1000);
		Assert.assertEquals(cityError.getText(), "Please enter a valid city","'City' should be mandatory");
		
		province.sendKeys(Keys.TAB);
		Thread.sleep(1000);
		Assert.assertEquals(provinceError.getText(), "Please select a province","'Province' should be mandatory");
		
		postalCode.sendKeys(Keys.TAB);
		Thread.sleep(1000);
		Assert.assertEquals(postalCodeError.getText(), "Please enter a valid postal code","'Postal Code' should be mandatory");
	}
	
	@When("^entering \"([^\"]*)\" in the Street number field on address screen$")
	public void entering_text_in_the_Street_number_field_on_address_screen(String dataPointer) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String testCaseID = Utility.getScenarioID();
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage01_Registration_InputData", testCaseID, dataPointer);
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(streetNumber));
		streetNumber.sendKeys(value);
	}
	
	@Then("^the 'street number' field should accept (\\d+) to (\\d+) characters on address screen$")
	public void the_street_number_field_should_accept_to_characters_on_address_screen(int arg1, int arg2) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		if (!((streetNumber.getAttribute("value").length()>0) && (streetNumber.getAttribute("value").length()<12))) {
			Thread.sleep(2000);
			throw new AssertionError("Street Number field should accept upto 11 characters");
		}
	}
	
	@When("^entering \"([^\"]*)\" in the Street name field on address screen$")
	public void entering_text_in_the_Street_name_field_on_address_screen(String dataPointer) throws Throwable {
		String testCaseID = Utility.getScenarioID();
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage01_Registration_InputData", testCaseID, dataPointer);
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(streetName));
		streetName.sendKeys(value);
	}
	
	@Then("^the 'street name' field should accept (\\d+) to (\\d+) characters on address screen$")
	public void the_street_name_field_should_accept_to_characters_on_address_screen(int arg1, int arg2) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		if (!((streetName.getAttribute("value").length()>0) && (streetName.getAttribute("value").length()<28))) {
			 throw new AssertionError("Street Name field should accept upto 27 characters");
		}
	}
	
	@When("^entering \"([^\"]*)\" in the unit number field on address screen$")
	public void entering_text_in_the_unit_number_field_on_address_screen(String dataPointer) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String testCaseID = Utility.getScenarioID();
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage01_Registration_InputData", testCaseID, dataPointer);
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(unitnumber));
		unitnumber.sendKeys(value);
	}
	
	@Then("^the 'unit number' field should accept (\\d+) to (\\d+) characters on address screen$")
	public void the_unit_number_field_should_accept_to_characters_on_address_screen(int arg1, int arg2) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		if (!((unitnumber.getAttribute("value").length()>0) && (unitnumber.getAttribute("value").length()<7))) {
			 throw new AssertionError("Unit Number field should accept upto 6 characters");
		}
	}
	
	@When("^entering \"([^\"]*)\" in the city field on address screen$")
	public void entering_text_in_the_city_field_on_address_screen(String dataPointer) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String testCaseID = Utility.getScenarioID();
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage01_Registration_InputData", testCaseID, dataPointer);
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(city));
		city.sendKeys(value);
	}
	
	@Then("^the 'city' field should accept (\\d+) to (\\d+) characters on address screen$")
	public void the_city_field_should_accept_to_characters_on_address_screen(int arg1, int arg2) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		if (!((city.getAttribute("value").length()>0) && (city.getAttribute("value").length()<20))) {
			 throw new AssertionError("City field should accept upto 19 characters");
		}
	}
	
	@Then("^the 'Country' field should default to Canada and non-editable on address screen$")
	public void the_Country_field_should_default_to_Canada_and_non_editable_on_address_screen() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(country));
		if (!(country.getText().equals("Canada"))) {
			 throw new AssertionError("Country is not defaulted to Canada");
		}
		if (!(countryHidden.getAttribute("hidden").equals("true"))) {
			 throw new AssertionError("Country value is disabled");
		}
	}
	
	@When("^entering \"([^\"]*)\" in the Postal Code field on address screen$")
	public void entering_text_in_the_Postal_Code_field_on_address_screen(String dataPointer) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String testCaseID = Utility.getScenarioID();
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage01_Registration_InputData", testCaseID, dataPointer);
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(postalCode));
		postalCode.sendKeys(value);
	}
	
	@Then("^the 'Postal Code' field should accept (\\d+) to (\\d+) characters on address screen$")
	public void the_Postal_Code_field_should_accept_to_characters_on_address_screen(int arg1, int arg2) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		if (!((postalCode.getAttribute("value").length()>0) && (postalCode.getAttribute("value").length()<11))) {
			 throw new AssertionError("Postal Code should accept upto 10 characters");
		}
	}
	
	@When("^Back button is clicked on address screen$")
	public void back_button_is_clicked_on_address_screen() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Common.backButtonClicked();
	}
	
	@Then("^'Date of Birth' screen should be displayed$")
	public void Date_of_Birth_screen_should_be_displayed() throws Throwable {
		if(!DOBtitle.isPresent())
			throw new AssertionError("Not navigated to Date Of Birth screen");
	}

	public static void ValidWhatsYourAddressValues(String streetNumberVal, String streetNameVal, String cityVal, String provinceVal,String postalCodeVal) throws InterruptedException {
		
		QAFExtendedWebElement streetNumber= new QAFExtendedWebElement("ehome.whatsYourAddress.streetnumber");
		QAFExtendedWebElement streetName= new QAFExtendedWebElement("ehome.whatsYourAddress.streetname");
		QAFExtendedWebElement city= new QAFExtendedWebElement("ehome.whatsYourAddress.city");
		QAFExtendedWebElement province= new QAFExtendedWebElement("ehome.whatsYourAddress.province");
		QAFExtendedWebElement postalCode= new QAFExtendedWebElement("ehome.whatsYourAddress.postalCode");
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(streetNumber));
		streetNumber.sendKeys(streetNumberVal);
		streetName.sendKeys(streetNameVal);
		city.sendKeys(cityVal);
		province.sendKeys(provinceVal);
		postalCode.sendKeys(postalCodeVal);		 
	}
	
	@When("^Continue button is clicked on address screen$")
	public void Continue_button_is_clicked_on_address_screen() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		QAFExtendedWebElement message= new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[1]/section/div/div[1]/h2");
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(message));
		String streetNumberVal="2201";
		String streetNameVal="EGLINTON AVE";
		String cityVal="TORONTO";
		String provinceVal="ONTARIO";
		String postalCodeVal="M1K2M1";
		Thread.sleep(2000);
		streetNumber.clear();
		streetName.clear();
		city.clear();
		postalCode.clear();	
		ValidWhatsYourAddressValues(streetNumberVal,streetNameVal,cityVal,provinceVal,postalCodeVal);
		Thread.sleep(2000);
		Common.continueButtonClicked();

	}
	
	@Then("^'Whats your email address?' screen should be displayed$")
	public void Whats_your_email_address_screen_should_be_displayed() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Assert.assertEquals(whatsyouremailaddresstitle.getText(), "What's your email address?", "Couldn't find the Whats your email address");
	}
}
