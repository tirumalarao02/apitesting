package com.scotiabank.ehome.ui.steps;

public enum PaymentScheduleEnum {
	MONTHLY(1),
	WEEKLY(4),
	BIWEEKLY(2),
	SEMIMONTHLY(2);
	private int numberOfMonthlyPayments;
	public int getNumberOfMonthlyPayments() {
		return numberOfMonthlyPayments;
	}
	PaymentScheduleEnum(int numberOfMonthlyPayments) {
		this.numberOfMonthlyPayments = numberOfMonthlyPayments;
	}
	public static PaymentScheduleEnum getByString(String value) {
		if(value.toUpperCase().equals("MONTHLY"))			
			return PaymentScheduleEnum.MONTHLY;
		else if(value.toUpperCase().equals("BI-WEEKLY"))
			return PaymentScheduleEnum.BIWEEKLY;
		else if(value.toUpperCase().equals("WEEKLY"))			
			return PaymentScheduleEnum.WEEKLY;
		else if(value.toUpperCase().equals("SEMIMONTHLY"))			
			return PaymentScheduleEnum.SEMIMONTHLY;
		else
			return null;
	}
}
