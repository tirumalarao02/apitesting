package com.scotiabank.ehome.ui.steps.stage5;
import com.qmetry.qaf.automation.step.QAFTestStepProvider;
import com.qmetry.qaf.automation.ui.WebDriverTestBase;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.quantum.java.pages.ExtentReportHelper;
import com.quantum.utils.ConfigurationUtils;
import com.scotiabank.ehome.ui.steps.Common;
import com.scotiabank.ehome.ui.steps.CommonAppMethodsAssetLiabilities;
import com.scotiabank.ehome.ui.steps.CommonAppMethodsEmployment;
import com.scotiabank.ehome.ui.steps.CommonApplicationMethods;
import com.scotiabank.ehome.ui.steps.Utility;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;

import java.util.Map;
import java.util.concurrent.TimeUnit;
import static com.scotiabank.ehome.ui.steps.Utility.*;

@QAFTestStepProvider

public class AssetSectionBreaker {
	
	  public static WebDriverWait wait=Utility.getWait();
	  static String curDir = System.getProperty("user.dir");
	  static String strfullPathToFile = curDir + "\\src\\main\\resources\\data\\eHomeTestData.xlsx"; // File Path
		
	  static String sheetStage05_InputData ="Stage05_AssetLiabilty_InputData";
	  static String sheetStage05_ExpectedData ="Stage05_AsetLiblty_ExpectedData";
	  
	  //String strtestCaseID = "Asset-Section-Brkr-TC-004";
	  String strtestCaseID = Utility.getScenarioID();

	QAFExtendedWebElement strAssetSectionBrkr_ActualTitle= new QAFExtendedWebElement("ehome.assetSectionBrkr.Title");
	QAFExtendedWebElement strAssetSectionBrkr_ActualContent= new QAFExtendedWebElement("ehome.assetSectionBrkr.Content");
	QAFExtendedWebElement strAssetSectionBrkr_ContinueBtn= new QAFExtendedWebElement("ehome.assetSectionBrkr.Continue");
	QAFExtendedWebElement AssetSectionBrkr_BacktoeHomeHUBBtn= new QAFExtendedWebElement("ehome.assetSectionBrkr.BacktoeHomeHUBBtn");
	QAFExtendedWebElement SrcOfIncome_ContinueBtn= new QAFExtendedWebElement("ehome.assetSectionBrkr.SrcOfIncomeCotninueBtn");

	  @Given ("^Customer should navigate to 'Sources of Income' screen$")
		public void Customer_should_navigate_to_Sources_of_Income_Screen() throws Throwable {
		  
		  Map<String, String> Stage05_InputData =  Utility.readTestData(strfullPathToFile, sheetStage05_InputData,strtestCaseID);
		  
		  	String strCurrentEmpStatus	= Stage05_InputData.get("Empmt_Status");
			String strDurationYear=  Stage05_InputData.get("Years");
			String strDurationMonth=  Stage05_InputData.get("Months");

			Utility.launchURL(ConfigurationUtils.getBaseBundle().getPropertyValue ("env.baseurl2"));
			Common.sessionBreakerContinueButtonClick();
			CommonAppMethodsEmployment.SelectEmpStatus(strCurrentEmpStatus);
			Thread.sleep(1000);
				
			if (strDurationYear != "") {
				CommonApplicationMethods.selectValuefromDropDownListBox("ehome.employmentDuration.years", strDurationYear);
		 			Thread.sleep(250);
			}
			if (strDurationMonth != "") {
				CommonApplicationMethods.selectValuefromDropDownListBox("ehome.employmentDuration.months", strDurationMonth);
				Thread.sleep(250);
			}
			Common.continueButtonClicked();
			Thread.sleep(500);
			}
	  
		  
		@When("^Select 'No Source of income' or 'Any source of income' on 'Sources of Income' Screen$")
		public void Select_No_Source_of_income_or_Any_source_of_income_on_Sources_of_Income_Screen() throws Throwable {
			  Map<String, String> Stage05_InputData =  Utility.readTestData(strfullPathToFile, sheetStage05_InputData,strtestCaseID);
			  
			 	String strInvestment_ExpectedInput	= Stage05_InputData.get("EmpOtherSrcsOfIncome_Investments");
				String strInvestmentAmt_ExpectedInput	= Stage05_InputData.get("EmpOtherSrcsOfIncome_Investments_Amt");
				String strNoSrcOfIncomeInput	= Stage05_InputData.get("EmpOtherSrcsOfIncome_NoSrcsOfIncome");
					
				if (strInvestment_ExpectedInput != "" ){
					CommonAppMethodsEmployment.SelectRetiredSourcesOfIncome(strInvestment_ExpectedInput);
					SrcOfIncome_ContinueBtn.click();
					CommonAppMethodsEmployment.EnterRetiredAnualIncomeSourceAmount(strInvestment_ExpectedInput, strInvestmentAmt_ExpectedInput);
					SrcOfIncome_ContinueBtn.click();
						}
				
				if (strNoSrcOfIncomeInput != "" ){
					CommonAppMethodsEmployment.SelectRetiredSourcesOfIncome(strNoSrcOfIncomeInput);
						}
				
	 		}
	  
		
	@Then("^Verify 'Asset Section Breaker' Screen and presence of all objects on 'Asset Section Breaker' Screen$")
	public void Verify_Asset_Section_Breaker_Screen_and_presence_of_all_objects_on_Asset_Section_Breaker_Screen() throws Throwable {
		Map<String, String> Stage05_ExpectedData =  Utility.readTestData(strfullPathToFile, sheetStage05_ExpectedData,strtestCaseID);
		 	String strAsset_Section_Breaker_ExpectedTitle	= Stage05_ExpectedData.get("Asset_Section_Breaker_Title");
			String strAsset_Section_Breaker_ExpectedContent	= Stage05_ExpectedData.get("Asset_Section_Breaker_Content");
	
			if (strAsset_Section_Breaker_ExpectedTitle.contentEquals(strAssetSectionBrkr_ActualTitle.getText())) {
    			ExtentReportHelper.StepPass(strAsset_Section_Breaker_ExpectedTitle + " Screen# is displayed.");
    		}
    		else
    		{
    			Assert.assertEquals(strAssetSectionBrkr_ActualTitle.getText(), strAsset_Section_Breaker_ExpectedTitle,"'Asset Section Breaker' content is NOT as Expected.");
    		}	
			
			if (strAsset_Section_Breaker_ExpectedContent.contentEquals(strAssetSectionBrkr_ActualContent.getText())) {
    			ExtentReportHelper.StepPass(strAsset_Section_Breaker_ExpectedContent + " Screen# is displayed.");
    		}
    		else
    		{
    			Assert.assertEquals(strAssetSectionBrkr_ActualContent.getText(), strAsset_Section_Breaker_ExpectedContent,"'Asset Section Breaker' content is NOT as Expected.");
    		}	

    		if(strAssetSectionBrkr_ContinueBtn.isPresent())
			{
				ExtentReportHelper.StepPass("'" + strAssetSectionBrkr_ContinueBtn.getText() + "' button is displayed.");
			}
			else
			{
				ExtentReportHelper.StepFail("'" + strAssetSectionBrkr_ContinueBtn.getText() + "' button is NOT displayed.");
			}
    		if(AssetSectionBrkr_BacktoeHomeHUBBtn.isPresent())
			{
				ExtentReportHelper.StepPass("'" + AssetSectionBrkr_BacktoeHomeHUBBtn.getText() + "' option button is displayed.");
			}
			else
			{
				ExtentReportHelper.StepFail("'" + AssetSectionBrkr_BacktoeHomeHUBBtn.getText() + "' option button is NOT displayed.");
			}
    		
 		}
	
	
	@Then("^Verify 'Hub PostOnboarding' Screen when Click on 'Back to eHome Hub' button on Asset Section Breaker$")
	public void Verify_Hub_Post_Onboarding_Screen_when_Click_on_Back_to_eHome_Hub_button_on_Asset_Section_when_selects_No_Source_Of_Income() throws Throwable {
		Map<String, String> Stage05_ExpectedData =  Utility.readTestData(strfullPathToFile, sheetStage05_ExpectedData,strtestCaseID);
			String strHub_PostOnboarding_ExpectedTitle	= Stage05_ExpectedData.get("HubPostOnboard_HowYourMortJrny_Title");
			QAFExtendedWebElement strHub_PostOnboarding_ActualTitle= new QAFExtendedWebElement("//p[@class='sidebar-header__title outline-none container-lines--bottom']");
				
			AssetSectionBrkr_BacktoeHomeHUBBtn.click();
    		if (strHub_PostOnboarding_ExpectedTitle.contentEquals(strHub_PostOnboarding_ActualTitle.getText())) {
    			ExtentReportHelper.StepPass(strHub_PostOnboarding_ExpectedTitle + " Screen# is displayed.");
    		}
    		else
    		{
    			Assert.assertEquals(strHub_PostOnboarding_ActualTitle.getText(), strHub_PostOnboarding_ExpectedTitle,"'Hub Post Onboard sreen is NOT as Expected.");
    		}	
    		
 		}
	
	
	@Then("^Verify 'Asset Sources' Screen when Click on 'Continue' button on Asset Section Breaker$")
	public void Verify_Asset_Sources_Screen_when_Click_on_Continue_button_on_Asset_Section_Breaker() throws Throwable {
		Map<String, String> Stage05_ExpectedData =  Utility.readTestData(strfullPathToFile, sheetStage05_ExpectedData,strtestCaseID);
			String strAssets_ExpectedTitle	= Stage05_ExpectedData.get("Assets_FollowingAssets_Label"); 
			strAssetSectionBrkr_ContinueBtn.click();
			QAFExtendedWebElement strAssetSources_ActualTitle= new QAFExtendedWebElement("ehome.AssetSources.Title");
			
	 		if (strAssets_ExpectedTitle.contentEquals(strAssetSources_ActualTitle.getText())) {
    			ExtentReportHelper.StepPass(strAssets_ExpectedTitle + " Screen# is displayed.");
    		}
    		else
    		{
    			Assert.assertEquals(strAssetSources_ActualTitle.getText(), strAssets_ExpectedTitle,"'Asset sreen is NOT as Expected.");
    		}	
 		}
	
	}

