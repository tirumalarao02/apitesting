package com.quantum.steps;
import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import org.junit.runner.RunWith;

@RunWith(Cucumber.class)
@CucumberOptions(
		//features = "src/main/resources/scenarios/scotiabank.feature",
		//features = {"src/main/resources/scenarios/scotiabank.feature", "src/main/resources/scenarios/scotiaHomeLogin.feature"},
		//features = {"src/main/resources/scenarios/scotiaHomeLogin.feature"},
		features = {"src/main/resources/scenarios/ui/debug.feature"},
		//glue= {"src/main/java/com/quantum/steps"},
		glue= {"src/main/java/com/scotiabank/ehome/ui/steps"},
		dryRun= true,
		//tags={"@regression"},
        plugin = {"json:cucumber.json"})

public class runTest {
}
