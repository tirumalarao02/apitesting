package com.scotiabank.ehome.ui.steps.coApp;
import com.qmetry.qaf.automation.step.QAFTestStepProvider;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.quantum.utils.ConfigurationUtils;
import com.scotiabank.ehome.ui.steps.Common;
import com.scotiabank.ehome.ui.steps.Utility;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.support.ui.WebDriverWait;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import java.util.concurrent.TimeUnit;
import static com.scotiabank.ehome.ui.steps.Utility.*;

@QAFTestStepProvider

public class CoAppEmployerDetails {
	public static WebDriverWait wait=Utility.getWait();	
	  String testCaseID = Utility.getScenarioID();
	  @Given("^Customer should login and navigates to CoApp Employer Details screen$")
	  public void customer_should_login_and_navigates_to_CoApp_Employer_Details_screen() throws Throwable {
	      // Write code here that turns the phrase above into concrete actions
//			 String strtestCaseID = Utility.getScenarioID();
//		  if (strtestCaseID.contains("CoApp"))
//		  {
//			  Common.TraverseToNewHomeSectionBreaker();
//			  Thread.sleep(10000);
//			  Common.TraverseFromNewHomeToRateSectionBreaker(strtestCaseID,"Co-App_InputData");
//			  Common.TraverseRateSectionToEmploymentSectionBreaker();
//			  Common.TraverseFromEmploymentSectionToLandOnCoApplicantPage();
//			  CoAppIntro.startSectionButtonClicked();
//		  }
		  Utility.launchURL(ConfigurationUtils.getBaseBundle().getPropertyValue ("env.baseurl3"));
			CoAppIntro.startSectionButtonClicked();
			CoAppEmpStatus.employedButtonClicked();
			CoAppEmpType.commissionedSalesButtonClicked();
			  Thread.sleep(3000);
			String jobField=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Co-App_ExpectedData", testCaseID, "Industry_JobTitle_Field_of_work");
			 CoAppIndustryJobTitle.jobField(jobField);
			  Thread.sleep(3000);
			String jobTitle=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Co-App_ExpectedData", testCaseID, "Industry_JobTitle_Job_Title");
			 CoAppIndustryJobTitle.jobTitle(jobTitle);
			  Thread.sleep(3000);
			String occupationType=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Co-App_ExpectedData", testCaseID, "Industry_JobTitle_Occupation_Type");
			 CoAppIndustryJobTitle.occupationType(occupationType);
			  Thread.sleep(3000);
			Common.continueButtonClicked();
	  }

	  
	  @When("^Verify \"([^\"]*)\" should be on the CoApp Employer Details screen$")
	  public void verify_should_be_on_the_CoApp_Employer_Details_screen(String dataPointer) throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
		  String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Co-App_ExpectedData", testCaseID, dataPointer);
			QAFExtendedWebElement headerMessage= new QAFExtendedWebElement("ehome.CoAppEmpType.HeaderMessage");
			 wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(headerMessage));
			 Assert.assertEquals(headerMessage.getText(), value,"Couldn't found expected header text");
	
		   
		}


	  @Then("^Verify \"([^\"]*)\" headertext should be on the CoApp Employer Details screen$")
	  public void verify_headertext_should_be_on_the_CoApp_Employer_Details_screen(String dataPointer) throws Throwable {
		   // Write code here that turns the phrase above into concrete actions
		  String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Co-App_ExpectedData", testCaseID, dataPointer);
		  Assert.assertEquals(Common.headertext(), value,"Couldn't found expected header text");
			
	  }

	  @When("^Enter the \"([^\"]*)\" invalid Employer name in the CoApp Employer Details screen$")
	  public void enter_the_invalid_Employer_name_in_the_CoApp_Employer_Details_screen(String dataPointer) throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
			String col="InputValues";
			String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "CommonErrorMessages", dataPointer,col);
			QAFExtendedWebElement employerName= new QAFExtendedWebElement("ehome.employerDetails.employerName");
			wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(employerName));
			employerName.clear();
			employerName.sendKeys(value);
	     
	  }
	  

	  @Then("^\"([^\"]*)\" should be displayed for name in the CoApp Employer Details screen$")
	  public void should_be_displayed_for_name_in_the_CoApp_Employer_Details_screen(String arg1) throws Throwable {
	      // Write code here that turns the phrase above into concrete actions
		// CoApp Error messages are not displayed on the screen code will be written onces the error messages are displayed
	     
	  }
	  @Then("^Green with a check mark should be displayed in the name of CoApp Employer Details screen$")
	  public void green_with_a_check_mark_should_be_displayed_in_the_name_of_CoApp_Employer_Details_screen() throws Throwable {
	      // Write code here that turns the phrase above into concrete actions
		  QAFExtendedWebElement greenicon= new QAFExtendedWebElement("ehome.employerDetails.greenicon.phone");
			if(!greenicon.isPresent()) {
				Assert.fail("Couldn't see the green check mark");	}
	
	  }
	  
	  @When("^Enter the \"([^\"]*)\" invalid Employer phone in the CoApp Employer Details screen$")
	  public void enter_the_invalid_Employer_phone_in_the_CoApp_Employer_Details_screen(String dataPointer) throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
		  String col="InputValues";
			String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "CommonErrorMessages", dataPointer,col);
			QAFExtendedWebElement employerphone= new QAFExtendedWebElement("ehome.employerDetails.employerPhone");
			wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(employerphone));
			employerphone.clear();
			employerphone.sendKeys(value);
	     
	  } 
	  @Then("^\"([^\"]*)\" should be displayed for phone in the CoApp Employer Details screen$")
	  public void should_be_displayed_for_phone_in_the_CoApp_Employer_Details_screen(String arg1) throws Throwable {
	      // Write code here that turns the phrase above into concrete actions
	     
	  }

	  @Then("^Green with a check mark should be displayed in the phone of CoApp Employer Details screen$")
	  public void green_with_a_check_mark_should_be_displayed_in_the_phone_of_CoApp_Employer_Details_screen() throws Throwable {
	      // Write code here that turns the phrase above into concrete actions
		  QAFExtendedWebElement greenicon= new QAFExtendedWebElement("ehome.employerDetails.greenicon.phone");
			if(!greenicon.isPresent()) {
				Assert.fail("Couldn't see the green check mark");	  }
	  }
	  
	  public static void employername(String name) {
			QAFExtendedWebElement employmentName= new QAFExtendedWebElement("ehome.employerDetails.employerName");
			wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(employmentName));
			
			employmentName.clear();
			employmentName.sendKeys(name);
		 }
	  @When("^Enter the \"([^\"]*)\" in employer name in the CoApp Employer Details screen$")
	  public void enter_the_in_employer_name_in_the_CoApp_Employer_Details_screen(String dataPointer) throws Throwable {
	      // Write code here that turns the phrase above into concrete actions
		  String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Co-App_InputData", testCaseID, dataPointer);
			employername(value);
			 Thread.sleep(3000);
	     
	  }
	  public static void employerphone(String phone) {
			QAFExtendedWebElement employmentPhone= new QAFExtendedWebElement("ehome.employerDetails.employerPhone");
			wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(employmentPhone));
			employmentPhone.clear();
			employmentPhone.sendKeys(phone);
		 }
	  @When("^Enter the \"([^\"]*)\" in employer phone in the CoApp Employer Details screen$")
	  public void enter_the_in_employer_phone_in_the_CoApp_Employer_Details_screen(String dataPointer) throws Throwable {
	      // Write code here that turns the phrase above into concrete actions
		  String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Co-App_InputData", testCaseID, dataPointer);
			employerphone(value);   
			 Thread.sleep(3000); 
	  }

}
