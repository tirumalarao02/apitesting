package com.scotiabank.ehome.ui.steps.hub;

import static com.scotiabank.ehome.ui.steps.Utility.getScreenDataset;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.qmetry.qaf.automation.step.QAFTestStepProvider;
import com.qmetry.qaf.automation.ui.WebDriverTestBase;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebDriver;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.quantum.utils.ConfigurationUtils;
import com.scotiabank.ehome.ui.steps.Common;
import com.scotiabank.ehome.ui.steps.Utility;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.openqa.selenium.support.ui.Select;

@QAFTestStepProvider
public class HubPreIngestion {

	private static QAFExtendedWebDriver webDriver = Utility.getDriver();
    public Actions action = null;
    public static WebDriverWait wait=Utility.getWait();	
    String ColoPickerStr;
    private Map<String,Map<String,Boolean>> HubPreIngestion_ExpectedData = getScreenDataset(Utility.getExcelFilePath("eHomeTestData.xlsx"), "HubPreIngestion_ExpectedData");
    //private Map<String,Map<String,Boolean>> emailAddressDataset = getScreenDataset(Utility.getExcelFilePath("eHomeTestDatastage-4.xlsx"), "IndustryAndJobTitle");
    QAFExtendedWebElement sidebar= new QAFExtendedWebElement("ehome.hubPreIngestion.sidebar");
	QAFExtendedWebElement ScotiaBankLogo = new QAFExtendedWebElement("ehome.hubPreIngestion.ScotiaBankLogo");
    QAFExtendedWebElement EditPersonalDetails= new QAFExtendedWebElement("ehome.hubPreIngestion.EditPersonalDetails");
    QAFExtendedWebElement SidebarNotifications= new QAFExtendedWebElement("ehome.hubPreIngestion.sidebarNotifications");    
    QAFExtendedWebElement FAQ= new QAFExtendedWebElement("ehome.hubPreIngestion.FAQ");
    QAFExtendedWebElement MortgageSummary= new QAFExtendedWebElement("ehome.hubPreIngestion.MortgageSummary");
    QAFExtendedWebElement MortgageSupport= new QAFExtendedWebElement("ehome.hubPreIngestion.MortgageSupport");
    QAFExtendedWebElement Logout= new QAFExtendedWebElement("ehome.hubPreIngestion.Logout");  
    QAFExtendedWebElement LetsGetStarted= new QAFExtendedWebElement("ehome.hubPreIngestion.LetsGetStarted");
    QAFExtendedWebElement FirstUp= new QAFExtendedWebElement("ehome.hubPreIngestion.FirstUp");
    QAFExtendedWebElement ApplicationSetUp= new QAFExtendedWebElement("ehome.hubPreIngestion.ApplicationSetUp");
    QAFExtendedWebElement YouRegisteredForeHOME= new QAFExtendedWebElement("ehome.hubPreIngestion.YouRegisteredForeHOME");
    QAFExtendedWebElement YouConfirmedYourPersonalDetails= new QAFExtendedWebElement("ehome.hubPreIngestion.YouConfirmedYourPersonalDetails");
    QAFExtendedWebElement DateItem= new QAFExtendedWebElement("ehome.hubPreIngestion.Date");
    QAFExtendedWebElement FirstImage= new QAFExtendedWebElement("ehome.hubPreIngestion.1Image");
    QAFExtendedWebElement StartYourApplication= new QAFExtendedWebElement("ehome.hubPreIngestion.StartYourApplication");
    QAFExtendedWebElement SavecontinueBtn= new QAFExtendedWebElement("ehome.hubPreIngestion.SavecontinueBtn");
    QAFExtendedWebElement SaveButton= new QAFExtendedWebElement("ehome.hubPreIngestion.SaveButton");
    
    QAFExtendedWebElement StageCard0Header= new QAFExtendedWebElement("ehome.hubPreIngestion.StageCard0Header");
    QAFExtendedWebElement StageCard0Mins= new QAFExtendedWebElement("ehome.hubPreIngestion.StageCard0Mins");
    QAFExtendedWebElement StageCard0Title= new QAFExtendedWebElement("ehome.hubPreIngestion.StageCard0Title");
    QAFExtendedWebElement StageCard0WhattoExpect= new QAFExtendedWebElement("ehome.hubPreIngestion.StageCard0WhattoExpect");
    QAFExtendedWebElement StageCard0FlipHeader= new QAFExtendedWebElement("ehome.hubPreIngestion.StageCard0FlipHeader");
    QAFExtendedWebElement StageCard0FlipText= new QAFExtendedWebElement("ehome.hubPreIngestion.StageCard0FlipText");
    
    QAFExtendedWebElement StageCard1Header= new QAFExtendedWebElement("ehome.hubPreIngestion.StageCard1Header");
    QAFExtendedWebElement StageCard1Mins= new QAFExtendedWebElement("ehome.hubPreIngestion.StageCard1Mins");
    QAFExtendedWebElement StageCard1Title= new QAFExtendedWebElement("ehome.hubPreIngestion.StageCard1Title");
    QAFExtendedWebElement StageCard1WhattoExpect= new QAFExtendedWebElement("ehome.hubPreIngestion.StageCard1WhattoExpect");
    QAFExtendedWebElement StageCard1FlipHeader= new QAFExtendedWebElement("ehome.hubPreIngestion.StageCard1FlipHeader");
    QAFExtendedWebElement StageCard1FlipText= new QAFExtendedWebElement("ehome.hubPreIngestion.StageCard1FlipText");
    
    QAFExtendedWebElement StageCard2Header= new QAFExtendedWebElement("ehome.hubPreIngestion.StageCard2Header");
    QAFExtendedWebElement StageCard2Mins= new QAFExtendedWebElement("ehome.hubPreIngestion.StageCard2Mins");
    QAFExtendedWebElement StageCard2Title= new QAFExtendedWebElement("ehome.hubPreIngestion.StageCard2Title");
    QAFExtendedWebElement StageCard2WhattoExpect= new QAFExtendedWebElement("ehome.hubPreIngestion.StageCard2WhattoExpect");
    QAFExtendedWebElement StageCard2FlipHeader= new QAFExtendedWebElement("ehome.hubPreIngestion.StageCard2FlipHeader");
    QAFExtendedWebElement StageCard2FlipText= new QAFExtendedWebElement("ehome.hubPreIngestion.StageCard2FlipText");
    
    QAFExtendedWebElement StageCard3Header= new QAFExtendedWebElement("ehome.hubPreIngestion.StageCard3Header");
    QAFExtendedWebElement StageCard3Mins= new QAFExtendedWebElement("ehome.hubPreIngestion.StageCard3Mins");
    QAFExtendedWebElement StageCard3Title= new QAFExtendedWebElement("ehome.hubPreIngestion.StageCard3Title");
    QAFExtendedWebElement StageCard3WhattoExpect= new QAFExtendedWebElement("ehome.hubPreIngestion.StageCard3WhattoExpect");
    QAFExtendedWebElement StageCard3FlipHeader= new QAFExtendedWebElement("ehome.hubPreIngestion.StageCard3FlipHeader");
    QAFExtendedWebElement StageCard3FlipText= new QAFExtendedWebElement("ehome.hubPreIngestion.StageCard3FlipText");
    
    QAFExtendedWebElement StageCard4Header= new QAFExtendedWebElement("ehome.hubPreIngestion.StageCard4Header");
    QAFExtendedWebElement StageCard4Mins= new QAFExtendedWebElement("ehome.hubPreIngestion.StageCard4Mins");
    QAFExtendedWebElement StageCard4Title= new QAFExtendedWebElement("ehome.hubPreIngestion.StageCard4Title");
    QAFExtendedWebElement StageCard4WhattoExpect= new QAFExtendedWebElement("ehome.hubPreIngestion.StageCard4WhattoExpect");
    QAFExtendedWebElement StageCard4FlipHeader= new QAFExtendedWebElement("ehome.hubPreIngestion.StageCard4FlipHeader");
    QAFExtendedWebElement StageCard4FlipText= new QAFExtendedWebElement("ehome.hubPreIngestion.StageCard4FlipText");

    QAFExtendedWebElement StageCard5Header= new QAFExtendedWebElement("ehome.hubPreIngestion.StageCard5Header");
    QAFExtendedWebElement StageCard5Mins= new QAFExtendedWebElement("ehome.hubPreIngestion.StageCard5Mins");
    QAFExtendedWebElement StageCard5Title= new QAFExtendedWebElement("ehome.hubPreIngestion.StageCard5Title");
    
    QAFExtendedWebElement ProfileColor= new QAFExtendedWebElement("ehome.hubPreIngestion.ProfileColor");
    QAFExtendedWebElement DarkBlueColor= new QAFExtendedWebElement("ehome.hubPreIngestion.DarkBlueColor");
    QAFExtendedWebElement LightBlueColor= new QAFExtendedWebElement("ehome.hubPreIngestion.LightBlueColor");
    QAFExtendedWebElement GreenColor= new QAFExtendedWebElement("ehome.hubPreIngestion.Green");
    QAFExtendedWebElement RedColor= new QAFExtendedWebElement("ehome.hubPreIngestion.Red");
    QAFExtendedWebElement OrangeColor= new QAFExtendedWebElement("ehome.hubPreIngestion.Orange");
    QAFExtendedWebElement PurpleColor= new QAFExtendedWebElement("ehome.hubPreIngestion.Purple");
    
    QAFExtendedWebElement salutation= new QAFExtendedWebElement("ehome.hubPreIngestion.salutation");
    QAFExtendedWebElement maritalStatus= new QAFExtendedWebElement("ehome.hubPreIngestion.maritalStatus");
    QAFExtendedWebElement streetNumber= new QAFExtendedWebElement("ehome.hubPreIngestion.streetNumber");
    QAFExtendedWebElement streetName= new QAFExtendedWebElement("ehome.hubPreIngestion.streetName");
    QAFExtendedWebElement direction= new QAFExtendedWebElement("ehome.hubPreIngestion.direction");
    QAFExtendedWebElement unitNumber= new QAFExtendedWebElement("ehome.hubPreIngestion.unitNumber");
    QAFExtendedWebElement city= new QAFExtendedWebElement("ehome.hubPreIngestion.city");
    QAFExtendedWebElement province= new QAFExtendedWebElement("ehome.hubPreIngestion.province");
    QAFExtendedWebElement postalCode= new QAFExtendedWebElement("ehome.hubPreIngestion.postalCode");
    QAFExtendedWebElement emailAddress= new QAFExtendedWebElement("ehome.hubPreIngestion.emailAddress");
    QAFExtendedWebElement phoneOne= new QAFExtendedWebElement("ehome.hubPreIngestion.phoneOne");
    QAFExtendedWebElement phoneTwo= new QAFExtendedWebElement("ehome.hubPreIngestion.phoneTwo");
    QAFExtendedWebElement phoneThree= new QAFExtendedWebElement("ehome.hubPreIngestion.phoneThree");
   
    QAFExtendedWebElement NotificationsHeader= new QAFExtendedWebElement("ehome.hubPreIngestion.NotificationsHeader");
    QAFExtendedWebElement NotificationsTitle= new QAFExtendedWebElement("ehome.hubPreIngestion.NotificationsTitle");
    QAFExtendedWebElement NotificationsContent= new QAFExtendedWebElement("ehome.hubPreIngestion.NotificationsContent");
  
    QAFExtendedWebElement MortgagesummaryHeader= new QAFExtendedWebElement("ehome.hubPreIngestion.MortgagesummaryHeader");
    QAFExtendedWebElement RateExpiryDate= new QAFExtendedWebElement("ehome.hubPreIngestion.RateExpiryDate");
    QAFExtendedWebElement MortgagesummaryContent= new QAFExtendedWebElement("ehome.hubPreIngestion.MortgagesummaryContent");
    QAFExtendedWebElement MortgagesummaryI= new QAFExtendedWebElement("ehome.hubPreIngestion.MortgagesummaryI");
    QAFExtendedWebElement MortgagesummaryIContent= new QAFExtendedWebElement("ehome.hubPreIngestion.MortgagesummaryIContent");
    
    QAFExtendedWebElement MortgageSupportHeader= new QAFExtendedWebElement("ehome.hubPreIngestion.MortgageSupportHeader");
    QAFExtendedWebElement eHOMEreferenceText= new QAFExtendedWebElement("ehome.hubPreIngestion.eHOMEreferenceText");
    QAFExtendedWebElement eHOMEreferenceNo= new QAFExtendedWebElement("ehome.hubPreIngestion.eHOMEreferenceNo");
    QAFExtendedWebElement ForQuick= new QAFExtendedWebElement("ehome.hubPreIngestion.ForQuick");
    QAFExtendedWebElement CanText= new QAFExtendedWebElement("ehome.hubPreIngestion.CanText");
    QAFExtendedWebElement OurMortgageAgents= new QAFExtendedWebElement("ehome.hubPreIngestion.OurMortgageAgents");
    QAFExtendedWebElement MortgageSupportPhone= new QAFExtendedWebElement("ehome.hubPreIngestion.MortgageSupportPhone");
    QAFExtendedWebElement MortgageSupportMonThursday= new QAFExtendedWebElement("ehome.hubPreIngestion.MortgageSupportMonThursday");
    QAFExtendedWebElement MortgageSupportFriday= new QAFExtendedWebElement("ehome.hubPreIngestion.MortgageSupportFriday");
    QAFExtendedWebElement MortgageSupportSaturday= new QAFExtendedWebElement("ehome.hubPreIngestion.MortgageSupportSaturday");
    QAFExtendedWebElement MortgageSupport9to11= new QAFExtendedWebElement("ehome.hubPreIngestion.MortgageSupport9to11");
    QAFExtendedWebElement MortgageSupport9to10= new QAFExtendedWebElement("ehome.hubPreIngestion.MortgageSupport9to10");
    QAFExtendedWebElement MortgageSupport10to6= new QAFExtendedWebElement("ehome.hubPreIngestion.MortgageSupport10to6");
    QAFExtendedWebElement MortgageSupportOnceYouSubmit= new QAFExtendedWebElement("ehome.hubPreIngestion.MortgageSupportOnceYouSubmit");

    QAFExtendedWebElement FAQAllYouNeed= new QAFExtendedWebElement("ehome.hubPreIngestion.FAQAllYouNeed");
    QAFExtendedWebElement FAQVideo= new QAFExtendedWebElement("ehome.hubPreIngestion.FAQVideo");
    QAFExtendedWebElement FAQGeneral= new QAFExtendedWebElement("ehome.hubPreIngestion.FAQGeneral");
    QAFExtendedWebElement FAQCoApplicants= new QAFExtendedWebElement("ehome.hubPreIngestion.FAQCoApplicants");
    QAFExtendedWebElement FAQStatusUpdates= new QAFExtendedWebElement("ehome.hubPreIngestion.FAQStatusUpdates");
    QAFExtendedWebElement FAQGettingInTouch= new QAFExtendedWebElement("ehome.hubPreIngestion.FAQGettingInTouch");
    QAFExtendedWebElement FAQCan= new QAFExtendedWebElement("ehome.hubPreIngestion.FAQCan");
    QAFExtendedWebElement FAQGiveUsACall= new QAFExtendedWebElement("ehome.hubPreIngestion.FAQGiveUsACall");
    
    QAFExtendedWebElement FAQGeneralPage= new QAFExtendedWebElement("ehome.hubPreIngestion.FAQGeneralPage");
    QAFExtendedWebElement FAQCoApplicantPage= new QAFExtendedWebElement("ehome.hubPreIngestion.FAQCoApplicantPage");
    QAFExtendedWebElement FAQStatusUpdatesPage= new QAFExtendedWebElement("ehome.hubPreIngestion.FAQStatusUpdatesPage");
    QAFExtendedWebElement FAQGettingInTouchPage= new QAFExtendedWebElement("ehome.hubPreIngestion.FAQGettingInTouchPage");
    
    QAFExtendedWebElement FAQGeneralPageQ1= new QAFExtendedWebElement("ehome.hubPreIngestion.FAQGeneralPageQ1");
    QAFExtendedWebElement FAQGeneralPageQ2= new QAFExtendedWebElement("ehome.hubPreIngestion.FAQGeneralPageQ2");
    QAFExtendedWebElement FAQGeneralPageQ3= new QAFExtendedWebElement("ehome.hubPreIngestion.FAQGeneralPageQ3");
    QAFExtendedWebElement FAQGeneralPageQ4= new QAFExtendedWebElement("ehome.hubPreIngestion.FAQGeneralPageQ4");
    QAFExtendedWebElement FAQGeneralPageQ5= new QAFExtendedWebElement("ehome.hubPreIngestion.FAQGeneralPageQ5");
    QAFExtendedWebElement FAQGeneralPageQ6= new QAFExtendedWebElement("ehome.hubPreIngestion.FAQGeneralPageQ6");
    QAFExtendedWebElement FAQGeneralPageQ7= new QAFExtendedWebElement("ehome.hubPreIngestion.FAQGeneralPageQ7");
    
    QAFExtendedWebElement FAQGeneralPage1Content= new QAFExtendedWebElement("ehome.hubPreIngestion.FAQGeneralPage1Content");
    QAFExtendedWebElement FAQGeneralPage2Content= new QAFExtendedWebElement("ehome.hubPreIngestion.FAQGeneralPage2Content");
    QAFExtendedWebElement FAQGeneralPage3Content= new QAFExtendedWebElement("ehome.hubPreIngestion.FAQGeneralPage3Content");
    QAFExtendedWebElement FAQGeneralPage4Content= new QAFExtendedWebElement("ehome.hubPreIngestion.FAQGeneralPage4Content");
    QAFExtendedWebElement FAQGeneralPage5Content= new QAFExtendedWebElement("ehome.hubPreIngestion.FAQGeneralPage5Content");
    QAFExtendedWebElement FAQGeneralPage6Content= new QAFExtendedWebElement("ehome.hubPreIngestion.FAQGeneralPage6Content");
    QAFExtendedWebElement FAQGeneralPage7Content= new QAFExtendedWebElement("ehome.hubPreIngestion.FAQGeneralPage7Content");
    
    QAFExtendedWebElement FAQCoApplicantsQ1= new QAFExtendedWebElement("ehome.hubPreIngestion.FAQCoApplicantsQ1");
    QAFExtendedWebElement FAQCoApplicantsQ2= new QAFExtendedWebElement("ehome.hubPreIngestion.FAQCoApplicantsQ2");
    QAFExtendedWebElement FAQCoApplicantsQ3= new QAFExtendedWebElement("ehome.hubPreIngestion.FAQCoApplicantsQ3");
    
    QAFExtendedWebElement FAQCoApplicantsPage1Content= new QAFExtendedWebElement("ehome.hubPreIngestion.FAQCoApplicantsPage1Content");
    QAFExtendedWebElement FAQCoApplicantsPage2Content= new QAFExtendedWebElement("ehome.hubPreIngestion.FAQCoApplicantsPage2Content");
    QAFExtendedWebElement FAQCoApplicantsPage3Content= new QAFExtendedWebElement("ehome.hubPreIngestion.FAQCoApplicantsPage3Content");
    
    QAFExtendedWebElement FAQStatusPagesQ1= new QAFExtendedWebElement("ehome.hubPreIngestion.FAQStatusPagesQ1");
    QAFExtendedWebElement FAQStatusPagesQ2= new QAFExtendedWebElement("ehome.hubPreIngestion.FAQStatusPagesQ2");
    QAFExtendedWebElement FAQStatusPagesQ3= new QAFExtendedWebElement("ehome.hubPreIngestion.FAQStatusPagesQ3");
    QAFExtendedWebElement FAQStatusPagesQ4= new QAFExtendedWebElement("ehome.hubPreIngestion.FAQStatusPagesQ4");
    QAFExtendedWebElement FAQStatusPagesQ5= new QAFExtendedWebElement("ehome.hubPreIngestion.FAQStatusPagesQ5");
    
    QAFExtendedWebElement FAQStatusPagesPage1Content= new QAFExtendedWebElement("ehome.hubPreIngestion.FAQStatusPagesPage1Content");
    QAFExtendedWebElement FAQStatusPagesPage2Content= new QAFExtendedWebElement("ehome.hubPreIngestion.FAQStatusPagesPage2Content");
    QAFExtendedWebElement FAQStatusPagesPage3Content= new QAFExtendedWebElement("ehome.hubPreIngestion.FAQStatusPagesPage3Content");
    QAFExtendedWebElement FAQStatusPagesPage4Content= new QAFExtendedWebElement("ehome.hubPreIngestion.FAQStatusPagesPage4Content");
    QAFExtendedWebElement FAQStatusPagesPage5Content= new QAFExtendedWebElement("ehome.hubPreIngestion.FAQStatusPagesPage5Content");
    
    QAFExtendedWebElement FAQGettingIntouchPagesQ1= new QAFExtendedWebElement("ehome.hubPreIngestion.FAQGettingIntouchPagesQ1");
    QAFExtendedWebElement FAQGettingIntouchPagesQ2= new QAFExtendedWebElement("ehome.hubPreIngestion.FAQGettingIntouchPagesQ2");
    
    QAFExtendedWebElement FAQGettingIntouchPage1Content= new QAFExtendedWebElement("ehome.hubPreIngestion.FAQGettingIntouchPage1Content");
    QAFExtendedWebElement FAQGettingIntouchPage2Content= new QAFExtendedWebElement("ehome.hubPreIngestion.FAQGettingIntouchPage2Content");

    QAFExtendedWebElement CoAppdetailstab= new QAFExtendedWebElement("ehome.hubPreIngestion.CoAppdetailstab");
    QAFExtendedWebElement WewillinviteTxt= new QAFExtendedWebElement("ehome.hubPreIngestion.WewillinviteTxt");
    QAFExtendedWebElement LegalFirstNameTxt= new QAFExtendedWebElement("ehome.hubPreIngestion.LegalFirstNameTxt");
    QAFExtendedWebElement LegalLastNameTxt= new QAFExtendedWebElement("ehome.hubPreIngestion.LegalLastNameTxt");
    QAFExtendedWebElement LegalEmailTxt= new QAFExtendedWebElement("ehome.hubPreIngestion.LegalEmailTxt");
    QAFExtendedWebElement LegalSave= new QAFExtendedWebElement("ehome.hubPreIngestion.LegalSave");
    QAFExtendedWebElement LegalDelete= new QAFExtendedWebElement("ehome.hubPreIngestion.LegalDelete");
    
    QAFExtendedWebElement firstNameVal= new QAFExtendedWebElement("ehome.hubPreIngestion.firstNameVal");
    QAFExtendedWebElement lastNameVal= new QAFExtendedWebElement("ehome.hubPreIngestion.lastNameVal");
    QAFExtendedWebElement emailAddressVal= new QAFExtendedWebElement("ehome.hubPreIngestion.emailAddressVal");
    
    @Given("^Customer should login and navigates to Hub PreIngestion Screen$")
    public void customer_should_login_and_navigates_to_Hub_PreIngestion_Screen() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	Utility.launchURL(ConfigurationUtils.getBaseBundle().getPropertyValue ("env.baseurl4"));
    	Login();
    }
    
    public static void ValidHubStart() throws InterruptedException, AWTException{
    	
    	QAFExtendedWebElement LetsGetStartedBtn= new QAFExtendedWebElement("ehome.hubPreIngestion.LetsGetStartedBtn");
        QAFExtendedWebElement SavecontinueBtn= new QAFExtendedWebElement("ehome.hubPreIngestion.SavecontinueBtn");
        QAFExtendedWebElement NoBtn= new QAFExtendedWebElement("ehome.hubPreIngestion.NoBtn");
        QAFExtendedWebElement GotitBtn= new QAFExtendedWebElement("ehome.hubPreIngestion.GotitBtn");
        
        Robot a = new Robot();
    	a.keyPress(KeyEvent.VK_Q);
    	Thread.sleep(1000);
    	a.keyPress(KeyEvent.VK_Q);
    	Thread.sleep(3000);
    	a.keyPress(KeyEvent.VK_ENTER);
    	Thread.sleep(5000);
    	a.keyPress(KeyEvent.VK_0);
    	a.keyPress(KeyEvent.VK_1);
    	a.keyPress(KeyEvent.VK_9);
    	a.keyPress(KeyEvent.VK_0);
    	Thread.sleep(2000);
    	a.keyPress(KeyEvent.VK_0);
    	a.keyPress(KeyEvent.VK_9);
    	a.keyPress(KeyEvent.VK_0);
    	a.keyPress(KeyEvent.VK_5);
    	a.keyPress(KeyEvent.VK_3);
    	a.keyPress(KeyEvent.VK_8);
    	a.keyPress(KeyEvent.VK_2);
    	a.keyPress(KeyEvent.VK_0);
    	Thread.sleep(2000);
    	a.keyPress(KeyEvent.VK_0);
    	a.keyPress(KeyEvent.VK_5);
    	a.keyPress(KeyEvent.VK_2);
    	Thread.sleep(4000);
    	a.keyPress(KeyEvent.VK_ENTER);
    	Thread.sleep(3000);
//    	LetsGetStartedBtn.click();
//    	Thread.sleep(3000);
//    	SavecontinueBtn.click();
//    	Thread.sleep(3000);
//    	NoBtn.click();
//    	Thread.sleep(3000);
//    	GotitBtn.click();
//    	Thread.sleep(3000);
//    	LetsGetStartedBtn.click();
//    	Thread.sleep(12000);
    }
    
    public static void Login() throws InterruptedException {
    	webDriver.findElement(By.xpath(".//*[contains(@id,'username')]")).sendKeys("4536000008459500");
        webDriver.findElement(By.xpath(".//*[contains(@id,'password')]")).sendKeys("a123456a");
        webDriver.findElement(By.xpath("//button[@id='signIn']")).click();
        Thread.sleep(3000);
        webDriver.findElement(By.xpath("//span[contains(text(),'Continue')]")).click();
        Thread.sleep(7000); 
	}
    
    @Then("^Verify Scotiabank Logo should be on the Hub PreIngestion screen$")
    public void verify_Scotiabank_Logo_should_be_on_the_Hub_PreIngestion_screen() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	sidebar.click();
    	wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(ScotiaBankLogo));
 		if(!ScotiaBankLogo.isPresent())
 			throw new AssertionError("Scotia Bank Logo is not present");
    }
    

    @Then("^Verify \"([^\"]*)\" , \"([^\"]*)\" , \"([^\"]*)\" , \"([^\"]*)\" , \"([^\"]*)\" , \"([^\"]*)\" message should be on side pane of HUB PreIngestion screen$")
    public void verify_message_should_be_on_side_pane_of_HUB_PreIngestion_screen(String arg1, String arg2, String arg3, String arg4, String arg5, String arg6) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	String testCaseID = Utility.getScenarioID();
		String editPersonalDetails=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "HubPreIngestion_ExpectedData", testCaseID, arg1);
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(EditPersonalDetails));
		Assert.assertEquals(EditPersonalDetails.getText(), editPersonalDetails,"Couldn't found expected message");
		
		String sidebarNotifications=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "HubPreIngestion_ExpectedData", testCaseID, arg2);
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(SidebarNotifications));
		Assert.assertEquals(SidebarNotifications.getText(), sidebarNotifications,"Couldn't found expected message");

		String faq=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "HubPreIngestion_ExpectedData", testCaseID, arg3);
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(FAQ));
		Assert.assertEquals(FAQ.getText(), faq,"Couldn't found expected message");

		String mortgageSummary=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "HubPreIngestion_ExpectedData", testCaseID, arg4);
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(MortgageSummary));
		Assert.assertEquals(MortgageSummary.getText(), mortgageSummary,"Couldn't found expected message");
		
		String mortgageSupport=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "HubPreIngestion_ExpectedData", testCaseID, arg5);
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(MortgageSupport));
		Assert.assertEquals(MortgageSupport.getText(), mortgageSupport,"Couldn't found expected message");
		
		String logout=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "HubPreIngestion_ExpectedData", testCaseID, arg6);
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(Logout));
		Assert.assertEquals(Logout.getText(), logout,"Couldn't found expected message");
    }
    
    
    @Then("^Verify \"([^\"]*)\" , \"([^\"]*)\" , \"([^\"]*)\" , \"([^\"]*)\" , \"([^\"]*)\" message should be on HUB PreIngestion screen$")
    public void verify_message_should_be_on_HUB_PreIngestion_screen(String arg1, String arg2, String arg3, String arg4, String arg5) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	String testCaseID = Utility.getScenarioID();
    	
    	String[] LetGetStartedText= LetsGetStarted.getText().split(",");
    	String letsGetStartedText=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "HubPreIngestion_ExpectedData", testCaseID, arg1);
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(LetsGetStarted));
		Assert.assertEquals(LetGetStartedText[0], letsGetStartedText,"Couldn't found expected message");
	
		String FirstUpText=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "HubPreIngestion_ExpectedData", testCaseID, arg2);
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(FirstUp));
		Assert.assertEquals(FirstUp.getText(), FirstUpText,"Couldn't found expected message");
				
		String ApplicationSetUpText=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "HubPreIngestion_ExpectedData", testCaseID, arg3);
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(ApplicationSetUp));
		Assert.assertEquals(ApplicationSetUp.getText(), ApplicationSetUpText,"Couldn't found expected message");
		
		String YouRegisteredForeHOMEText=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "HubPreIngestion_ExpectedData", testCaseID, arg4);
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(YouRegisteredForeHOME));
		Assert.assertEquals(YouRegisteredForeHOME.getText(), YouRegisteredForeHOMEText,"Couldn't found expected message");
		
		String YouConfirmedYourPersonalDetailsText=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "HubPreIngestion_ExpectedData", testCaseID, arg5);
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(YouConfirmedYourPersonalDetails));
		Assert.assertEquals(YouConfirmedYourPersonalDetails.getText(), YouConfirmedYourPersonalDetailsText,"Couldn't found expected message");
    }
    
    
    @Then("^Verify Date should be on HUB PreIngestion screen$")
    public void verify_Date_should_be_on_HUB_PreIngestion_screen() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(DateItem));
 		if(!DateItem.isPresent())
 			throw new AssertionError("Date is not present");
    	
    }

    @Then("^Verify (\\d+) to (\\d+) images should be on HUB PreIngestion screen$")
    public void verify_to_images_should_be_on_HUB_PreIngestion_screen(int arg1, int arg2) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	Thread.sleep(2000);
    	String firstImage=FirstImage.getAttribute("aria-hidden");
    	System.out.println(firstImage);
    	if(firstImage=="false")
    		throw new AssertionError("First Image is hidden");
    }

    @Then("^Verify StartYourApplication button should be on HUB PreIngestion screen$")
    public void verify_StartYourApplication_button_should_be_on_HUB_PreIngestion_screen() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(StartYourApplication));
 		if(!StartYourApplication.isPresent())
 			throw new AssertionError("StartYourApplication is not present");
    }
    
    @Then("^Verify \"([^\"]*)\" header from \"([^\"]*)\" on HUB PreIngestion screen$")
    public void verify_header_from_on_HUB_PreIngestion_screen(String arg1, String arg2) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	String testCaseID = Utility.getScenarioID();
    	String HeaderText=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "HubPreIngestion_ExpectedData", testCaseID, arg1);
		if(arg2=="StageCard1")
		{
			wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(StageCard0Header));
			Assert.assertEquals(StageCard0Header.getText(), HeaderText,"Couldn't found expected message");
		}
		if(arg2=="StageCard2")
		{
			wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(StageCard1Header));
			Assert.assertEquals(StageCard1Header.getText(), HeaderText,"Couldn't found expected message");
		}
		if(arg2=="StageCard3")
		{
			wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(StageCard2Header));
			Assert.assertEquals(StageCard2Header.getText(), HeaderText,"Couldn't found expected message");
		}
		if(arg2=="StageCard4")
		{
			wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(StageCard3Header));
			Assert.assertEquals(StageCard3Header.getText(), HeaderText,"Couldn't found expected message");
		}
		if(arg2=="StageCard5")
		{
			wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(StageCard4Header));
			Assert.assertEquals(StageCard4Header.getText(), HeaderText,"Couldn't found expected message");
		}
		if(arg2=="StageCard6")
		{
			wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(StageCard5Header));
			Assert.assertEquals(StageCard5Header.getText(), HeaderText,"Couldn't found expected message");
		}
    }
    

    @Then("^Verify \"([^\"]*)\" mins from \"([^\"]*)\" on HUB PreIngestion screen$")
    public void verify_mins_from_on_HUB_PreIngestion_screen(String arg1, String arg2) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	String testCaseID = Utility.getScenarioID();
    	String MinsText=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "HubPreIngestion_ExpectedData", testCaseID, arg1);
		if(arg2=="StageCard1")
		{
			wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(StageCard0Mins));
			Assert.assertEquals(StageCard0Mins.getText(), MinsText,"Couldn't found expected message");
		}
		if(arg2=="StageCard2")
		{
			wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(StageCard1Mins));
			Assert.assertEquals(StageCard1Mins.getText(), MinsText,"Couldn't found expected message");
		}
		if(arg2=="StageCard3")
		{
			wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(StageCard2Mins));
			Assert.assertEquals(StageCard2Mins.getText(), MinsText,"Couldn't found expected message");
		}
		if(arg2=="StageCard4")
		{
			wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(StageCard3Mins));
			Assert.assertEquals(StageCard3Mins.getText(), MinsText,"Couldn't found expected message");
		}
		if(arg2=="StageCard5")
		{
			wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(StageCard4Mins));
			Assert.assertEquals(StageCard4Mins.getText(), MinsText,"Couldn't found expected message");
		}
		if(arg2=="StageCard6")
		{
			wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(StageCard5Mins));
			Assert.assertEquals(StageCard5Mins.getText(), MinsText,"Couldn't found expected message");
		}
    	
    }

    @Then("^Verify \"([^\"]*)\" title from \"([^\"]*)\" on HUB PreIngestion screen$")
    public void verify_title_from_on_HUB_PreIngestion_screen(String arg1, String arg2) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	String testCaseID = Utility.getScenarioID();
    	String TitleText=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "HubPreIngestion_ExpectedData", testCaseID, arg1);
		if(arg2=="StageCard1")
		{
			wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(StageCard0Title));
			Assert.assertEquals(StageCard0Title.getText(), TitleText,"Couldn't found expected message");
		}
		if(arg2=="StageCard2")
		{
			wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(StageCard1Title));
			Assert.assertEquals(StageCard1Title.getText(), TitleText,"Couldn't found expected message");
		}
		if(arg2=="StageCard3")
		{
			wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(StageCard2Title));
			Assert.assertEquals(StageCard2Title.getText(), TitleText,"Couldn't found expected message");
		}
		if(arg2=="StageCard4")
		{
			wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(StageCard3Title));
			Assert.assertEquals(StageCard3Title.getText(), TitleText,"Couldn't found expected message");
		}
		if(arg2=="StageCard5")
		{
			wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(StageCard4Title));
			Assert.assertEquals(StageCard4Title.getText(), TitleText,"Couldn't found expected message");
		}
		if(arg2=="StageCard6")
		{
			wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(StageCard5Title));
			Assert.assertEquals(StageCard5Title.getText(), TitleText,"Couldn't found expected message");
		}
    }

    @Then("^Verify \"([^\"]*)\" whattoExpect message from \"([^\"]*)\" on HUB PreIngestion screen$")
    public void verify_whattoExpect_message_from_on_HUB_PreIngestion_screen(String arg1, String arg2) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	String testCaseID = Utility.getScenarioID();
    	String WhattoExpectText=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "HubPreIngestion_ExpectedData", testCaseID, arg1);
		if(arg2=="StageCard1")
		{
			wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(StageCard0WhattoExpect));
			Assert.assertEquals(StageCard0WhattoExpect.getText(), WhattoExpectText,"Couldn't found expected message");
		}
		if(arg2=="StageCard2")
		{
			wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(StageCard1WhattoExpect));
			Assert.assertEquals(StageCard1WhattoExpect.getText(), WhattoExpectText,"Couldn't found expected message");
		}
		if(arg2=="StageCard3")
		{
			wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(StageCard2WhattoExpect));
			Assert.assertEquals(StageCard2WhattoExpect.getText(), WhattoExpectText,"Couldn't found expected message");
		}
		if(arg2=="StageCard4")
		{
			wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(StageCard3WhattoExpect));
			Assert.assertEquals(StageCard3WhattoExpect.getText(), WhattoExpectText,"Couldn't found expected message");
		}
		if(arg2=="StageCard5")
		{
			wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(StageCard4WhattoExpect));
			Assert.assertEquals(StageCard4WhattoExpect.getText(), WhattoExpectText,"Couldn't found expected message");
		}
    }

    @Then("^Verify \"([^\"]*)\" flip header from \"([^\"]*)\" on HUB PreIngestion screen$")
    public void verify_flip_header_from_on_HUB_PreIngestion_screen(String arg1, String arg2) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	String testCaseID = Utility.getScenarioID();
    	String FlipCardHeaderText=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "HubPreIngestion_ExpectedData", testCaseID, arg1);
		if(arg2=="StageCard1")
		{
			wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(StageCard0FlipHeader));
			Assert.assertEquals(StageCard0FlipHeader.getText(), FlipCardHeaderText,"Couldn't found expected message");
		}
		if(arg2=="StageCard2")
		{
			wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(StageCard1FlipHeader));
			Assert.assertEquals(StageCard1FlipHeader.getText(), FlipCardHeaderText,"Couldn't found expected message");
		}
		if(arg2=="StageCard3")
		{
			wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(StageCard2FlipHeader));
			Assert.assertEquals(StageCard2FlipHeader.getText(), FlipCardHeaderText,"Couldn't found expected message");
		}
		if(arg2=="StageCard4")
		{
			wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(StageCard3FlipHeader));
			Assert.assertEquals(StageCard3FlipHeader.getText(), FlipCardHeaderText,"Couldn't found expected message");
		}
		if(arg2=="StageCard5")
		{
			wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(StageCard4FlipHeader));
			Assert.assertEquals(StageCard4FlipHeader.getText(), FlipCardHeaderText,"Couldn't found expected message");
		}
    	
    }

    @Then("^Verify \"([^\"]*)\" flip message from \"([^\"]*)\" on HUB PreIngestion screen$")
    public void verify_flip_message_from_on_HUB_PreIngestion_screen(String arg1, String arg2) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	String testCaseID = Utility.getScenarioID();
    	String FlipCardMsgText=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "HubPreIngestion_ExpectedData", testCaseID, arg1);
		if(arg2=="StageCard1")
		{
			wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(StageCard0FlipText));
			Assert.assertEquals(StageCard0FlipText.getText(), FlipCardMsgText,"Couldn't found expected message");
		}
		if(arg2=="StageCard2")
		{
			wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(StageCard1FlipText));
			Assert.assertEquals(StageCard1FlipText.getText(), FlipCardMsgText,"Couldn't found expected message");
		}
		if(arg2=="StageCard3")
		{
			wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(StageCard2FlipText));
			Assert.assertEquals(StageCard2FlipText.getText(), FlipCardMsgText,"Couldn't found expected message");
		}
		if(arg2=="StageCard4")
		{
			wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(StageCard3FlipText));
			Assert.assertEquals(StageCard3FlipText.getText(), FlipCardMsgText,"Couldn't found expected message");
		}
		if(arg2=="StageCard5")
		{
			wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(StageCard4FlipText));
			Assert.assertEquals(StageCard4FlipText.getText(), FlipCardMsgText,"Couldn't found expected message");
		}
    }
    
    @When("^customer changes the profile color to \"([^\"]*)\" , the same color should reflect in the side bar for the profile$")
    	public void customer_changes_the_profile_color_to_the_same_color_should_reflect_in_the_side_bar_for_the_profile(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	String testCaseID = Utility.getScenarioID();
    	String ColorPickerText=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "HubPreIngestion_ExpectedData", testCaseID, arg1);
    	sidebar.click();
    	EditPersonalDetails.click();
    	Thread.sleep(3000);
    	String[] ColorPickerTxt;
    	if(ColorPickerText.equalsIgnoreCase("Dark Blue"))
    	{
    		DarkBlueColor.click();
    		ColorPickerTxt = DarkBlueColor.getAttribute("style").split(":");
            ColoPickerStr = ColorPickerTxt[1];
    	}
    	if(ColorPickerText.equalsIgnoreCase("Light Blue"))
        {
        	LightBlueColor.click();
        	ColorPickerTxt = LightBlueColor.getAttribute("style").split(":");
            ColoPickerStr = ColorPickerTxt[1];
    	}
    	if(ColorPickerText.equalsIgnoreCase("Green")) 
        {
        	GreenColor.click();	
        	ColorPickerTxt = GreenColor.getAttribute("style").split(":");
            ColoPickerStr = ColorPickerTxt[1];
    	}
    	if(ColorPickerText.equalsIgnoreCase("Red"))
        {
        	RedColor.click();
        	ColorPickerTxt = RedColor.getAttribute("style").split(":");
            ColoPickerStr = ColorPickerTxt[1];
        }
    	if(ColorPickerText.equalsIgnoreCase("Orange"))
    	{
        	OrangeColor.click();
        	ColorPickerTxt = OrangeColor.getAttribute("style").split(":");
            ColoPickerStr = ColorPickerTxt[1];
        }
    	if(ColorPickerText.equalsIgnoreCase("Purple"))
    	{
        	PurpleColor.click();
        	ColorPickerTxt = PurpleColor.getAttribute("style").split(":");
            ColoPickerStr = ColorPickerTxt[1];
        }
    	Thread.sleep(3000);
    	String[] profileColortext = ProfileColor.getAttribute("style").split(":");
    	if(!(ColoPickerStr.equalsIgnoreCase(profileColortext[1])))
    		throw new AssertionError("Selected color doesnt match with the profile color");
    }

    @When("^customer changes the title to \"([^\"]*)\" , the same title should reflect in the side bar for the profile$")
    public void customer_changes_the_title_to_the_same_title_should_reflect_in_the_side_bar_for_the_profile(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	String testCaseID = Utility.getScenarioID();
    	String TitlePickerText=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "HubPreIngestion_ExpectedData", testCaseID, arg1);
    	sidebar.click();
    	EditPersonalDetails.click();
    	Thread.sleep(3000);
    	salutation.sendKeys(TitlePickerText);
    	Thread.sleep(2000);
    	SaveButton.click();
    	Thread.sleep(2000);
    	
    	sidebar.click();
    	EditPersonalDetails.click();
    	Thread.sleep(3000);
    	Select sel=new Select(salutation);
    	String salText=sel.getFirstSelectedOption().getText();
    	if(!(salText.equalsIgnoreCase(TitlePickerText)))
    		throw new AssertionError("Selected Title didnt update in the profile");
    }
    
    @When("^customer changes the marital status to \"([^\"]*)\" , the same status should reflect in the side bar for the profile$")
    public void customer_changes_the_marital_status_to_the_same_status_should_reflect_in_the_side_bar_for_the_profile(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	String testCaseID = Utility.getScenarioID();
    	String MaritalStatusPickerText=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "HubPreIngestion_ExpectedData", testCaseID, arg1);
    	sidebar.click();
    	EditPersonalDetails.click();
    	Thread.sleep(3000);
    	maritalStatus.sendKeys(MaritalStatusPickerText);
    	Thread.sleep(2000);
    	SaveButton.click();
    	Thread.sleep(2000);
    	
    	sidebar.click();
    	EditPersonalDetails.click();
    	Thread.sleep(3000);
    	Select sel=new Select(maritalStatus);
    	String marText=sel.getFirstSelectedOption().getText();
    	if(!(marText.equalsIgnoreCase(MaritalStatusPickerText)))
    		throw new AssertionError("Selected Marital Status didnt update in the profile");
    }

    @When("^customer changes the street number to \"([^\"]*)\" , the same street number should reflect in the side bar for the profile$")
    public void customer_changes_the_street_number_to_the_same_street_number_should_reflect_in_the_side_bar_for_the_profile(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	String testCaseID = Utility.getScenarioID();
    	String StreetNumberPickerText=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "HubPreIngestion_ExpectedData", testCaseID, arg1);
    	sidebar.click();
    	EditPersonalDetails.click();
    	Thread.sleep(3000);
    	streetNumber.clear();
    	Thread.sleep(1000);
    	streetNumber.sendKeys(StreetNumberPickerText);
    	String streetNoText=streetNumber.getAttribute("value");
    	Thread.sleep(2000);
    	SaveButton.click();
    	Thread.sleep(3000);
    	sidebar.click();
    	EditPersonalDetails.click();
    	Thread.sleep(3000);
    	if(!(streetNoText.equalsIgnoreCase(StreetNumberPickerText)))
    		throw new AssertionError("Selected Street Number didnt update in the profile");
    }
    
    @When("^customer changes the street name to \"([^\"]*)\" , the same street name should reflect in the side bar for the profile$")
    public void customer_changes_the_street_name_to_the_same_street_name_should_reflect_in_the_side_bar_for_the_profile(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	String testCaseID = Utility.getScenarioID();
    	String StreetNamePickerText=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "HubPreIngestion_ExpectedData", testCaseID, arg1);
    	sidebar.click();
    	EditPersonalDetails.click();
    	Thread.sleep(3000);
    	streetName.clear();
    	Thread.sleep(1000);
    	streetName.sendKeys(StreetNamePickerText);
    	String streetNameText=streetName.getAttribute("value");
    	Thread.sleep(2000);
    	SaveButton.click();
    	Thread.sleep(3000);
    	sidebar.click();
    	EditPersonalDetails.click();
    	Thread.sleep(3000);
    	if(!(streetNameText.equalsIgnoreCase(StreetNamePickerText)))
    		throw new AssertionError("Selected Street Name didnt update in the profile");
    }
    
    @When("^customer changes the direction to \"([^\"]*)\" , the same direction should reflect in the side bar for the profile$")
    public void customer_changes_the_direction_to_the_same_direction_should_reflect_in_the_side_bar_for_the_profile(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	String testCaseID = Utility.getScenarioID();
    	String DirectionPickerText=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "HubPreIngestion_ExpectedData", testCaseID, arg1);
    	sidebar.click();
    	EditPersonalDetails.click();
    	Thread.sleep(3000);
    	direction.sendKeys(DirectionPickerText);
    	Thread.sleep(2000);
    	SaveButton.click();
    	Thread.sleep(2000);
    	
    	sidebar.click();
    	EditPersonalDetails.click();
    	Thread.sleep(3000);
    	Select sel=new Select(direction);
    	String directionText=sel.getFirstSelectedOption().getText();
    	if(!(directionText.equalsIgnoreCase(DirectionPickerText)))
    		throw new AssertionError("Selected Direction didnt update in the profile");
    }

    @When("^customer changes the unit to \"([^\"]*)\" , the same unit should reflect in the side bar for the profile$")
    public void customer_changes_the_unit_to_the_same_unit_should_reflect_in_the_side_bar_for_the_profile(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	String testCaseID = Utility.getScenarioID();
    	String UnitNumberPickerText=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "HubPreIngestion_ExpectedData", testCaseID, arg1);
    	sidebar.click();
    	EditPersonalDetails.click();
    	Thread.sleep(3000);
    	unitNumber.clear();
    	Thread.sleep(1000);
    	unitNumber.sendKeys(UnitNumberPickerText);
    	String unitNumberText=unitNumber.getAttribute("value");
    	Thread.sleep(2000);
    	SaveButton.click();
    	Thread.sleep(3000);
    	sidebar.click();
    	EditPersonalDetails.click();
    	Thread.sleep(3000);
    	if(!(unitNumberText.equalsIgnoreCase(UnitNumberPickerText)))
    		throw new AssertionError("Selected Unit Number didnt update in the profile");
    }

    @When("^customer changes the city to \"([^\"]*)\" , the same city should reflect in the side bar for the profile$")
    public void customer_changes_the_city_to_the_same_city_should_reflect_in_the_side_bar_for_the_profile(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	String testCaseID = Utility.getScenarioID();
    	String CityPickerText=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "HubPreIngestion_ExpectedData", testCaseID, arg1);
    	sidebar.click();
    	EditPersonalDetails.click();
    	Thread.sleep(3000);
    	city.clear();
    	Thread.sleep(1000);
    	city.sendKeys(CityPickerText);
    	String cityText=city.getAttribute("value");
    	Thread.sleep(2000);
    	SaveButton.click();
    	Thread.sleep(3000);
    	sidebar.click();
    	EditPersonalDetails.click();
    	Thread.sleep(3000);
    	if(!(cityText.equalsIgnoreCase(CityPickerText)))
    		throw new AssertionError("Selected City didnt update in the profile");
    }

    @When("^customer changes the province to \"([^\"]*)\" , the same province should reflect in the side bar for the profile$")
    public void customer_changes_the_province_to_the_same_province_should_reflect_in_the_side_bar_for_the_profile(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	String testCaseID = Utility.getScenarioID();
    	String ProvincePickerText=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "HubPreIngestion_ExpectedData", testCaseID, arg1);
    	sidebar.click();
    	EditPersonalDetails.click();
    	Thread.sleep(3000);
    	province.sendKeys(ProvincePickerText);
    	Thread.sleep(2000);
    	SaveButton.click();
    	Thread.sleep(2000);
    	
    	sidebar.click();
    	EditPersonalDetails.click();
    	Thread.sleep(3000);
    	Select sel=new Select(province);
    	String provinceText=sel.getFirstSelectedOption().getText();
    	if(!(provinceText.equalsIgnoreCase(ProvincePickerText)))
    		throw new AssertionError("Selected Province didnt update in the profile");
    }

    @When("^customer changes the postal code to \"([^\"]*)\" , the same postal code should reflect in the side bar for the profile$")
    public void customer_changes_the_postal_code_to_the_same_postal_code_should_reflect_in_the_side_bar_for_the_profile(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	
    	String testCaseID = Utility.getScenarioID();
    	String PostalCodePickerText=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "HubPreIngestion_ExpectedData", testCaseID, arg1);
    	sidebar.click();
    	EditPersonalDetails.click();
    	Thread.sleep(3000);
    	postalCode.clear();
    	Thread.sleep(1000);
    	postalCode.sendKeys(PostalCodePickerText);
    	String postalCodeText=postalCode.getAttribute("value");
    	Thread.sleep(2000);
    	SaveButton.click();
    	Thread.sleep(3000);
    	sidebar.click();
    	EditPersonalDetails.click();
    	Thread.sleep(3000);
    	if(!(postalCodeText.equalsIgnoreCase(PostalCodePickerText)))
    		throw new AssertionError("Selected Postal Code didnt update in the profile");
    }
    
    @When("^customer changes the mobile phone number to \"([^\"]*)\" , \"([^\"]*)\" , \"([^\"]*)\" the same mobile phone number should reflect in the side bar for the profile$")
    public void customer_changes_the_mobile_phone_number_to_the_same_mobile_phone_number_should_reflect_in_the_side_bar_for_the_profile(String arg1, String arg2, String arg3) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	String testCaseID = Utility.getScenarioID();
    	String MobilePhoneNumberPickerText1=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "HubPreIngestion_ExpectedData", testCaseID, arg1);
    	String MobilePhoneNumberPickerText2=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "HubPreIngestion_ExpectedData", testCaseID, arg2);
    	String MobilePhoneNumberPickerText3=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "HubPreIngestion_ExpectedData", testCaseID, arg3);
    	sidebar.click();
    	EditPersonalDetails.click();
    	Thread.sleep(3000);
    	phoneOne.clear();
    	phoneTwo.clear();
    	phoneThree.clear();
    	Thread.sleep(2000);
    	Thread.sleep(2000);
    	phoneOne.sendKeys(MobilePhoneNumberPickerText1);
    	phoneTwo.sendKeys(MobilePhoneNumberPickerText2);
    	phoneThree.sendKeys(MobilePhoneNumberPickerText3);
    	String phoneOneText=phoneOne.getAttribute("value");
    	String phoneTwoText=phoneTwo.getAttribute("value");
    	String phoneThreeText=phoneThree.getAttribute("value");
    	Thread.sleep(2000);
    	SaveButton.click();
    	Thread.sleep(3000);
    	sidebar.click();
    	EditPersonalDetails.click();
    	Thread.sleep(3000);
    	if(!(phoneOneText.equalsIgnoreCase(MobilePhoneNumberPickerText1)))
    		throw new AssertionError("Selected Mobile1 didnt update in the profile");
    	if(!(phoneTwoText.equalsIgnoreCase(MobilePhoneNumberPickerText2)))
    		throw new AssertionError("Selected Mobile2 didnt update in the profile");
    	if(!(phoneThreeText.equalsIgnoreCase(MobilePhoneNumberPickerText3)))
    		throw new AssertionError("Selected Mobile3 didnt update in the profile");
    }
    
    @When("^customer changes the email Address to \"([^\"]*)\" , the same email Address should reflect in the side bar for the profile$")
    public void customer_changes_the_email_Address_to_the_same_email_Address_should_reflect_in_the_side_bar_for_the_profile(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
     	String testCaseID = Utility.getScenarioID();
    	String EmailAddressPickerText=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "HubPreIngestion_ExpectedData", testCaseID, arg1);
    	sidebar.click();
    	EditPersonalDetails.click();
    	Thread.sleep(3000);
    	emailAddress.clear();
    	Thread.sleep(1000);
    	emailAddress.sendKeys(EmailAddressPickerText);
    	String emailAddressText=emailAddress.getAttribute("value");
    	Thread.sleep(2000);
    	SaveButton.click();
    	Thread.sleep(3000);
    	sidebar.click();
    	EditPersonalDetails.click();
    	Thread.sleep(3000);
    	if(!(emailAddressText.equalsIgnoreCase(EmailAddressPickerText)))
    		throw new AssertionError("Selected Email Address didnt update in the profile");
    }

    @When("^customer clicks on notifications$")
    public void customer_clicks_on_notifications() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	sidebar.click();
    	SidebarNotifications.click();
    	Thread.sleep(2000);
    }

    @Then("^Verify \"([^\"]*)\" header under notifications$")
    public void verify_header_under_notifications(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	String testCaseID = Utility.getScenarioID();
		String editPersonalDetails=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "HubPreIngestion_ExpectedData", testCaseID, arg1);
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(NotificationsHeader));
		Assert.assertEquals(NotificationsHeader.getText(), editPersonalDetails,"Couldn't found expected message");
    }

    @Then("^Verify \"([^\"]*)\" title under notifications$")
    public void verify_title_under_notifications(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	String testCaseID = Utility.getScenarioID();
		String editPersonalDetails=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "HubPreIngestion_ExpectedData", testCaseID, arg1);
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(NotificationsTitle));
		Assert.assertEquals(NotificationsTitle.getText(), editPersonalDetails,"Couldn't found expected message");
    }

    @Then("^Verify \"([^\"]*)\" content under notifications$")
    public void verify_content_under_notifications(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	String testCaseID = Utility.getScenarioID();
		String editPersonalDetails=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "HubPreIngestion_ExpectedData", testCaseID, arg1);
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(NotificationsContent));
		Assert.assertEquals(NotificationsContent.getText(), editPersonalDetails,"Couldn't found expected message");
    }
    
    @When("^customer clicks on mortgage summary$")
    public void customer_clicks_on_mortgage_summary() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
     	sidebar.click();
     	MortgageSummary.click();
    	Thread.sleep(2000);
    }

    @Then("^Verify \"([^\"]*)\" Header under Mortgage Summary$")
    public void verify_Header_under_Mortgage_Summary(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	String testCaseID = Utility.getScenarioID();
		String mortgageSummaryHeaderText=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "HubPreIngestion_ExpectedData", testCaseID, arg1);
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(MortgagesummaryHeader));
		Assert.assertEquals(MortgagesummaryHeader.getText(), mortgageSummaryHeaderText,"Couldn't found expected message");
    }

    @Then("^Verify \"([^\"]*)\" Rate Expiry header under Mortgage Summary$")
    public void verify_Rate_Expiry_header_under_Mortgage_Summary(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	String testCaseID = Utility.getScenarioID();
		String rateExpiryText=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "HubPreIngestion_ExpectedData", testCaseID, arg1);
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(RateExpiryDate));
		Assert.assertEquals(RateExpiryDate.getText(), rateExpiryText,"Couldn't found expected message");
    }

    @Then("^Verify \"([^\"]*)\" Rate Expiry content under Mortgage Summary$")
    public void verify_Rate_Expiry_content_under_Mortgage_Summary(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	String testCaseID = Utility.getScenarioID();
		String mortgageSummaryContentText=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "HubPreIngestion_ExpectedData", testCaseID, arg1);
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(MortgagesummaryContent));
		Assert.assertEquals(MortgagesummaryContent.getText(), mortgageSummaryContentText,"Couldn't found expected message");
    }
    
    @When("^Click on I in Mortgage Summary$")
    public void click_on_I_in_Mortgage_Summary() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	sidebar.click();
    	MortgageSummary.click();
    	Thread.sleep(2000);
    	MortgagesummaryI.click();
    	Thread.sleep(2000);
    }

    @Then("^Verify the \"([^\"]*)\" content for I in Mortgage Summary$")
    public void verify_the_content_for_I_in_Mortgage_Summary(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	String testCaseID = Utility.getScenarioID();
		String MortgagesummaryIContentText=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "HubPreIngestion_ExpectedData", testCaseID, arg1);
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(MortgagesummaryIContent));
		Assert.assertEquals(MortgagesummaryIContent.getText(), MortgagesummaryIContentText,"Couldn't found expected message");
    }
    
    @When("^customer clicks on Mortgage Support$")
    public void customer_clicks_on_Mortgage_Support() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	sidebar.click();
    	Thread.sleep(2000);
    	MortgageSupport.click();
    	Thread.sleep(2000);
    }

    @Then("^Verify the \"([^\"]*)\" Header in Mortgage Support$")
    public void verify_the_Header_in_Mortgage_Support(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	String testCaseID = Utility.getScenarioID();
		String MortgageSupportHeaderText=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "HubPreIngestion_ExpectedData", testCaseID, arg1);
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(MortgageSupportHeader));
		Assert.assertEquals(MortgageSupportHeader.getText(), MortgageSupportHeaderText,"Couldn't found expected message");
    }

    @Then("^Verify the \"([^\"]*)\" reference number text in Mortgage Support$")
    public void verify_the_reference_number_text_in_Mortgage_Support(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	String testCaseID = Utility.getScenarioID();
		String eHOMEreferenceTxt=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "HubPreIngestion_ExpectedData", testCaseID, arg1);
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(eHOMEreferenceText));
		Assert.assertEquals(eHOMEreferenceText.getText(), eHOMEreferenceTxt,"Couldn't found expected message");
    }

    @Then("^Verify the \"([^\"]*)\" reference number in Mortgage Support$")
    public void verify_the_reference_number_in_Mortgage_Support(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	String testCaseID = Utility.getScenarioID();
		String eHOMEreferenceNoText=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "HubPreIngestion_ExpectedData", testCaseID, arg1);
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(eHOMEreferenceNo));
		Assert.assertEquals(eHOMEreferenceNo.getText(), eHOMEreferenceNoText,"Couldn't found expected message");
    }

    @Then("^Verify the \"([^\"]*)\" FAQ text in Mortgage Support$")
    public void verify_the_FAQ_text_in_Mortgage_Support(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
     	String testCaseID = Utility.getScenarioID();
    		String ForQuickText=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "HubPreIngestion_ExpectedData", testCaseID, arg1);
    		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(ForQuick));
    		Assert.assertEquals(ForQuick.getText(), ForQuickText,"Couldn't found expected message");
    }

    @Then("^Verify the \"([^\"]*)\" cant find text in Mortgage Support$")
    public void verify_the_cant_find_text_in_Mortgage_Support(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
     	String testCaseID = Utility.getScenarioID();
    	String CanTxt=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "HubPreIngestion_ExpectedData", testCaseID, arg1);
    	wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(CanText));
    	Assert.assertEquals(CanText.getText(), CanTxt,"Couldn't found expected message");
    }

    @Then("^Verify the \"([^\"]*)\" our mortgage text in Mortgage Support$")
    public void verify_the_our_mortgage_text_in_Mortgage_Support(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
     	String testCaseID = Utility.getScenarioID();
    	String OurMortgageAgentsText=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "HubPreIngestion_ExpectedData", testCaseID, arg1);
    	wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(OurMortgageAgents));
    	Assert.assertEquals(OurMortgageAgents.getText(), OurMortgageAgentsText,"Couldn't found expected message");
    }

    @Then("^Verify the \"([^\"]*)\" mortgage support no in Mortgage Support$")
    public void verify_the_mortgage_support_no_in_Mortgage_Support(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
     	String testCaseID = Utility.getScenarioID();
    	String MortgageSupportPhoneText=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "HubPreIngestion_ExpectedData", testCaseID, arg1);
    	wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(MortgageSupportPhone));
    	Assert.assertEquals(MortgageSupportPhone.getText(), MortgageSupportPhoneText,"Couldn't found expected message");
    }

    @Then("^Verify the \"([^\"]*)\" mon to thur text in Mortgage Support$")
    public void verify_the_mon_to_thur_text_in_Mortgage_Support(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
     	String testCaseID = Utility.getScenarioID();
    	String MortgageSupportMonThursdayText=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "HubPreIngestion_ExpectedData", testCaseID, arg1);
    	wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(MortgageSupportMonThursday));
    	Assert.assertEquals(MortgageSupportMonThursday.getText(), MortgageSupportMonThursdayText,"Couldn't found expected message");
    }

    @Then("^Verify the \"([^\"]*)\" friday text in Mortgage Support$")
    public void verify_the_friday_text_in_Mortgage_Support(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
     	String testCaseID = Utility.getScenarioID();
    	String MortgageSupportFridayText=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "HubPreIngestion_ExpectedData", testCaseID, arg1);
    	wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(MortgageSupportFriday));
    	Assert.assertEquals(MortgageSupportFriday.getText(), MortgageSupportFridayText,"Couldn't found expected message");
    }

    @Then("^Verify the \"([^\"]*)\" sat text in Mortgage Support$")
    public void verify_the_sat_text_in_Mortgage_Support(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
     	String testCaseID = Utility.getScenarioID();
    	String MortgageSupportSaturdayText=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "HubPreIngestion_ExpectedData", testCaseID, arg1);
    	wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(MortgageSupportSaturday));
    	Assert.assertEquals(MortgageSupportSaturday.getText(), MortgageSupportSaturdayText,"Couldn't found expected message");
    }

    @Then("^Verify the \"([^\"]*)\" monday nine time text in Mortgage Support$")
    public void verify_the_monday_nine_time_text_in_Mortgage_Support(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
     	String testCaseID = Utility.getScenarioID();
    	String MortgageSupport9to11Text=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "HubPreIngestion_ExpectedData", testCaseID, arg1);
    	wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(MortgageSupport9to11));
    	Assert.assertEquals(MortgageSupport9to11.getText(), MortgageSupport9to11Text,"Couldn't found expected message");
    }

    @Then("^Verify the \"([^\"]*)\" friday nine to ten text in Mortgage Support$")
    public void verify_the_friday_nine_to_ten_text_in_Mortgage_Support(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
     	String testCaseID = Utility.getScenarioID();
    	String MortgageSupport9to10Text=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "HubPreIngestion_ExpectedData", testCaseID, arg1);
    	wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(MortgageSupport9to10));
    	Assert.assertEquals(MortgageSupport9to10.getText(), MortgageSupport9to10Text,"Couldn't found expected message");
  }

    @Then("^Verify the \"([^\"]*)\" saturday ten in Mortgage Support$")
    public void verify_the_saturday_ten_in_Mortgage_Support(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
     	String testCaseID = Utility.getScenarioID();
    	String MortgageSupport10to6Text=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "HubPreIngestion_ExpectedData", testCaseID, arg1);
    	wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(MortgageSupport10to6));
    	Assert.assertEquals(MortgageSupport10to6.getText(), MortgageSupport10to6Text,"Couldn't found expected message");
    }

    @Then("^Verify the \"([^\"]*)\" once you submit text in Mortgage Support$")
    public void verify_the_once_you_submit_text_in_Mortgage_Support(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
     	String testCaseID = Utility.getScenarioID();
    	String MortgageSupportOnceYouSubmitText=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "HubPreIngestion_ExpectedData", testCaseID, arg1);
    	wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(MortgageSupportOnceYouSubmit));
    	Assert.assertEquals(MortgageSupportOnceYouSubmit.getText(), MortgageSupportOnceYouSubmitText,"Couldn't found expected message");
    }
    
    @When("^customer clicks on FAQs$")
    public void customer_clicks_on_FAQs() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	sidebar.click();
    	Thread.sleep(2000);
    	FAQ.click();
    	Thread.sleep(2000);
    }

    @Then("^Verify the \"([^\"]*)\" Header in FAQs$")
    public void verify_the_Header_in_FAQs(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	String testCaseID = Utility.getScenarioID();
    	String FAQAllYouNeedText=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "HubPreIngestion_ExpectedData", testCaseID, arg1);
    	wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(FAQAllYouNeed));
    	Assert.assertEquals(FAQAllYouNeed.getText(), FAQAllYouNeedText,"Couldn't found expected message");
    }

    @Then("^Verify HUB Video in FAQs$")
    public void verify_HUB_Video_in_FAQs() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	if(!FAQVideo.isPresent())
 			throw new AssertionError("Scotia Bank FAQ Video is not present");
    }

    @Then("^Verify the \"([^\"]*)\" About Home in FAQs$")
    public void verify_the_About_Home_in_FAQs(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	String testCaseID = Utility.getScenarioID();
    	String FAQGeneralText=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "HubPreIngestion_ExpectedData", testCaseID, arg1);
    	wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(FAQGeneral));
    	Assert.assertEquals(FAQGeneral.getText(), FAQGeneralText,"Couldn't found expected message");
    }

    @Then("^Verify the \"([^\"]*)\" CoApplicant in FAQs$")
    public void verify_the_CoApplicant_in_FAQs(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	String testCaseID = Utility.getScenarioID();
    	String FAQCoApplicantsText=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "HubPreIngestion_ExpectedData", testCaseID, arg1);
    	wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(FAQCoApplicants));
    	Assert.assertEquals(FAQCoApplicants.getText(), FAQCoApplicantsText,"Couldn't found expected message");
    }

    @Then("^Verify the \"([^\"]*)\" Status Updates in FAQs$")
    public void verify_the_Status_Updates_in_FAQs(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	String testCaseID = Utility.getScenarioID();
    	String FAQStatusUpdatesText=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "HubPreIngestion_ExpectedData", testCaseID, arg1);
    	wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(FAQStatusUpdates));
    	Assert.assertEquals(FAQStatusUpdates.getText(), FAQStatusUpdatesText,"Couldn't found expected message");
    }

    @Then("^Verify the \"([^\"]*)\" get in touch in FAQs$")
    public void verify_the_get_in_touch_in_FAQs(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	String testCaseID = Utility.getScenarioID();
    	String FAQGettingInTouchText=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "HubPreIngestion_ExpectedData", testCaseID, arg1);
    	wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(FAQGettingInTouch));
    	Assert.assertEquals(FAQGettingInTouch.getText(), FAQGettingInTouchText,"Couldn't found expected message");
    }

    @Then("^Verify the \"([^\"]*)\" cant find in FAQs$")
    public void verify_the_cant_find_in_FAQs(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	String testCaseID = Utility.getScenarioID();
    	String FAQCanText=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "HubPreIngestion_ExpectedData", testCaseID, arg1);
    	wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(FAQCan));
    	Assert.assertEquals(FAQCan.getText(), FAQCanText,"Couldn't found expected message");
    }

    @Then("^Verify the \"([^\"]*)\" Give us in FAQs$")
    public void verify_the_Give_us_in_FAQs(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	String testCaseID = Utility.getScenarioID();
    	String FAQGiveUsACallText=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "HubPreIngestion_ExpectedData", testCaseID, arg1);
    	wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(FAQGiveUsACall));
    	Assert.assertEquals(FAQGiveUsACall.getText(), FAQGiveUsACallText,"Couldn't found expected message");
    }
    

    @When("^clicks \"([^\"]*)\" in FAQs$")
    public void clicks_in_FAQs(String arg1) throws Throwable {
    	// Write code here that turns the phrase above into concrete actions
    	String testCaseID = Utility.getScenarioID();
    	String FAQText=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "HubPreIngestion_ExpectedData", testCaseID, arg1);
    	if(FAQText.equalsIgnoreCase("General – about eHOME"))
    	{
    		FAQGeneral.click();
    	}
    	if(FAQText.equalsIgnoreCase("Co-applicants"))
    	{
    		FAQCoApplicants.click();
    	}
    	if(FAQText.equalsIgnoreCase("Status updates and notifications"))
    	{
    		FAQStatusUpdates.click();
    	}
    	if(FAQText.equalsIgnoreCase("Getting in touch"))
    	{
    		FAQGettingInTouch.click();
    	}
    }

    @Then("^\"([^\"]*)\" FAQs should come up$")
    public void faqs_should_come_up(String arg1) throws Throwable {
    	// Write code here that turns the phrase above into concrete actions
    	String testCaseID = Utility.getScenarioID();
    	String FAQContentText=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "HubPreIngestion_ExpectedData", testCaseID, arg1);
    	if(FAQContentText.equalsIgnoreCase("General – about eHOME"))
    	{
    		if(!FAQGeneralPage.isPresent())
    			throw new AssertionError("Scotia Bank FAQ is not present");
    	}
    	if(FAQContentText.equalsIgnoreCase("Co-applicants"))
    	{
    		if(!FAQCoApplicantPage.isPresent())
    			throw new AssertionError("Scotia Bank FAQ is not present");
    	}
    	if(FAQContentText.equalsIgnoreCase("Status updates and notifications"))
    	{
    		if(!FAQStatusUpdatesPage.isPresent())
    			throw new AssertionError("Scotia Bank FAQ is not present");
    	}
    	if(FAQContentText.equalsIgnoreCase("Getting in touch"))
    	{
    		if(!FAQGettingInTouchPage.isPresent())
    			throw new AssertionError("Scotia Bank FAQ is not present");
    	}
    }
    
    @When("^clicks \"([^\"]*)\" from \"([^\"]*)\" in FAQs$")
    public void clicks_from_in_FAQs(String arg1, String arg2) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	String testCaseID = Utility.getScenarioID();
    	String FAQQsText=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "HubPreIngestion_ExpectedData", testCaseID, arg1);
    	String FAQPageText=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "HubPreIngestion_ExpectedData", testCaseID, arg2);
    	
    	if(FAQPageText.equalsIgnoreCase("General – about eHOME"))
    	{
    		if(FAQQsText.equalsIgnoreCase("FirstQuestion"))
    		{
    			FAQGeneralPageQ1.click();
    		}
    		if(FAQQsText.equalsIgnoreCase("SecondQuestion"))
    		{
    			FAQGeneralPageQ2.click();
    		}
    		if(FAQQsText.equalsIgnoreCase("ThirdQuestion"))
    		{
    			FAQGeneralPageQ3.click();
    		}
    		if(FAQQsText.equalsIgnoreCase("ForthQuestion"))
    		{
    			FAQGeneralPageQ4.click();
    		}
    		if(FAQQsText.equalsIgnoreCase("FifthQuestion"))
    		{
    			FAQGeneralPageQ5.click();
    		}
    		if(FAQQsText.equalsIgnoreCase("SixthQuestion"))
    		{
    			FAQGeneralPageQ6.click();
    		}
    		if(FAQQsText.equalsIgnoreCase("SeventhQuestion"))
    		{
    			FAQGeneralPageQ7.click();
    		}
    	}
    	if(FAQPageText.equalsIgnoreCase("Co-applicants"))
    	{
    		if(FAQQsText.equalsIgnoreCase("FirstQuestion"))
    		{
    			FAQCoApplicantsQ1.click();
    		}
    		if(FAQQsText.equalsIgnoreCase("SecondQuestion"))
    		{
    			FAQCoApplicantsQ2.click();
    		}
    		if(FAQQsText.equalsIgnoreCase("ThirdQuestion"))
    		{
    			FAQCoApplicantsQ3.click();
    		}
    	}
    	if(FAQPageText.equalsIgnoreCase("Status updates and notifications"))
    	{
    		if(FAQQsText.equalsIgnoreCase("FirstQuestion"))
    		{
    			FAQStatusPagesQ1.click();
    		}
    		if(FAQQsText.equalsIgnoreCase("SecondQuestion"))
    		{
    			FAQStatusPagesQ2.click();
    		}
    		if(FAQQsText.equalsIgnoreCase("ThirdQuestion"))
    		{
    			FAQStatusPagesQ3.click();
    		}
    		if(FAQQsText.equalsIgnoreCase("ForthQuestion"))
    		{
    			FAQStatusPagesQ4.click();
    		}
    		if(FAQQsText.equalsIgnoreCase("FifthQuestion"))
    		{
    			FAQStatusPagesQ5.click();
    		}
    	}
    	if(FAQPageText.equalsIgnoreCase("Getting in touch"))
    	{
    		if(FAQQsText.equalsIgnoreCase("FirstQuestion"))
    		{
    			FAQGettingIntouchPagesQ1.click();
    		}
    		if(FAQQsText.equalsIgnoreCase("SecondQuestion"))
    		{
    			FAQGettingIntouchPagesQ2.click();
    		}
    	}
	}
    
    @Then("^Verify \"([^\"]*)\" content from \"([^\"]*)\" in \"([^\"]*)\" FAQs$")
    public void verify_content_from_in_FAQs(String arg1, String arg2, String arg3) throws Throwable {
    	String testCaseID = Utility.getScenarioID();
    	String FAQPageContentText=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "HubPreIngestion_ExpectedData", testCaseID, arg1);
    	String FAQQsText=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "HubPreIngestion_ExpectedData", testCaseID, arg2);
    	String FAQPageText=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "HubPreIngestion_ExpectedData", testCaseID, arg3);
    	if(FAQPageText.equalsIgnoreCase("General – about eHOME"))
		{
    		if(FAQQsText.equalsIgnoreCase("FirstQuestion"))
    		{
    			wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(FAQGeneralPage1Content));
    			Assert.assertEquals(FAQGeneralPage1Content.getText(), FAQPageContentText,"Couldn't found expected message");
    		}
    		if(FAQQsText.equalsIgnoreCase("SecondQuestion"))
    		{
    			wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(FAQGeneralPage2Content));
    			Assert.assertEquals(FAQGeneralPage2Content.getText(), FAQPageContentText,"Couldn't found expected message");
    		}
    		if(FAQQsText.equalsIgnoreCase("ThirdQuestion"))
    		{
    			wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(FAQGeneralPage3Content));
    			Assert.assertEquals(FAQGeneralPage3Content.getText(), FAQPageContentText,"Couldn't found expected message");
    		}
    		if(FAQQsText.equalsIgnoreCase("ForthQuestion"))
    		{
    			wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(FAQGeneralPage4Content));
    			Assert.assertEquals(FAQGeneralPage4Content.getText(), FAQPageContentText,"Couldn't found expected message");
    		}
    		if(FAQQsText.equalsIgnoreCase("FifthQuestion"))
    		{
    			wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(FAQGeneralPage5Content));
    			Assert.assertEquals(FAQGeneralPage5Content.getText(), FAQPageContentText,"Couldn't found expected message");
    		}
    		if(FAQQsText.equalsIgnoreCase("SixthQuestion"))
    		{
    			wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(FAQGeneralPage6Content));
    			Assert.assertEquals(FAQGeneralPage6Content.getText(), FAQPageContentText,"Couldn't found expected message");
    		}
    		if(FAQQsText.equalsIgnoreCase("SeventhQuestion"))
    		{
    			wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(FAQGeneralPage7Content));
    			Assert.assertEquals(FAQGeneralPage7Content.getText(), FAQPageContentText,"Couldn't found expected message");
    		}
		}
    	if(FAQPageText.equalsIgnoreCase("Co-applicants"))
		{
    		if(FAQQsText.equalsIgnoreCase("FirstQuestion"))
    		{
    			wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(FAQCoApplicantsPage1Content));
    			Assert.assertEquals(FAQCoApplicantsPage1Content.getText(), FAQPageContentText,"Couldn't found expected message");
    		}
    		if(FAQQsText.equalsIgnoreCase("SecondQuestion"))
    		{
    			wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(FAQCoApplicantsPage2Content));
    			Assert.assertEquals(FAQCoApplicantsPage2Content.getText(), FAQPageContentText,"Couldn't found expected message");
    		}
    		if(FAQQsText.equalsIgnoreCase("ThirdQuestion"))
    		{
    			wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(FAQCoApplicantsPage3Content));
    			Assert.assertEquals(FAQCoApplicantsPage3Content.getText(), FAQPageContentText,"Couldn't found expected message");
    		}
		}
    	if(FAQPageText.equalsIgnoreCase("Status updates and notifications"))
		{
    		if(FAQQsText.equalsIgnoreCase("FirstQuestion"))
    		{
    			wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(FAQStatusPagesPage1Content));
    			Assert.assertEquals(FAQStatusPagesPage1Content.getText(), FAQPageContentText,"Couldn't found expected message");
    		}
    		if(FAQQsText.equalsIgnoreCase("SecondQuestion"))
    		{
    			wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(FAQStatusPagesPage2Content));
    			Assert.assertEquals(FAQStatusPagesPage2Content.getText(), FAQPageContentText,"Couldn't found expected message");
    		}
    		if(FAQQsText.equalsIgnoreCase("ThirdQuestion"))
    		{
    			wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(FAQStatusPagesPage3Content));
    			Assert.assertEquals(FAQStatusPagesPage3Content.getText(), FAQPageContentText,"Couldn't found expected message");
    		}
    		if(FAQQsText.equalsIgnoreCase("ForthQuestion"))
    		{
    			wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(FAQStatusPagesPage4Content));
    			Assert.assertEquals(FAQStatusPagesPage4Content.getText(), FAQPageContentText,"Couldn't found expected message");
    		}
    		if(FAQQsText.equalsIgnoreCase("FifthQuestion"))
    		{
    			wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(FAQStatusPagesPage5Content));
    			Assert.assertEquals(FAQStatusPagesPage5Content.getText(), FAQPageContentText,"Couldn't found expected message");
    		}
		} 
    	if(FAQPageText.equalsIgnoreCase("Getting in touch"))
		{
    		if(FAQQsText.equalsIgnoreCase("FirstQuestion"))
    		{
    			wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(FAQGettingIntouchPage1Content));
    			Assert.assertEquals(FAQGettingIntouchPage1Content.getText(), FAQPageContentText,"Couldn't found expected message");
    		}
    		if(FAQQsText.equalsIgnoreCase("SecondQuestion"))
    		{
    			wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(FAQGettingIntouchPage2Content));
    			Assert.assertEquals(FAQGettingIntouchPage2Content.getText(), FAQPageContentText,"Couldn't found expected message");
    		}
		}
    }
    
    @When("^customer clicks on co-applicant details screen$")
    public void customer_clicks_on_co_applicant_details_screen() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
   		sidebar.click();
   		EditPersonalDetails.click();
   		Thread.sleep(3000);
   		CoAppdetailstab.click();
    }

    @Then("^Verify \"([^\"]*)\" text in co-applicant on Hub PreIngestion Screen$")
    public void verify_text_in_co_applicant_on_Hub_PreIngestion_Screen(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	String testCaseID = Utility.getScenarioID();
		String WewillinviteText=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "HubPreIngestion_ExpectedData", testCaseID, arg1);
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(WewillinviteTxt));
		Assert.assertEquals(WewillinviteTxt.getText(), WewillinviteText,"Couldn't found expected message");
    }

    @Then("^Verify first name in co-applicant on Hub PreIngestion Screen$")
    public void verify_first_name_in_co_applicant_on_Hub_PreIngestion_Screen() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(LegalFirstNameTxt));
 		if(!LegalFirstNameTxt.isPresent())
 			throw new AssertionError("Scotia Bank LegalFirstNameTxt is not present");
    }

    @Then("^Verify last name in co-applicant on Hub PreIngestion Screen$")
    public void verify_last_name_in_co_applicant_on_Hub_PreIngestion_Screen() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(LegalLastNameTxt));
 		if(!LegalLastNameTxt.isPresent())
 			throw new AssertionError("Scotia Bank LegalLastNameTxt is not present");
    }

    @Then("^Verify email in co-applicant on Hub PreIngestion Screen$")
    public void verify_email_in_co_applicant_on_Hub_PreIngestion_Screen() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(LegalEmailTxt));
 		if(!LegalEmailTxt.isPresent())
 			throw new AssertionError("Scotia Bank LegalEmailTxt is not present");
    }

    @Then("^Verify Save button in co-applicant on Hub PreIngestion Screen$")
    public void verify_Save_button_in_co_applicant_on_Hub_PreIngestion_Screen() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(LegalSave));
 		if(!LegalSave.isPresent())
 			throw new AssertionError("Scotia Bank LegalSave is not present");
    }

    @Then("^Verify Delete button in co-applicant on Hub PreIngestion Screen$")
    public void verify_Delete_button_in_co_applicant_on_Hub_PreIngestion_Screen() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(LegalDelete));
 		if(!LegalDelete.isPresent())
 			throw new AssertionError("Scotia Bank LegalDelete is not present");
    }
    
    @When("^customer edits \"([^\"]*)\" first name on co-applicant details screen$")
    public void customer_edits_first_name_on_co_applicant_details_screen(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	sidebar.click();
    	Thread.sleep(2000);
   		EditPersonalDetails.click();
   		Thread.sleep(3000);
   		CoAppdetailstab.click();
    	Thread.sleep(130000);
    	String testCaseID = Utility.getScenarioID();
		String LegalFirstNameText=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "HubPreIngestion_ExpectedData", testCaseID, arg1);
		firstNameVal.sendKeys("");
		Thread.sleep(2000);
		firstNameVal.sendKeys(LegalFirstNameText);
		Thread.sleep(2000);
		LegalSave.click();
   }

    @Then("^customer should able to edit \"([^\"]*)\" first name on co-applicant details screen$")
    public void customer_should_able_to_edit_first_name_on_co_applicant_details_screen(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	sidebar.click();
   		EditPersonalDetails.click();
   		Thread.sleep(3000);
   		CoAppdetailstab.click();
   		Thread.sleep(3000);
   		String testCaseID = Utility.getScenarioID();
		String LegalFirstNameText=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "HubPreIngestion_ExpectedData", testCaseID, arg1);
   		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(LegalFirstNameTxt));
		Assert.assertEquals(LegalFirstNameTxt.getText(), LegalFirstNameText,"Couldn't found expected message");
    }
}    
//lastNameVal
//emailAddressVal
	



















