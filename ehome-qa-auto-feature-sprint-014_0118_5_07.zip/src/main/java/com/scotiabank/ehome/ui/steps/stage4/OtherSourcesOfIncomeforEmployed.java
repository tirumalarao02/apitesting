package com.scotiabank.ehome.ui.steps.stage4;
import com.qmetry.qaf.automation.step.QAFTestStepProvider;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebDriver;
import com.quantum.java.pages.ExtentReportHelper;
import com.quantum.utils.ConfigurationUtils;
import com.scotiabank.ehome.ui.steps.Common;
import com.scotiabank.ehome.ui.steps.CommonAppMethodsAssetLiabilities;
import com.scotiabank.ehome.ui.steps.CommonAppMethodsEmployment;
import com.scotiabank.ehome.ui.steps.CommonApplicationMethods;
import com.scotiabank.ehome.ui.steps.Utility;
import com.scotiabank.ehome.ui.steps.coApp.CoAppIntro;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.support.ui.WebDriverWait;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;

import java.util.Map;
import java.util.concurrent.TimeUnit;
import static com.scotiabank.ehome.ui.steps.Utility.*;

@QAFTestStepProvider

public class OtherSourcesOfIncomeforEmployed {
	public static WebDriverWait wait=Utility.getWait();
	  static String curDir = System.getProperty("user.dir");
	  static String strfullPathToFile = curDir + "\\src\\main\\resources\\data\\eHomeTestData.xlsx"; // File Path
		
	  static String sheetStage04_InputData ="Stage04_Employment_InputData";
	  static String sheetStage04_ExpectedData ="Stage04_Employment_ExpectedData";
	  static String sheetStage05_ExpectedData ="Stage05_AsetLiblty_ExpectedData";
	  
	  //String strtestCaseID = "OtherSourcesOfIncome-Employed-TC-026";
	  String strtestCaseID = Utility.getScenarioID();
	  
	  @Given("^Customer should login and navigates to 'Other Sources Of Income' Screen$")
	  public void customer_should_login_and_navigates_to_Other_Sources_Of_Income_Screen() throws Throwable {
		  if (strtestCaseID.contains("CoApp"))
		  {
			  Common.TraverseToNewHomeSectionBreaker();
			  Thread.sleep(10000);
			  Common.TraverseFromNewHomeToRateSectionBreaker(strtestCaseID,"Co-App_InputData");
			  Common.TraverseRateSectionToEmploymentSectionBreaker();
			  Common.TraverseFromEmploymentSectionToLandOnCoApplicantPage();
			  CoAppIntro.startSectionButtonClicked();
		  }
		  else
		  {
			  Utility.launchURL(ConfigurationUtils.getBaseBundle().getPropertyValue ("env.baseurl2"));
			  Common.sessionBreakerContinueButtonClick();

		  }
		  Map<String, String> Stage04_InputData =  Utility.readTestData(strfullPathToFile, sheetStage04_InputData,strtestCaseID);
			  
		  String strCurrentEmpStatus	= Stage04_InputData.get("Empmt_Status");
		  String strEmploymentType = Stage04_InputData.get("Empmt_Type");
		  String strDurationYear=  Stage04_InputData.get("Years");
		  String strDurationMonth=  Stage04_InputData.get("Months");
		  String strFieldOfWork=  Stage04_InputData.get("EmploymentFieldOfWork");
		  String strJobTitle=  Stage04_InputData.get("EmploymentJobTitle");
		

		  if (strCurrentEmpStatus.contentEquals("Employed")) {                // Selecting current Employment Status
			  CommonAppMethodsEmployment.SelectEmpStatus(strCurrentEmpStatus);
			  Thread.sleep(4000);
			  if (strEmploymentType.contentEquals("Commissioned sales")) {             // Selecting Employment Type
				  CommonAppMethodsEmployment.SelectEmpType("Commissioned sales");}
			  else if (strEmploymentType.contentEquals("Contract")) {
				  CommonAppMethodsEmployment.SelectEmpType("Contract");}
			  else if (strEmploymentType.contentEquals("Full Time")) {
				  CommonAppMethodsEmployment.SelectEmpType("Full Time");}
			  else if (strEmploymentType.contentEquals("Part Time")) {
				  CommonAppMethodsEmployment.SelectEmpType("Part Time");}
			  else if (strEmploymentType.contentEquals("Seasonal")) {
				  CommonAppMethodsEmployment.SelectEmpType("Seasonal");}
			  Thread.sleep(2000);
		 		
			  CommonApplicationMethods.selectValuefromDropDownListBox("ehome.industryAndJObTitle.jobField", strFieldOfWork); // Selecting Field of work
			  Thread.sleep(1000);
			  CommonApplicationMethods.selectValuefromDropDownListBox("ehome.industryAndJObTitle.jobTitle", strJobTitle);    // Selecting Job Title
			  Common.continueButtonClicked();
			  Thread.sleep(1000);
			  
			  if (strtestCaseID.contains("CoApp")){
				  Utility.sendKeys("ehome.employmentNameAndPhone.coAppEmploymentName","Scotia Bank");
				  Utility.sendKeys("ehome.employmentNameAndPhone.coAppEmploymentPhoneName","6471234567");
			  }
			  else {
				  Utility.sendKeys("ehome.employmentNameAndPhone.employmentName","Scotia Bank");
				  Utility.sendKeys("ehome.employmentNameAndPhone.employmentPhoneName","6471234567");
			  }
			  Thread.sleep(1000);
			  Common.continueButtonClicked();
			  Thread.sleep(500);
				
			  CommonApplicationMethods.enterAutoSuggestAddress("888 Birch","ehome.employeraddress.address","//ul[@id='address-lookup__results-list']" );
			  Thread.sleep(1000);
			  Common.continueButtonClicked();
			  Thread.sleep(1000);				
			  Utility.sendKeys("ehome.annualIncome.salary", "120000");
			  Utility.sendKeys("ehome.annualIncome.bonus", "9000");
			  Utility.sendKeys("ehome.annualIncome.overtime", "50000");
			  Thread.sleep(1000);
			  Common.continueButtonClicked();
			  Thread.sleep(1000);
		 	}
			if (strtestCaseID.contains("CoApp")){
				if (strDurationYear != "") {
					CommonApplicationMethods.selectValuefromDropDownListBox("ehome.coapp.RetirementDuration.years", strDurationYear);
					Thread.sleep(250);
				}
				if (strDurationMonth != "") {
					CommonApplicationMethods.selectValuefromDropDownListBox("ehome.coapp.RetirementDuration.months", strDurationMonth);
					Thread.sleep(250);
				}
				Common.continueButtonClicked();
				Thread.sleep(250);
			}
		 	else
			{
		 	if (strDurationYear != "") {
				CommonApplicationMethods.selectValuefromDropDownListBox("ehome.employmentDuration.years", strDurationYear);
					Thread.sleep(250);
			}
			if (strDurationMonth != "") {
				CommonApplicationMethods.selectValuefromDropDownListBox("ehome.employmentDuration.months", strDurationMonth);
				Thread.sleep(250);
			}
			Common.continueButtonClicked();
			Thread.sleep(250);
			}
	  }
	  @Then("^Verify 'Other Sources Of Income' Screen and presence of all objects on 'Other Sources Of Income' Screen$")
		public void Verify_Other_Sources_Of_Income_Screen_and_presence_of_all_objects_on_Other_Sources_Of_Income_Screen() throws Throwable {
		  
		  Map<String, String> Stage04_ExpectedData =  Utility.readTestData(strfullPathToFile, sheetStage04_ExpectedData,strtestCaseID);

		  String strSrcOfInc_Header_ExpectedTitle	= Stage04_ExpectedData.get("OtherSourceOfIncome_Header_title");
		  String strSrcOfInc_Please_Select_All_Expectedlabel	= Stage04_ExpectedData.get("OtherSourceOfIncome_Please_Select_All_label");

		  if (strtestCaseID.contains("CoApp")){
			  Utility.verifyIsObjectPresent("ehome.otherSrcsOfInc.MaternalPaternalLeave", "Maternity/Parental Leave Button");
		  }
		  else
		  {
			  Utility.verifyIsTextPresent("ehome.otherSrcsOfIncome.SrcOfIncomeTitle", "Heading Centre Text", strSrcOfInc_Header_ExpectedTitle);
		  }
		  Utility.verifyIsObjectPresent("ehome.otherSrcsOfInc.ChildSupport", "ChildSupport Button");
		  Utility.verifyIsObjectPresent("ehome.otherSrcsOfInc.Commission", "Commission Button");
		  Utility.verifyIsObjectPresent("ehome.otherSrcsOfInc.Investments", "Investments Button");
		  Utility.verifyIsObjectPresent("ehome.otherSrcsOfInc.PartTimeWork", "PartTimeWork Button");
		  Utility.verifyIsObjectPresent("ehome.otherSrcsOfInc.PensionDisability", "PensionDisability Button");
		  Utility.verifyIsObjectPresent("ehome.otherSrcsOfInc.RIFLIF", "RIFLIF Button");
		  Utility.verifyIsObjectPresent("ehome.otherSrcsOfInc.SeasonalWork", "SeasonalWork Button");
		  Utility.verifyIsObjectPresent("ehome.otherSrcsOfInc.SpousalSupport", "SpousalSupport Button");
		  Utility.verifyIsObjectPresent("ehome.otherSrcsOfInc.NoSrcOfInc.Link", "Button");
		  Utility.verifyIsObjectPresent("ehome.otherSrcsOfInc.Back", "Button");

		  Utility.verifyIsTextPresent("ehome.otherSrcsOfInc.PleaseSelectAll_Label", "Row Centre Label", strSrcOfInc_Please_Select_All_Expectedlabel);
	  }
	
		@Then("^Verify 'How long have you worked at Scotia Bank' Screen when Click on 'Back' button on 'Other Sources Of Income' Screen$")
		public void Verify_How_long_have_you_worked_at_Scotia_Bank_Screen_when_Click_on_Back_button_on_Other_Sources_Of_Income_Screen() throws Throwable {
			
			  Map<String, String> Stage04_ExpectedData =  Utility.readTestData(strfullPathToFile, sheetStage04_ExpectedData,strtestCaseID);
			  String strHow_long_have_you_worked_ExpectedTitle	= Stage04_ExpectedData.get("How_long_have_you_worked_Title");
			  if (strtestCaseID.contains("CoApp")){
				  Utility.clickObject("ehome.otherSrcsOfInc.Back", "Back Button in Asset Sources");
				  Thread.sleep(1000);
				  Utility.verifyIsObjectPresent("ehome.coAppHowLongHaveYou.Title", "Title");
			  }
			  else {
				  Utility.clickObject("ehome.otherSrcsOfInc.Back", "Back Button in Asset Sources");
				  Thread.sleep(1000);
				  Utility.verifyIsTextPresent("ehome.HowLongHaveYou.Title", "Heading Centre Text", strHow_long_have_you_worked_ExpectedTitle);
			  }
			}
		
	
		@When("^Select 'No Source of income' or 'Any Other Sources Of Income' on 'Other Sources Of Income' Screen$")
		public void Select_NoSourceofincome_or_Any_Other_Sources_Of_Income_on_Other_Sources_Of_Income_Screen() throws Throwable {


	  	Map<String, String> Stage04_InputData =  Utility.readTestData(strfullPathToFile, sheetStage04_InputData,strtestCaseID);
	
		  	String strNoOtherSrcOfInc_Input = Stage04_InputData.get("EmpOtherSrcsOfIncome_NoOtherSrcOfInc");
			String strChildSupport_Input = Stage04_InputData.get("EmpOtherSrcsOfIncome_ChildSupport");
			String strCommission_Input = Stage04_InputData.get("EmpOtherSrcsOfIncome_Commission");
			String strInvestments_Input = Stage04_InputData.get("EmpOtherSrcsOfIncome_Investments");
			String strPartTimeWork_Input = Stage04_InputData.get("EmpOtherSrcsOfIncome_PartTimeWork");
			String strPensionDisability_Input = Stage04_InputData.get("EmpOtherSrcsOfIncome_PensionDisability");
			String strRIFLIF_Input = Stage04_InputData.get("EmpOtherSrcsOfIncome_RIFLIF");
			String strSeasonalWork_Input = Stage04_InputData.get("EmpOtherSrcsOfIncome_SeasonalWork");
			String strSpousalSupport_Input = Stage04_InputData.get("EmpOtherSrcsOfIncome_SpousalSupport");
				
			if (strChildSupport_Input.contentEquals("Child support")) {
				CommonAppMethodsEmployment.SelectOtherSourcesOfIncome(strChildSupport_Input);
				}
			if (strCommission_Input.contentEquals("Commission")) {
				CommonAppMethodsEmployment.SelectOtherSourcesOfIncome(strCommission_Input);
				}
			if (strInvestments_Input.contentEquals("Investments")) {
				CommonAppMethodsEmployment.SelectOtherSourcesOfIncome(strInvestments_Input);
				}
			if (!(strtestCaseID.contentEquals("CoAppOtherSourcesOfIncomeDetails-Employed-TC-004")))
			{CommonAppMethodsEmployment.SelectOtherSourcesOfIncome("Maternity/Parental Leave");}
			if (strPartTimeWork_Input.contentEquals("Part time work")) {
				CommonAppMethodsEmployment.SelectOtherSourcesOfIncome(strPartTimeWork_Input);
				}
			if (strPensionDisability_Input.contentEquals("Pension/Disability")) {
				CommonAppMethodsEmployment.SelectOtherSourcesOfIncome(strPensionDisability_Input);
				}
			if (strRIFLIF_Input.contentEquals("RIF/LIF")) {
				CommonAppMethodsEmployment.SelectOtherSourcesOfIncome(strRIFLIF_Input);
				}
			if (strSeasonalWork_Input.contentEquals("Seasonal work")) {
				CommonAppMethodsEmployment.SelectOtherSourcesOfIncome(strSeasonalWork_Input);
				}
			if (strSpousalSupport_Input.contentEquals("Spousal support")) {
				CommonAppMethodsEmployment.SelectOtherSourcesOfIncome(strSpousalSupport_Input);
				}
			if (strNoOtherSrcOfInc_Input.contentEquals("No other sources of income")) {
				CommonAppMethodsEmployment.SelectOtherSourcesOfIncome(strNoOtherSrcOfInc_Input);
				}
		}

		@When("^Verify 'Annual income for each source' screen when select 'Source of income' on 'Other Sources Of Income' Screen$")
		public void Verify_Annual_income_for_each_source_Screen_when_Select_Src_Of_Income_And_click_on_Continue_button_on_Other_Sources_Of_Income_Screen() throws Throwable {

			Common.continueButtonClicked();

			if (strtestCaseID.contains("CoApp")){
			String Title = Utility.getDriver().findElement("ehome.coAppOtherIncomeSrcDetails.Title").getText();
			if (!(Title.contains("other sources of income")))
				throw new AssertionError("Title is not correct");
			}
			else {
				Map<String, String> Stage04_ExpectedData = Utility.readTestData(strfullPathToFile, sheetStage04_ExpectedData, strtestCaseID);
				String strOtherIncomeSrcDetails_ExpectedTitle = Stage04_ExpectedData.get("Other_Srcs_income_details_Title");
				Utility.verifyIsTextPresent("ehome.otherIncomeSrcDetails.Title", "Heading Centre Text", strOtherIncomeSrcDetails_ExpectedTitle);
			}
		}
	
		@When("^Verify 'Asset-section-breaker' Screen when select 'No Source of income' on 'Other Sources Of Income' Screen$")
		public void Verify_AssetSectionbreaker_Screen_when_select_No_Source_of_income_on_Other_Sources_Of_Income_Screen() throws Throwable {

	  	Map<String, String> Stage05_ExpectedData =  Utility.readTestData(strfullPathToFile, sheetStage05_ExpectedData,strtestCaseID);
			String strAssetSectionBrkr_ExpectedTitle = Stage05_ExpectedData.get("Asset_Section_Breaker_Title");
			Utility.verifyIsTextPresent("ehome.assetSectionBrkr.Title", "Heading Centre Text", strAssetSectionBrkr_ExpectedTitle);
		}

		@When("^Verify presence of 'Remove' 'Continue' Options when 'Select' 'Any Sources Of Income' on 'Sources Of Income' Screen$")
		public void Verify_presence_of_Remove_Continue_Options_when_Select_Any_Sources_Of_Income_on_Sources_Of_Income_Screen() throws Throwable {
				
			  Utility.verifyIsObjectPresent("ehome.otherSrcsOfInc.ChildSupportRemove", "ChildSupport Remove Button");
			  Utility.verifyIsObjectPresent("ehome.otherSrcsOfInc.CommissionRemove", "Commission Remove Button");
			  Utility.verifyIsObjectPresent("ehome.otherSrcsOfInc.InvestmentsRemove", "Investments Remove Button");
			  Utility.verifyIsObjectPresent("ehome.otherSrcsOfInc.PartTimeWorkRemove", "PartTimeWork Remove Button");
			  Utility.verifyIsObjectPresent("ehome.otherSrcsOfInc.PensionDisabilityRemove", "PensionDisability Remove Button");
			  Utility.verifyIsObjectPresent("ehome.otherSrcsOfInc.RIFLIFRemove", "RIFLIF Remove Button");
			  Utility.verifyIsObjectPresent("ehome.otherSrcsOfInc.SeasonalWorkRemove", "SeasonalWork Remove Button");
			  Utility.verifyIsObjectPresent("ehome.otherSrcsOfInc.SpousalSupportRemove", "SpousalSupport Remove Button");
			  Utility.verifyIsObjectPresent("ehome.Continue.button", "Continue Button");
		}		
		
		@When("^UnSelect 'No Source of income' or 'Any Other Sources Of Income' on 'Other Sources Of Income' Screen$")
		public void UnSelect_NoSourceofincome_or_Any_Other_Sources_Of_Income_on_Other_Sources_Of_Income_Screen() throws Throwable {
		  Map<String, String> Stage04_InputData =  Utility.readTestData(strfullPathToFile, sheetStage04_InputData,strtestCaseID);
	
		  	String strNoOtherSrcOfInc_Input = Stage04_InputData.get("EmpOtherSrcsOfIncome_NoOtherSrcOfInc");
			String strChildSupport_Input = Stage04_InputData.get("EmpOtherSrcsOfIncome_ChildSupport");
			String strCommission_Input = Stage04_InputData.get("EmpOtherSrcsOfIncome_Commission");
			String strInvestments_Input = Stage04_InputData.get("EmpOtherSrcsOfIncome_Investments");
			String strPartTimeWork_Input = Stage04_InputData.get("EmpOtherSrcsOfIncome_PartTimeWork");
			String strPensionDisability_Input = Stage04_InputData.get("EmpOtherSrcsOfIncome_PensionDisability");
			String strRIFLIF_Input = Stage04_InputData.get("EmpOtherSrcsOfIncome_RIFLIF");
			String strSeasonalWork_Input = Stage04_InputData.get("EmpOtherSrcsOfIncome_SeasonalWork");
			String strSpousalSupport_Input = Stage04_InputData.get("EmpOtherSrcsOfIncome_SpousalSupport");
				
			if (strChildSupport_Input.contentEquals("Child support")) {
				CommonAppMethodsEmployment.UnSelectOtherSourcesOfIncome(strChildSupport_Input);
				}
			if (strCommission_Input.contentEquals("Commission")) {
				CommonAppMethodsEmployment.UnSelectOtherSourcesOfIncome(strCommission_Input);
				}
			if (strInvestments_Input.contentEquals("Investments")) {
				CommonAppMethodsEmployment.UnSelectOtherSourcesOfIncome(strInvestments_Input);
				}
			if (strPartTimeWork_Input.contentEquals("Part time work")) {
				CommonAppMethodsEmployment.UnSelectOtherSourcesOfIncome(strPartTimeWork_Input);
				}
			if (strPensionDisability_Input.contentEquals("Pension/Disability")) {
				CommonAppMethodsEmployment.UnSelectOtherSourcesOfIncome(strPensionDisability_Input);
				}
			if (strRIFLIF_Input.contentEquals("RIF/LIF")) {
				CommonAppMethodsEmployment.UnSelectOtherSourcesOfIncome(strRIFLIF_Input);
				}
			if (strSeasonalWork_Input.contentEquals("Seasonal work")) {
				CommonAppMethodsEmployment.UnSelectOtherSourcesOfIncome(strSeasonalWork_Input);
				}
			if (strSpousalSupport_Input.contentEquals("Spousal support")) {
				CommonAppMethodsEmployment.UnSelectOtherSourcesOfIncome(strSpousalSupport_Input);
				}
			if (strNoOtherSrcOfInc_Input.contentEquals("No other sources of income")) {
				CommonAppMethodsEmployment.UnSelectOtherSourcesOfIncome(strNoOtherSrcOfInc_Input);
				}
		}
				
		@When("^Verify presence of 'Select' 'No other sources of income' Options when 'UnSelect' 'Any Sources Of Income' on 'Sources Of Income' Screen$")
		public void Verify_presence_of_Select_No_Source_of_income_Options_when_Select_Any_Sources_Of_Income_on_Sources_Of_Income_Screen() throws Throwable {
			  Utility.verifyIsObjectPresent("ehome.otherSrcsOfInc.ChildSupport", "ChildSupport Button");
			  Utility.verifyIsObjectPresent("ehome.otherSrcsOfInc.Commission", "Commission Button");
			  Utility.verifyIsObjectPresent("ehome.otherSrcsOfInc.Investments", "Investments Button");
			  Utility.verifyIsObjectPresent("ehome.otherSrcsOfInc.PartTimeWork", "PartTimeWork Button");
			  Utility.verifyIsObjectPresent("ehome.otherSrcsOfInc.PensionDisability", "PensionDisability Button");
			  Utility.verifyIsObjectPresent("ehome.otherSrcsOfInc.RIFLIF", "RIFLIF Button");
			  Utility.verifyIsObjectPresent("ehome.otherSrcsOfInc.SeasonalWork", "SeasonalWork Button");
			  Utility.verifyIsObjectPresent("ehome.otherSrcsOfInc.SpousalSupport", "SpousalSupport Button");
			  Utility.verifyIsObjectPresent("ehome.otherSrcsOfInc.NoSrcOfInc.Link", "Button");
		}		

}
