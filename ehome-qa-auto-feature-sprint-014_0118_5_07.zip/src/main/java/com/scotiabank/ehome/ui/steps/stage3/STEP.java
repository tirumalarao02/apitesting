package com.scotiabank.ehome.ui.steps.stage3;
import com.qmetry.qaf.automation.step.QAFTestStepProvider;
import com.qmetry.qaf.automation.ui.WebDriverTestBase;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebDriver;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.quantum.utils.ConfigurationUtils;

import com.scotiabank.ehome.ui.steps.Common;
import com.scotiabank.ehome.ui.steps.Utility;
import com.scotiabank.ehome.ui.steps.valueObjects.Tuple;
import com.scotiabank.ehome.ui.steps.valueObjects.TypeOfRateVO;
import cucumber.api.PendingException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static com.scotiabank.ehome.ui.steps.BusinessCalculations.*;
import static com.scotiabank.ehome.ui.steps.Utility.*;
@QAFTestStepProvider

public class STEP {

    private QAFExtendedWebDriver webDriver = new WebDriverTestBase().getDriver();
    public Actions action = null;
    WebDriverWait wait = new WebDriverWait(webDriver,50000);

    String testCaseID = Utility.getScenarioID();

    QAFExtendedWebElement Continue = new QAFExtendedWebElement("ehome.rate.continue.button");
    QAFExtendedWebElement ContinueinStep = new QAFExtendedWebElement("ehome.Step.Continue");
    QAFExtendedWebElement Back= new QAFExtendedWebElement("ehome.Step.Back");
    QAFExtendedWebElement whatTypeOfRate = new QAFExtendedWebElement("ehome.typeofrate.header");
    QAFExtendedWebElement selectFixed= new QAFExtendedWebElement("ehome.typeofrate.selectfixed.radio");
    QAFExtendedWebElement twoyears= new QAFExtendedWebElement("ehome.termsofrate.2years.radio");
    QAFExtendedWebElement twoyear= new QAFExtendedWebElement("ehome.ratepresentation.twoyears.select");
    QAFExtendedWebElement LockandHold= new QAFExtendedWebElement("ehome.ratelock.LockandHold");
    QAFExtendedWebElement RateCustomizationContinuebutton= new QAFExtendedWebElement("ehome.RateCustomization.Continue.Button");

    QAFExtendedWebElement StepMessage= new QAFExtendedWebElement("ehome.step.message");
    QAFExtendedWebElement ehomeStepHeader= new QAFExtendedWebElement("ehome.step.ehomestepheader");
    QAFExtendedWebElement Yourhomeispotentially= new QAFExtendedWebElement("ehome.step.ehomestepP1");
    QAFExtendedWebElement Overallborrowing= new QAFExtendedWebElement("ehome.step.help.link");

    //QAFExtendedWebElement StepHelpLink = new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[2]/div/div[4]/div/button");
    QAFExtendedWebElement StepHelpP1 = new QAFExtendedWebElement("ehome.step.help.P1");
    QAFExtendedWebElement StepHelpP2 = new QAFExtendedWebElement("ehome.step.help.P2");
    QAFExtendedWebElement StepHelpP3 = new QAFExtendedWebElement("ehome.step.help.P3");
    QAFExtendedWebElement StepHelpClose = new QAFExtendedWebElement("ehome.step.help.Close");

    QAFExtendedWebElement StepHeader= new QAFExtendedWebElement("ehome.step.header");

    QAFExtendedWebElement STEPOption1= new QAFExtendedWebElement("ehome.step.Option1");
    QAFExtendedWebElement STEPOption1Img= new QAFExtendedWebElement("ehome.step.Option1.image");
    QAFExtendedWebElement STEPOption2= new QAFExtendedWebElement("ehome.step.Option2");
    QAFExtendedWebElement STEPOption2Img= new QAFExtendedWebElement("ehome.step.Option2.image");
    QAFExtendedWebElement STEPOption3= new QAFExtendedWebElement("ehome.step.Option3");
    QAFExtendedWebElement STEPOption3Img= new QAFExtendedWebElement("ehome.step.Option3.image");
    QAFExtendedWebElement STEPOption4= new QAFExtendedWebElement("ehome.step.Option4");
    QAFExtendedWebElement STEPOption4Img= new QAFExtendedWebElement("ehome.step.Option4.image");
    QAFExtendedWebElement STEPOption5= new QAFExtendedWebElement("ehome.step.Option5");
    QAFExtendedWebElement STEPOption5Img= new QAFExtendedWebElement("ehome.step.Option5.image");
    QAFExtendedWebElement STEPOption6= new QAFExtendedWebElement("ehome.step.Option6");
    QAFExtendedWebElement STEPOption6Img= new QAFExtendedWebElement("ehome.step.Option6.image");

    QAFExtendedWebElement LOCHeader= new QAFExtendedWebElement("ehome.LOC.header");
    QAFExtendedWebElement RateCustomizationHeader= new QAFExtendedWebElement("ehome.RateCustomization.header");

    //1
    @Given("^Customer should login and navigates to Step$")
    public void Customer_should_login_and_navigates_to_STEP_screen() throws Throwable {

        Common.stage2ToStage3(testCaseID);
        Continue.click();
           if (!whatTypeOfRate.verifyText("What type of rate are you looking for?"))
               throw new AssertionError("Not able to launch what type of rate page");

           selectFixed.click ();

           if(!twoyears.verifyPresent())
               throw new AssertionError("Couldn't find 2 years button");
            Thread.sleep(2000);
           twoyears.click();

           if(!twoyear.verifyPresent())
	            throw new AssertionError("Couldn't find 2 years button");
	       twoyear.click();

           if(!LockandHold.verifyPresent())
               throw new AssertionError("Couldn't find Lock & Hold on the screen");
       LockandHold.click();

	   RateCustomizationContinuebutton.click();

}


    @When("^Verify eHome STEP Message and Header in STEP Screen$")
    public void verifyEHomeSTEPMessageAndHeaderInSTEPScreen() throws Throwable {


        String STEP_Message = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage03_Rate_ExpectedData", testCaseID, "STEP_Message");
        Assert.assertEquals(StepMessage.getText(), STEP_Message, "You'll be a STEP ahead! not present");

        String EHOME_STEP_Header = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage03_Rate_ExpectedData", testCaseID, "EHOME_STEP_Header");
        Assert.assertEquals(ehomeStepHeader.getText(), EHOME_STEP_Header, "With eHOME, your mortgage will be set up as a Scotia Total Equity not present");

        String STEP_P1 = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage03_Rate_ExpectedData", testCaseID, "STEP_P1");
        Assert.assertEquals(Yourhomeispotentially.getText(), STEP_P1, "With eHOME, your mortgage will be set up as a Scotia Total Equity not present");

    }

    @Then("^Verify STEP Help and Info section on the STEP Screen$")
    public void verifySTEPHelpAndInfoSectionOnTheSTEPScreen() throws Throwable {

        String STEP_Help_Link = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage03_Rate_ExpectedData", testCaseID, "STEP_Help_Link");
        Assert.assertEquals(Overallborrowing.getText(), STEP_Help_Link, "With eHOME, your mortgage will be set up as a Scotia Total Equity not present");

        Overallborrowing.click();

        String STEP_Help_P1 = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage03_Rate_ExpectedData", testCaseID, "STEP_Help_P1");
        Assert.assertEquals(StepHelpP1.getText(), STEP_Help_P1, "With eHOME, your mortgage will be set up as a Scotia Total Equity not present");

        String STEP_Help_P2 = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage03_Rate_ExpectedData", testCaseID, "STEP_Help_P2");
        Assert.assertEquals(StepHelpP2.getText(), STEP_Help_P2, "With eHOME, your mortgage will be set up as a Scotia Total Equity not present");

        String STEP_Help_P3 = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage03_Rate_ExpectedData", testCaseID, "STEP_Help_P3");
        Assert.assertEquals(StepHelpP3.getText(), STEP_Help_P3, "With eHOME, your mortgage will be set up as a Scotia Total Equity not present");

        StepHelpClose.click();
    }

    //2
    @Then("^Verify STEP Header and available equities in the STEP Screen$")
    public void verifySTEPHeaderAndAvailableEquitiesInTheSTEPScreen() throws Throwable {
        // Write code here that turns the phrase above into concrete actions

        String STEP_Header_1 = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage03_Rate_ExpectedData", testCaseID, "STEP_Header_1");
        Assert.assertEquals(StepHeader.getText(), STEP_Header_1, "Header not present");

        String STEP_Option1 = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage03_Rate_ExpectedData", testCaseID, "STEP_Option1");
        STEPOption1Img.isPresent();
        Assert.assertEquals(STEPOption1.getText(), STEP_Option1, "Step Option not present");

        String STEP_Option2 = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage03_Rate_ExpectedData", testCaseID, "STEP_Option2");
        STEPOption2Img.isPresent();
        Assert.assertEquals(STEPOption2.getText(), STEP_Option2, "Step Option not present");

        String STEP_Option3 = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage03_Rate_ExpectedData", testCaseID, "STEP_Option3");
        STEPOption3Img.isPresent();
        Assert.assertEquals(STEPOption3.getText(), STEP_Option3, "Step Option not present");

        String STEP_Option4 = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage03_Rate_ExpectedData", testCaseID, "STEP_Option4");
        STEPOption4Img.isPresent();
        Assert.assertEquals(STEPOption4.getText(), STEP_Option4, "Step Option not present");

        String STEP_Option5 = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage03_Rate_ExpectedData", testCaseID, "STEP_Option5");
        STEPOption5Img.isPresent();
        Assert.assertEquals(STEPOption5.getText(), STEP_Option5, "Step Option not present");

        String STEP_Option6 = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage03_Rate_ExpectedData", testCaseID, "STEP_Option6");
        STEPOption6Img.isPresent();
        Assert.assertEquals(STEPOption6.getText(), STEP_Option6, "Step Option not present");
    }

    //3
    @When("^Customer click on continue button in Step screen$")
    public void CustomerclickoncontinuebuttoninStepscreen() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        ContinueinStep.isPresent();
        ContinueinStep.click();
    }
    
    @Then("^It should navigate to LOC screen or rate-equity screen$")
    public void It_should_navigate_from_STEP_screen_to_Rate_customization_screen() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	Assert.assertEquals(LOCHeader.getText(), "With the Scotia Total Equity ® Plan, you may be eligible for a $20,000.00 secured line of credit1.");
    }
    
    //4
    @When("^Customer clicks on the Back button in Step screen$")
    public void CustomerClicksOnTheBackButtonInStepScreen() throws Throwable {
          Back.click();
    }



    @Then("^It should navigate to rate-customization screen$")
    public void itShouldNavigateToRateCustomizationScreen() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	Assert.assertEquals(RateCustomizationHeader.getText(), "Now it's time to customize your mortgage!");
        
    }

}

