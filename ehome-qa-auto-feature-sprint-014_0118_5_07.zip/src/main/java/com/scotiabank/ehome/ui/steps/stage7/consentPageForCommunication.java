package com.scotiabank.ehome.ui.steps.stage7;

import com.qmetry.qaf.automation.step.QAFTestStepProvider;
import com.qmetry.qaf.automation.ui.WebDriverTestBase;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebDriver;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.quantum.utils.ConfigurationUtils;
import com.scotiabank.ehome.ui.steps.Common;
import com.scotiabank.ehome.ui.steps.Utility;
import cucumber.api.PendingException;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import java.util.List;

@QAFTestStepProvider
public class consentPageForCommunication {
    QAFExtendedWebDriver webDriver = new WebDriverTestBase().getDriver();
    public Actions action = null;
    WebDriverWait wait = new WebDriverWait(webDriver, 50000);

    String testCaseID = Utility.getScenarioID();

    QAFExtendedWebElement AgreeAndContinueButton = new QAFExtendedWebElement("ehome.termsAndConditions.AgreeContinue");
    QAFExtendedWebElement CreditCheckHeader = new QAFExtendedWebElement("ehome.termsAndConditions.CreditCheckHeader");
    QAFExtendedWebElement CreditConsentYes = new QAFExtendedWebElement("ehome.CreditCheck.Yes");
    QAFExtendedWebElement Back = new QAFExtendedWebElement("ehome.termsAndConditions.Back");
    QAFExtendedWebElement Feedback_Page_Header = new QAFExtendedWebElement("ehome.Feedback.Page");
    QAFExtendedWebElement Communication_Title = new QAFExtendedWebElement("ehome.Communication.Title");
    QAFExtendedWebElement Communication_Content = new QAFExtendedWebElement("ehome.Communication.Content");
    QAFExtendedWebElement Communication_Checkbox = new QAFExtendedWebElement("ehome.Communication.checkbox");
    QAFExtendedWebElement ApplicationSummary_Header = new QAFExtendedWebElement("ehome.ApplicationSummary.Header");

    @Given("^Customer should login and navigates to Consent Page for Communications Page$")
    public void customerShouldLoginAndNavigatesToConsentPageForCommunicationsPage() throws Throwable {
        Utility.launchURL(ConfigurationUtils.getBaseBundle().getPropertyValue("env.baseurl3"));

        AgreeAndContinueButton.click();
        CreditConsentYes.click();

        String Feedback_PageHeader = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage07_ExpectedData", testCaseID, "Communication_Header");
        Assert.assertEquals(Feedback_Page_Header.getText(), Feedback_PageHeader, "Couldn't found Expected Text");

        String Feedback_PageTitle = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage07_ExpectedData", testCaseID, "Communication_Title");
        Assert.assertEquals(Communication_Title.getText(), Feedback_PageTitle, "Couldn't found Expected Text");

    }

    @Then("^Customer verifies the content of Consent Page for Communication on the screen$")
    public void customerVerifiesTheContentOfConsentPageForCommunicationOnTheScreen() throws Throwable {

        String Communication_Text = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage07_ExpectedData", testCaseID, "Communication_Text");
        Assert.assertEquals(Communication_Content.getText(), Communication_Text, "Couldn't found Expected Text");

    }

    @And("^Customer selects the Checkbox and click on Continue Button and navigates to Application Summary Page$")
    public void customerSelectsTheCheckboxAndClickOnContinueButtonAndNavigatesToApplicationSummaryPage() throws Throwable {
        if(!Communication_Checkbox.isSelected()){
            Communication_Checkbox.click();
        }

        Common.continueButtonClicked();

        ApplicationSummary_Header.isPresent();
    }

    @And("^Customer does not select the Checkbox and click on Continue Button and navigates to Application Summary Page$")
    public void customerDoesNotSelectTheCheckboxAndClickOnContinueButtonAndNavigatesToApplicationSummaryPage() throws Throwable {

        Common.continueButtonClicked();

        ApplicationSummary_Header.isPresent();
    }

    @And("^Customer clicks on the Back button in Consent Page for Commiunication Screen and navigated to Credit Check Page$")
    public void customerClicksOnTheBackButtonInConsentPageForCommiunicationScreenAndNavigatedToCreditCheckPage() throws Throwable {

        Back.click();
        CreditCheckHeader.isPresent();

    }
}
