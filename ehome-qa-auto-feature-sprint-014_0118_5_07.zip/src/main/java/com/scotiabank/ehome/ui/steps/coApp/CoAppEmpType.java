package com.scotiabank.ehome.ui.steps.coApp;
import com.qmetry.qaf.automation.step.QAFTestStepProvider;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.quantum.utils.ConfigurationUtils;
import com.scotiabank.ehome.ui.steps.Common;
import com.scotiabank.ehome.ui.steps.Utility;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.support.ui.WebDriverWait;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;
import java.util.concurrent.TimeUnit;
import static com.scotiabank.ehome.ui.steps.Utility.*;


@QAFTestStepProvider

public class CoAppEmpType {
	 public static WebDriverWait wait=Utility.getWait();	
	  String testCaseID = Utility.getScenarioID();
	  @Given("^Customer should login and navigates to Co App Employment Type$")
	  public void customer_should_login_and_navigates_to_Co_App_Employment_Type() throws Throwable {
	      // Write code here that turns the phrase above into concrete actions
//			 String strtestCaseID = Utility.getScenarioID();
//		  if (strtestCaseID.contains("CoApp"))
//		  {
//			  Common.TraverseToNewHomeSectionBreaker();
//			  Thread.sleep(10000);
//			  Common.TraverseFromNewHomeToRateSectionBreaker(strtestCaseID,"Co-App_InputData");
//			  Common.TraverseRateSectionToEmploymentSectionBreaker();
//			  Common.TraverseFromEmploymentSectionToLandOnCoApplicantPage();
//			  CoAppIntro.startSectionButtonClicked();
//		  }
		  Utility.launchURL(ConfigurationUtils.getBaseBundle().getPropertyValue ("env.baseurl3"));
			CoAppIntro.startSectionButtonClicked();
			CoAppEmpStatus.employedButtonClicked();
	  }

	  @When("^Verify \"([^\"]*)\" should be on the Co App Employment Type screen$")
	  public void verify_should_be_on_the_Co_App_Employment_Type_screen(String dataPointer) throws Throwable {
	      // Write code here that turns the phrase above into concrete actions
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Co-App_ExpectedData", testCaseID, dataPointer);
		QAFExtendedWebElement headerMessage= new QAFExtendedWebElement("ehome.CoAppEmpType.HeaderMessage");
		 wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(headerMessage));
		Assert.assertEquals(headerMessage.getText(), value,"Couldn't found expected header text");
	  }

	  @Then("^Verify \"([^\"]*)\" headertext on the Co App Employment Type screen$")
	  public void verify_headertext_on_the_Co_App_Employment_Type_screen(String dataPointer) throws Throwable {
	      // Write code here that turns the phrase above into concrete actions
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Co-App_ExpectedData", testCaseID, dataPointer);
		Assert.assertEquals(Common.headertext(), value,"Couldn't found expected header text");
	      
	  }
	  public static void commissionedSalesButtonClicked() {
	    	/*QAFExtendedWebElement selfemployed= new QAFExtendedWebElement("ehome.empType.Selfemployed.label");
	       	wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(selfemployed));*/
	       	QAFExtendedWebElement commissionedSales= new QAFExtendedWebElement("ehome.empType.commissionedSales.label");
	       	wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(commissionedSales));
	       	commissionedSales.click();
		}
	    public static void contractSalesButtonClicked() {
	    	QAFExtendedWebElement contract= new QAFExtendedWebElement("ehome.empType.contract.label");
	        wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(contract));
	        contract.click();
		}
	    public static void fulltimeButtonClicked() {
	    	QAFExtendedWebElement fulltime= new QAFExtendedWebElement("ehome.empType.fulltime.label");
	        wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(fulltime));
	        fulltime.click();
		}
	    public static void parttimeButtonClicked() {
	    	QAFExtendedWebElement parttime= new QAFExtendedWebElement("ehome.empType.parttime.label");
	        wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(parttime));
	        parttime.click();
		}
	    
	    public static void seasonalSalesButtonClicked() {
	    	QAFExtendedWebElement seasonal= new QAFExtendedWebElement("ehome.empType.seasonal.label");
	        wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(seasonal));
	        seasonal.click();
		}
	    public static void selfemployedButtonClicked() {
	    	QAFExtendedWebElement selfemployed= new QAFExtendedWebElement("ehome.empType.Selfemployed.label");
	        wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(selfemployed));
	        selfemployed.click();
		}

	  @When("^verify \"([^\"]*)\" check button and then click on it in Co App Employment Type screen$")
	  public void verify_check_button_and_then_click_on_it_in_Co_App_Employment_Type_screen(String dataPointer) throws Throwable {
	      // Write code here that turns the phrase above into concrete actions
		  String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Co-App_ExpectedData", testCaseID, dataPointer);
		  
			if(value.contentEquals("Commissioned sales")) {
				commissionedSalesButtonClicked();	
				
			}
			else if (value.contentEquals("Contract")) {
				contractSalesButtonClicked();
				
			}
			else if (value.contentEquals("Full time")) {
				fulltimeButtonClicked();				
			}
			else if (value.contentEquals("Part time")) {
				parttimeButtonClicked();				
			}
			else if (value.contentEquals("Seasonal")) {
				seasonalSalesButtonClicked();			
			}
			else if (value.contentEquals("Self employed")) {
				selfemployedButtonClicked();				
    		}
	      
	  }

	  @Then("^Commissioned sales It should be highlighted with the check mark and navigate to Industry and job title screen and click continue button and check \"([^\"]*)\" in Co App Employment Type screen$")
	  public void commissioned_sales_It_should_be_highlighted_with_the_check_mark_and_navigate_to_Industry_and_job_title_screen_and_click_continue_button_and_check_in_Co_App_Employment_Type_screen(String arg1) throws Throwable {
	      // Write code here that turns the phrase above into concrete actions
		  // Write code here that turns the phrase above into concrete actions
	    	Thread.sleep(3000);
	    	String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Co-App_ExpectedData", testCaseID, "Industry_JobTitle_Screen_Title");
	        QAFExtendedWebElement headertext= new QAFExtendedWebElement("ehome.Header.text");
	        wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(headertext));
	        Assert.assertEquals(headertext.getText(), value,"Couldn't found expected header text");
	        
		    //TO click on back button
		    QAFExtendedWebElement backbutton= new QAFExtendedWebElement("ehome.Back.button");
		    wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(backbutton));
		     backbutton.click(); 
		   //TO check the highlighted with the check mark
		       Thread.sleep(3000);
		     //To check Select label should be disappeared and the radio button Select should be highlighted and checked
		       QAFExtendedWebElement commissionedSaleschecked= new QAFExtendedWebElement("ehome.empType.commissionedSaleschecked.input");
		       String checked=commissionedSaleschecked.getAttribute("checked");
		       if(checked==null || !checked.contentEquals("true"))
		           throw new AssertionError("Couldn't find the checked in unemployment");
		       QAFExtendedWebElement commissionedSales= new QAFExtendedWebElement("ehome.empType.commissionedSales.label");
		       String color=commissionedSales.getCssValue("background-color");
		       String hex = convertRGBToHex(color);
		       Assert.assertEquals("#8230df",hex);
		       System.out.println("HEX"+hex);
		       if(!hex.contentEquals("#8230df"))
		           throw new AssertionError("Select when clicked is not highlighted with #8230df color");
		       //To check the continue button is there and it should be in red color and click on the continue button
		       QAFExtendedWebElement continuebutton = new QAFExtendedWebElement("ehome.Continue.button");
		       Assert.assertEquals(continuebutton.getText(), "Continue", "Continue Button text does not matched");
		       Assert.assertEquals(convertRGBToHex(continuebutton.getCssValue("color")), "#ed722", "Continue button not in Red color");
		       continuebutton.click();
		       Thread.sleep(2000);
	      
	  }

	

	  @Then("^Contract It should be highlighted with the check mark and navigate to Industry and job title screen and click continue button and check \"([^\"]*)\" in Co App Employment Type screen$")
	  public void contract_It_should_be_highlighted_with_the_check_mark_and_navigate_to_Industry_and_job_title_screen_and_click_continue_button_and_check_in_Co_App_Employment_Type_screen(String arg1) throws Throwable {
	      // Write code here that turns the phrase above into concrete actions
		  	Thread.sleep(3000);
	    	String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Co-App_ExpectedData", testCaseID, "Industry_JobTitle_Screen_Title");
	        QAFExtendedWebElement headertext= new QAFExtendedWebElement("ehome.Header.text");
	        wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(headertext));
	        Assert.assertEquals(headertext.getText(), value,"Couldn't found expected header text");
	        
	        //TO click on back button
	        QAFExtendedWebElement backbutton= new QAFExtendedWebElement("ehome.Back.button");
	        wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(backbutton));
	         backbutton.click(); 
	       //TO check the highlighted with the check mark
	           Thread.sleep(3000);
	         //To check Select label should be disappeared and the radio button Select should be highlighted and checked
	           QAFExtendedWebElement contractchecked= new QAFExtendedWebElement("ehome.empType.contractchecked.input");
	           String checked=contractchecked.getAttribute("checked");
	           if(checked==null || !checked.contentEquals("true"))
	               throw new AssertionError("Couldn't find the checked in unemployment");
	           QAFExtendedWebElement contract= new QAFExtendedWebElement("ehome.empType.contract.label");
	           String color=contract.getCssValue("background-color");
	           String hex = convertRGBToHex(color);
	           Assert.assertEquals("#8230df",hex);
	           System.out.println("HEX"+hex);
	           if(!hex.contentEquals("#8230df"))
	               throw new AssertionError("Select when clicked is not highlighted with #8230df color");
	           //To check the continue button is there and it should be in red color and click on the continue button
	           QAFExtendedWebElement continuebutton = new QAFExtendedWebElement("ehome.Continue.button");
	           Assert.assertEquals(continuebutton.getText(), "Continue", "Continue Button text does not matched");
	           Assert.assertEquals(convertRGBToHex(continuebutton.getCssValue("color")), "#ed722", "Continue button not in Red color");
	           continuebutton.click();
	           Thread.sleep(2000);
	      
	  }

	  @Then("^Full time It should be highlighted with the check mark and navigate to Industry and job title screen and click continue button and check \"([^\"]*)\" in Co App Employment Type screen$")
	  public void full_time_It_should_be_highlighted_with_the_check_mark_and_navigate_to_Industry_and_job_title_screen_and_click_continue_button_and_check_in_Co_App_Employment_Type_screen(String arg1) throws Throwable {
		  Thread.sleep(3000);
	    	String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Co-App_ExpectedData", testCaseID, "Industry_JobTitle_Screen_Title");
	        QAFExtendedWebElement headertext= new QAFExtendedWebElement("ehome.Header.text");
	        wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(headertext));
	        Assert.assertEquals(headertext.getText(), value,"Couldn't found expected header text");
	        
	        //TO click on back button
	        QAFExtendedWebElement backbutton= new QAFExtendedWebElement("ehome.Back.button");
	        wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(backbutton));
	         backbutton.click(); 
	       //TO check the highlighted with the check mark
	           Thread.sleep(3000);
	         //To check Select label should be disappeared and the radio button Select should be highlighted and checked
	           QAFExtendedWebElement fulltimechecked= new QAFExtendedWebElement("ehome.empType.fulltimechecked.input");
	           String checked=fulltimechecked.getAttribute("checked");
	           if(checked==null || !checked.contentEquals("true"))
	               throw new AssertionError("Couldn't find the checked in unemployment");
	           QAFExtendedWebElement fulltime= new QAFExtendedWebElement("ehome.empType.fulltime.label");
	           String color=fulltime.getCssValue("background-color");
	           String hex = convertRGBToHex(color);
	           Assert.assertEquals("#8230df",hex);
	           System.out.println("HEX"+hex);
	           if(!hex.contentEquals("#8230df"))
	               throw new AssertionError("Select when clicked is not highlighted with #8230df color");
	           //To check the continue button is there and it should be in red color and click on the continue button
	           QAFExtendedWebElement continuebutton = new QAFExtendedWebElement("ehome.Continue.button");
	           Assert.assertEquals(continuebutton.getText(), "Continue", "Continue Button text does not matched");
	           Assert.assertEquals(convertRGBToHex(continuebutton.getCssValue("color")), "#ed722", "Continue button not in Red color");
	           continuebutton.click();
	           Thread.sleep(2000);  
	  }

	  @Then("^Part time It should be highlighted with the check mark and navigate to Industry and job title screen and click continue button and check \"([^\"]*)\" in Co App Employment Type screen$")
	  public void part_time_It_should_be_highlighted_with_the_check_mark_and_navigate_to_Industry_and_job_title_screen_and_click_continue_button_and_check_in_Co_App_Employment_Type_screen(String arg1) throws Throwable {
	      // Write code here that turns the phrase above into concrete actions
		  // Write code here that turns the phrase above into concrete actions
	    	Thread.sleep(3000);
	    	String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Co-App_ExpectedData", testCaseID, "Industry_JobTitle_Screen_Title");
	        QAFExtendedWebElement headertext= new QAFExtendedWebElement("ehome.Header.text");
	        wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(headertext));
	        Assert.assertEquals(headertext.getText(), value,"Couldn't found expected header text");
	        
	        //TO click on back button
	        QAFExtendedWebElement backbutton= new QAFExtendedWebElement("ehome.Back.button");
	        wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(backbutton));
	         backbutton.click(); 
	       //TO check the highlighted with the check mark
	           Thread.sleep(3000);
	         //To check Select label should be disappeared and the radio button Select should be highlighted and checked
	           QAFExtendedWebElement parttimechecked= new QAFExtendedWebElement("ehome.empType.parttimechecked.input");
	           String checked=parttimechecked.getAttribute("checked");
	           if(checked==null || !checked.contentEquals("true"))
	               throw new AssertionError("Couldn't find the checked in unemployment");
	           QAFExtendedWebElement parttime= new QAFExtendedWebElement("ehome.empType.parttime.label");
	           String color=parttime.getCssValue("background-color");
	           String hex = convertRGBToHex(color);
	           Assert.assertEquals("#8230df",hex);
	           System.out.println("HEX"+hex);
	           if(!hex.contentEquals("#8230df"))
	               throw new AssertionError("Select when clicked is not highlighted with #8230df color");
	           //To check the continue button is there and it should be in red color and click on the continue button
	           QAFExtendedWebElement continuebutton = new QAFExtendedWebElement("ehome.Continue.button");
	           Assert.assertEquals(continuebutton.getText(), "Continue", "Continue Button text does not matched");
	           Assert.assertEquals(convertRGBToHex(continuebutton.getCssValue("color")), "#ed722", "Continue button not in Red color");
	           continuebutton.click();
	           Thread.sleep(2000);
	      
	  }

	  @Then("^Seasonal It should be highlighted with the check mark and navigate to Industry and job title screen and click continue button and check \"([^\"]*)\" in Co App Employment Type screen$")
	  public void seasonal_It_should_be_highlighted_with_the_check_mark_and_navigate_to_Industry_and_job_title_screen_and_click_continue_button_and_check_in_Co_App_Employment_Type_screen(String arg1) throws Throwable {
	      // Write code here that turns the phrase above into concrete actions
		  Thread.sleep(3000);
	    	String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Co-App_ExpectedData", testCaseID, "Industry_JobTitle_Screen_Title");
	        QAFExtendedWebElement headertext= new QAFExtendedWebElement("ehome.Header.text");
	        wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(headertext));
	        Assert.assertEquals(headertext.getText(), value,"Couldn't found expected header text");
	        
	        //TO click on back button
	        QAFExtendedWebElement backbutton= new QAFExtendedWebElement("ehome.Back.button");
	        wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(backbutton));
	         backbutton.click(); 
	       //TO check the highlighted with the check mark
	           Thread.sleep(3000);
	         //To check Select label should be disappeared and the radio button Select should be highlighted and checked
	           QAFExtendedWebElement seasonalchecked= new QAFExtendedWebElement("ehome.empType.seasonal.input");
	           String checked=seasonalchecked.getAttribute("checked");
	           if(checked==null || !checked.contentEquals("true"))
	               throw new AssertionError("Couldn't find the checked in unemployment");
	           QAFExtendedWebElement seasonal= new QAFExtendedWebElement("ehome.empType.seasonal.label");
	           String color=seasonal.getCssValue("background-color");
	           String hex = convertRGBToHex(color);
	           Assert.assertEquals("#8230df",hex);
	           System.out.println("HEX"+hex);
	           if(!hex.contentEquals("#8230df"))
	               throw new AssertionError("Select when clicked is not highlighted with #8230df color");
	           //To check the continue button is there and it should be in red color and click on the continue button
	           QAFExtendedWebElement continuebutton = new QAFExtendedWebElement("ehome.Continue.button");
	           Assert.assertEquals(continuebutton.getText(), "Continue", "Continue Button text does not matched");
	           Assert.assertEquals(convertRGBToHex(continuebutton.getCssValue("color")), "#ed722", "Continue button not in Red color");
	           continuebutton.click();
	           Thread.sleep(2000);
	        
	      
	  }

	  @Then("^Self employed It should be highlighted with the check mark and navigate to Industry and job title screen and click continue button and check \"([^\"]*)\" in Co App Employment Type screen$")
	  public void self_employed_It_should_be_highlighted_with_the_check_mark_and_navigate_to_Industry_and_job_title_screen_and_click_continue_button_and_check_in_Co_App_Employment_Type_screen(String arg1) throws Throwable {
		  // Write code here that turns the phrase above into concrete actions
	    	Thread.sleep(3000);
	    	String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Co-App_ExpectedData", testCaseID, "Industry_JobTitle_Screen_Title");
	        QAFExtendedWebElement headertext= new QAFExtendedWebElement("ehome.Header.text");
	        wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(headertext));
	        Assert.assertEquals(headertext.getText(), value,"Couldn't found expected header text");
	        
	        //TO click on back button
	        QAFExtendedWebElement backbutton= new QAFExtendedWebElement("ehome.Back.button");
	        wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(backbutton));
	         backbutton.click(); 
	       //TO check the highlighted with the check mark
	           Thread.sleep(3000);
	         //To check Select label should be disappeared and the radio button Select should be highlighted and checked
	           QAFExtendedWebElement selfemployedchecked= new QAFExtendedWebElement("ehome.empType.Selfemployedchecked.input");
	           String checked=selfemployedchecked.getAttribute("checked");
	           if(checked==null || !checked.contentEquals("true"))
	               throw new AssertionError("Couldn't find the checked in unemployment");
	           QAFExtendedWebElement selfemployed= new QAFExtendedWebElement("ehome.empType.Selfemployed.label");
	           String color=selfemployed.getCssValue("background-color");
	           String hex = convertRGBToHex(color);
	           Assert.assertEquals("#8230df",hex);
	           System.out.println("HEX"+hex);
	           if(!hex.contentEquals("#8230df"))
	               throw new AssertionError("Select when clicked is not highlighted with #8230df color");
	           //To check the continue button is there and it should be in red color and click on the continue button
	           QAFExtendedWebElement continuebutton = new QAFExtendedWebElement("ehome.Continue.button");
	           Assert.assertEquals(continuebutton.getText(), "Continue", "Continue Button text does not matched");
	           Assert.assertEquals(convertRGBToHex(continuebutton.getCssValue("color")), "#ed722", "Continue button not in Red color");
	           continuebutton.click();
	           Thread.sleep(2000);
	      
	  }

	  @Then("^Verify \"([^\"]*)\" headertext should be on the Co App Employment Type screen$")
	  public void verify_headertext_should_be_on_the_Co_App_Employment_Type_screen(String arg1) throws Throwable {
	      // Write code here that turns the phrase above into concrete actions
	      
	  }


}
