package com.scotiabank.ehome.ui.steps.stage4;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.step.QAFTestStepProvider;
import com.qmetry.qaf.automation.ui.WebDriverTestBase;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebDriver;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.quantum.utils.ConfigurationUtils;
import com.scotiabank.ehome.ui.steps.Common;
import com.scotiabank.ehome.ui.steps.ExcelDataToDataTable;
import com.scotiabank.ehome.ui.steps.Utility;
import com.scotiabank.ehome.ui.steps.valueObjects.Tuple;
import com.scotiabank.ehome.ui.steps.valueObjects.TypeOfRateVO;
import com.thoughtworks.qdox.model.expression.Add;

import org.junit.runner.RunWith;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;

import cucumber.api.CucumberOptions;
import cucumber.api.DataTable;
import cucumber.api.PendingException;
import cucumber.api.Transform;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import cucumber.api.junit.Cucumber;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import static com.scotiabank.ehome.ui.steps.BusinessCalculations.*;
import static com.scotiabank.ehome.ui.steps.Utility.*;

import org.openqa.selenium.Keys;
@QAFTestStepProvider

public class PreviousIndustryAndJobTitle {
	private QAFExtendedWebDriver webDriver = Utility.getDriver();
    public Actions action = null;
    public static WebDriverWait wait=Utility.getWait();	
    
    private Map<String,Map<String,Boolean>> employerAddressDataset = getScreenDataset(Utility.getExcelFilePath("eHomeTestDatastage-4.xlsx"), "EmployerAddress");
    private Map<String,Map<String,Boolean>> employerDetailsDataset = getScreenDataset(Utility.getExcelFilePath("eHomeTestDatastage-4.xlsx"), "EmployerDetails");
    private Map<String,Map<String,Boolean>> industryAndJobTitleDataset = getScreenDataset(Utility.getExcelFilePath("eHomeTestDatastage-4.xlsx"), "IndustryAndJobTitle");
    private Map<String,Map<String,Boolean>> negativeValuesDataset = getScreenDataset(Utility.getExcelFilePath("eHomeTestDatastage-4.xlsx"), "NegativeValues");
    private Map<String,Map<String,Boolean>> annualIncomeDataset = getScreenDataset(Utility.getExcelFilePath("eHomeTestDatastage-4.xlsx"), "AnnualIncome");
    private Map<String,Map<String,Boolean>> empDurationDataset = getScreenDataset(Utility.getExcelFilePath("eHomeTestDatastage-4.xlsx"), "EmploymentDuration");
    private Map<String,Map<String,Boolean>> previousEmplyerDetailsDataset = getScreenDataset(Utility.getExcelFilePath("eHomeTestDatastage-4.xlsx"), "PreviousEmplyerDetails");
    private Map<String,Map<String,Boolean>> previousEmployerAddressDataset = getScreenDataset(Utility.getExcelFilePath("eHomeTestDatastage-4.xlsx"), "Employer_Address");
    private Map<String,Map<String,Boolean>> previousIndustryJobtitleDataset = getScreenDataset(Utility.getExcelFilePath("eHomeTestDatastage-4.xlsx"), "PreviousIndustryJobtitle");
    
	@Given("^Customer should login and navigates to Previous Industry and Job Title$")
	public void customer_should_login_and_navigates_to_Previous_Industry_and_Job_Title() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Common.sessionBreakerContinueButtonClick();
        EmpStatus.employedButtonClicked();
        EmpType.commissionedSalesButtonClicked();
        IndustryAndJobTitle.jobField(Utility.getLabelValueForDataPointer(industryAndJobTitleDataset, "Industry_JobTitle_Field_of_work"));
        IndustryAndJobTitle.jobTitle(Utility.getLabelValueForDataPointer(industryAndJobTitleDataset, "Industry_JobTitle_Job_Title"));
        Common.continueButtonClicked();
        EmployerDetails.employername(Utility.getLabelValueForDataPointer(employerDetailsDataset, "Employer_Details_employername"));
        EmployerDetails.employerphone(Utility.getLabelValueForDataPointer(employerDetailsDataset, "Employer_Details_employerphone"));
        Common.continueButtonClicked();
        EmpAddress.employeraddress(Utility.getLabelValueForDataPointer(employerAddressDataset, "Employer_Address"));
        Thread.sleep(2000);
        Common.continueButtonClicked();		
        AnnualIncome.annualincomeSalary(Utility.getLabelValueForDataPointer(annualIncomeDataset, "Employer_AnnualIncome_Salary"));
        Common.continueButtonClicked();
        String year = Utility.getLabelValueForDataPointer(empDurationDataset, ("Employer_Duration_lessThan2Years_years"));
        String month = Utility.getLabelValueForDataPointer(empDurationDataset, ("Employer_Duration_lessThan2Years_months"));
        EmploymentDuration.employmentDuration(year, month);
        Common.continueButtonClicked();
        PreviousEmployerDetails.previousEmployerName(Utility.getLabelValueForDataPointer(previousEmplyerDetailsDataset, "Employer_PreviosDetails_employername"));
       // PreviousEmployerDetails.previousEmployerPhone(Utility.getLabelValueForDataPointer(previousEmplyerDetailsDataset, "Employer_PreviosDetails_employerphone"));
	    Common.continueButtonClicked();
	    PreviousEmployerAddress.previousemployeraddress(Utility.getLabelValueForDataPointer(negativeValuesDataset, "AplhaNumeric"));
	    Common.continueButtonClicked();
	    
	   
	    
	}

	
	@When("^Verify \"([^\"]*)\" should be on the Previous Industry and Job Title screen$")
	public void verify_should_be_on_the_Previous_Industry_and_Job_Title_screen(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    
	}

	@Then("^Verify \"([^\"]*)\" header should be on the Previous Industry and Job Title screen$")
	public void verify_header_should_be_on_the_Previous_Industry_and_Job_Title_screen(String dataPointer) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String value = Utility.getLabelValueForDataPointer(previousIndustryJobtitleDataset, dataPointer);
		Assert.assertEquals(Common.headertext(), value,"Couldn't found expected header text");
	    
	}
	
	// Previous-Industry-JobTitle-TC-005
	
	public static void jobField(String field) {
    	QAFExtendedWebElement jobField= new QAFExtendedWebElement("ehome.previousIndustryAndJobTitle.jobField");
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(jobField));
		Select dropdown = new Select(jobField);
        dropdown.selectByValue(field);
   	 }
    
    @When("^Click on the \"([^\"]*)\" work dop down and select one in Previous Industry and Job field screen$")
    public void click_on_the_field_of_work_dop_down_and_select_one_in_Previous_Industry_and_Job_field_screen(String dataPointer) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	String value = Utility.getLabelValueForDataPointer(previousIndustryJobtitleDataset, dataPointer);
    	jobField(value);
    }
    public static void jobTitle(String title) {
    	QAFExtendedWebElement jobTitle= new QAFExtendedWebElement("ehome.previousIndustryAndJobTitle.jobTitle");
        wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(jobTitle));
       Select dropdown2 = new Select(jobTitle);
        dropdown2.selectByValue(title);
   	 }
      
    @Then("^Click on the \"([^\"]*)\" title dop down and select one in Previous Industry and Job Title screen$")
    public void click_on_the__title_dop_down_and_select_one_in_Previous_Industry_and_Job_Title_screen(String dataPointer) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	String value = Utility.getLabelValueForDataPointer(previousIndustryJobtitleDataset, dataPointer);
    	Thread.sleep(3000);
    	 jobTitle(value);
    }

    @Then("^It should navigate to OtherSource of incomewith header \"([^\"]*)\"$")
    public void it_should_navigate_to_OtherSource_of_income(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	QAFExtendedWebElement headerText= new QAFExtendedWebElement("ehome.Header.text");
        Assert.assertEquals(headerText.getText(), arg1,"Couldn't display header text");
    }
	



}
