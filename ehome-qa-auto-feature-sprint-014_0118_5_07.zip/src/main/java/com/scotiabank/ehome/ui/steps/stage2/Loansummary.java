package com.scotiabank.ehome.ui.steps.stage2;

import java.util.List;
import java.util.concurrent.TimeUnit;

import com.scotiabank.ehome.ui.steps.Utility;
import cucumber.api.PendingException;
import gherkin.lexer.Th;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.qmetry.qaf.automation.step.QAFTestStepProvider;
import com.qmetry.qaf.automation.ui.WebDriverTestBase;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebDriver;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.quantum.utils.ConfigurationUtils;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

@QAFTestStepProvider
public class Loansummary {
	
	private QAFExtendedWebDriver webDriver = new WebDriverTestBase().getDriver();
	public Actions action = null;
    public WebDriverWait wait = new WebDriverWait(webDriver, 50000);

	String testCaseID = Utility.getScenarioID();

	QAFExtendedWebElement scotiabankLogo = new QAFExtendedWebElement("ehome.scotiabanklogo.image");
    QAFExtendedWebElement applicationTracter= new QAFExtendedWebElement("ehome.applicationstatustracker.image");
	QAFExtendedWebElement userloginname= new QAFExtendedWebElement("ehome.userloginname.image");
    
    QAFExtendedWebElement eleAddress = new QAFExtendedWebElement(By.xpath("//*[@id='app']/div/div[1]/div[1]/section/div[3]/div/div[1]/div/div[2]/div/ul"));
    QAFExtendedWebElement TypeofPropertyhouseselect= new QAFExtendedWebElement("ehome.loansummary.TypeofPropertyhouseselect");
	QAFExtendedWebElement Detached= new QAFExtendedWebElement("ehome.loansummary.Detached");
	QAFExtendedWebElement sqft= new QAFExtendedWebElement("ehome.loansummary.sqft");
	QAFExtendedWebElement ContinueButton= new QAFExtendedWebElement("ehome.loansummary.ContinueButton");
	QAFExtendedWebElement ContinueButtonDetails= new QAFExtendedWebElement("ehome.loansummary.ContinueButtonDetails");
	QAFExtendedWebElement purchasePrice= new QAFExtendedWebElement("ehome.loansummary.purchasePrice");
	QAFExtendedWebElement downPayment= new QAFExtendedWebElement("ehome.loansummary.downPayment");
	QAFExtendedWebElement bankAccountOption= new QAFExtendedWebElement("ehome.loansummary.bankAccountOption");
	QAFExtendedWebElement saleOfExistingProperty= new QAFExtendedWebElement("ehome.loansummary.saleOfExistingProperty");
	QAFExtendedWebElement investmentAccount= new QAFExtendedWebElement("ehome.loansummary.investmentAccount");
	QAFExtendedWebElement bankAccountAmountProperty= new QAFExtendedWebElement("ehome.loansummary.bankAccountAmountProperty");
	QAFExtendedWebElement investmentAccountAmountProperty= new QAFExtendedWebElement("ehome.loansummary.investmentAccountAmountProperty");
	QAFExtendedWebElement saleOfExistingPropertyAmountProperty= new QAFExtendedWebElement("ehome.loansummary.saleOfExistingPropertyAmountProperty");
	QAFExtendedWebElement bankAccountAmount= new QAFExtendedWebElement("ehome.loansummary.bankAccountAmount");
	QAFExtendedWebElement saleOfExistingAmount= new QAFExtendedWebElement("ehome.loansummary.saleOfExistingAmount");
	QAFExtendedWebElement investmentAccountAmount= new QAFExtendedWebElement("ehome.loansummary.investmentAccountAmount");
	QAFExtendedWebElement closedate = new QAFExtendedWebElement("//*[@id=\'app\']/div/div[1]/div[1]/section/div[3]/div/div[1]/div/div/div/button");
    QAFExtendedWebElement closedateSelection = new QAFExtendedWebElement("//*[@id='app']/div/div[1]/div[1]/section/div[3]/div/div[1]/div/div[2]/div/div[3]/div/div[1]/div[2]/div/select");
    QAFExtendedWebElement closedateSel = new QAFExtendedWebElement("//*[@id=\'app\']/div/div[1]/div[1]/section/div[3]/div/div[1]/div/div[2]/div/div[3]/div/div[2]/div[2]/div[3]");
    QAFExtendedWebElement Back = new QAFExtendedWebElement("ehome.loansummary.Back");
    
    QAFExtendedWebElement letsreviewtext = new QAFExtendedWebElement("ehome.loansummary.letsreviewtext");
    QAFExtendedWebElement loansummarytext = new QAFExtendedWebElement("ehome.loansummary.loansummarytext");
    QAFExtendedWebElement totalloanamounttext = new QAFExtendedWebElement("ehome.loansummary.totalloanamounttext");
    QAFExtendedWebElement totalloanamountvalue = new QAFExtendedWebElement("ehome.loansummary.totalloanamountvalue");
    QAFExtendedWebElement banner = new QAFExtendedWebElement("ehome.loansummary.banner");
    QAFExtendedWebElement MinimumdownpaymentAmount = new QAFExtendedWebElement("ehome.loansummary.MinimumdownpaymentAmount");
    QAFExtendedWebElement Minimumdownpaymentpercentage = new QAFExtendedWebElement("ehome.loansummary.Minimumdownpaymentpercentage");
    QAFExtendedWebElement howwecalculatedtext = new QAFExtendedWebElement("ehome.loansummary.howwecalculatedtext");
    QAFExtendedWebElement purchasePriceText = new QAFExtendedWebElement("ehome.loansummary.purchasePriceText");
    QAFExtendedWebElement downpaymenttext = new QAFExtendedWebElement("ehome.loansummary.downpaymenttext");
    QAFExtendedWebElement mortgageloanrequestedtext = new QAFExtendedWebElement("ehome.loansummary.mortgageloanrequestedtext");

    QAFExtendedWebElement purchasePriceAmount = new QAFExtendedWebElement("ehome.loansummary.purchasePriceAmount");
    QAFExtendedWebElement downpaymentAmount = new QAFExtendedWebElement("ehome.loansummary.downpaymentAmount");
    QAFExtendedWebElement mortgageloanrequestedAmount = new QAFExtendedWebElement("ehome.loansummary.mortgageloanrequestedAmount");
    QAFExtendedWebElement wehavesomeamazingoffers = new QAFExtendedWebElement("ehome.loansummary.wehavesomeamazingoffers");
    
    QAFExtendedWebElement greatPropertyText= new QAFExtendedWebElement("ehome.whenistheclosingdate.header");

	QAFExtendedWebElement Continue = new QAFExtendedWebElement("ehome.tellus.continue.button");
	QAFExtendedWebElement address = new QAFExtendedWebElement("ehome.whatstheaddress.addressList.list");
	QAFExtendedWebElement addressFirstOption = new QAFExtendedWebElement("ehome.whatstheaddress.addressList.firstOption");
	QAFExtendedWebElement continueWhattypeofproperty= new QAFExtendedWebElement("ehome.enteraddressmanually.continue.button");

	QAFExtendedWebElement defaultInsurance= new QAFExtendedWebElement("ehome.loansummary.defaultInsurance");
	QAFExtendedWebElement defaultInsurancePraragraph= new QAFExtendedWebElement("ehome.loansummary.defaultInsurancePraragraph");
	QAFExtendedWebElement defaultInsuranceClose= new QAFExtendedWebElement("ehome.loansummary.defaultInsurance.close");


	@Given("^Customer should login and navigate to 'When is the closing date\\?' page and select the closing date$")
	public void customer_should_login_and_navigate_to_When_is_the_closing_date_page_and_select_the_closing_date() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions

		Utility.launchURL(ConfigurationUtils.getBaseBundle ().getPropertyValue("env.baseurl1"));
		Continue.click();

		QAFExtendedWebElement Enteraddress= new QAFExtendedWebElement("ehome.Address.address.text");
		String addressFromExcel = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_InputData",testCaseID , "Address");
		Enteraddress.sendKeys(addressFromExcel);

		wait.until(ExpectedConditions.elementToBeClickable(address));
		Thread.sleep(1000);
		addressFirstOption.click();
	    //TO click on continue button is address screen
		wait.until(ExpectedConditions.visibilityOf(continueWhattypeofproperty));
		continueWhattypeofproperty.click();

		//wait.pollingEvery(25, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.elementToBeClickable(TypeofPropertyhouseselect));
		Thread.sleep(15000);
        TypeofPropertyhouseselect.click();

		Thread.sleep(3000);
   	    Detached.click();

		wait.pollingEvery(5, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(sqft));
		String sqftFromExcel = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_InputData",testCaseID , "SQFT");
		sqft.sendKeys(sqftFromExcel);

		wait.until(ExpectedConditions.visibilityOf(ContinueButton));
    	ContinueButton.click();

		wait.until(ExpectedConditions.visibilityOf(purchasePrice));
		String PurchasePriceFromExcel = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_InputData",testCaseID , "Purchase_Price");
		purchasePrice.sendKeys(PurchasePriceFromExcel);
		ContinueButton.click();

		wait.until(ExpectedConditions.visibilityOf(downPayment));
		String DownPaymentFromExcel = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_InputData",testCaseID , "Down_Payment_Amount");
		downPayment.sendKeys(DownPaymentFromExcel);

		wait.until(ExpectedConditions.visibilityOf(ContinueButton));
		ContinueButton.click();

		Thread.sleep(5000);
		bankAccountOption.click();
		investmentAccount.click();

		ContinueButton.click();

		wait.until(ExpectedConditions.visibilityOf(bankAccountAmountProperty));
		if(bankAccountAmountProperty.getAttribute("aria-expanded").contentEquals("false")) {
			bankAccountAmountProperty.click();
			String BankAccountAmountFromExcel = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_InputData",testCaseID , "Bank_Account_Amount");
			bankAccountAmount.sendKeys(BankAccountAmountFromExcel);
		}
		else {
			String BankAccountAmountFromExcel = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_InputData",testCaseID , "Bank_Account_Amount");
			bankAccountAmount.sendKeys(BankAccountAmountFromExcel);
		}
		Thread.sleep(5000);
		if(investmentAccountAmountProperty.getAttribute("aria-expanded").contentEquals("false")) {
			investmentAccountAmountProperty.click();
			String InvestmentAccountAmountFromExcel = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_InputData",testCaseID , "Investment_Account_Amount");
			investmentAccountAmount.sendKeys(InvestmentAccountAmountFromExcel);
		}
		else {
			String InvestmentAccountAmountFromExcel = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_InputData",testCaseID , "Investment_Account_Amount");
			investmentAccountAmount.sendKeys(InvestmentAccountAmountFromExcel);
		}

		ContinueButtonDetails.click();

		wait.until(ExpectedConditions.visibilityOf(closedate));
		closedate.click();
		Select closedateSelect =  new Select(closedateSelection);
		closedateSelect.selectByIndex(2);
		closedateSel.click();
	}

	@When("^click on continue button from 'When is the closing date\\?' page$")
	public void click_on_continue_button_from_When_is_the_closing_date_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Thread.sleep(3000);
		ContinueButton.click();
	}

	@Then("^Verify 'Scotiabank Logo', 'Application status' tracker', 'Login username', 'chat icon' functionality on the screen and Back Button should be enabled, Continue Button should be enabled$")
	public void verifyScotiabankLogoApplicationStatusTrackerLoginUsernameChatIconFunctionalityOnTheScreenAndBackButtonShouldBeEnabledContinueButtonShouldBeEnabled() throws Throwable {
		// Write code here that turns the phrase above into concrete actions

		scotiabankLogo.assertPresent ("Couldn't find the ScotiaBank logo"  );
		if(!scotiabankLogo.verifyPresent())
			throw new AssertionError("Couldn't find the ScotiaBank logo");

		//To Check Application status tracker
		applicationTracter.assertPresent ( "Application status tracker image is missing" );
		if(!applicationTracter.verifyPresent())
			throw new AssertionError("Couldn't find the Application status tracker");

		String Back_Text = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_ExpectedData",testCaseID , "Back_Button_Text");
		Assert.assertEquals(Back.getText(), Back_Text,"Couldn't found Back button, Back button should be present");

		Back.isPresent();
	    ContinueButtonDetails.isPresent();
	}


	@Then("^Verify the Content of 'Let’s review, Janet Header', 'Your eHOME Loan Summary Header', 'Total loan amount Header', 'Total loan amount value', 'down payment banner', 'Purchase Price Header', the total down payment, the percentage of down payment, 'How we calculated your total loan amount Header', 'Purchase Price Header', 'Purchase price Amount', 'Down payment Header', 'Down payment Amount', 'Mortgage loan requested Header', 'Mortgage loan requested Amount'$")
	public void verifyTheContentOfLetSReviewJanetHeaderYourEHOMELoanSummaryHeaderTotalLoanAmountHeaderTotalLoanAmountValueDownPaymentBannerPurchasePriceHeaderTheTotalDownPaymentThePercentageOfDownPaymentHowWeCalculatedYourTotalLoanAmountHeaderPurchasePriceHeaderPurchasePriceAmountDownPaymentHeaderDownPaymentAmountMortgageLoanRequestedHeaderMortgageLoanRequestedAmount() throws Throwable {
		// Write code here that turns the phrase above into concrete actions

		Thread.sleep(2000);
		String LetsReviewHeaderfromExcel = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_ExpectedData",testCaseID , "Let's_Review_Janet_Header");
		Assert.assertEquals(letsreviewtext.getText(), LetsReviewHeaderfromExcel,"Couldn't found lets review Janet text");

		String LoanSummaryHeaderfromExcel = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_ExpectedData",testCaseID , "Loan_Summary_Header");
		Assert.assertEquals(loansummarytext.getText(), LoanSummaryHeaderfromExcel,"Couldn't found Loan summary text");

		String LoanAmountHeaderfromExcel = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_ExpectedData",testCaseID , "Total_Loan_amount_Header");
		Assert.assertEquals(totalloanamounttext.getText(), LoanAmountHeaderfromExcel,"Couldn't found total loan amount text");

		String TotalLoanAmountValuefromExcel = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_ExpectedData",testCaseID , "Total_Loan_Amount");
		Assert.assertEquals(totalloanamountvalue.getText(), TotalLoanAmountValuefromExcel,"Couldn't found total loan amount");
		
		banner.assertPresent ("Couldn't find the Banner"  );
	    if(!banner.verifyPresent())
	    throw new AssertionError("Couldn't find the Banner");
	     
		Minimumdownpaymentpercentage.assertPresent ();
	    if(!Minimumdownpaymentpercentage.verifyPresent())
	    throw new AssertionError("Couldn't find the Minimum Downpayment Percentage");

		String HowWeCalculateHeaderfromExcel = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_ExpectedData",testCaseID , "How_we_calculated_your_total_loan_amount_Header");
		Assert.assertEquals(howwecalculatedtext.getText(), HowWeCalculateHeaderfromExcel,"how we calculated text is not displayed");

		String PurchasePriceHeaderfromExcel = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_ExpectedData",testCaseID , "Purchase_Price_Header");
		Assert.assertEquals(purchasePriceText.getText(), PurchasePriceHeaderfromExcel,"purchase Price Text text is not displayed");

		String DownPaymentHeaderfromExcel = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_ExpectedData",testCaseID , "Down_Payment_Header");
		Assert.assertEquals(downpaymenttext.getText(), DownPaymentHeaderfromExcel,"down payment text is not displayed");

		String MortgageLoanHeaderfromExcel = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_ExpectedData",testCaseID , "Mortgage_loan_requested_Header");
		Assert.assertEquals(mortgageloanrequestedtext.getText(), MortgageLoanHeaderfromExcel,"mortgage loan requested text is not displayed");

		String PurchasePriceAmountfromExcel = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_ExpectedData",testCaseID , "Purchase_Price");
		Assert.assertEquals(purchasePriceAmount.getText(), PurchasePriceAmountfromExcel,"purchase Price Amount is not displayed");
			
		String DownPaymentAmountfromExcel = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_ExpectedData",testCaseID , "Down_Payment_Amount");
		Assert.assertEquals(downpaymentAmount.getText(), DownPaymentAmountfromExcel,"down payment Amount is not displayed");

		String MortgageloanrequestedAmountfromExcel = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_ExpectedData",testCaseID , "Mortgage_loan_requested_Amount");
		Assert.assertEquals(mortgageloanrequestedAmount.getText(), MortgageloanrequestedAmountfromExcel,"mortgage loan requested Amount is not displayed");
			     
	}
	
	@When("^click on continue button from 'Your ehome Loan Summary' page$")
	public void click_on_continue_button_from_Youe_ehom_Loan_Summary_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		ContinueButtonDetails.click();
	}

	@Then("^'We have some amazing online-only mortgage rates to offer you!' page should be displayed$")
	public void we_have_some_amazing_online_only_mortgage_rates_to_offer_you_page_should_be_displayed() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions

		wehavesomeamazingoffers.assertPresent ("Couldn't find the Title"  );
	     if(!wehavesomeamazingoffers.verifyPresent())
	            throw new AssertionError("Couldn't find the Title");
	}
	
	@When("^Back button is clicked from 'Your ehome Loan Summary' page$")
	public void back_button_is_clicked_from_Your_ehome_Loan_Summary_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Back.click();
	}

	@Then("^'When is the closing date\\?' page should be displayed$")
	public void when_is_the_closing_date_page_should_be_displayed() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String GreatHeaderfromExcel = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_ExpectedData",testCaseID , "Great_Header");
		Assert.assertEquals(greatPropertyText.getText(), GreatHeaderfromExcel,"Not able to launch When is the Closing Date page");

	}

	@Then("^Verify Default insurance Text on the Loan Summary Screen$")
	public void verifyDefaultInsuranceTextOnTheLoanSummaryScreen() throws Throwable {

	defaultInsurance.isPresent();

	defaultInsurance.click();

	String Default_Insurance_Paragraph = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_ExpectedData",testCaseID , "Default_Insurance_Paragraph");
	Assert.assertEquals(defaultInsurancePraragraph.getText(), Default_Insurance_Paragraph,"Not able to see default insurance paragraph");

	defaultInsuranceClose.click();

	}
}
