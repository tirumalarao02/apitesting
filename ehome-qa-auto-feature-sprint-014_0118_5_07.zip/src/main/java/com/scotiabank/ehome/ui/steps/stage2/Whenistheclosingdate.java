package com.scotiabank.ehome.ui.steps.stage2;

import java.util.List;
import java.util.concurrent.TimeUnit;

import cucumber.api.PendingException;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.qmetry.qaf.automation.step.QAFTestStepProvider;
import com.qmetry.qaf.automation.ui.WebDriverTestBase;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebDriver;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.quantum.utils.ConfigurationUtils;
import com.scotiabank.ehome.ui.steps.Utility;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

@QAFTestStepProvider
public class Whenistheclosingdate {

	public Actions action = null;

	QAFExtendedWebElement TypeofPropertyhouseselect= new QAFExtendedWebElement("ehome.whenistheclosingdate.TypeofPropertyhouseselect");
	QAFExtendedWebElement Detached= new QAFExtendedWebElement("ehome.whenistheclosingdate.Detached");
	QAFExtendedWebElement address = new QAFExtendedWebElement("ehome.whatstheaddress.addressList.list");
	QAFExtendedWebElement addressFirstOption = new QAFExtendedWebElement("ehome.whatstheaddress.addressList.firstOption");
	QAFExtendedWebElement ContinueButton= new QAFExtendedWebElement("ehome.whenistheclosingdate.ContinueButton");
	QAFExtendedWebElement ContinueButtonDetails= new QAFExtendedWebElement("ehome.whenistheclosingdate.ContinueButtonDetails");
	QAFExtendedWebElement sqft= new QAFExtendedWebElement("ehome.whenistheclosingdate.sqft");
	QAFExtendedWebElement purchasePrice= new QAFExtendedWebElement("ehome.whenistheclosingdate.purchasePrice");
	QAFExtendedWebElement downPayment= new QAFExtendedWebElement("ehome.whenistheclosingdate.downPayment");
	QAFExtendedWebElement bankAccountOption= new QAFExtendedWebElement("ehome.whenistheclosingdate.bankAccountOption");
	QAFExtendedWebElement saleOfExistingProperty= new QAFExtendedWebElement("ehome.whenistheclosingdate.saleOfExistingProperty");
	QAFExtendedWebElement investmentAccount= new QAFExtendedWebElement("ehome.whenistheclosingdate.investmentAccount");

	QAFExtendedWebElement bankAccountAmount= new QAFExtendedWebElement("ehome.whenistheclosingdate.bankAccountAmount");
	QAFExtendedWebElement saleOfExistingAmount= new QAFExtendedWebElement("ehome.whenistheclosingdate.saleOfExistingAmount");
	QAFExtendedWebElement investmentAccountAmount= new QAFExtendedWebElement("ehome.whenistheclosingdate.investmentAccountAmount");

	QAFExtendedWebElement bankAccountAmountProperty= new QAFExtendedWebElement("ehome.whenistheclosingdate.bankAccountAmountProperty");
	QAFExtendedWebElement investmentAccountAmountProperty= new QAFExtendedWebElement("ehome.whenistheclosingdate.investmentAccountAmountProperty");
	QAFExtendedWebElement saleOfExistingPropertyAmountProperty= new QAFExtendedWebElement("ehome.whenistheclosingdate.saleOfExistingPropertyAmountProperty");

	QAFExtendedWebElement saleOfExistingAmountProperty= new QAFExtendedWebElement("ehome.whenistheclosingdate.saleOfExistingAmountProperty");
	QAFExtendedWebElement saleOfExistingCalender= new QAFExtendedWebElement("ehome.whenistheclosingdate.saleOfExistingCalender");
	QAFExtendedWebElement saleOfExistingMonth= new QAFExtendedWebElement("ehome.whenistheclosingdate.saleOfExistingMonth");

	QAFExtendedWebElement scotiabankLogo= new QAFExtendedWebElement("ehome.scotiabanklogo.image");
	QAFExtendedWebElement applicationTracter= new QAFExtendedWebElement("ehome.applicationstatustracker.image");
	QAFExtendedWebElement userloginname= new QAFExtendedWebElement("ehome.userloginname.image");
	QAFExtendedWebElement Back= new QAFExtendedWebElement("ehome.whenistheclosingdate.Back");

	QAFExtendedWebElement greatPropertyText= new QAFExtendedWebElement("ehome.whenistheclosingdate.header");
	QAFExtendedWebElement closingDateHeaderText= new QAFExtendedWebElement("ehome.whenistheclosingdate.ClosingDateHeader");
	QAFExtendedWebElement whenPropertyText= new QAFExtendedWebElement("ehome.whenistheclosingdate.whenText");
	QAFExtendedWebElement setClosingDatePropertyText= new QAFExtendedWebElement("ehome.whenistheclosingdate.setClosingDateText");
	QAFExtendedWebElement thisIsTheDatePropertyText= new QAFExtendedWebElement("ehome.whenistheclosingdate.thisIsTheDateText");
	QAFExtendedWebElement closingDateButton= new QAFExtendedWebElement("ehome.whenistheclosingdate.closingDateButton");
	QAFExtendedWebElement saleOfExistingdate = new QAFExtendedWebElement("ehome.saleOfExistingdate.datePicker");
	QAFExtendedWebElement saleOfExistingdateSelection = new QAFExtendedWebElement("ehome.saleOfExistingdateSelection.dateSelection.datePicker");
	QAFExtendedWebElement saleOfExistingdateSel = new QAFExtendedWebElement("ehome.saleOfExistingdateSel.dateSelection.date");
	QAFExtendedWebElement closedate = new QAFExtendedWebElement("ehome.closingDate.datePicker");
	QAFExtendedWebElement closedateSelection = new QAFExtendedWebElement("ehome.closingDate.dateSelection.datePicker");
	QAFExtendedWebElement closedateSel = new QAFExtendedWebElement("ehome.closingDate.dateSelection.date");

	QAFExtendedWebElement detailsOfDownPaymentHeader= new QAFExtendedWebElement("ehome.whenistheclosingdate.detailsOfDownPaymentHeader");
	QAFExtendedWebElement loansummary= new QAFExtendedWebElement("ehome.whenistheclosingdate.loansummary");

	QAFExtendedWebElement Continue = new QAFExtendedWebElement("ehome.tellus.continue.button");
	QAFExtendedWebElement continueWhattypeofproperty= new QAFExtendedWebElement("ehome.enteraddressmanually.continue.button");

	QAFExtendedWebDriver webDriver = new WebDriverTestBase().getDriver();
	WebDriverWait wait = new WebDriverWait(webDriver, 50000);

	String testCaseID = Utility.getScenarioID();


	@Given("^Customer should login and navigate to down payment sources details with the required input fields$")
	public void customerShouldLoginAndNavigateToDownPaymentSourcesDetailsWithTheRequiredInputFields() throws Throwable {

		Utility.launchURL(ConfigurationUtils.getBaseBundle().getPropertyValue("env.baseurl1"));
		Continue.click();

		QAFExtendedWebElement Enteraddress= new QAFExtendedWebElement("ehome.Address.address.text");
		String addressFromExcel = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_InputData",testCaseID , "Address");
		Enteraddress.sendKeys(addressFromExcel);

		//wait.until(ExpectedConditions.elementToBeClickable(address)); //Commenting this line due to failure over Grid
		Thread.sleep(8000);
		addressFirstOption.click();
		//TO click on continue button is address screen
		wait.until(ExpectedConditions.visibilityOf(continueWhattypeofproperty));
		continueWhattypeofproperty.click();

		//wait.pollingEvery(15, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.elementToBeClickable(TypeofPropertyhouseselect));
		Thread.sleep(15000);
		TypeofPropertyhouseselect.click();

		Thread.sleep(3000);
		Detached.click();

		wait.pollingEvery(5, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(sqft));
		String sqftFromExcel = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_InputData",testCaseID , "SQFT");
		sqft.sendKeys(sqftFromExcel);

		wait.until(ExpectedConditions.visibilityOf(ContinueButton));
		ContinueButton.click();

		wait.until(ExpectedConditions.visibilityOf(purchasePrice));
		String PurchasePriceFromExcel = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_InputData",testCaseID , "Purchase_Price");
		purchasePrice.sendKeys(PurchasePriceFromExcel);

		wait.until(ExpectedConditions.visibilityOf(ContinueButton));
		ContinueButton.click();

		wait.until(ExpectedConditions.visibilityOf(downPayment));
		String DownPaymentFromExcel = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_InputData",testCaseID , "Down_Payment_Amount");
		downPayment.sendKeys(DownPaymentFromExcel);

		wait.until(ExpectedConditions.visibilityOf(ContinueButton));
		ContinueButton.click();

		//wait.until(ExpectedConditions.elementToBeClickable(bankAccountOption));
		Thread.sleep(5000);
		bankAccountOption.click();
		investmentAccount.click();

		ContinueButton.click();

		wait.until(ExpectedConditions.visibilityOf(bankAccountAmountProperty));
		if(bankAccountAmountProperty.getAttribute("aria-expanded").contentEquals("false")) {
			bankAccountAmountProperty.click();
			String BankAccountAmountFromExcel = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_InputData",testCaseID , "Bank_Account_Amount");
			bankAccountAmount.sendKeys(BankAccountAmountFromExcel);
		}
		else {
			String BankAccountAmountFromExcel = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_InputData",testCaseID , "Bank_Account_Amount");
			bankAccountAmount.sendKeys(BankAccountAmountFromExcel);
		}
		Thread.sleep(5000);
		if(investmentAccountAmountProperty.getAttribute("aria-expanded").contentEquals("false")) {
			investmentAccountAmountProperty.click();
			String InvestmentAccountAmountFromExcel = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_InputData",testCaseID , "Investment_Account_Amount");
			investmentAccountAmount.sendKeys(InvestmentAccountAmountFromExcel);
		}
		else {
			String InvestmentAccountAmountFromExcel = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_InputData",testCaseID , "Investment_Account_Amount");
			investmentAccountAmount.sendKeys(InvestmentAccountAmountFromExcel);
		}
	}

	@Given("^Customer should login and navigate to down payment sources details with sale of existing property and other required input fields$")
	public void customerShouldLoginAndNavigateToDownPaymentSourcesDetailsWithSaleOfExistingPropertyAndOtherRequiredInputFields() throws Throwable {

		Utility.launchURL(ConfigurationUtils.getBaseBundle().getPropertyValue("env.baseurl1"));
		Continue.click();

		QAFExtendedWebElement Enteraddress= new QAFExtendedWebElement("ehome.Address.address.text");
		String addressFromExcel = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_InputData",testCaseID , "Address");
		Enteraddress.sendKeys(addressFromExcel);

		wait.until(ExpectedConditions.visibilityOf(address));
		addressFirstOption.click();
		//TO click on continue button is address screen
		wait.until(ExpectedConditions.visibilityOf(continueWhattypeofproperty));
		Thread.sleep(1000);
		continueWhattypeofproperty.click();

		//wait.pollingEvery(15, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(TypeofPropertyhouseselect));
		Thread.sleep(10000);
		TypeofPropertyhouseselect.click();

		Thread.sleep(3000);
		Detached.click();

		wait.pollingEvery(5, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(sqft));
		String sqftFromExcel = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_InputData",testCaseID , "SQFT");
		sqft.sendKeys(sqftFromExcel);

		wait.until(ExpectedConditions.visibilityOf(ContinueButton));
		ContinueButton.click();

		wait.until(ExpectedConditions.visibilityOf(purchasePrice));
		String PurchasePriceFromExcel = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_InputData",testCaseID , "Purchase_Price");
		purchasePrice.sendKeys(PurchasePriceFromExcel);

		wait.until(ExpectedConditions.visibilityOf(ContinueButton));
		ContinueButton.click();

		wait.until(ExpectedConditions.visibilityOf(downPayment));
		String DownPaymentFromExcel = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_InputData",testCaseID , "Down_Payment_Amount");
		downPayment.sendKeys(DownPaymentFromExcel);

		wait.until(ExpectedConditions.visibilityOf(ContinueButton));
		ContinueButton.click();

		//wait.until(ExpectedConditions.elementToBeClickable(bankAccountOption));
		Thread.sleep(5000);
		bankAccountOption.click();
		investmentAccount.click();
		saleOfExistingProperty.click();

		ContinueButton.click();

		wait.until(ExpectedConditions.visibilityOf(bankAccountAmountProperty));
		if(bankAccountAmountProperty.getAttribute("aria-expanded").contentEquals("false")) {
			bankAccountAmountProperty.click();
			String BankAccountAmountFromExcel = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_InputData",testCaseID , "Bank_Account_Amount");
			bankAccountAmount.sendKeys(BankAccountAmountFromExcel);
		}
		else {
			String BankAccountAmountFromExcel = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_InputData",testCaseID , "Bank_Account_Amount");
			bankAccountAmount.sendKeys(BankAccountAmountFromExcel);
		}

		Thread.sleep(5000);

		if(investmentAccountAmountProperty.getAttribute("aria-expanded").contentEquals("false")) {
			investmentAccountAmountProperty.click();
			String InvestmentAccountAmountFromExcel = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_InputData",testCaseID , "Investment_Account_Amount");
			investmentAccountAmount.sendKeys(InvestmentAccountAmountFromExcel);
		}
		else {
			String InvestmentAccountAmountFromExcel = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_InputData",testCaseID , "Investment_Account_Amount");
			investmentAccountAmount.sendKeys(InvestmentAccountAmountFromExcel);
		}

		Thread.sleep(5000);

		if(saleOfExistingPropertyAmountProperty.getAttribute("aria-expanded").contentEquals("false")) {
			saleOfExistingPropertyAmountProperty.click();
			String saleOfExistingPropertyAccountAmountFromExcel = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_InputData",testCaseID , "Sale_Of_Existing_Property");
			saleOfExistingAmountProperty.sendKeys(saleOfExistingPropertyAccountAmountFromExcel);
			saleOfExistingdate.click();
			Select saleOfexistingSelect =  new Select(saleOfExistingdateSelection);
			saleOfexistingSelect.selectByIndex(3);
			saleOfExistingdateSel.click();
		}
		else {
			String saleOfExistingPropertyAccountAmountFromExcel = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_InputData",testCaseID , "Sale_Of_Existing_Property");
			saleOfExistingAmountProperty.sendKeys(saleOfExistingPropertyAccountAmountFromExcel);
			saleOfExistingdate.click();
			Select saleOfexistingSelect =  new Select(saleOfExistingdateSelection);
			saleOfexistingSelect.selectByIndex(3);
			saleOfExistingdateSel.click();
		}
	}

	@When("^click on continue button$")
	public void click_on_continue_button() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		ContinueButtonDetails.click();
	}

	@Then("^Verify 'Scotiabank Logo' should be as \"([^\"]*)\" on the screen, Verify 'Application status' should be as \"([^\"]*)\" tracker on the screen, Verify for the 'Login username' as \"([^\"]*)\" on the screen, Verify the 'chat icon' functionality as \"([^\"]*)\" on the screen, 'Back' button should be as \"([^\"]*)\"$")
	public void verify_Scotiabank_Logo_should_be_as_on_the_screen_Verify_Application_status_should_be_as_tracker_on_the_screen_Verify_for_the_Login_username_as_on_the_screen_Verify_the_chat_icon_functionality_as_on_the_screen_Back_button_should_be_as(String arg1, String arg2, String arg3, String arg4, String arg5) throws Throwable {

		scotiabankLogo.assertPresent ("Couldn't find the ScotiaBank logo"  );
		if(!scotiabankLogo.verifyPresent())
			throw new AssertionError("Couldn't find the ScotiaBank logo");
		//To Check Application status tracker
		applicationTracter.assertPresent ( "Application status tracker image is missing" );
		if(!applicationTracter.verifyPresent())
			throw new AssertionError("Couldn't find the Application status tracker");

		String Back_Text = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_ExpectedData",testCaseID , "Back_Button_Text");
		Assert.assertEquals(Back.getText(), Back_Text,"Couldn't found Back button, Back button should be present");
	}

	@Then("^'Great' should be displayed as \"([^\"]*)\" , 'When is the closing date\\?' text should be displayed as \"([^\"]*)\", 'Set Closing Date' text for calender should be displayed as \"([^\"]*)\", 'This is the date on which the sale of the property becomes final and you take possession\\.' text should be displayed as \"([^\"]*)\"$")
	public void great_should_be_displayed_as_When_is_the_closing_date_text_should_be_displayed_as_Set_Closing_Date_text_for_calender_should_be_displayed_as_This_is_the_date_on_which_the_sale_of_the_property_becomes_final_and_you_take_possession_text_should_be_displayed_as(String greatText, String whenText, String setClosingDateText, String thisIsTheDateText) throws Throwable {

		String GreatHeader = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_ExpectedData",testCaseID , "Great_Header");
		Assert.assertEquals(greatPropertyText.getText(), GreatHeader,"Couldn't found expected header Text, 'Great Header Text' not found");

		String ClosingDateHeader = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_ExpectedData",testCaseID , "Closing_Date_Header");
		Assert.assertEquals(closingDateHeaderText.getText(), ClosingDateHeader,"Couldn't found expected header Text, 'Closing Date Header Text' not found");
	}

	@Then("^I am on ‘When is the closing date\\?’ page$")
	public void i_am_on_When_is_the_closing_date_page() throws Throwable {

		if(!greatPropertyText.verifyText( "Great!"  ))
			throw new AssertionError("Not able to launch When is the Closing Date page");
	}

	@Then("^I am presented with a date field to select/enter my closing date, I can only select dates in the future \\(greater than today date, excluding weekends\\)$")
	public void i_am_presented_with_a_date_field_to_select_enter_my_closing_date_I_can_only_select_dates_in_the_future_greater_than_today_date_excluding_weekends() throws Throwable {

		closedate.click();
		Select closedateSelect =  new Select(closedateSelection);
		closedateSelect.selectByIndex(2);
		closedateSel.click();
	}

	@When("^I enter or change my closing date and I have indicated “Sale of Existing Property” as a down payment source and the closing date of my Sale property occurs after the Purchase Closing date$")
	public void i_enter_or_change_my_closing_date_and_I_have_indicated_Sale_of_Existing_Property_as_a_down_payment_source_and_the_closing_date_of_my_Sale_property_occurs_after_the_Purchase_Closing_date() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		closedate.click();
		Thread.sleep(5000);

		Select closedateSelect =  new Select(closedateSelection);
		closedateSelect.selectByIndex(1);

//	        wait.until(ExpectedConditions.visibilityOf(closedateSelection));
		closedateSel.click();
		Thread.sleep(3000);
	}

	@When("^Click on Continue button from closing date$")
	public void click_on_Continue_button_from_closing_date() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		ContinueButton.click();
	}


	@Then("^I want the following message to display “It appears you may require Bridge Financing to support the purchase of your new home as it takes place before the sale of your existing property\\. Once you have submitted your application, your Mortgage Specialist will be pleased to discuss some options with you\\.”$")
	public void i_want_the_following_message_to_display_It_appears_you_may_require_Bridge_Financing_to_support_the_purchase_of_your_new_home_as_it_takes_place_before_the_sale_of_your_existing_property_Once_you_have_submitted_your_application_your_Mortgage_Specialist_will_be_pleased_to_discuss_some_options_with_you() throws Throwable {
		// Write code here that turns the phrase above into concrete actions

	}

	@When("^Click on Back button$")
	public void click_on_Back_button() throws Throwable {
		Back.click();

	}

	@Then("^navigate to down payment sources details$")
	public void navigate_to_down_payment_sources_details() throws Throwable {
		String DownPaymentHeader = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_ExpectedData",testCaseID , "Down_Payment_Header");
		Assert.assertEquals(detailsOfDownPaymentHeader.getText(), DownPaymentHeader,"Couldn't found expected Down Payment Header Text, 'Down Payment Header Text' should be present");
		/*if(!detailsOfDownPaymentHeader.verifyText(DownPaymentHeader))
			throw new AssertionError("Not able to launch details of down payment sources page");*/
	}

	@Then("^navigate to Your eHOME Loan Summary page$")
	public void navigate_to_Your_eHOME_Loan_Summary_page() throws Throwable {
		String LoanSummaryHeader = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_ExpectedData",testCaseID , "Loan_Summary_Header");
		//Assert.assertEquals(loansummary.getText(), DownPaymentHeader,"Couldn't found expected Down Payment Header Text, 'Down Payment Header Text' should be present");
		if(!loansummary.verifyText(LoanSummaryHeader))
			throw new AssertionError("Not able to launch details of Loan Summary page");
	}
}
