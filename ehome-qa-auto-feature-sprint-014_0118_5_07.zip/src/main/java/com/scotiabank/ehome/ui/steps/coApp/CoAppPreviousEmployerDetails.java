package com.scotiabank.ehome.ui.steps.coApp;
import com.qmetry.qaf.automation.step.QAFTestStepProvider;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.quantum.utils.ConfigurationUtils;
import com.scotiabank.ehome.ui.steps.Common;
import com.scotiabank.ehome.ui.steps.Utility;
import com.scotiabank.ehome.ui.steps.stage4.EmploymentDuration;
import com.scotiabank.ehome.ui.steps.stage4.PreviousEmployerDetails;

import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.support.ui.WebDriverWait;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import java.util.concurrent.TimeUnit;
import static com.scotiabank.ehome.ui.steps.Utility.*;

@QAFTestStepProvider

public class CoAppPreviousEmployerDetails {
	public static WebDriverWait wait=Utility.getWait();	
	  String testCaseID = Utility.getScenarioID();
	
	@Given("^Customer should login and navigates to CoApp Previous Employer details$")
	public void customer_should_login_and_navigates_to_CoApp_Previous_Employer_details() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
//		 String strtestCaseID = Utility.getScenarioID();
//		  if (strtestCaseID.contains("CoApp"))
//		  {
//			  Common.TraverseToNewHomeSectionBreaker();
//			  Thread.sleep(10000);
//			  Common.TraverseFromNewHomeToRateSectionBreaker(strtestCaseID,"Co-App_InputData");
//			  Common.TraverseRateSectionToEmploymentSectionBreaker();
//			  Common.TraverseFromEmploymentSectionToLandOnCoApplicantPage();
//			  CoAppIntro.startSectionButtonClicked();
//		  }
		 Utility.launchURL(ConfigurationUtils.getBaseBundle().getPropertyValue ("env.baseurl3"));
			CoAppIntro.startSectionButtonClicked();
			CoAppEmpStatus.employedButtonClicked();
			CoAppEmpType.commissionedSalesButtonClicked();
			  Thread.sleep(3000);
			String jobField=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Co-App_ExpectedData", testCaseID, "Industry_JobTitle_Field_of_work");
			 CoAppIndustryJobTitle.jobField(jobField);
			  Thread.sleep(3000);
			String jobTitle=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Co-App_ExpectedData", testCaseID, "Industry_JobTitle_Job_Title");
			 CoAppIndustryJobTitle.jobTitle(jobTitle);
			  Thread.sleep(3000);
			String occupationType=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Co-App_ExpectedData", testCaseID, "Industry_JobTitle_Occupation_Type");
			 CoAppIndustryJobTitle.occupationType(occupationType);
			  Thread.sleep(3000);
			Common.continueButtonClicked();
			String employername=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Co-App_InputData", testCaseID, "Employer_Details_employername");
			CoAppEmployerDetails.employername(employername);
			String employerphone=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Co-App_InputData", testCaseID, "Employer_Details_employerphone");
			CoAppEmployerDetails.employerphone(employerphone);	
			 Thread.sleep(3000);
			Common.continueButtonClicked();
			String address=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Co-App_InputData", testCaseID, "Employer_Address");
			CoAppEmployerAddress.employeraddress(address);
			Thread.sleep(3000);
			Common.continueButtonClicked();
			CoAppAnnualIncome.annualincomeSalary("5000");
			Thread.sleep(3000);
			Common.continueButtonClicked();
			Thread.sleep(30000);
			String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Co-App_InputData", testCaseID, "Employer_Duration_lessThan2Years_years");
			String value1=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Co-App_InputData", testCaseID, "Employer_Duration_lessThan2Years_months");
			EmploymentDuration.employmentDuration("1 year", "0 months"); 
			Thread.sleep(3000);
			Common.continueButtonClicked();
	}
	
	
	@When("^Verify \"([^\"]*)\" message should be on the CoAPP Previous Employer details screen$")
	public void verify_should_be_on_the_CoAPP_Previous_Employer_details_screen1(String dataPointer) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String valueRaw=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Co-App_ExpectedData", testCaseID, dataPointer);
		System.out.println("testCaseID==========="+testCaseID);
		System.out.println("dataPointer==========="+dataPointer);
		System.out.println("value==========="+valueRaw);
		String value = Utility.messageFormatName(valueRaw, Common.coApplicantFirstName);
		QAFExtendedWebElement headerMessage= new QAFExtendedWebElement("ehome.CoApp.HeaderMessage");
		 wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(headerMessage));
		Assert.assertEquals(headerMessage.getText(), value,"Couldn't found expected header text");
	    
	}

	@Then("^Verify \"([^\"]*)\" header text should be on the CoAPP Previous Employer details screen$")
	public void verify_header_should_be_on_the_CoAPP_Previous_Employer_details_screen(String dataPointer) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions 
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Co-App_ExpectedData", testCaseID, dataPointer);
		Assert.assertEquals(Common.headertext(), value,"Couldn't found expected header text");
	    
	}
	
	@When("^Enter the \"([^\"]*)\" invalid Employer name in the CoApp Previous Employer details screen$")
	public void enter_the_invalid_Employer_name_in_the_CoApp_Previous_Employer_details_screen(String dataPointer) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String col="InputValues";
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "CommonErrorMessages", dataPointer,col);
		QAFExtendedWebElement previousEmployerName= new QAFExtendedWebElement("ehome.previousEmployerDetails.employerName");
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(previousEmployerName));
		previousEmployerName.clear();
		previousEmployerName.sendKeys(value);
	   
	}

	@Then("^\"([^\"]*)\" should be displayed for name in the CoApp Previous Employer details screen$")
	public void should_be_displayed_for_name_in_the_CoApp_Previous_Employer_details_screen(String dataPointer) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage04_Employment_ExpectedData", testCaseID, dataPointer);
		QAFExtendedWebElement previousEmployerNameErrorMessage= new QAFExtendedWebElement("ehome.previousEmployerDetails.errorMessage");
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(previousEmployerNameErrorMessage));
		System.out.println("testCaseID==========="+testCaseID);
		System.out.println("dataPointer==========="+dataPointer);
		System.out.println("value==========="+value);
		Assert.assertEquals(previousEmployerNameErrorMessage.getText(), value,"Couldn't found expected header text");
	   
	}
	
	
	@Then("^Green with a check mark should be displayed in the Previous CoApp Previous Employer details screen$")
	public void green_with_a_check_mark_should_be_displayed_in_the_Previous_CoApp_Previous_Employer_details_screen() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   
	}
	
	@When("^Enter the \"([^\"]*)\" valid Employer name in the CoApp Previous Employer details screen$")
	public void enter_the_valid_Employer_name_in_the_CoApp_Previous_Employer_details_screen(String dataPointer) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Co-App_InputData", testCaseID, dataPointer);
		PreviousEmployerDetails.previousEmployerName(value);
	 
	}
	@Then("^Green with a check mark should be displayed in the CoApp Previous Employer details screen$")
	public void green_with_a_check_mark_should_be_displayed_in_the_CoApp_Previous_Employer_details_screen() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		QAFExtendedWebElement greenicon= new QAFExtendedWebElement("ehome.previousEmployerDetails.greenicon.name");
		if(!greenicon.isPresent()) {
			Assert.fail("Couldn't see the green check mark");
		}
	}
}
