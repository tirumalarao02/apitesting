package com.scotiabank.ehome.ui.steps.stage1;

import static com.scotiabank.ehome.ui.steps.Utility.getScreenDataset;

import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.qmetry.qaf.automation.step.QAFTestStepProvider;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebDriver;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.quantum.utils.ConfigurationUtils;
import com.scotiabank.ehome.ui.steps.Common;
import com.scotiabank.ehome.ui.steps.Utility;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

@QAFTestStepProvider
public class TimeToCreateUserName {
	
	private QAFExtendedWebDriver webDriver = Utility.getDriver();
    public Actions action = null;
    public static WebDriverWait wait=Utility.getWait();	
    
    QAFExtendedWebElement timeToCreateUserNameHeader= new QAFExtendedWebElement("ehome.timeToCreateUserName.headerTitle");
    QAFExtendedWebElement timeToCreateUserNameTitle= new QAFExtendedWebElement("ehome.timeToCreateUserName.headerText");
    QAFExtendedWebElement UserNameText= new QAFExtendedWebElement("ehome.timeToCreateUserName.UserNameText");
    QAFExtendedWebElement UserNameSupportText= new QAFExtendedWebElement("ehome.timeToCreateUserName.UserNameSupportText");
    QAFExtendedWebElement UserNameCharacters= new QAFExtendedWebElement("ehome.timeToCreateUserName.UserNameCharacters");
    QAFExtendedWebElement UserNameNumber= new QAFExtendedWebElement("ehome.timeToCreateUserName.UserNameNumber");
    QAFExtendedWebElement UserNameSpecialCharacters= new QAFExtendedWebElement("ehome.timeToCreateUserName.UserNameSpecialCharacters");
    QAFExtendedWebElement UserNameRepeatCharacters= new QAFExtendedWebElement("ehome.timeToCreateUserName.UserNameRepeatCharacters");
    QAFExtendedWebElement otpHeader= new QAFExtendedWebElement("ehome.timeToCreateUserName.headerText");
    QAFExtendedWebElement createPasswordHeader= new QAFExtendedWebElement("ehome.createPassword.headerTitle");
    
	@Given("^Customer should login and navigates to Time To Create User Name Screen$")
	public void customer_should_login_and_navigates_to_Time_To_Create_User_Name_Screen() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Utility.launchURL(ConfigurationUtils.getBaseBundle().getPropertyValue ("env.baseurl0"));
		Welcome.viewOurPrivacyAgreementButtonClicked();
		PrivacyAgreement.acceptAndContinuetButtonClicked();
		SOLCustomerQuestion.triageQuestionsButtonClicked();
		SOLCustomerQuestion.noButtonClicked();
		LegalName.validlegalname("Mrs", "Delna", "Dr", "Press");
		Common.continueButtonClicked();
		MaritalStatus.maritalstatusselect("Married");
		Common.continueButtonClicked();
		DateOfBirth.dateOfBirth("20", "Mar", "1998");
		Common.continueButtonClicked();
		WhatsYourAddress.ValidWhatsYourAddressValues("2201", "EGLINTON AVE", "TORONTO", "ONTARIO","M1K2M1");
		Common.continueButtonClicked();
		Thread.sleep(4000);
		EmailAddress.ValidEmailAddress("test@test.com", "test@test.com");
		Common.continueButtonClicked();
		Thread.sleep(4000);
		MobilePhoneNumber.ValidMobilePhoneNumber("616", "237", "2324");
		Common.continueButtonClicked();
		Thread.sleep(4000);
		OTPScreen.ValidOTPCode("1", "1", "1", "1", "1", "1");
		Thread.sleep(4000);
		Common.backButtonClicked();//THIS SHOULD BE REMOVED
	    Thread.sleep(4000);//THIS SHOULD BE REMOVED
	    Common.continueButtonClicked();//THIS SHOULD BE REMOVED
	    Common.continueButtonClicked();//THIS SHOULD BE REMOVED
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(timeToCreateUserNameHeader));
	}
	
	@Then("^Verify \"([^\"]*)\" message should be on Time To Create User Name Screen$")
	public void verify_message_should_be_on_Time_To_Create_User_Name_Screen(String dataPointer) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String testCaseID = Utility.getScenarioID();
		String timeToCreateUserNameHeaderText=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage01_Registration_ExpectedDa", testCaseID, dataPointer);
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(timeToCreateUserNameHeader));
		Assert.assertEquals(timeToCreateUserNameHeader.getText(), timeToCreateUserNameHeaderText,"Couldn't find expected header message");
	}

	@Then("^Verify \"([^\"]*)\" headertext should be on Time To Create User Name Screen$")
	public void verify_headertext_should_be_on_Time_To_Create_User_Name_Screen(String dataPointer) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String testCaseID = Utility.getScenarioID();
		String timeToCreateUserNameTitleText=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage01_Registration_ExpectedDa", testCaseID, dataPointer);
		Assert.assertEquals(timeToCreateUserNameTitle.getText(), timeToCreateUserNameTitleText,"Couldn't find expected title message");
	}

	@Then("^Verify \"([^\"]*)\" UserName should be on Time To Create User Name Screen$")
	public void verify_UserName_should_be_on_Time_To_Create_User_Name_Screen(String dataPointer) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String testCaseID = Utility.getScenarioID();
		String UserNameTxt=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage01_Registration_ExpectedDa", testCaseID, dataPointer);
		Assert.assertEquals(UserNameText.getAttribute("placeholder"), UserNameTxt, "Couldn't find the UserName field");
	}

	@Then("^Verify \"([^\"]*)\" UserName Support Text should be on Time To Create User Name Screen$")
	public void verify_UserName_Support_Text_should_be_on_Time_To_Create_User_Name_Screen(String dataPointer) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String testCaseID = Utility.getScenarioID();
		String timeToCreateUserNameSupportText=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage01_Registration_ExpectedDa", testCaseID, dataPointer);
		Assert.assertEquals(UserNameSupportText.getText(), timeToCreateUserNameSupportText,"Couldn't find expected UserName Support message");
	}

	@Then("^Verify \"([^\"]*)\" UserName Characters Text should be on Time To Create User Name Screen$")
	public void verify_UserName_Characters_Text_should_be_on_Time_To_Create_User_Name_Screen(String dataPointer) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String testCaseID = Utility.getScenarioID();
		String timeToCreateUserNameCharatersText=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage01_Registration_ExpectedDa", testCaseID, dataPointer);
		Assert.assertEquals(UserNameCharacters.getText(), timeToCreateUserNameCharatersText,"Couldn't find expected UserName Characters message");
	}

	@Then("^Verify \"([^\"]*)\" UserNameNumber should be on Time To Create User Name Screen$")
	public void verify_UserNameNumber_should_be_on_Time_To_Create_User_Name_Screen(String dataPointer) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String testCaseID = Utility.getScenarioID();
		String timeToCreateUserNameNumberText=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage01_Registration_ExpectedDa", testCaseID, dataPointer);
		Assert.assertEquals(UserNameNumber.getText(), timeToCreateUserNameNumberText,"Couldn't find expected UserName Number message");
	}

	@Then("^Verify \"([^\"]*)\" UserName Special Characters should be on Time To Create User Name Screen$")
	public void verify_UserName_Special_Characters_should_be_on_Time_To_Create_User_Name_Screen(String dataPointer) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String testCaseID = Utility.getScenarioID();
		String timeToCreateUserNameSpecialCharatersText=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage01_Registration_ExpectedDa", testCaseID, dataPointer);
		Assert.assertEquals(UserNameSpecialCharacters.getText(), timeToCreateUserNameSpecialCharatersText,"Couldn't find expected UserName Special Characters message");
	}

	@Then("^Verify \"([^\"]*)\" UserName Repeat Special Characters should be on Time To Create User Name Screen$")
	public void verify_UserName_Repeat_Special_Characters_should_be_on_Time_To_Create_User_Name_Screen(String dataPointer) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String testCaseID = Utility.getScenarioID();
		String timeToCreateUserNameRepeatCharatersText=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage01_Registration_ExpectedDa", testCaseID, dataPointer);
		Assert.assertEquals(UserNameRepeatCharacters.getText(), timeToCreateUserNameRepeatCharatersText,"Couldn't find expected UserName Repeat Characters message");
	}
    
	@When("^Back button is clicked on Time To Create User Name Screen$")
	public void back_button_is_clicked_on_Time_To_Create_User_Name_Screen() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    Common.backButtonClicked();
	    Thread.sleep(2000);
	}

	@Then("^\"([^\"]*)\" screen should be displayed\\.$")
	public void screen_should_be_displayed(String dataPointer) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String testCaseID = Utility.getScenarioID();
		String otpHeaderText=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage01_Registration_ExpectedDa", testCaseID, dataPointer);
		Assert.assertEquals(otpHeader.getText(), otpHeaderText,"Couldn't find expected OTP page");
	}
	
	public static void ValidUserName(String UserNameTxt) throws InterruptedException {
		 QAFExtendedWebElement UserNameText= new QAFExtendedWebElement("ehome.timeToCreateUserName.UserNameText");
		 UserNameText.sendKeys(UserNameTxt);
	}
	
	@When("^Continue button is clicked after entering valid \"([^\"]*)\" on Time To Create User Name Screen$")
	public void continue_button_is_clicked_after_entering_valid_on_Time_To_Create_User_Name_Screen(String dataPointer) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String testCaseID = Utility.getScenarioID();
		String UserNameTxt=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage01_Registration_InputData", testCaseID, dataPointer);
		ValidUserName(UserNameTxt);
		Common.continueButtonClicked();
	    Thread.sleep(2000);
	}
	
	@Then("^Verify \"([^\"]*)\" screen should be displayed$")
	public void verify_screen_should_be_displayed(String dataPointer) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String testCaseID = Utility.getScenarioID();
		String createPasswordHeaderText=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage01_Registration_ExpectedDa", testCaseID, dataPointer);
		Assert.assertEquals(createPasswordHeader.getText(), createPasswordHeaderText,"Couldn't find expected create Password Header page");
	}
}
