package com.scotiabank.ehome.ui.steps;
import com.qmetry.qaf.automation.step.QAFTestStepProvider;
import com.qmetry.qaf.automation.ui.WebDriverTestBase;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebDriver;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.quantum.utils.ConfigurationUtils;

import cucumber.api.PendingException;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.FluentWait;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.beans.PropertyChangeListener;

import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.Date;
import static com.scotiabank.ehome.ui.steps.Utility.*;
@QAFTestStepProvider

public class MortgageSummary {
	private QAFExtendedWebDriver webDriver = null;
    public Actions action = null;
    public WebDriverWait wait=null;
	 //1
    @Given("^Customer should login and navigates to Mortgage summary Screen$")
    public void CustomershouldloginandnavigatestoMortgagesummaryScreen() throws Throwable {
    	// Write code here that turns the phrase above into concrete actions
    	   webDriver = new WebDriverTestBase().getDriver();
           webDriver.get(ConfigurationUtils.getBaseBundle().getPropertyValue("env.baseurl"));
           
          // webDriver.manage().window().maximize();
          // Actions action = new Actions(webDriver);
           //WebDriverWait wait = new WebDriverWait(webDriver, 10);
           QAFExtendedWebElement Continue = new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div/div/div[3]/div/button");
           Continue.click();
           
          /* QAFExtendedWebElement whatTypeOfRate = new QAFExtendedWebElement("ehome.whattypeofrate.header");
           if (!whatTypeOfRate.verifyText("What type of rate are you looking for?"))
               throw new AssertionError("Not able to launch what type of rate page");*/
           QAFExtendedWebElement selectFixed= new QAFExtendedWebElement("ehome.whattypeofrate.selectfixed.radio");
           selectFixed.click ();
           Thread.sleep(3000);
           QAFExtendedWebElement twoyears= new QAFExtendedWebElement("ehome.termsofrate.2years.radio");
           if(!twoyears.verifyPresent())
               throw new AssertionError("Couldn't find 2 years button");
           twoyears.click();
           QAFExtendedWebElement twoyear= new QAFExtendedWebElement("ehome.ratepresentation.twoyears.select");
	        if(!twoyear.verifyPresent())
	            throw new AssertionError("Couldn't find 2 years button");
	        twoyear.click();  
	     QAFExtendedWebElement LockandHold= new QAFExtendedWebElement("ehome.ratelock.LockandHold");
       if(!LockandHold.verifyPresent())
           throw new AssertionError("Couldn't find Lock & Hold on the screen");
       LockandHold.click();
	     Thread.sleep(2000); 
	//	 QAFExtendedWebElement RateCustomizationHeader= new QAFExtendedWebElement("ehome.RateCustomization.Unlockyourrate");
	//	 Assert.assertEquals(RateCustomizationHeader.getText(), "Unlock your rate");
		 
		 QAFExtendedWebElement RateCustomizationContinuebutton= new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[7]/div/button[2]");
		 RateCustomizationContinuebutton.click();
		 
		 QAFExtendedWebElement Continueinstep= new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[3]/div/button[2]");
		 Continueinstep.isPresent();
		 Continueinstep.click();
		 
		 QAFExtendedWebElement YesIminterested= new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[4]/div[2]/button");
		 YesIminterested.isPresent();
		 YesIminterested.click();
		 
		 QAFExtendedWebElement ContinueinLOCConfirmation= new QAFExtendedWebElement("//*[@id='app']/div/div[1]/div[2]/button[2]");
		 ContinueinLOCConfirmation.isPresent();
		 ContinueinLOCConfirmation.click();
    } 
    //2
    @When("^Customer click on Back button in Mortgage summary Screen$")
    public void CustomerclickonBackbuttoninMortgagesummaryScreenn() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        QAFExtendedWebElement Back= new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[5]/div/button[1]");
        Back.isPresent();
        Back.click();
    	

    }
    
    @Then("^It should navigate to LOCConfirmation screen$")
    public void ItshouldnavigatetoLOCConfirmationscreen() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	QAFExtendedWebElement LOCHeader= new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[1]/div[3]");
       Assert.assertEquals(LOCHeader.getText(), "We’ll assess your eligibility for a $40,000 secured line of credit");
        
    }
  //3
    @When("^Customer click on Continue button in Mortgage summary Screen$")
    public void CustomerclickonContinuebuttoninMortgagesummaryScreenn() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        
    }
    
    @Then("^It should navigate to Mortgage summary Screen$")
    public void ItshouldnavigatetoMortgagesummaryscreen() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	
        
    }

}
