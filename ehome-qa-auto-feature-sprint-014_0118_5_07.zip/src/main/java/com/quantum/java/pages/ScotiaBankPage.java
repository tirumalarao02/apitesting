package com.quantum.java.pages;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import org.openqa.selenium.support.ui.Select;

public class ScotiaBankPage extends WebDriverBaseTestPage<WebDriverTestPage> {
    @FindBy(locator = "css=ul#main-nav a.personal-banking")
    private QAFWebElement personalBankingLinkElement;

    @FindBy(locator = "css=a.lang-en")
    private QAFWebElement englishLanguageLinkElement;

    @FindBy(locator = "css=div#personal-banking-content-links")
    private QAFWebElement productLinkElement;

    @FindBy(locator = "css=div#background-location a.north-america")
    private QAFWebElement northAmericaLinkElement;

    @FindBy(locator = "css=div#background-location ul.country-list li:nth-child(1) a")
    private QAFWebElement canadaLinkElement;

    @FindBy(locator = "css=li:nth-child(1) div.visible-desktop a.btn-primary")
    private QAFWebElement applyNowBtnElement;

    @FindBy(locator = "css=div.cta-secondary a")
    private QAFWebElement applyNowLinkElement;

    @FindBy(locator = "css=div.inputContainer input#DISC_AGREE")
    private QAFWebElement termsandconChkbxElement;

    @FindBy(locator = "css=div.buttons button.red-btn")
    private QAFWebElement startBtnElement;

    @FindBy(locator = "css=div.progress-bar div.sub-title h2")
    private QAFWebElement personalInformationTextElement;

    @FindBy(locator = "css=#TITLE")
    private QAFWebElement titleSelectElement;

    @FindBy(locator = "css=#FNAME")
    private QAFWebElement firstNameInputTextElement;

    @FindBy(locator = "css=#INITIAL")
    private QAFWebElement initialInputTextElement;

    @FindBy(locator = "css=#LNAME")
    private QAFWebElement lastNameInputTextElement;

    @FindBy(locator = "css=span#helpLine span.phone")
    private QAFWebElement scotiaHelplineNumberTextElement;

    @FindBy(locator = "css=section#product-cta div.product-cta-content a.button--primary")
    private QAFWebElement applyNowBtnMasterCardElement;

    @FindBy(locator = "css=div.disclosureAccept button.button-primary")
    private QAFWebElement acceptAndContinueBtnMasterCardElement;

    @FindBy(locator = "css=div.progress-text span")
    private QAFWebElement enterYourInfoTextElement;

    @FindBy(locator = "css=div.page-header li a.tooltip-toggle")
    private QAFWebElement contactUsLinkElement;


    @Override
    protected void openPage(PageLocator locator, Object... args) {
    }

    public void clickOnPersonalBankingLink(){
        personalBankingLinkElement.click();
    }

    public void clickOnEnglishLanguageLink(){
        englishLanguageLinkElement.click();
    }

    public void clickOnProductLink(){
        productLinkElement.click();
    }

    public void clickOnNorthAmericaLink(){
        northAmericaLinkElement.click();
    }

    public void clickOnCanadaLink(){
        canadaLinkElement.click();
    }

    public void clickOnApplyNowButton(){
        applyNowBtnElement.click();
    }

    public void clickOnApplyNowLink(){
        applyNowLinkElement.click();
    }

    public void clickOnTermsAndConChkbx(){
        termsandconChkbxElement.click();
    }

    public void clickOnStartButton(){
        startBtnElement.click();
    }

    public void verifyPersonalInformationText(String value){
        personalInformationTextElement.verifyText(value);
    }

    public void selectTitle(String value){
        Select oselect = new Select(titleSelectElement);
        oselect.selectByVisibleText(value);
    }

    public void enterFirstName(String fname){
        firstNameInputTextElement.clear();
        firstNameInputTextElement.sendKeys(fname);
    }

    public void enterInitials(String initials){
        initialInputTextElement.clear();
        initialInputTextElement.sendKeys(initials);
    }

    public void enterLastName(String lname){
        lastNameInputTextElement.clear();
        lastNameInputTextElement.sendKeys(lname);
    }

    public void verifyScotiaHelplineNumberText(String value){
        scotiaHelplineNumberTextElement.verifyText(value);
    }

    public void clickOnApplyNowButtonMastercard(){
        applyNowBtnMasterCardElement.click();
    }

    public void clickOnAcceptAndContinueButtonMastercard(){
        acceptAndContinueBtnMasterCardElement.click();
    }

    public void verifyEnterYourInfoText(String value){
        enterYourInfoTextElement.verifyText(value);
    }

    public void verifyContactUsLink(){
        contactUsLinkElement.verifyPresent();
    }
}
