package com.scotiabank.ehome.ui.steps.stage1;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.step.QAFTestStepProvider;
import com.qmetry.qaf.automation.ui.WebDriverTestBase;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebDriver;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.quantum.utils.ConfigurationUtils;
import com.scotiabank.ehome.ui.steps.Common;
import com.scotiabank.ehome.ui.steps.ExcelDataToDataTable;
import com.scotiabank.ehome.ui.steps.Utility;
import com.scotiabank.ehome.ui.steps.valueObjects.Tuple;
import com.scotiabank.ehome.ui.steps.valueObjects.TypeOfRateVO;
import com.thoughtworks.qdox.model.expression.Add;

import org.junit.runner.RunWith;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;

import cucumber.api.CucumberOptions;
import cucumber.api.DataTable;
import cucumber.api.PendingException;
import cucumber.api.Transform;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import cucumber.api.junit.Cucumber;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import java.io.File;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import static com.scotiabank.ehome.ui.steps.BusinessCalculations.*;
import static com.scotiabank.ehome.ui.steps.Utility.*;

import org.openqa.selenium.Keys;
@QAFTestStepProvider

public class PrivacyAgreement {
	public static WebDriverWait wait=Utility.getWait();	
	//private Map<String,Map<String,Boolean>> privacyAgreementDataset = getScreenDataset(Utility.getExcelFilePath("eHomeTestDatastage-1.xlsx"), "PA");
	    
	@Given("^Customer should login and navigates to privacy agreement screen$")
	public void customer_should_login_and_navigates_to_privacy_agreement_screen() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Utility.launchURL(ConfigurationUtils.getBaseBundle().getPropertyValue ("env.baseurl0"));
		Welcome.viewOurPrivacyAgreementButtonClicked();
	   
	}

	@When("^Verify \"([^\"]*)\" should be on the privacy agreement screen$")
	public void verify_should_be_on_the_privacy_agreement_screen(String dataPointer) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String testCaseID = Utility.getScenarioID();
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage01_Registration_ExpectedDa", testCaseID, dataPointer);
		QAFExtendedWebElement message= new QAFExtendedWebElement("ehome.PrivacyAgreement.message");
       wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(message));
	   Assert.assertEquals(message.getText(), value,"Couldn't found expected header message");
	}
	


	@Then("^Verify \"([^\"]*)\" headertext should be on the privacy agreement screen$")
	public void verify_headertext_should_be_on_the_privacy_agreement_screen(String dataPointer) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String testCaseID = Utility.getScenarioID();
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage01_Registration_ExpectedDa", testCaseID, dataPointer);
		QAFExtendedWebElement headertext= new QAFExtendedWebElement("ehome.PrivacyAgreement.message.Header");
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(headertext));
		Assert.assertEquals(headertext.getText(), value,"Couldn't found expected header text");
	   
	}


	@Then("^Verify the \"([^\"]*)\" content should be on the privacy agreement screen$")
	public void verify_the_content_should_be_on_the_privacy_agreement_screen(String dataPointer) throws Throwable {
	   // Write code here that turns the phrase above into concrete actions
	   String testCaseID = Utility.getScenarioID();
	   String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage01_Registration_ExpectedDa", testCaseID, dataPointer);
		 QAFExtendedWebElement content= new QAFExtendedWebElement("ehome.PrivacyAgreement.content");
       wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(content));
	   Assert.assertEquals(content.getText(), value,"Couldn't found expected content text");
	   
	}
	//Privacy-Agreement-TC-002

	@When("^Click on To eHome button on the privacy agreement screen$")
	public void click_on_eHome_button_on_the_privacy_agreement_screen() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		QAFExtendedWebElement eHome= new QAFExtendedWebElement("ehome.PrivacyAgreement.ToeHome");
	    wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(eHome));
	    eHome.click();
	   
	}

	@When("^Click on \"([^\"]*)\" button on the privacy agreement screen$")
	public void click_on_the_PrivacyPolicy_View_our_privacy_agreement(String dataPointer) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String testCaseID = Utility.getScenarioID();
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage01_Registration_ExpectedDa", testCaseID, dataPointer);
		QAFExtendedWebElement privacyPolicy= new QAFExtendedWebElement("ehome.PrivacyAgreement.privacyPolicy");
	    wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(privacyPolicy));
	    Assert.assertEquals(privacyPolicy.getText(), value,"Couldn't found expected privacy agreement");
	    privacyPolicy.click();
	 		 		 	   
	}

	@Then("^Privacy Policy page should be open \"([^\"]*)\" in a separate page$")
	public void privacy_Policy_page_should_be_open_in_a_separate_page(String dataPointer) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String testCaseID = Utility.getScenarioID();
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage01_Registration_ExpectedDa", testCaseID, dataPointer);
		String windowHandleBefore = getDriver().getWindowHandle();
		 for(String winHandle: getDriver().getWindowHandles()) {
			 getDriver().switchTo().window(winHandle);
		 }
		 Assert.assertEquals(getDriver().getCurrentUrl(), value,"Couldn't found expected privacy agreement URL");
		 getDriver().close();
		 getDriver().switchTo().window(windowHandleBefore);
		
	}
	public static void acceptAndContinuetButtonClicked() {
    	QAFExtendedWebElement acceptAndContinue= new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[1]/section/div[3]/div/button");
	    wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(acceptAndContinue));
	    acceptAndContinue.click();
	}


	@When("^Click on the Accept and Continue button on the privacy agreement screen$")
	public void click_on_the_Accept_and_Continue_button_on_the_privacy_agreement_screen() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		acceptAndContinuetButtonClicked();
			   
	}

	@Then("^It should navigate to triage page$")
	public void it_should_navigate_to_triage_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   
	}


}
