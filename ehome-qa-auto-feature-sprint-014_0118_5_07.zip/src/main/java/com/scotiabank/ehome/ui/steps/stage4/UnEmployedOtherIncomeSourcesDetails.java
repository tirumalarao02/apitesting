package com.scotiabank.ehome.ui.steps.stage4;

import com.scotiabank.ehome.ui.steps.Common;
import com.scotiabank.ehome.ui.steps.Utility;
import com.scotiabank.ehome.ui.steps.coApp.CoAppIntro;
import cucumber.api.PendingException;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.qmetry.qaf.automation.step.QAFTestStepProvider;
import com.qmetry.qaf.automation.ui.WebDriverTestBase;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebDriver;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.quantum.utils.ConfigurationUtils;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

@QAFTestStepProvider
public class UnEmployedOtherIncomeSourcesDetails {

    private  QAFExtendedWebDriver webDriver = new WebDriverTestBase().getDriver();
	public Actions action = null;
    private WebDriverWait wait = new WebDriverWait(webDriver,50000);
    private String selectText = "//*[contains(@value,'%s')]/parent::div//*[contains(text(),'Select')]";
    
    
    String testCaseID = Utility.getScenarioID();
    
    QAFExtendedWebElement employmentStatusUnEmployed= new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[1]/section/div[3]/div/fieldset/div/span[2]/label");
    QAFExtendedWebElement employmentStatusRetired= new QAFExtendedWebElement("ehome.UnEmployedOtherIncomeSourceDetails.employmentStatusRetired");
    QAFExtendedWebElement employmentStatusRetiredYears= new QAFExtendedWebElement("ehome.UnEmployedOtherIncomeSourceDetails.employmentStatusRetiredYears");
    QAFExtendedWebElement employmentStatusRetiredMonths= new QAFExtendedWebElement("ehome.UnEmployedOtherIncomeSourceDetails.employmentStatusRetiredMonths");
    QAFExtendedWebElement Back= new QAFExtendedWebElement("ehome.UnEmployedOtherIncomeSourceDetails.Back");
    QAFExtendedWebElement ContinueButton= new QAFExtendedWebElement("ehome.UnEmployedOtherIncomeSourceDetails.ContinueButton");
    QAFExtendedWebElement Continue= new QAFExtendedWebElement("//*[contains(text(),'Continue')]");
//    ehome.UnEmployedOtherIncomeSource.Continue
    QAFExtendedWebElement scotiabankLogo = new QAFExtendedWebElement("ehome.scotiabanklogo.image");
    QAFExtendedWebElement applicationTracter= new QAFExtendedWebElement("ehome.applicationstatustracker.image");
	QAFExtendedWebElement userloginname= new QAFExtendedWebElement("ehome.userloginname.image");
//	QAFExtendedWebElement childSupport= new QAFExtendedWebElement("//*[contains(@value,'child-support')]/parent::div//*[contains(text(),'Select')]");
	QAFExtendedWebElement childSupport= new QAFExtendedWebElement(String.format(selectText, "child-support"));
	//QAFExtendedWebElement childSupport= new QAFExtendedWebElement("ehome.UnEmployedOtherIncomeSourceDetails.childSupport");
   // QAFExtendedWebElement investments= new QAFExtendedWebElement("ehome.UnEmployedOtherIncomeSourceDetails.investments");
//	QAFExtendedWebElement investments= new QAFExtendedWebElement("//*[contains(@value,'%s')]/parent::div//*[contains(text(),'Select')]");
	QAFExtendedWebElement investments= new QAFExtendedWebElement(String.format(selectText, "investments"));
    //QAFExtendedWebElement pension= new QAFExtendedWebElement("ehome.UnEmployedOtherIncomeSourceDetails.pension");
	QAFExtendedWebElement pension= new QAFExtendedWebElement("//*[contains(@value,'pension-disability')]/parent::div//*[contains(text(),'Select')]");
	
    QAFExtendedWebElement header= new QAFExtendedWebElement("ehome.UnEmployedOtherIncomeSourceDetails.header");
    QAFExtendedWebElement AddAnother= new QAFExtendedWebElement("ehome.UnEmployedOtherIncomeSourceDetails.AddAnother");
    QAFExtendedWebElement RemoveEntireSource= new QAFExtendedWebElement("ehome.UnEmployedOtherIncomeSourceDetails.RemoveEntireSource");
    QAFExtendedWebElement ShowOtherSources= new QAFExtendedWebElement("ehome.UnEmployedOtherIncomeSourceDetails.ShowOtherSources");
    QAFExtendedWebElement ShowOtherSourcesText= new QAFExtendedWebElement("ehome.UnEmployedOtherIncomeSourceDetails.ShowOtherSourcesText");
    QAFExtendedWebElement childSupportAddButtonTextField1= new QAFExtendedWebElement("ehome.UnEmployedOtherIncomeSourceDetails.childSupportAddButtonTextField1");
    QAFExtendedWebElement childSupportAddButtonTextField2= new QAFExtendedWebElement("ehome.UnEmployedOtherIncomeSourceDetails.childSupportAddButtonTextField2");
    QAFExtendedWebElement coAppChildSupportAddButtonTextField2= new QAFExtendedWebElement("ehome.UnEmployedOtherIncomeSourceDetails.coAppchildSupportAddButtonTextField2");
    QAFExtendedWebElement pensionsection = new QAFExtendedWebElement("ehome.UnEmployedOtherIncomeSourceDetails.pensionsection");
    QAFExtendedWebElement investmentssection = new QAFExtendedWebElement("ehome.UnEmployedOtherIncomeSourceDetails.investmentssection");
    QAFExtendedWebElement investmentsAddButtonTextField1= new QAFExtendedWebElement("ehome.UnEmployedOtherIncomeSourceDetails.investmentsAddButtonTextField1");
    QAFExtendedWebElement pensionAddButtonTextField1= new QAFExtendedWebElement("ehome.UnEmployedOtherIncomeSourceDetails.pensionAddButtonTextField1");
    
    QAFExtendedWebElement Remove2= new QAFExtendedWebElement("ehome.UnEmployedOtherIncomeSourceDetails.Remove2");
    QAFExtendedWebElement AssestsOutsideScotiaHeader= new QAFExtendedWebElement("ehome.AssestsOutsideScotia.Header");
    QAFExtendedWebElement SourcesOfIncomeHeader= new QAFExtendedWebElement("ehome.SourcesOfIncome.Header");
    QAFExtendedWebElement Nosourcesofincome= new QAFExtendedWebElement("ehome.UnEmployedOtherIncomeSourceDetails.Nosourcesofincome");
    QAFExtendedWebElement UnEmployedOtherSourcesOfIncomeDetailsTitle= new QAFExtendedWebElement("ehome.CoAppUnEmployedOtherIncomeSourceDetails.Title");
    QAFExtendedWebElement coAppdoyouhaveanysourcesofincome= new QAFExtendedWebElement("ehome.CoAppUnEmployedOtherIncomeSource.doyouhaveanysourcesofincome");
    
    
    @Given("^Customer should login and select 'current employment status' as \"([^\"]*)\" and navigate to UnEmployed Other Income Sources Details screen$")
    public void customer_should_login_and_select_current_employment_status_as_and_navigate_to_UnEmployed_Other_Income_Sources_Details_screen(String employmentStatus) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        if (testCaseID.contains("CoApp"))
        {
            Common.TraverseToNewHomeSectionBreaker();
            Thread.sleep(2000);
            Common.TraverseFromNewHomeToRateSectionBreaker(testCaseID,"Co-App_InputData");
            Common.TraverseRateSectionToEmploymentSectionBreaker();
            Common.TraverseFromEmploymentSectionToLandOnCoApplicantPage();
            CoAppIntro.startSectionButtonClicked();
        }
        else {
            Utility.launchURL(ConfigurationUtils.getBaseBundle().getPropertyValue("env.baseurl2"));
            Continue.click();
        }
        if (employmentStatus.equals("Unemployed"))
        {
        	Thread.sleep(3000);
        	employmentStatusUnEmployed.click();
        	//wait.until(ExpectedConditions.elementSelectionStateToBe(childSupport,true));
            Thread.sleep(3000);
        	childSupport.click();
        	investments.click();
        	pension.click();
            ContinueButton.click();
        }
        else if (employmentStatus.equals("Retired"))
        {
        	employmentStatusRetired.click();
        	Select employmentStatusRetiredYrs =  new Select(employmentStatusRetiredYears);
            Thread.sleep(3000);
    	    employmentStatusRetiredYrs.selectByIndex(3);
    	    
    	    Select employmentStatusRetiredMnths =  new Select(employmentStatusRetiredMonths);
    	    employmentStatusRetiredMnths.selectByIndex(3);

            wait.until(ExpectedConditions.visibilityOf(ContinueButton));
            ContinueButton.click();
        }
    }

    @Then("^Verify 'Scotia bank Logo' should be as \"([^\"]*)\" on the screen, Verify 'Application status' should be as \"([^\"]*)\" tracker on the screen, Verify for the 'Login username' as \"([^\"]*)\" on the screen, Verify the 'chat icon' functionality as \"([^\"]*)\" on the screen, 'Back' button should be as \"([^\"]*)\" in UnEmployed Other Income Sources Details screen$")
    public void verify_Scotia_bank_Logo_should_be_as_on_the_screen_Verify_Application_status_should_be_as_tracker_on_the_screen_Verify_for_the_Login_username_as_on_the_screen_Verify_the_chat_icon_functionality_as_on_the_screen_Back_button_should_be_as_in_UnEmployed_Other_Income_Sources_Details_screen(String arg1, String arg2, String arg3, String arg4, String arg5) throws Throwable {
        // Write code here that turns the phrase above into concrete actions

        scotiabankLogo.assertPresent ("Couldn't find the ScotiaBank logo"  );
        if(!scotiabankLogo.verifyPresent())
            throw new AssertionError("Couldn't find the ScotiaBank logo");

        //To Check Application status tracker
        applicationTracter.assertPresent ( "Application status tracker image is missing" );
        if(!applicationTracter.verifyPresent())
            throw new AssertionError("Couldn't find the Application status tracker");

        String Back_Text = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage04_Employment_ExpectedData",testCaseID , "Back_Button_Text");
        Assert.assertEquals(Back.getText(), Back_Text,"Couldn't found Back button, Back button should be present");

        Back.isPresent();
        ContinueButton.isPresent();

// 	        userloginname.assertPresent (  );
// 	        if(!userloginname.verifyPresent())
// 	            throw new AssertionError("Couldn't find the Login username");
 	        
 	      //To Check Login username should be on the Right corner
// 	        String result=userloginname.getCssValue("float");
// 	        Assert.assertEquals("right",result);
// 	        if(!userloginname.getCssValue("float").contentEquals( "right"  ))
// 	            throw new AssertionError("Userloginname is not in the right corner");

    }


    @Then("^Verify the header on 'Whats the annual income for each source', 'Add Another', 'Remove entire source' & 'Show other sources'$")
    public void verifyTheHeaderOnWhatsTheAnnualIncomeForEachSourceAddAnotherRemoveEntireSourceShowOtherSources() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        if (!(testCaseID.contains("CoApp"))) {
            String Annual_Income_Screen_Header = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage04_Employment_ExpectedData", testCaseID, "Annual_Income_Screen_Header");
            Assert.assertEquals(header.getText(), Annual_Income_Screen_Header, "What's the annual income for each source? is not displayed");

            String Remove_Entire_Source_Text = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage04_Employment_ExpectedData",testCaseID , "Remove_Entire_Source_Text");
            Assert.assertEquals(RemoveEntireSource.getText(), Remove_Entire_Source_Text,"Remove Entire is not displayed");

        }
        else {
            if (!(UnEmployedOtherSourcesOfIncomeDetailsTitle.getText().contains("other sources of income")))
                throw new AssertionError("UnEmployed Other Sources of Income Title is not Present");
        }
    	AddAnother.assertPresent();
 	     if(!AddAnother.verifyPresent())
 	            throw new AssertionError("Couldn't find the Add Another");

        String Show_Other_Sources_Text = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage04_Employment_ExpectedData",testCaseID , "Show_Other_Sources_Text");
 	    Assert.assertEquals(ShowOtherSourcesText.getText(), Show_Other_Sources_Text,"Show other sources is not displayed");

    }
    
    @When("^Click on Add Another button from UnEmployed Other Income Sources Details screen$")
    public void click_on_Add_Another_button_from_UnEmployed_Other_Income_Sources_Details_screen() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	AddAnother.click();
    }

    @Then("^Add another text field for amount to enter$")
    public void add_another_text_field_for_amount_to_enter() throws Throwable {
        // Write code here that turns the phrase above into concrete actions

        if (testCaseID.contains("CoApp")) {
//Xpath for the second Add Another is junk values keeping aside for now.
            /*//            coAppChildSupportAddButtonTextField2.assertPresent();
            if (!(coAppChildSupportAddButtonTextField2).isPresent())
                throw new AssertionError("Couldn't find the free text field");*/
        } else {
//            childSupportAddButtonTextField2.assertPresent();
            if (!childSupportAddButtonTextField2.isPresent())
                throw new AssertionError("Couldn't find the free text field");
        }
    }
    
    @When("^Click on Remove button in UnEmployed Other Income Sources Details screen$")
    public void click_on_Remove_button_in_UnEmployed_Other_Income_Sources_Details_screen() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        Back.click();
    	Remove2.click();
    	Thread.sleep(10000);
    }

    @When("^click on Show Other sources in UnEmployed Other Income Sources Details screen$")
    public void click_on_Show_Other_sources_in_UnEmployed_Other_Income_Sources_Details_screen() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	ShowOtherSources.click();
    }

    @Then("^other sources should be visible and hide other sources should be visible$")
    public void other_sources_should_be_visible_and_hide_other_sources_should_be_visible() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	childSupport.assertPresent();
	     if(!childSupport.verifyPresent())
	            throw new AssertionError("Couldn't find the field");
    }
    
    @When("^click on Hide Other sources in UmEmployed Other income Sources Details screen$")
    public void click_on_Hide_Other_sources_in_UmEmployed_Other_income_Sources_Details_screen() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	ShowOtherSources.click();
    	Thread.sleep(2000);
        ShowOtherSources.click();

    }

    @Then("^other sources should be hidden$")
    public void other_sources_should_be_hidden() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        String Show_Other_Sources_Text = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage04_Employment_ExpectedData",testCaseID , "Show_Other_Sources_Text");
    	Assert.assertEquals(ShowOtherSourcesText.getText(), Show_Other_Sources_Text,"Show other sources is not visible");
    }
    
    @When("^Entering amount in the text field in UnEmployed Other Income Sources Details screen$")
    public void entering_amount_in_the_text_field_in_UnEmployed_Other_Income_Sources_Details_screen() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	childSupportAddButtonTextField1.waitForVisible(2000);
        String Support_Amount = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage04_Employment_InputData",testCaseID , "Child_Support_Amount");
    	childSupportAddButtonTextField1.sendKeys(Support_Amount);

    	Thread.sleep(2000);
    	investmentssection.click();
        investmentsAddButtonTextField1.waitForVisible(2000);
        investmentsAddButtonTextField1.sendKeys(Support_Amount);

        Thread.sleep(2000);
        pensionsection.click();
        pensionAddButtonTextField1.waitForVisible(2000);
        pensionAddButtonTextField1.sendKeys(Support_Amount);
    }

    @When("^Click on continue button in UnEmployed Other Income Sources Details screen$")
    public void click_on_continue_button_in_UnEmployed_Other_Income_Sources_Details_screen() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	ContinueButton.click();
    }

    @Then("^navigate to 'Do you have any assets outside of Scotiabank\\?' page$")
    public void navigate_to_Do_you_have_any_assets_outside_of_Scotiabank_page() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	AssestsOutsideScotiaHeader.assertPresent ("Couldn't find the Header"  );
	     if(!AssestsOutsideScotiaHeader.verifyPresent())
	            throw new AssertionError("Couldn't find the Header");
	 	//To Check Application status tracker
    }
    
    @When("^Click on Back button in UnEmployed Other Income Sources Details screen$")
    public void click_on_Back_button_in_UnEmployed_Other_Income_Sources_Details_screen() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	Back.click();
    }

    @Then("^navigate to 'Do you have any sources of income' page in UnEmployed Other Income Sources Details Screen$")
    public void navigateToDoYouHaveAnySourcesOfIncomePageInUnEmployedOtherIncomeSourcesDetailsScreen() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        if (testCaseID.contains("CoApp")) {
            if (!(coAppdoyouhaveanysourcesofincome.isPresent()))
                throw new AssertionError("Unemployed Other Sources of Income is not present");
        } else {
            SourcesOfIncomeHeader.assertPresent("Couldn't find the Header");
            if (!SourcesOfIncomeHeader.verifyPresent())
                throw new AssertionError("Couldn't find the Header");
        }
    }

}
