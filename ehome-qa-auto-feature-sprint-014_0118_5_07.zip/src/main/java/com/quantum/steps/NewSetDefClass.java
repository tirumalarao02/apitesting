package com.quantum.steps;

import com.qmetry.qaf.automation.step.QAFTestStepProvider;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

@QAFTestStepProvider
public class NewSetDefClass {
	@Given("^User is on ScotiaHome homepage$")
	public void user_is_on_ScotiaHome_homepage() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		
	    throw new PendingException();
	}

	@When("^User enter valid credentials$")
	public void user_enter_valid_credentials() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^User should be able to see Select Branch page$")
	public void user_should_be_able_to_see_Select_Branch_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^User should be able to see branch (\\d+) listed on Select Branch page$")
	public void user_should_be_able_to_see_branch_listed_on_Select_Branch_page(int arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^User enter invalid credentials$")
	public void user_enter_invalid_credentials() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^User should be redirected to enter valid login$")
	public void user_should_be_redirected_to_enter_valid_login() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Given("^Customer should login and navigates to  Stage (\\d+) - Rate Presentment$")
	public void customer_should_login_and_navigates_to_Stage_Rate_Presentment(int arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^Launch eHome url and click on Application link$")
	public void launch_eHome_url_and_click_on_Application_link() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^User should be able to Login  eHome successfully$")
	public void user_should_be_able_to_Login_eHome_successfully() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^Verify for the Scotiabank Logo in  What type of Rate you are looking for Screen$")
	public void verify_for_the_Scotiabank_Logo_in_What_type_of_Rate_you_are_looking_for_Screen() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^Scotiabank  Logo should be on the left corner of  What type of Rate you are looking for  Screen$")
	public void scotiabank_Logo_should_be_on_the_left_corner_of_What_type_of_Rate_you_are_looking_for_Screen() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}
	
	
}
