package com.scotiabank.ehome.ui.steps.coApp;
import com.qmetry.qaf.automation.step.QAFTestStepProvider;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.quantum.utils.ConfigurationUtils;
import com.scotiabank.ehome.ui.steps.Common;
import com.scotiabank.ehome.ui.steps.Utility;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.support.ui.WebDriverWait;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;
import java.util.concurrent.TimeUnit;
import static com.scotiabank.ehome.ui.steps.Utility.*;


@QAFTestStepProvider

public class CoAppIntro {
	 public static WebDriverWait wait=Utility.getWait();	
	  String testCaseID = Utility.getScenarioID();
	  @Given("^Customer should login and navigate to Co-App Intro screen$")
	  public void customer_should_login_and_navigate_to_Co_App_Intro_screen() throws Throwable {
	      // Write code here that turns the phrase above into concrete actions
//			 String strtestCaseID = Utility.getScenarioID();
//		  if (strtestCaseID.contains("CoApp"))
//		  {
//			  Common.TraverseToNewHomeSectionBreaker();
//			  Thread.sleep(10000);
//			  Common.TraverseFromNewHomeToRateSectionBreaker(strtestCaseID,"Co-App_InputData");
//			  Common.TraverseRateSectionToEmploymentSectionBreaker();
//			  Common.TraverseFromEmploymentSectionToLandOnCoApplicantPage();
//			  CoAppIntro.startSectionButtonClicked();
//		  }
		  Utility.launchURL(ConfigurationUtils.getBaseBundle().getPropertyValue ("env.baseurl3"));
	      
	  }

	  @When("^Verify \"([^\"]*)\" message should be on the Co-App Intro screen$")
	  public void verify_message_should_be_on_the_Co_App_Intro_screen(String dataPointer) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Co-App_ExpectedData", testCaseID, dataPointer);
		Assert.assertEquals(Common.headerMessage(), value,"Couldn't found expected header text");
	      
	  }

	  @Then("^Verify \"([^\"]*)\" headertext should be on Co-App Intro screen$")
	  public void verify_headertext_should_be_on_Co_App_Intro_screen(String dataPointer) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Co-App_ExpectedData", testCaseID, dataPointer);
		Assert.assertEquals(Common.headertext(), value,"Couldn't found expected header text");
	      
	  }

	  @Then("^Verify \"([^\"]*)\" and \"([^\"]*)\" information should be on Co-App Intro screen$")
	  public void verify_co_applicant_information_should_be_on_Co_App_Intro_screen(String dataPointer,String dataPointer1) throws Throwable {
	      // Write code here that turns the phrase above into concrete actions
		  String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Co-App_ExpectedData", testCaseID, dataPointer);
		  String value1=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Co-App_ExpectedData", testCaseID, dataPointer1);
		  QAFExtendedWebElement content1= new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[3]/div[1]/div/p[1]");
		  wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(content1));
		  Assert.assertEquals(content1.getText(), value,"Couldn't found expected header text");
		  QAFExtendedWebElement content2= new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[3]/div[1]/div/p[2]");
		  wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(content2));
		  Assert.assertEquals(content2.getText(), value1,"Couldn't found expected header text");
	      
	  }

	  @When("^Click on the skip button on the Co-App Intro screen$")
	  public void click_on_the_skip_button_on_the_Co_App_Intro_screen() throws Throwable {
	      // Write code here that turns the phrase above into concrete actions
		  QAFExtendedWebElement skip= new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[3]/div[2]/div/button/span/span");
		  wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(skip));
		  skip.click();
	      
	  }
	  @Then("^Verify \"([^\"]*)\" headertext should be on the Asset-section-breaker screen$")
	  public void verify_title_headertext_should_be_on_the_Assetsectionbreaker_screen(String dataPointer) throws Throwable {
	      // Write code here that turns the phrase above into concrete actions
		  String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Co-App_ExpectedData", testCaseID, dataPointer);
		  QAFExtendedWebElement headerText= new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[2]/div/div[1]/div/h1");
		  wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(headerText));
		  Assert.assertEquals(headerText.getText(), value,"Couldn't found expected header text");
	      
	  }
	  
	  public static void startSectionButtonClicked() {
		  QAFExtendedWebElement start= new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[3]/div[2]/div/div/div/div/button");
		  wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(start));
		  start.click();
		}

	  @When("^Click on the Start section button in Co-App Intro screen$")
	  public void click_on_the_Start_with_question_button_in_Co_App_Intro_screen() throws Throwable {
	      // Write code here that turns the phrase above into concrete actions
		  startSectionButtonClicked();
	      
	  }
	 
	 
}
