package com.scotiabank.ehome.ui.steps;
import org.apache.poi.ss.formula.functions.Column;
import org.apache.poi.ss.usermodel.*;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.qmetry.qaf.automation.step.QAFTestStepProvider;
import com.qmetry.qaf.automation.ui.WebDriverTestBase;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebDriver;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.quantum.utils.ConfigurationUtils;

import cucumber.api.java.en.Given;

import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;
@QAFTestStepProvider

public class CommonAppMethodsYourNewHome {
     
 	 /* *************************************************************************************************************************************************
	 Author:      RameshChalumuri
	 Stage:       Stage 02  
	 Method Name: selectPropertyType
	 Purpose:     This method is for selecting Property Type "House" or "Condo" 
	 Created on:  18-September-2018  
	 Updated By: 
	 Updated on:
	 *************************************************************************************************************************************************** */
    public static void selectPropertyType(String propertyType) throws InterruptedException{
    	switch(propertyType) {
           case "House" :
        	   QAFExtendedWebElement TypeofPropertyOptionHouseBtn = new QAFExtendedWebElement("ehome.Propertytype.House.Select");
        	   TypeofPropertyOptionHouseBtn.click (); // Click on Property Type "House"
              break;
           case "Condo" : 
        	   QAFExtendedWebElement TypeofPropertyOptionCondoBtn= new QAFExtendedWebElement("ehome.Propertytype.Condo.Select");
        	   TypeofPropertyOptionCondoBtn.click (); // Click on Property Type "Condo"
              break;
              default :
              System.out.println("Invalid Property Type");
        }
   }
	
    /* *************************************************************************************************************************************************
	 Author:      RameshChalumuri
	 Stage:       Stage 02
	 Method Name: selectTypeofHouse
	 Purpose:     This method is for selecting Type of house "Detached" or "Semi-detached" or "Freehold townhouse"
	 Created on:  18-September-2018  
	 Updated By: 
	 Updated on:
	 *************************************************************************************************************************************************** */
    public static void selectTypeofHouse(String typeOfHouse) throws InterruptedException{
    	switch(typeOfHouse) {
           case "Detached" :
        	   Thread.sleep(1000);
        	   QAFExtendedWebElement TypeofHouseOptionDetachedBtn = new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[1]/section/div[3]/div/fieldset/div/span[1]/label");
        	   TypeofHouseOptionDetachedBtn.click (); // Click on Type of house "Detached"
        	   Thread.sleep(1000);
              break;
           case "Semi-detached" :
        	   QAFExtendedWebElement TypeofHouseOptionSemidetachedBtn= new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[1]/section/div[3]/div/fieldset/div/span[2]/label");
        	   TypeofHouseOptionSemidetachedBtn.click (); // Click on Type of house "Semi-detached"
        	   
              break;
           case "Freehold townhouse" :
        	   QAFExtendedWebElement TypeofHouseOptionFreeholdtownhouseBtn = new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[1]/section/div[3]/div/fieldset/div/span[3]/label");
        	   TypeofHouseOptionFreeholdtownhouseBtn.click (); // Click on Type of house "Freehold townhouse"
              break;
              default :
              System.out.println("Invalid Type of House");
        }
   }
    
    /* *************************************************************************************************************************************************
	 Author: 	  RameshChalumuri
	 Stage:       Stage 02
	 Method Name: selectDownPaymentSources
	 Purpose: 	  This method is for selecting Down Payment Sources
	 Created on:  18-September-2018  
	 Updated By: 
	 Updated on:
	 *************************************************************************************************************************************************** */
   public static void selectDownPaymentSources(String DownPaymentSources) throws InterruptedException{
 
    	switch(DownPaymentSources) {
           case "Bank account" :                                                        
        	   QAFExtendedWebElement DownPymtSrcBankRadioBtn= new QAFExtendedWebElement("ehome.SrcsOfDownpaymt.Bankaccount");
        	   DownPymtSrcBankRadioBtn.click (); // Click on Down Payment Sources "Bank account"
              break;
           case "Investment account" :
        	   QAFExtendedWebElement DownPymtSrcInvesRadioBtn= new QAFExtendedWebElement("ehome.SrcsOfDownpaymt.Investmentaccount");
        	   DownPymtSrcInvesRadioBtn.click (); // Click on Down Payment Sources "Investment account"
        	   Thread.sleep(500);
              break;
           case "A gift from family" :
        	   QAFExtendedWebElement DownPymtSrcGiftRadioBtn= new QAFExtendedWebElement("ehome.SrcsOfDownpaymt.Agiftfromfamily");
        	   DownPymtSrcGiftRadioBtn.click (); // Click on Down Payment Sources "A gift from family"
        	   Thread.sleep(500);
              break;
           case "RRSP withdrawal" :
        	   QAFExtendedWebElement DownPymtSrcRRSPRadioBtn= new QAFExtendedWebElement("ehome.SrcsOfDownpaymt.RRSPwithdrawal");
        	   DownPymtSrcRRSPRadioBtn.click (); // Click on Down Payment Sources "RRSP withdrawal"
        	   Thread.sleep(500);
              break;
           case "Sale of asset" :
        	   QAFExtendedWebElement DownPymtSrcSaleAssetRadioBtn= new QAFExtendedWebElement("ehome.SrcsOfDownpaymt.Saleofasset");
        	   DownPymtSrcSaleAssetRadioBtn.click (); // Click on Down Payment Sources "Sale of asset"
        	   Thread.sleep(500);
              break;
           case "Sale of existing property" :
        	   QAFExtendedWebElement DownPymtSrcSaleofExistRadioBtn= new QAFExtendedWebElement("ehome.SrcsOfDownpaymt.Saleofexistingproperty");
        	   DownPymtSrcSaleofExistRadioBtn.click (); // // Click on Down Payment Sources "Sale of existing property"
        	   Thread.sleep(500);
              break;
           default :
              System.out.println("Invalid Down Payment Sources");
        }
   }
   
   
   /* *************************************************************************************************************************************************
	 Author: 	  RameshChalumuri
	 Stage:       Stage 02
	 Method Name: enterDownPaymentSourcesAmount
	 Purpose: 	  This method is for selecting Down Payment Sources
	 Created on:  18-September-2018  
	 Updated By: 
	 Updated on:
	 *************************************************************************************************************************************************** */
 public static void enterDownPaymentSourcesAmount(String DownPaymentSources,String DownPaymentSourcesAmount) throws InterruptedException{

 	switch(DownPaymentSources) {
        case "Bank account" :
     	   QAFExtendedWebElement DownPymtSrcBankAmtInput= new QAFExtendedWebElement("ehome.detailsofdownpayment.BankAccountEdit");
     	   DownPymtSrcBankAmtInput.sendKeys(DownPaymentSourcesAmount); // Enter Down Payment Sources Amount "Bank account"
     	   Thread.sleep(500);
     	   break;
        case "Investment account" :   
        	 QAFExtendedWebElement DownPymtSrcInvesAmtRadioBtn= new QAFExtendedWebElement("ehome.detailsofdownpayment.InvestmentAccountSelection");
            DownPymtSrcInvesAmtRadioBtn.click ();
            Thread.sleep(500);
     	   QAFExtendedWebElement DownPymtSrcInvesAmtInput= new QAFExtendedWebElement("ehome.detailsofdownpayment.InvestmentAccountEdit");
       	   DownPymtSrcInvesAmtInput.sendKeys(DownPaymentSourcesAmount); // Enter Down Payment Sources Amount "Investment account"

           break;
        case "A gift from family" :
        	QAFExtendedWebElement DownPymtSrcGiftAmtRadioBtn= new QAFExtendedWebElement("ehome.detailsofdownpayment.AgiftfromfamilySelection");
     	   DownPymtSrcGiftAmtRadioBtn.click (); 
     	   QAFExtendedWebElement DownPymtSrcGiftAmtInput= new QAFExtendedWebElement("ehome.detailsofdownpayment.AgiftfromfamilyEdit");
     	  Thread.sleep(500);
     	   DownPymtSrcGiftAmtInput.sendKeys(DownPaymentSourcesAmount); // Enter Down Payment Sources Amount "A gift from family"
           break;
        case "RRSP withdrawal" :
      	   QAFExtendedWebElement DownPymtSrcRRSPAmtRadioBtn= new QAFExtendedWebElement("ehome.detailsofdownpayment.RRSPwithdrawalSelection");
       	    DownPymtSrcRRSPAmtRadioBtn.click ();
     	   QAFExtendedWebElement DownPymtSrcRRSPAmtInput= new QAFExtendedWebElement("ehome.detailsofdownpayment.RRSPwithdrawalEdit");
     	  Thread.sleep(500);
     	   DownPymtSrcRRSPAmtInput.sendKeys(DownPaymentSourcesAmount); // Enter Down Payment Sources Amount "RRSP withdrawal"
           break;
        case "Sale of asset" :        	   
     	   QAFExtendedWebElement DownPymtSrcSaleAssetAmtRadioBtn= new QAFExtendedWebElement("ehome.detailsofdownpayment.SaleofassettSelection");
      	    DownPymtSrcSaleAssetAmtRadioBtn.click ();
     	   QAFExtendedWebElement DownPymtSrcSaleAssetAmtInput= new QAFExtendedWebElement("ehome.detailsofdownpayment.SaleofassettEdit");
     	  Thread.sleep(500);
     	   DownPymtSrcSaleAssetAmtInput.sendKeys(DownPaymentSourcesAmount); // Enter Down Payment Sources Amount "Sale of asset"
           break;
        case "Sale of existing property" :
      	 QAFExtendedWebElement DownPymtSrcSaleofExistAmtRadioBtn= new QAFExtendedWebElement("ehome.detailsofdownpayment.Saleofexistingproperty");
      	DownPymtSrcSaleofExistAmtRadioBtn.click (); 
      	  Thread.sleep(500);
     	   QAFExtendedWebElement DownPymtSrcSaleofExistAmt= new QAFExtendedWebElement("ehome.detailsofdownpayment.SaleofexistingpropertyEdit");
     	   DownPymtSrcSaleofExistAmt.sendKeys(DownPaymentSourcesAmount); // Enter Down Payment Sources Amount "Sale of existing property"
     	  
     	  
//     	
//     	 Utility.clickObject("//button[@class='button button--calendar-mobile']", "Image");
//     	 Utility.clickObject("//div[@class='react-datepicker__day react-datepicker__day--fri react-datepicker__day--outside-month']","Date");
//
          
     	   
           break;
        default :
           System.out.println("Invalid Down Payment Sources");
     }
}
     
    /* *************************************************************************************************************************************************
	 Author: 	  RameshChalumuri
	 Stage:       Stage 02
	 Method Name: Auto suggest address
	 Purpose: 	  This method is for enters Auto suggest address (DMTI field) in New-Home screen 
	 Created on:  18-September-2018  
	 Updated By: 
	 Updated on:
	 *************************************************************************************************************************************************** */
   public static void enterAutosuggestaddress(String DMTIAddress) throws InterruptedException{
	   QAFExtendedWebElement Enteraddress= new QAFExtendedWebElement("ehome.Address.address.text");
       Enteraddress.clear();
       char[] addarr = DMTIAddress.toCharArray();
       for(char oneAt : addarr) {
     	  	Enteraddress.sendKeys(oneAt+"");
       	}                                                                                                                       
       QAFExtendedWebElement eleAddress = new QAFExtendedWebElement(By.xpath("//*[@id='app']/div/div[1]/div[1]/section/div[3]/div/div[1]/div/div[2]/div/ul"));
       List<WebElement> liLi = eleAddress.findElements(By.tagName("li"));
        liLi.get(1).click();
        QAFExtendedWebElement ContinueAddress= new QAFExtendedWebElement("//*[@id='app']/div/div[1]/div[2]/button[2]"); //click on continue button is address screen
        ContinueAddress.click(); 
   }

}
   
   
   
   
