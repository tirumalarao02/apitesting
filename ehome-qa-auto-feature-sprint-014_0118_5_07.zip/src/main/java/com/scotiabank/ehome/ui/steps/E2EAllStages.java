package com.scotiabank.ehome.ui.steps;

import java.awt.*;
import java.awt.event.KeyEvent;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import com.qmetry.qaf.automation.step.QAFTestStepProvider;
import com.qmetry.qaf.automation.ui.WebDriverTestBase;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebDriver;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.quantum.java.pages.ExtentReportHelper;
import com.quantum.utils.ConfigurationUtils;
import com.scotiabank.ehome.ui.steps.CommonApplicationMethods;
import com.scotiabank.ehome.ui.steps.Utility;

import cucumber.api.PendingException;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

@QAFTestStepProvider

public class E2EAllStages {
	
	static String curDir = System.getProperty("user.dir");
	static String strfullPathToFile = curDir + "\\src\\main\\resources\\data\\eHomeTestData.xlsx"; // File Path
	static String strDocsPath = curDir + "\\src\\main\\resources\\data\\AutoIt-workspace\\Documents"; 
	static String strGemaltoIDPath = curDir + "\\src\\main\\resources\\data\\AutoIt-workspace\\GemaltoID"; 

	static String sheetE2E_InputData ="E2E_InputData";
	static String sheetE2E_ExpectedData ="E2E_ExpectedData";
	String strtestCaseID = "MIMS-E2E-Scenario-018";
	//String strtestCaseID = Utility.getScenarioID();
 	
//	@Given("^Launch eHome URL$")
//	public void Launch_eHome_URL() throws Throwable {
//	Utility.launchURL(ConfigurationUtils.getBaseBundle ().getPropertyValue ("env.baseurlHub"));
	@Given("^Continue HUB functionality$")

    	public void Continue_HUB_functionality() throws Throwable {
		
			Thread.sleep(2000);
////
//		Utility.clickObject("ehome.hubOnboarding.LetsGetStartedBtn","Let's Get Started Button on Hub on Boarding");
////			Thread.sleep(2000);
//		Utility.clickObject("ehome.hubOnboarding.SaveContinueBtn","Save and Continue Button");
////       		Thread.sleep(250);
//
//      		Utility.clickObject("ehome.hubOnboarding.NoCoAppBtn","No Co-Applicant Button");
//      		Thread.sleep(250);
//      		Utility.clickObject("ehome.hubOnboarding.GotitBtn","Got it Btn Button");
//      		Thread.sleep(250);
//      		Utility.clickObject("ehome.hubOnboarding.LetsGetStartedBtnSampleSteps","Lets Get Started Button in 6 simple steps");
//      		Thread.sleep(250);
//	Utility.clickObject("ehome.hubOnboarding.StartyourAppBtn","Start your application Button");
////      		Thread.sleep(250);
//	//Utility.clickObject("ehome.hubOnboarding.ContinueyourAppBtn","Continue your application Button");
      		
		} 
               
    @Then("^Verify 'Address of Your New Home' screen and enter 'Address' in the screen in 'Stage2_New-Home'$")
    	public void Verify_Address_of_Your_New_Home_And_Enter_Address_Stage2_New_Home() throws Throwable {
    	
    		Map<String, String> E2E_InputData =  Utility.readTestData(strfullPathToFile, sheetE2E_InputData,strtestCaseID);
    		Map<String, String> E2E_ExpectedData =  Utility.readTestData(strfullPathToFile, sheetE2E_ExpectedData,strtestCaseID);
    			
    			String strInputAddress= E2E_InputData.get("TypeOfAddress");
    			String strExpectAddressOfYourNewHome_Title= E2E_ExpectedData.get("AddressOfYourNewHome_Title");
    			
    			Utility.clickObject("ehome.stage2sectionbreaker.Continue.button","Continue");
    			
    			// Verify 'Address of Your New Home' Title in STAGE#2 
    			QAFExtendedWebElement strActualAddressOfYourNewHome_Title= new QAFExtendedWebElement("ehome.whatstheaddress.Whatstheaddressofyournewhome");
    			if (strExpectAddressOfYourNewHome_Title.contentEquals(strActualAddressOfYourNewHome_Title.getText())) {
    				ExtentReportHelper.StepPass(strExpectAddressOfYourNewHome_Title + " Screen# is displayed.");
    			}
    			else
    			{
    				Assert.assertEquals(strActualAddressOfYourNewHome_Title.getText(), strExpectAddressOfYourNewHome_Title,"'Address of Your New Home' Title is NOT as Expected.");
    			}
    			Thread.sleep(250);
    			// Enter 'Address' in 'Address of Your New Home' screen in STAGE#2
    			if (strInputAddress.contentEquals("Manual")) {
    				//CommonApplicationMethods.enterAddressManually(); // Select Address Manually in "Address of your new home"
    				CommonApplicationMethods.enterAnyProvinceAddressManually();
    			}
    			else
    			{
    				CommonApplicationMethods.enterAutosuggestaddress(strInputAddress); // Enters Auto suggest address (DMTI field) in Address screen 
    			}
    	}
    
    @And("^Verify 'Type of Property' screen and select 'type of property' in the screen in 'Stage2_New-Home'$")
    	public void Verify_Type_of_Property_New_Home_And_Enter_TypeOfProperty_Stage2_New_Home() throws Throwable {
    	
        	Map<String, String> E2E_InputData =  Utility.readTestData(strfullPathToFile, sheetE2E_InputData,strtestCaseID);
        	Map<String, String> E2E_ExpectedData =  Utility.readTestData(strfullPathToFile, sheetE2E_ExpectedData,strtestCaseID);
        		String strInputPropertyType= E2E_InputData.get("PropertyType"); 
        		String strExpectTypeofProperty_Title= E2E_ExpectedData.get("TypeofProperty_Title");
        		Thread.sleep(3000);      	
        		// Verify 'Type of Property Type' Title in STAGE#2 
        		QAFExtendedWebElement strActualTypeofProperty_Title= new QAFExtendedWebElement("ehome.Propertytype.header.text");
        		
        		if (strExpectTypeofProperty_Title.contentEquals(strActualTypeofProperty_Title.getText())) {
        			ExtentReportHelper.StepPass(strExpectTypeofProperty_Title + " Screen# is displayed.");
        		}
        		else
        		{
        			Assert.assertEquals(strActualTypeofProperty_Title.getText(), strExpectTypeofProperty_Title,"'Type of Property' Title is NOT as Expected.");
        		}
        		CommonAppMethodsYourNewHome.selectPropertyType(strInputPropertyType); // Select Property Type in "Type of Property"
        		Thread.sleep(2000);
    	}
      
    @And("^Verify 'Purchase Price' screen and enter 'Purchase Price' in the screen in 'Stage2_New-Home'$")
   	public void Verify_Purchase_Price_And_Enter_Purchase_Price_Stage2_New_Home() throws Throwable {
       	Map<String, String> E2E_InputData =  Utility.readTestData(strfullPathToFile, sheetE2E_InputData,strtestCaseID);
       	Map<String, String> E2E_ExpectedData =  Utility.readTestData(strfullPathToFile, sheetE2E_ExpectedData,strtestCaseID);
       		String strInputPropertyType= E2E_InputData.get("PropertyType");								// Retrieve "PropertyType" from Excel 
   	    	String strInputHouseType= E2E_InputData.get("HouseType");									// Retrieve "HouseType" from Excel
   	    	String strInputCondoFees = E2E_InputData.get("CondoFees");									// Retrieve "CondoFees" from Excel
   	    	String strInputSquareFeet  = E2E_InputData.get("SquareFeet");								// Retrieve "SquareFeet" from Excel
   	  	  	String strInputPurchasePrice  = E2E_InputData.get("PurchasePrice");							// Retrieve "PurchasePrice" from Excel
      		String strExpectPurchasePrice_Title= E2E_ExpectedData.get("PurchasePrice_Title");
   			Thread.sleep(4000);      	
   		
   			if (strInputPropertyType.contentEquals("Condo")) {
   		 		Utility.sendKeys("ehome.CondoFees.CondoFees.input", strInputCondoFees); // Enter "Condo fee" in "Type of Property" 
   		 		Thread.sleep(500);
   		 		Utility.clickObject("ehome.CloseDtContinue.button", "Button"); // Click on Continue in "Type of Property"  
   		  		Thread.sleep(500);
   			}
   		 	if (strInputPropertyType.contentEquals("House")) {
   		 		CommonAppMethodsYourNewHome.selectTypeofHouse(strInputHouseType); // Select Type of House in "Type of house" 
   		 		Thread.sleep(500);
   		 	}
   		 	Utility.sendKeys("//*[@id=\"sqFeet\"]", strInputSquareFeet); // Enter "Area of Property" 
   		 	Thread.sleep(1000);
   			Utility.clickObject("ehome.areaOfProp.continue.button", "Button"); // Click on Continue
   			Thread.sleep(1000);
   		
   			// Verify 'Purchase Price' Title in STAGE#2 
//   			QAFExtendedWebElement strActualPurchasePrice_Title= new QAFExtendedWebElement("ehome.PurchasePrice.title");
//   			if (strExpectPurchasePrice_Title.contentEquals(strActualPurchasePrice_Title.getText())) {
//   				ExtentReportHelper.StepPass(strExpectPurchasePrice_Title + " Screen# is displayed.");
//   			}
//   			else
//   			{
//   				Assert.assertEquals(strActualPurchasePrice_Title.getText(), strExpectPurchasePrice_Title,"'Purchase Price' Title is NOT as Expected.");
//   			}
//   			
   			Thread.sleep(1000);
   			Utility.sendKeys("ehome.PurchasePrice.inputtextbox", strInputPurchasePrice); // Enter "Purchase Price" in Purchase Price
   			Thread.sleep(500);
	    	Utility.clickObject("ehome.areaOfProp.continue.button", "Button"); // Click on Continue
	    	Thread.sleep(500);
  		}
    
    @And("^Verify 'Down Payment' screen and enter 'Down Payment' in the screen in 'Stage2_New-Home'$")
	public void Verify_Down_Payment_And_Enter_Down_Payment_Stage2_New_Home() throws Throwable {
      	
    	Map<String, String> E2E_InputData =  Utility.readTestData(strfullPathToFile, sheetE2E_InputData,strtestCaseID);
    	Map<String, String> E2E_ExpectedData =  Utility.readTestData(strfullPathToFile, sheetE2E_ExpectedData,strtestCaseID);
        
    	String strInputDownPayment  = E2E_InputData.get("DownPayment");								// Retrieve "DownPayment" from Excel
    	String strExpectDownPayment_Title= E2E_ExpectedData.get("DownPayment_Title");
    	String strExpectDownPaymentReq_Link= E2E_ExpectedData.get("DownPayment_Req_Link");
    	
	    	
    	Thread.sleep(4000);      	
		// Verify 'Down Payment' Title in STAGE#2 
		QAFExtendedWebElement strActualDownPayment_Title = new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[1]/section/div[2]/div/p");
		if (strExpectDownPayment_Title.contentEquals(strActualDownPayment_Title.getText())) {
			ExtentReportHelper.StepPass(strExpectDownPayment_Title + " Screen# is displayed.");
			}
		else {
			Assert.assertEquals(strActualDownPayment_Title.getText(), strExpectDownPayment_Title,"'Down Payment' Title is NOT as Expected.");
			}
		
		QAFExtendedWebElement strActualDownPaymentReq_Link = new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[1]/section/div[6]/button/span");
		if (strExpectDownPaymentReq_Link.contentEquals(strActualDownPaymentReq_Link.getText())) {
			ExtentReportHelper.StepPass(strExpectDownPaymentReq_Link + " Hyper Link # is displayed.");
			}
		else {
			Assert.assertEquals(strActualDownPaymentReq_Link.getText(), strExpectDownPaymentReq_Link,"'Down Payment Requirement' Hyper Link is NOT as Expected.");
			}
    	Utility.sendKeys("ehome.DownPayement.Price", strInputDownPayment); // Enter "Down Payment Amount" in Down Payment
     	Thread.sleep(500);
     	
     	Utility.clickObject("ehome.areaOfProp.continue.button", "Button"); // Click on Continue
    	Thread.sleep(500);
    }
    
    @And("^Verify 'Sources of Your Down Payment' screen and select 'Sources' in the screen in 'Stage2_New-Home'$")
	public void Verify_Sources_of_Your_Down_Payment_And_Select_Sources_Stage2_New_Home() throws Throwable {
		Map<String, String> E2E_InputData =  Utility.readTestData(strfullPathToFile, sheetE2E_InputData,strtestCaseID);
		Map<String, String> E2E_ExpectedData =  Utility.readTestData(strfullPathToFile, sheetE2E_ExpectedData,strtestCaseID);
		
		 	String strInputDownPymtSrcBankAcct  = E2E_InputData.get("DownPymtSrcBankAcct");				// Retrieve "DownPymtSrcBankAcct" from Excel
	    	String strInputDownPymtSrcInvAcct  = E2E_InputData.get("DownPymtSrcInvAcct");				// Retrieve "DownPymtSrcInvAcct" from Excel
	    	String strInputDownPymtSrcFamilyGift  = E2E_InputData.get("DownPymtSrcFamilyGift");			// Retrieve "DownPymtSrcFamilyGift" from Excel
	    	String strInputDownPymtSrcRRSP  = E2E_InputData.get("DownPymtSrcRRSP");						// Retrieve "DownPymtSrcRRSP" from Excel
	    	String strInputDownPymtSrcSaleOfAss  = E2E_InputData.get("DownPymtSrcSaleOfAss");			// Retrieve "DownPymtSrcSaleOfAss" from Excel
	    	String strInputDownPymtSrcSaleOfExist  = E2E_InputData.get("DownPymtSrcSaleOfExist");		// Retrieve "DownPymtSrcSaleOfExist" from Excel
	    	String strInputDownPymtSrcBankAcctAmt  = E2E_InputData.get("DownPymtSrcBankAcctAmt");		// Retrieve "DownPymtSrcBankAcctAmt" from Excel
	    	String strInputDownPymtSrcInvAcctAmt  = E2E_InputData.get("DownPymtSrcInvAcctAmt");			// Retrieve "DownPymtSrcnvAcctAmt" from Excel
	    	String strInputDownPymtSrcFamilyGiftAmt  = E2E_InputData.get("DownPymtSrcFamilyGiftAmt");	// Retrieve "DownPymtSrcFamilyGiftAmt" from Excel		
	    	String strInputDownPymtSrcRRSPAmt  = E2E_InputData.get("DownPymtSrcRRSPAmt");				// Retrieve "DownPymtSrcRRSPAmt" from Excel
	    	String strInputDownPymtSrcSaleOfAssAmt  = E2E_InputData.get("DownPymtSrcSaleOfAssAmt");		// Retrieve "DownPymtSrcSaleOfAssAmt" from Excel
	    	String strInputDownPymtSrcSaleOfExistAmt  = E2E_InputData.get("DownPymtSrcSaleOfExistAmt");	// Retrieve "DownPymtSrcSaleOfExistAmt" from Excel
	    	String strExpectSrcsofDownPayment_Title= E2E_ExpectedData.get("SrcsofDownPayment_Title");
	    	String strExpectDetailsofDownPaymtSrcs_Title= E2E_ExpectedData.get("DetailsofDownPaymtSrcs_Title");
	
		Thread.sleep(4000);      	
		
		// Verify 'Sources of Down Payment' Title in STAGE#2 
		QAFExtendedWebElement strActualSrcsofDownPayment_Title= new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[1]/section/div[2]/div/p");
		if (strExpectSrcsofDownPayment_Title.contentEquals(strActualSrcsofDownPayment_Title.getText())) {
			ExtentReportHelper.StepPass(strExpectSrcsofDownPayment_Title + " Screen# is displayed.");
			}
			else 
			{
			Assert.assertEquals(strActualSrcsofDownPayment_Title.getText(), strExpectSrcsofDownPayment_Title,"'Sources of Down Payment' Title is NOT as Expected.");
			}

		if (strInputDownPymtSrcBankAcct.contentEquals("Bank account")) {
     		CommonAppMethodsYourNewHome.selectDownPaymentSources(strInputDownPymtSrcBankAcct); // Select "Bank account" option 
     		}
     	if (strInputDownPymtSrcInvAcct.contentEquals("Investment account")) {
     		CommonAppMethodsYourNewHome.selectDownPaymentSources(strInputDownPymtSrcInvAcct); // Select "Investment account" option 
     		}
     	if (strInputDownPymtSrcFamilyGift.contentEquals("A gift from family")) {
     		CommonAppMethodsYourNewHome.selectDownPaymentSources(strInputDownPymtSrcFamilyGift); // Select "A gift from family" option 
     		}
     	if (strInputDownPymtSrcRRSP.contentEquals("RRSP withdrawal")) {
     		CommonAppMethodsYourNewHome.selectDownPaymentSources(strInputDownPymtSrcRRSP); // Select "RRSP withdrawal" option 
     		}
     	if (strInputDownPymtSrcSaleOfAss.contentEquals("Sale of asset")) {
     		CommonAppMethodsYourNewHome.selectDownPaymentSources(strInputDownPymtSrcSaleOfAss); // Select "Sale of asset" option 
     		}
 	
     	if (strInputDownPymtSrcSaleOfExist.contentEquals("Sale of existing property")) {
     		CommonAppMethodsYourNewHome.selectDownPaymentSources(strInputDownPymtSrcSaleOfExist); // Select "Sale of existing property" option 
     		}
     	Thread.sleep(250);  
     	Utility.clickObject("ehome.areaOfProp.continue.button", "Button");
     	Thread.sleep(2000);  
     	
//     	QAFExtendedWebElement strActualDetailsofDownPaymtSrcs_Title= new QAFExtendedWebElement("//p[contains(text(),'What are the details of your down payment sources?')]");
//		if (strExpectDetailsofDownPaymtSrcs_Title.contentEquals(strActualDetailsofDownPaymtSrcs_Title.getText())) {
//			ExtentReportHelper.StepPass(strExpectDetailsofDownPaymtSrcs_Title + " Screen# is displayed.");
//			}
//		else {
//			Assert.assertEquals(strActualDetailsofDownPaymtSrcs_Title.getText(), strExpectDetailsofDownPaymtSrcs_Title,"'Details of Payment Sources' Title is NOT as Expected.");
//			}
     	
     	//  ***** STAGE2-Detailed Down Payment Screen# *****
       if (strInputDownPymtSrcBankAcct != null | strInputDownPymtSrcBankAcctAmt.length() != 0) {
    	   CommonAppMethodsYourNewHome.enterDownPaymentSourcesAmount(strInputDownPymtSrcBankAcct, strInputDownPymtSrcBankAcctAmt);
       		Thread.sleep(500); 
       		}
     	if (strInputDownPymtSrcInvAcct != null | strInputDownPymtSrcInvAcctAmt.length() != 0) {
     		CommonAppMethodsYourNewHome.enterDownPaymentSourcesAmount(strInputDownPymtSrcInvAcct, strInputDownPymtSrcInvAcctAmt);
     		Thread.sleep(500);  
     		}
     	if (strInputDownPymtSrcFamilyGift != null | strInputDownPymtSrcFamilyGiftAmt.length() != 0) {
     		CommonAppMethodsYourNewHome.enterDownPaymentSourcesAmount(strInputDownPymtSrcFamilyGift, strInputDownPymtSrcFamilyGiftAmt);
     		Thread.sleep(500);  
     		}
     	if (strInputDownPymtSrcRRSP != null | strInputDownPymtSrcRRSPAmt.length() != 0) {
     		CommonAppMethodsYourNewHome.enterDownPaymentSourcesAmount(strInputDownPymtSrcRRSP, strInputDownPymtSrcRRSPAmt);
     		Thread.sleep(500);  
     		}
     	if (strInputDownPymtSrcSaleOfAss != null | strInputDownPymtSrcSaleOfAssAmt.length() != 0) {
     		CommonAppMethodsYourNewHome.enterDownPaymentSourcesAmount(strInputDownPymtSrcSaleOfAss, strInputDownPymtSrcSaleOfAssAmt);
     		Thread.sleep(500);  
     		}
     	if (strInputDownPymtSrcSaleOfExist != null | strInputDownPymtSrcSaleOfExistAmt.length() != 0) {
     		CommonAppMethodsYourNewHome.enterDownPaymentSourcesAmount(strInputDownPymtSrcSaleOfExist, strInputDownPymtSrcSaleOfExistAmt);
     		Thread.sleep(500);  
     		}
     	
     	Utility.clickObject("ehome.detailsofdownpayment.ContinueButtonDetails", "Button"); // Click on Continue
     	try {
     		
     		QAFExtendedWebElement YesUpdateAndContinueBtn= new QAFExtendedWebElement("ehome.downPaymentMismatch.YesUpdateAndContinue");
     		 
         	if(YesUpdateAndContinueBtn.isPresent())
         	{
         		YesUpdateAndContinueBtn.click();
          	}
     		
     	}catch(Exception e) {
     		//Utility.clickObject("ehome.detailsofdownpayment.ContinueButtonDetails", "Button"); // Click on Continue
     	}
   	
     	//Utility.clickObject("//*[@id=\"app\"]/div/div[1]/div[4]/button[2]/span", "Button"); // Click on Continue
     	Thread.sleep(1000);
        	
      	Utility.clickObject("ehome.closingDtPicker.button", "Button");
      	Thread.sleep(250);
     	Utility.clickObject("//div[@class='DayPicker DayPicker_1 DayPicker__horizontal DayPicker__horizontal_2 DayPicker__withBorder DayPicker__withBorder_3']//div//div//td[@class='CalendarDay CalendarDay_1 CalendarDay__default CalendarDay__default_2'][contains(text(),'31')]", "Button");
     	Thread.sleep(250);
      	Utility.clickObject("ehome.CloseDtContinue.button", "Button"); // Click on Continue
      	
      	
//      	Utility.clickObject("//*[@id='app']/div/div[1]/div[4]/div/div[1]/div/div/div/button", "Closing Button");
//      	//Utility.clickObject(".//*[contains(text(),'Set Closing Date')]","Closing Button");
//       	//webDriver.findElement(By.xpath(".//*[contains(text(),'Great')]"));
//      	
//     	Thread.sleep(250);
//     	//Utility.clickObject("ehome.closingDtPickerSelection.button", "Button");
//     	Utility.clickObject("//*[@id=\"app\"]/div/div[1]/div[4]/div/div[1]/div/div[2]/div/div[3]/div/div[2]/div[5]/div[6]", "Button");
//     	Thread.sleep(250);
//     	
//      	//Utility.clickObject("ehome.CloseDtContinue.button", "Button"); // Click on Continue
//     	Utility.clickObject("//*[@id='app']/div/div[1]/div[6]/button[2]/span","Continue Button in Closing Date Screen");
     	Utility.clickObject("ehome.detailsofdownpayment.ContinueButtonDetails", "Button"); // Click on Continue button in Details of 
     	//Common.continueButtonClicked();
      	Thread.sleep(500);
     	Utility.clickObject("//*[@id='app']/div/div[1]/div[2]/div/div[3]/div/button", "Section Breaker of Stage2 & Stage3");
     	Thread.sleep(2000);
	 
    }

    @And("^Verify 'Type Of Rate' 'Mortgage Term' 'Rate Presentment' screens and select 'Rate' 'Mortgage Term' 'Rate Presentment' and verify 'Mortgage Summary' from 'Rate Presentment' Screen in 'Stage3_Rate-Presentment'$")
	public void Verify_Type_Of_Rate_And_Select_Rate_Term_Stage3_RatePresentment() throws Throwable {
		Map<String, String> E2E_InputData =  Utility.readTestData(strfullPathToFile, sheetE2E_InputData,strtestCaseID);
		String strInputTypeOfRate= E2E_InputData.get("TypeOfRate"); // Retrieve "TypeOfRate" from Excel 
	  	String strInputMortgageTerm   = E2E_InputData.get("MortgageTerm");// Retrieve "MortgageTerm" from Excel
	 
		Map<String, String> E2E_ExpectedData =  Utility.readTestData(strfullPathToFile, sheetE2E_ExpectedData,strtestCaseID);
		String strExpectTypeOfRate_Title= E2E_ExpectedData.get("TypeOfRate_Title");
		String strExpectMortgTerm_Title= E2E_ExpectedData.get("MortgageTerm_Title");
		Thread.sleep(1000);      
		
		// Verify 'Type Of Rate' Title in STAGE#2 
		QAFExtendedWebElement strActualTypeOfRate_Title= new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[1]/section/div[2]/p");
		if (strExpectTypeOfRate_Title.contentEquals(strActualTypeOfRate_Title.getText())) {
			ExtentReportHelper.StepPass(strExpectTypeOfRate_Title + " Screen# is displayed.");
			}
		else {
			Assert.assertEquals(strActualTypeOfRate_Title.getText(), strExpectTypeOfRate_Title,"'Type Of Rate' Title is NOT as Expected.");
			}
		
		Thread.sleep(1000); 
		CommonAppMethodsGettingNewRate.selectRateType(strInputTypeOfRate); // Select "Type of Rate" option 
    	Thread.sleep(1000);
		    	
    	// Verify 'Mortgage Term' Title in STAGE#2 
 		
    	if (strInputTypeOfRate.contentEquals("Fixed")) {
//    		QAFExtendedWebElement strActualMortgTerm_Title= new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[1]/section/div[2]/p");
//    		if (strExpectMortgTerm_Title.contentEquals(strActualMortgTerm_Title.getText())) {
//    			ExtentReportHelper.StepPass(strExpectMortgTerm_Title + " Screen# is displayed.");
//    			}
//    		else {
//    			Assert.assertEquals(strActualMortgTerm_Title.getText(), strExpectMortgTerm_Title,"'Mortgage Term' Title is NOT as Expected.");
//    			}
    		
    		Thread.sleep(6000);
    		CommonAppMethodsGettingNewRate.selectMortgageTerm(strInputMortgageTerm); // Select "Mortgage Term" option 
    		Thread.sleep(4000);
    	}
      	CommonAppMethodsGettingNewRate.chooseRatesfromRatePresentment(strInputTypeOfRate, strInputMortgageTerm); // Choose Rates button
    	Thread.sleep(1000);
	  }
    
    @And("^Verify 'Lock & Hold' screen and and Verify 'Mortgage summary' and select 'Lock & Hold' in the screen in 'Stage3_Rate-Presentment'$")
	public void Verify_LockHold_And_Verify_MortgageSummary_Select_LockHold_Stage3_RatePresentment() throws Throwable {
    	Map<String, String> E2E_InputData =  Utility.readTestData(strfullPathToFile, sheetE2E_InputData,strtestCaseID);
		Map<String, String> E2E_ExpectedData =  Utility.readTestData(strfullPathToFile, sheetE2E_ExpectedData,strtestCaseID);

			String strInputPurchasePrice  		= E2E_InputData.get("PurchasePrice"); // Retrieve "PurchasePrice" from Excel
			String strInputDownPayment  		= E2E_InputData.get("DownPayment");	// Retrieve "DownPayment" from Excel
			String strInputRateCustomization    = E2E_InputData.get("RateCustomization");// Retrieve "UnLockYourRate" from Excel
			String strInputRateUnlock           = E2E_InputData.get("RateUnlock");// Retrieve "RateUnlock" from Excel
			String strInputRateEquity           = E2E_InputData.get("RateEquity");// Retrieve "Rate Equity" from Excel 
			String strExpectRateLock_Title= E2E_ExpectedData.get("RateLock_Title");
			Thread.sleep(4000);   
		
			QAFExtendedWebElement strActualRateLock_Title= new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[2]/div[2]/h2");
		
//		if (strActualRateLock_Title.getText().contains(strExpectRateLock_Title)){
//			ExtentReportHelper.StepPass(strExpectRateLock_Title + " Screen# is displayed.");
//			}
//		else {
//			Assert.assertEquals(strActualRateLock_Title.getText(), strExpectRateLock_Title,"'' Title is NOT as Expected.");
//			}
		
		Thread.sleep(500);
    	Utility.clickObject("ehome.ratelock.LockandHold", "Button"); // Click on Lock & Hold button
    	Thread.sleep(500);
    	if (strInputRateCustomization.contentEquals("Unlockyourrate")) {
    		Utility.clickObject("ehome.rateunlock.UnlockyourrateBtn", "Button"); // Click on Unlock your rate
    		Thread.sleep(1000);
    		if (strInputRateUnlock.contentEquals("Yes, unlock my rate")) {
    			Utility.clickObject("ehome.rateunlock.Yesunlockmyrate", "Button"); // Click on Yes, unlock my rate
    			return;
    			//Utility.clickObject("//*[@id='app']/div/div[1]/div[2]/div/div[3]/div/button", "Section Breaker of Stage2 & Stage3");
    			
    		}
    		if (strInputRateUnlock.contentEquals("No, keep my rate")) {
    			Utility.clickObject("ehome.rateunlock.Nokeepmyrate", "Button"); // Click on No, keep my rate
    		}
    	}
    	Utility.clickObject("ehome.RateCustContiniueBtn", "Button"); // Click on Continue button
    	QAFExtendedWebElement strActualSTEPTitle= new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[2]/div/div[2]/h2");
    	if(strActualSTEPTitle.getText().contains("Plan (STEP)")) //"STEP" Title
    	{
    		Utility.clickObject("ehome.STEPContiniueBtn", "Button");
    	}	
    	else
    	{
    		System.err.printf("Plan (STEP) is NOT displayed", strActualSTEPTitle.getText());
    	}
    	
    	Double dbPurchasePrice = Double.valueOf(strInputPurchasePrice);
    	Double dbDownPayment = 	Double.valueOf(strInputDownPayment);
    	Double defaultInsurance =  dbDownPayment/dbPurchasePrice*100;
    	
    	if(defaultInsurance >= 20.0)
    	{
    		if (strInputRateEquity.contentEquals("Yes, I'm interested")) {
    			Utility.clickObject("ehome.step.yesImInterestedBtn", "Button");
    			Utility.clickObject("ehome.CloseDtContinue.button", "Button");
    		}
    	}
//    	if (strInputRateEquity.contentEquals("No thanks")) {
//    		QAFExtendedWebElement NothanksBtn= new QAFExtendedWebElement("ehome.step.NothanksBtn");
//    		NothanksBtn.click(); // Click on Continue
//    	}
    	Utility.clickObject("ehome.RateViewContinueBtn", "Button");
    	Utility.clickObject("//*[@id=\"app\"]/div/div[1]/div/div/div[3]/div/button/span", "Button");
   }
    
    
    @And("^Verify 'Employment Status' 'Employment Type' screens and select 'Employment Status' 'Employment Type' in the screen in 'Stage4_Employment'$")
	public void Verify_Employment_Status_And_EmploymentType_Select_Employment_Status_Employment_Type_Employment() throws Throwable {
		Map<String, String> E2E_InputData =  Utility.readTestData(strfullPathToFile, sheetE2E_InputData,strtestCaseID);
	
		String strCurrentEmpStatus	= E2E_InputData.get("CurrentEmpStatus"); 	// Retrieve "Current Employment status" from Excel
		String strEmploymentType = E2E_InputData.get("EmploymentType");
	
	 	Thread.sleep(2000);
	 	
	// 	Utility.clickObject("ehome.Continue.SectionBreaker.button", "Button");
	 	
	 	if (strCurrentEmpStatus.contentEquals("Employed")) {                // Selecting current Employment Status
	 		CommonAppMethodsEmployment.SelectEmpStatus("Employed");
	 		Thread.sleep(4000);
	 		if (strEmploymentType.contentEquals("Commissioned sales")) {             // Selecting Employment Type
	 			CommonAppMethodsEmployment.SelectEmpType("Commissioned sales");}
	 		else if (strEmploymentType.contentEquals("Contract")) {
	 			CommonAppMethodsEmployment.SelectEmpType("Contract");}
	 		else if (strEmploymentType.contentEquals("Full Time")) {
	 			CommonAppMethodsEmployment.SelectEmpType("Full Time");}
	 		else if (strEmploymentType.contentEquals("Part Time")) {
	 			CommonAppMethodsEmployment.SelectEmpType("Part Time");}
	 		else if (strEmploymentType.contentEquals("Seasonal")) {
	 			CommonAppMethodsEmployment.SelectEmpType("Seasonal");}
	 		Thread.sleep(2000);
	 	}
	 	if (strEmploymentType.contentEquals("Self Employed")) {
			CommonAppMethodsEmployment.SelectEmpType("Self Employed");}
    }
    
    @And("^Verify 'Field of work and Job title' screen and select 'Field of work and Job title' in the screen in 'Stage4_Employment'$")
	public void Verify_Field_of_work_and_Job_title_Stage4_Employment() throws Throwable {
		Map<String, String> E2E_InputData =  Utility.readTestData(strfullPathToFile, sheetE2E_InputData,strtestCaseID);
			String strCurrentEmpStatus	= E2E_InputData.get("CurrentEmpStatus"); 	// Retrieve "Current Employment status" from Excel
			String strFieldOfWork=  E2E_InputData.get("EmploymentFieldOfWork");
			String strJobTitle=  E2E_InputData.get("EmploymentJobTitle");

		Thread.sleep(2000);
	 	if (strCurrentEmpStatus.contentEquals("Employed")) {                // Selecting current Employment Status
	 		CommonApplicationMethods.selectValuefromDropDownListBox("//*[@id=\"jobField\"]", strFieldOfWork); // Selecting Field of work
	 		Thread.sleep(1000);
	 		CommonApplicationMethods.selectValuefromDropDownListBox("//*[@id=\"jobTitle\"]", strJobTitle);    // Selecting Job Title
	 		Common.continueButtonClicked();
	 		Thread.sleep(1000);
	 	}    
    }
    
    @And("^Verify 'Employers Name and Phone Number' screen and enter 'Employers Name and Phone Number' in the screen in 'Stage4_Employment'$")
  	public void Verify_Employers_Name_and_Phone_Number_Screen_Stage4_Employment() throws Throwable {
    	Map<String, String> E2E_InputData =  Utility.readTestData(strfullPathToFile, sheetE2E_InputData,strtestCaseID);
    		String strCurrentEmpStatus	= E2E_InputData.get("CurrentEmpStatus"); 	// Retrieve "Current Employment status" from Excel
    		String strEmployerName	= E2E_InputData.get("CurrentEmployerName"); 
    	
    	if (strCurrentEmpStatus.contentEquals("Employed")) {                // Selecting current Employment Status
	      	//Utility.sendKeys("//*[@id=\'employerName\']","Scotia Bank");
    		Utility.sendKeys("//*[@id=\'employerName\']",strEmployerName);
			Utility.sendKeys("//*[@id=\"employerPhone\"]","6471234567");
			Thread.sleep(1000);
			Common.continueButtonClicked();
			Thread.sleep(500);
    	}
       }
   
    @And("^Verify 'Employers Address' screen and enter 'Employers Address' in the screen in 'Stage4_Employment'$")
  	public void Verify_Employers_Address_and_enter_Employers_Address_Stage4_Employment() throws Throwable {
    	Map<String, String> E2E_InputData =  Utility.readTestData(strfullPathToFile, sheetE2E_InputData,strtestCaseID);
			String strCurrentEmpStatus	= E2E_InputData.get("CurrentEmpStatus"); 	// Retrieve "Current Employment status" from Excel
    	
		if (strCurrentEmpStatus.contentEquals("Employed")) {                // Selecting current Employment Status
	//	CommonApplicationMethods.enterAutoSuggestAddress("888 BIRCHMOUNT RD TORONTO ON M1K5L1","ehome.employeraddress.address","//*[@id=\"app\"]/div/div[1]/div[1]/section/div/div[3]/div[1]/div/div[2]/div/ul" );
			CommonApplicationMethods.enterAutoSuggestAddress("888 BIR","ehome.employeraddress.address","//li[@id='address-lookup__result-0']" );	
		Thread.sleep(1000);
		Common.continueButtonClicked();
		}
       }
    
    @And("^Verify 'Annual Income' screen and enter 'Salary' 'Bonus' 'Overtime' in the screen in 'Stage4_Employment'$")
  	public void Verify_Annual_Income_Screen_and_enter_Annual_Income_Stage4_Employment() throws Throwable {
    	Map<String, String> E2E_InputData =  Utility.readTestData(strfullPathToFile, sheetE2E_InputData,strtestCaseID);
			String strCurrentEmpStatus	= E2E_InputData.get("CurrentEmpStatus"); 	// Retrieve "Current Employment status" from Excel
    	
		if (strCurrentEmpStatus.contentEquals("Employed")) {                // Selecting current Employment Status
			Thread.sleep(4000);
			Utility.sendKeys("ehome.annualIncome.salary", "120000");
			Utility.sendKeys("ehome.annualIncome.bonus", "9000");
			Utility.sendKeys("ehome.annualIncome.overtime", "50000");
			Thread.sleep(1000);
			Common.continueButtonClicked();
			Thread.sleep(1000);
		    	}
      }
    
    
    @And("^Verify 'How long have you worked' screen and enter 'Year' 'Month' in the screen in 'Stage4_Employment'$")
  	public void Verify_How_long_have_you_worked_and_enter_Year_Month_Stage4_Employment() throws Throwable {
    	Map<String, String> E2E_InputData =  Utility.readTestData(strfullPathToFile, sheetE2E_InputData,strtestCaseID);
    		String strCurrentEmpStatus	= E2E_InputData.get("CurrentEmpStatus"); 	// Retrieve "Current Employment status" from Excel
    		String strDurationYear=  E2E_InputData.get("Years");
    		String strDurationMonth=  E2E_InputData.get("Months");
		
		if (strCurrentEmpStatus.contentEquals("Employed")) {                // Selecting current Employment Status
			if (strDurationYear != "") {
				CommonApplicationMethods.selectValuefromDropDownListBox("ehome.employmentDuration.years", strDurationYear);
	 		Thread.sleep(500);
			}
			if (strDurationMonth != "") {
				CommonApplicationMethods.selectValuefromDropDownListBox("ehome.employmentDuration.months", strDurationMonth);
	 		Thread.sleep(500);
			}
			
			Common.continueButtonClicked();
			Thread.sleep(1000);
			
			if (strDurationYear.contentEquals("1 year") | strDurationYear.contentEquals("0 years") ){  
				Utility.sendKeys("ehome.previousEmployerDetails.employerName","Mahindra Satyam");
		 		Thread.sleep(500);
		 		Common.continueButtonClicked();
		 		Thread.sleep(500);
				Utility.sendKeys("ehome.previousAnnualIncome.salary", "80000");
		 		Thread.sleep(500);
		 		Common.continueButtonClicked();
		 		Thread.sleep(1000);
		 		CommonApplicationMethods.selectValuefromDropDownListBox("ehome.previousemploymentDuration.years", strDurationYear);
		 		Thread.sleep(500);
		 		CommonApplicationMethods.selectValuefromDropDownListBox("ehome.previousemploymentDuration.months", strDurationMonth);
		 		Thread.sleep(500);
		 		Common.continueButtonClicked();
		 		Thread.sleep(1000);
				 		}
		    	}
		
		if (strCurrentEmpStatus.contentEquals("Retired")) {
			CommonAppMethodsEmployment.SelectEmpStatus("Retired");
			if (strDurationYear != "") {
				CommonApplicationMethods.selectValuefromDropDownListBox("ehome.employmentDuration.years", strDurationYear);
	 		Thread.sleep(500);
			}
			if (strDurationMonth != "") {
				CommonApplicationMethods.selectValuefromDropDownListBox("ehome.employmentDuration.months", strDurationMonth);
	 		Thread.sleep(500);
			}
			Thread.sleep(1000);
			Common.continueButtonClicked();
			Thread.sleep(1000);
		}
	  }
     
    @And("^Verify 'Other sources of income' screen and select 'Other sources of income' in the screen in 'Stage4_Employment'$")
  	public void Verify_Other_sources_of_income_screen_and_select_Other_sources_of_income_Stage4_Employment() throws Throwable {
    	Map<String, String> E2E_InputData =  Utility.readTestData(strfullPathToFile, sheetE2E_InputData,strtestCaseID);
			String strCurrentEmpStatus	= E2E_InputData.get("CurrentEmpStatus"); 	// Retrieve "Current Employment status" from Excel
			String strChildSupport= E2E_InputData.get("EmpOtherSrcsOfIncome_Child Support");
			String strCommission= E2E_InputData.get("EmpOtherSrcsOfIncome_Commission");
			String strInvestments= E2E_InputData.get("EmpOtherSrcsOfIncome_Investments");
			String strPartTimeWork= E2E_InputData.get("EmpOtherSrcsOfIncome_PartTimeWork");
			String strPensionDisability= E2E_InputData.get("EmpOtherSrcsOfIncome_PensionDisability");
			String strRIFLIF= E2E_InputData.get("EmpOtherSrcsOfIncome_RIFLIF");
			String strSeasonalWork= E2E_InputData.get("EmpOtherSrcsOfIncome_SeasonalWork");
			String strSpousalSupport= E2E_InputData.get("EmpOtherSrcsOfIncome_SpousalSupport");
    	
		if (strCurrentEmpStatus.contentEquals("Employed")) {                // Selecting current Employment Status
			
		//  Do you have any other sources of income?
			if (strChildSupport.contentEquals("Child support")) {
				CommonAppMethodsEmployment.SelectOtherSourcesOfIncome(strChildSupport); 
			}
			if (strCommission.contentEquals("Commission")) {
				CommonAppMethodsEmployment.SelectOtherSourcesOfIncome(strCommission); 
			}
			if (strInvestments.contentEquals("Investments")) {
				CommonAppMethodsEmployment.SelectOtherSourcesOfIncome(strInvestments); 
			}
			if (strPartTimeWork.contentEquals("Part time work")) {
				CommonAppMethodsEmployment.SelectOtherSourcesOfIncome(strPartTimeWork); 
			}
			if (strPensionDisability.contentEquals("Pension/Disability")) {
				CommonAppMethodsEmployment.SelectOtherSourcesOfIncome(strPensionDisability); 
			}
			if (strRIFLIF.contentEquals("RIF/LIF")) {
				CommonAppMethodsEmployment.SelectOtherSourcesOfIncome(strRIFLIF); 
			}
			if (strSeasonalWork.contentEquals("Seasonal work")) {
				CommonAppMethodsEmployment.SelectOtherSourcesOfIncome(strSeasonalWork); 
			}
			if (strSpousalSupport.contentEquals("Spousal support")) {
				CommonAppMethodsEmployment.SelectOtherSourcesOfIncome(strSpousalSupport); 
			}
			if (strChildSupport.contentEquals("No other sources of income") | strCommission.contentEquals("No other sources of income") | strPartTimeWork.contentEquals("No other sources of income") | strPensionDisability.contentEquals("No other sources of income")| strRIFLIF.contentEquals("No other sources of income")| strInvestments.contentEquals("No other sources of income")| strSeasonalWork.contentEquals("No other sources of income")| strSpousalSupport.contentEquals("No other sources of income")) {
				CommonAppMethodsEmployment.SelectOtherSourcesOfIncome("No other sources of income");
			}
			Common.continueButtonClicked();
			Thread.sleep(500); 
			    	}
		if (strCurrentEmpStatus.contentEquals("UnEmployed")) {
			CommonAppMethodsEmployment.SelectEmpStatus("UnEmployed");
			Thread.sleep(2000); 
			if (strChildSupport.contentEquals("Child support")) {
				CommonAppMethodsEmployment.SelectOtherSourcesOfIncome(strChildSupport); 
			}
			if (strInvestments.contentEquals("Investments")) {
				CommonAppMethodsEmployment.SelectOtherSourcesOfIncome(strInvestments); 
			}
			if (strPensionDisability.contentEquals("Pension/Disability")) {
				CommonAppMethodsEmployment.SelectOtherSourcesOfIncome(strPensionDisability); 
			}
		if (strSpousalSupport.contentEquals("Spousal support")) {
			CommonAppMethodsEmployment.SelectOtherSourcesOfIncome(strSpousalSupport); 
		} 
			Common.continueButtonClicked();
		Thread.sleep(500); 
		}
	       }
    
    @And("^Verify 'Annual income for each source' screen and enter 'Annual income for each source' in the screen in 'Stage4_Employment'$")
  	public void Verify_Annual_income_for_each_source_screen_and_enter_Annual_income_for_each_source_Stage4_Employment() throws Throwable {
    	Map<String, String> E2E_InputData =  Utility.readTestData(strfullPathToFile, sheetE2E_InputData,strtestCaseID);
	    	String strChildSupport= E2E_InputData.get("EmpOtherSrcsOfIncome_Child Support");
			String strCommission= E2E_InputData.get("EmpOtherSrcsOfIncome_Commission");
			String strInvestments= E2E_InputData.get("EmpOtherSrcsOfIncome_Investments");
			String strPartTimeWork= E2E_InputData.get("EmpOtherSrcsOfIncome_PartTimeWork");
			String strPensionDisability= E2E_InputData.get("EmpOtherSrcsOfIncome_PensionDisability");
			String strRIFLIF= E2E_InputData.get("EmpOtherSrcsOfIncome_RIFLIF");
			String strSeasonalWork= E2E_InputData.get("EmpOtherSrcsOfIncome_SeasonalWork");
			String strSpousalSupport= E2E_InputData.get("EmpOtherSrcsOfIncome_SpousalSupport");
			String strCurrentEmpStatus	= E2E_InputData.get("CurrentEmpStatus"); 	// Retrieve "Current Employment status" from Excel
			String strChildSupportAmt= E2E_InputData.get("EmpOtherSrcsOfIncome_ChildSupport_Amt");
			String strCommissionAmt= E2E_InputData.get("EmpOtherSrcsOfIncome_Commission_Amt");
			String strInvestmentsAmt= E2E_InputData.get("EmpOtherSrcsOfIncome_Investments_Amt");
			String strPartTimeWorkAmt= E2E_InputData.get("EmpOtherSrcsOfIncome_PartTimeWork_Amt");
			String strPensionDisabilityAmt= E2E_InputData.get("EmpOtherSrcsOfIncome_PensionDisability_Amt");
			String strRIFLIFAmt= E2E_InputData.get("EmpOtherSrcsOfIncome_RIFLIF_Amt");
			String strSeasonalWorkAmt= E2E_InputData.get("EmpOtherSrcsOfIncome_SeasonalWork_Amt");
			String strSpousalSupportAmt= E2E_InputData.get("EmpOtherSrcsOfIncome_SpousalSupport_Amt");
    	
		if (strCurrentEmpStatus.contentEquals("Employed")) {                // Selecting current Employment Status
			//  What's the annual income for each source?
			if (strChildSupport != null | strChildSupportAmt.length() != 0) {
				CommonAppMethodsEmployment.EnterAnualIncomeSourceAmount(strChildSupport, strChildSupportAmt);
			}
			if (strCommission != null | strCommissionAmt.length() != 0) {
				CommonAppMethodsEmployment.EnterAnualIncomeSourceAmount(strCommission, strCommissionAmt);
			}
			if (strInvestments != null | strInvestmentsAmt.length() != 0) {
				CommonAppMethodsEmployment.EnterAnualIncomeSourceAmount(strInvestments, strInvestmentsAmt);
			}
			if (strPartTimeWork != null | strPartTimeWorkAmt.length() != 0) {
				CommonAppMethodsEmployment.EnterAnualIncomeSourceAmount(strPartTimeWork, strPartTimeWorkAmt);
			}
			if (strPensionDisability != null | strPensionDisabilityAmt.length() != 0) {
				CommonAppMethodsEmployment.EnterAnualIncomeSourceAmount(strPensionDisability, strPensionDisabilityAmt);
			}
			if (strRIFLIF != null | strRIFLIFAmt.length() != 0) {
				CommonAppMethodsEmployment.EnterAnualIncomeSourceAmount(strRIFLIF, strRIFLIFAmt);
			}

			if (strSeasonalWork != null | strSeasonalWorkAmt.length() != 0) {
				CommonAppMethodsEmployment.EnterAnualIncomeSourceAmount(strSeasonalWork, strSeasonalWorkAmt);
			}
			if (strSpousalSupport != null | strSpousalSupportAmt.length() != 0) {
				CommonAppMethodsEmployment.EnterAnualIncomeSourceAmount(strSpousalSupport, strSpousalSupportAmt);
			}
			Thread.sleep(500);
			Utility.clickObject("//*[@id=\"app\"]/div/div[1]/div[3]/button[2]/span", "Button");
			Thread.sleep(500);  
		    	}
		if (strCurrentEmpStatus.contentEquals("UnEmployed")) {
		//  What's the annual income for each source?
			if (strChildSupport != null | strChildSupportAmt.length() != 0) {
				CommonAppMethodsEmployment.EnterAnualIncomeSourceAmount(strChildSupport, strChildSupportAmt);
				}
			if (strInvestments != null | strInvestmentsAmt.length() != 0) {
				CommonAppMethodsEmployment.EnterAnualIncomeSourceAmount(strInvestments, strInvestmentsAmt);
				}
			if (strPensionDisability != null | strPensionDisabilityAmt.length() != 0) {
				CommonAppMethodsEmployment.EnterAnualIncomeSourceAmount(strPensionDisability, strPensionDisabilityAmt);
			}
			if (strSpousalSupport != null | strSpousalSupportAmt.length() != 0) {
				CommonAppMethodsEmployment.EnterAnualIncomeSourceAmount(strSpousalSupport, strSpousalSupportAmt);
			}
			Thread.sleep(500);
			Utility.clickObject("//*[@id=\"app\"]/div/div[1]/div[3]/button[2]/span", "employment-income");
			Thread.sleep(500);
			Utility.clickObject("//*[@id=\"app\"]/div/div[1]/div[2]/div/div[3]/div/button/span","asset-section-breaker");
			Thread.sleep(500);  
		}

		if (strCurrentEmpStatus.contentEquals("Retired")) {
			if (strInvestments.contentEquals("Investments")) {
				CommonAppMethodsEmployment.SelectRetiredSourcesOfIncome(strInvestments); 
					}
			if (strPensionDisability.contentEquals("Pension/Disability")) {
				CommonAppMethodsEmployment.SelectRetiredSourcesOfIncome(strPensionDisability); 
			}
			if (strRIFLIF.contentEquals("RIF/LIF")) {
				CommonAppMethodsEmployment.SelectRetiredSourcesOfIncome(strRIFLIF); 
			}
			if (strInvestments.contentEquals("No sources of income") | strPensionDisability.contentEquals("No sources of income")  | strRIFLIF.contentEquals("No sources of income")  ) {
				CommonAppMethodsEmployment.SelectRetiredSourcesOfIncome("No sources of income"); 
			}
			Common.continueButtonClicked();
			Thread.sleep(1000);
			if (strInvestments != null | strInvestmentsAmt.length() != 0) {
				CommonAppMethodsEmployment.EnterRetiredAnualIncomeSourceAmount(strInvestments, strInvestmentsAmt);
			}
			if (strPensionDisability != null | strPensionDisabilityAmt.length() != 0) {
				CommonAppMethodsEmployment.EnterRetiredAnualIncomeSourceAmount(strPensionDisability, strPensionDisabilityAmt);
			}
			if (strRIFLIF != null | strRIFLIFAmt.length() != 0) {
				CommonAppMethodsEmployment.EnterRetiredAnualIncomeSourceAmount(strRIFLIF, strRIFLIFAmt);
			}
			Thread.sleep(500);
			if (strInvestments != "" | strPensionDisability != "" | strRIFLIF !=""  )
				{
					Utility.clickObject("//*[@id=\"app\"]/div/div[1]/div[3]/button[2]/span", "Button");
					Thread.sleep(500);
				}
			Utility.clickObject("//*[@id=\"app\"]/div/div[1]/div[2]/div/div[3]/div/button/span", "asset-section-breaker");
			}
			
	      }
    
    @And("^Verify 'Co-Applicant_Employment' screen and select 'Skip Section' in the screen in 'Stage4_Co-Applicant_Employment'$")
  	public void Verify_CoApplicant_Employment_screen_select_skip_section_Stage4_Co_Applicant_Employment() throws Throwable {
    	Map<String, String> E2E_InputData =  Utility.readTestData(strfullPathToFile, sheetE2E_InputData,strtestCaseID);
			String strCurrentEmpStatus	= E2E_InputData.get("CurrentEmpStatus"); 	// Retrieve "Current Employment status" from Excel
   
		if (strCurrentEmpStatus.contentEquals("Employed")) {                // Selecting current Employment Status
				Utility.clickObject("//*[@id=\"app\"]/div/div[1]/div[2]/div/div[3]/div/button/span","Asset-section-breaker Button");
				Thread.sleep(500);
		    	}
      }
     
    @And("^Verify 'Asset-sources' screen and select 'Assets' in the screen in 'Stage5_AssetLiabilities'$")
  	public void Verify_Assetsources_screen_and_enter_Assets_Stage5_AssetLiabilities() throws Throwable {
    	Map<String, String> E2E_InputData =  Utility.readTestData(strfullPathToFile, sheetE2E_InputData,strtestCaseID);
				String strCurrentEmpStatus	= E2E_InputData.get("CurrentEmpStatus"); 	// Retrieve "Current Employment status" from Excel
				String strAutomobile = E2E_InputData.get("AssetSources_Automobile");
				String strCash = E2E_InputData.get("AssetSources_Cash");
				String strGICTermDeposit = E2E_InputData.get("AssetSources_GICTermDeposit");
				String strPrimaryResidence = E2E_InputData.get("AssetSources_PrimaryResidence");
				String strRentalProperty = E2E_InputData.get("AssetSources_RentalProperty");
				String strRRSP = E2E_InputData.get("AssetSources_RRSP");
				String strSecondaryProperty = E2E_InputData.get("AssetSources_SecondaryProperty");
				String strStockBond = E2E_InputData.get("AssetSources_StockBond");
				String strOtherAssets = E2E_InputData.get("AssetSources_OtherAssets");
	    	
			if (strCurrentEmpStatus.contentEquals("Employed") | strCurrentEmpStatus.contentEquals("UnEmployed") | strCurrentEmpStatus.contentEquals("Retired")) {                // Selecting current Employment Status
				//Do you have any of the following assets?
				
				Thread.sleep(500);
				
				if (strAutomobile.contentEquals("Automobile")) {
					CommonAppMethodsAssetLiabilities.SelectAssetsSources(strAutomobile); 
				}
				if (strCash.contentEquals("Cash")) {
					CommonAppMethodsAssetLiabilities.SelectAssetsSources(strCash); 
				}
				if (strGICTermDeposit.contentEquals("GIC/Term deposit")) {
					CommonAppMethodsAssetLiabilities.SelectAssetsSources(strGICTermDeposit); 
				}
				if (strPrimaryResidence.contentEquals("Primary residence")) {
					CommonAppMethodsAssetLiabilities.SelectAssetsSources(strPrimaryResidence); 
				}
				
				if (strRentalProperty.contentEquals("Rental property")) {
					CommonAppMethodsAssetLiabilities.SelectAssetsSources(strRentalProperty); 
				}
				if (strRRSP.contentEquals("RRSP")) {
					CommonAppMethodsAssetLiabilities.SelectAssetsSources(strRRSP); 
				}
				if (strSecondaryProperty.contentEquals("Secondary property")) {
					CommonAppMethodsAssetLiabilities.SelectAssetsSources(strSecondaryProperty); 
				}
				if (strStockBond.contentEquals("Stock/Bond")) {
					CommonAppMethodsAssetLiabilities.SelectAssetsSources(strStockBond); 
				}
				if (strOtherAssets.contentEquals("Other assets")) {
					CommonAppMethodsAssetLiabilities.SelectAssetsSources(strOtherAssets); 
				}
				if (strAutomobile.contentEquals("No assets") | strCash.contentEquals("No assets") | strGICTermDeposit.contentEquals("No assets") | strPrimaryResidence.contentEquals("No assets")| strRentalProperty.contentEquals("No assets")| strRRSP.contentEquals("No other assets")| strSecondaryProperty.contentEquals("No assets")| strStockBond.contentEquals("No assets")| strOtherAssets.contentEquals("No assets")) {
					CommonAppMethodsAssetLiabilities.SelectAssetsSources("No assets"); 
				}
				Common.continueButtonClicked();
			    	}
      }
    
    @And("^Verify 'Asset-Calculator' screen and enter 'Assets' in the screen in 'Stage5_AssetLiabilities'$")
  	public void Verify_AssetCalculator_screen_and_enter_Assets_Stage5_AssetLiabilities() throws Throwable {
    	Map<String, String> E2E_InputData =  Utility.readTestData(strfullPathToFile, sheetE2E_InputData,strtestCaseID);
			String strCurrentEmpStatus	= E2E_InputData.get("CurrentEmpStatus"); 	// Retrieve "Current Employment status" from Excel
			String strAutomobile = E2E_InputData.get("AssetSources_Automobile");
			String strCash = E2E_InputData.get("AssetSources_Cash");
			String strGICTermDeposit = E2E_InputData.get("AssetSources_GICTermDeposit");
			String strPrimaryResidence = E2E_InputData.get("AssetSources_PrimaryResidence");
			String strRentalProperty = E2E_InputData.get("AssetSources_RentalProperty");
			String strRRSP = E2E_InputData.get("AssetSources_RRSP");
			String strSecondaryProperty = E2E_InputData.get("AssetSources_SecondaryProperty");
			String strStockBond = E2E_InputData.get("AssetSources_StockBond");
			String strOtherAssets = E2E_InputData.get("AssetSources_OtherAssets");
			String strAutomobileAmt = E2E_InputData.get("AssetSources_Automobile_Amt");
			String strCashAmt = E2E_InputData.get("AssetSources_Cash_Amt");
			String strGICTermDepositAmt = E2E_InputData.get("AssetSources_GICTermDeposit_Amt");
			String strPrimaryResidenceAmt = E2E_InputData.get("AssetSources_PrimaryResidence_Amt");
			String strRentalPropertyAmt = E2E_InputData.get("AssetSources_RentalProperty_Amt");
			String strRRSPAmt = E2E_InputData.get("AssetSources_RRSP_Amt");
			String strSecondaryPropertyAmt = E2E_InputData.get("AssetSources_SecondaryProperty_Amt");
			String strStockBondAmt = E2E_InputData.get("AssetSources_StockBond_Amt");
			String strOtherAssetsAmt = E2E_InputData.get("AssetSources_OtherAssets_Amt");
		
		if (strCurrentEmpStatus.contentEquals("Employed") | strCurrentEmpStatus.contentEquals("UnEmployed") | strCurrentEmpStatus.contentEquals("Retired")) {                // Selecting current Employment Status
				//Do you have any of the following assets?
				if (strAutomobile != "" && strAutomobileAmt != "")
					CommonAppMethodsAssetLiabilities.EnterAssetCalculateAmount(strAutomobile, strAutomobileAmt);
					}
				if (strCash != "" && strCashAmt != "") {
					CommonAppMethodsAssetLiabilities.EnterAssetCalculateAmount(strCash, strCashAmt);
					}
				if (strGICTermDeposit != "" && strGICTermDepositAmt != "") {
					CommonAppMethodsAssetLiabilities.EnterAssetCalculateAmount(strGICTermDeposit, strGICTermDepositAmt);
					}
				if (strPrimaryResidence != "" && strPrimaryResidenceAmt != "") {
					CommonAppMethodsAssetLiabilities.EnterAssetCalculateAmount(strPrimaryResidence, strPrimaryResidenceAmt );
					}
				if (strRentalProperty != "" && strRentalPropertyAmt != "") {
					CommonAppMethodsAssetLiabilities.EnterAssetCalculateAmount(strRentalProperty, strRentalPropertyAmt );
			 		}
				if (strRRSP != "" && strRRSPAmt != "") {
					CommonAppMethodsAssetLiabilities.EnterAssetCalculateAmount(strRRSP, strRRSPAmt);
					}
				if (strSecondaryProperty != "" && strSecondaryPropertyAmt != "") {
					CommonAppMethodsAssetLiabilities.EnterAssetCalculateAmount(strSecondaryProperty, strSecondaryPropertyAmt);
					}
				if (strStockBond != "" && strStockBondAmt != "") {
					CommonAppMethodsAssetLiabilities.EnterAssetCalculateAmount(strStockBond, strStockBondAmt);
					}
				if (strOtherAssets != "" && strOtherAssetsAmt != "") {
					CommonAppMethodsAssetLiabilities.EnterAssetCalculateAmount(strOtherAssets, strOtherAssetsAmt );
					}
				Thread.sleep(1000);
				
			 QAFExtendedWebElement continueBtn = new WebDriverTestBase().getDriver().findElement(By.xpath("//button[contains(@class,'nav-button nav-button--next nav-button--enabled')]"));
//			 Actions action =new Actions(new WebDriverTestBase().getDriver());
//			 action.moveToElement(continueBtn).doubleClick().build().perform();
//			 action.moveToElement(continueBtn,0,0).click().build().perform();
			 continueBtn.click();
				
//				Utility.webDriver.findElement(By.xpath(".//*[contains(text(),'Continue')]")).click();
//				webDriver.findElement(By.xpath(".//*[contains(text(),'Continue')]"));
//				Utility.clickObject(".//span[contains(text(),'Continue')]","continue");
				Thread.sleep(1000);
    }
     
    @And("^Verify 'Liabilities-sources' screen and select 'Liabilities' in the screen in 'Stage5_AssetLiabilities'$")
  	public void Verify_Liabilitiessources_screen_and_enter_Liabilitiessources_Stage5_AssetLiabilities() throws Throwable {
    	Map<String, String> E2E_InputData =  Utility.readTestData(strfullPathToFile, sheetE2E_InputData,strtestCaseID);
			String strCurrentEmpStatus	= E2E_InputData.get("CurrentEmpStatus"); 	// Retrieve "Current Employment status" from Excel
			String strAlimonyLiability = E2E_InputData.get("LiabilitySources_Alimony");
			String strChildSupportLiability = E2E_InputData.get("LiabilitySources_ChildSupport");
			String strPrivateDebtLiability = E2E_InputData.get("LiabilitySources_PrivateDebt");
			
			Thread.sleep(1000);
		
			if (strCurrentEmpStatus.contentEquals("Employed") | strCurrentEmpStatus.contentEquals("UnEmployed") | strCurrentEmpStatus.contentEquals("Retired")) {                // Selecting current Employment Status
				if (strAlimonyLiability.contentEquals("Alimony")) {
					CommonAppMethodsAssetLiabilities.SelectLiabilitySources(strAlimonyLiability); 
				}
				if (strChildSupportLiability.contentEquals("Child support")) {
					CommonAppMethodsAssetLiabilities.SelectLiabilitySources(strChildSupportLiability); 
				}
				if (strPrivateDebtLiability .contentEquals("Private debt")) {
					CommonAppMethodsAssetLiabilities.SelectLiabilitySources(strPrivateDebtLiability ); 
				}
				if (strAlimonyLiability.contentEquals("No liabilities") | strChildSupportLiability.contentEquals("No liabilities") | strPrivateDebtLiability.contentEquals("No liabilities")) {
					CommonAppMethodsAssetLiabilities.SelectLiabilitySources("No liabilities"); 
				}
				Common.continueButtonClicked();
		    	}
      }
    
    @And("^Verify 'Liabilities-Calculator' screen and enter 'Liabilities' in the screen in 'Stage5_AssetLiabilities'$")
  	public void Verify_LiabilitiesCalculator_screen_and_enter_LiabilitiesCalculator_Stage5_AssetLiabilities() throws Throwable {
    	Map<String, String> E2E_InputData =  Utility.readTestData(strfullPathToFile, sheetE2E_InputData,strtestCaseID);
			String strCurrentEmpStatus	= E2E_InputData.get("CurrentEmpStatus"); 	// Retrieve "Current Employment status" from Excel
			String strAlimonyLiability = E2E_InputData.get("LiabilitySources_Alimony");
			String strChildSupportLiability = E2E_InputData.get("LiabilitySources_ChildSupport");
			String strPrivateDebtLiability = E2E_InputData.get("LiabilitySources_PrivateDebt");
			
			String strAlimonyLiabilityMonthlyPaymt = E2E_InputData.get("LiabilitySources_Alimony_Monthly_Pymt");
			String strChildSupportLiabilityMonthlyPayment = E2E_InputData.get("LiabilitySources_ChildSupport_Monthly_Pymt");
			String strPrivateDebtLiabilityMonthlyPayment = E2E_InputData.get("LiabilitySources_PrivateDebt_Monthly_Pymt");
			String strPrivateDebtLiabilityBalanceOwing = E2E_InputData.get("LiabilitySources_BalanceOwing__Monthly_Pymt");
		
			if (strCurrentEmpStatus.contentEquals("Employed") | strCurrentEmpStatus.contentEquals("UnEmployed") | strCurrentEmpStatus.contentEquals("Retired")) {                // Selecting current Employment Status
			//Do you have any liabilities outside of Scotiabank?
				if (strAlimonyLiability != "" && strAlimonyLiabilityMonthlyPaymt != "") {
					CommonAppMethodsAssetLiabilities.EnterLiabilityCalculateAmount(strAlimonyLiability, strAlimonyLiabilityMonthlyPaymt);
			 	}
				Thread.sleep(2000);
				if (strChildSupportLiability != "" && strChildSupportLiabilityMonthlyPayment != "") {
					CommonAppMethodsAssetLiabilities.EnterLiabilityCalculateAmount(strChildSupportLiability, strChildSupportLiabilityMonthlyPayment);
				}
				if (strPrivateDebtLiabilityBalanceOwing != "") {
					String strBalanceOwing = "Balance Owing";
					CommonAppMethodsAssetLiabilities.EnterLiabilityCalculateAmount(strBalanceOwing, strPrivateDebtLiabilityBalanceOwing);
				}
				if (strPrivateDebtLiability!= "" && strPrivateDebtLiabilityMonthlyPayment != "") {
					CommonAppMethodsAssetLiabilities.EnterLiabilityCalculateAmount(strPrivateDebtLiability, strPrivateDebtLiabilityMonthlyPayment);
				 }
				Common.continueButtonClicked();
				Thread.sleep(2000);
			    	}
       }
    
    @When("^User is on 'Upload section breaker' screen$")
  	public void When_User_is_on_Upload_section_breaker_screen() throws Throwable {
  			Utility.clickObject("ehome.docUploadSectionBrkr.Start.Button", "Document-upload-section-breaker-Start Button");
			Thread.sleep(6000);
    }
    
    @And("^Upload the document in all the sections and validate the Total document upload section$")
  	public void Upload_the_document_in_all_the_sections_and_validate_the_Total_documentupload_section() throws Throwable {
      	Utility.clickObject("ehome.docUpload.PurchaseSaleAgrmt.UploadBtn", "Purchase & Sale Agreement upload Button");
    	Thread.sleep(6000);
    	Runtime.getRuntime().exec("C:\\MyWorkPlace\\AutoIt-workspace\\Documents\\PropertyDocs_PurchaseSaleAgre.exe");
    	//Runtime.getRuntime().exec( strDocsPath + "PropertyDocs_PurchaseSaleAgre.exe");
    	Thread.sleep(6000);
    	Common.continueButtonClicked();
		//Common.continueButtonClicked();
           }
    
    @When("^User is on 'Id Verification' screen$")
  	public void When_User_is_on_IdVerification_breaker_screen() throws Throwable {
    	//Thread.sleep(2000);
    	Map<String, String> E2E_InputData =  Utility.readTestData(strfullPathToFile, sheetE2E_InputData,strtestCaseID);
	    	String strPhotoIDDocument	= E2E_InputData.get("PhotoIDDocument");
		Thread.sleep(6000);
		Robot robot = null;
		try {
			robot = new Robot();

		} catch (AWTException e) {
			e.printStackTrace();
		}

		Thread.sleep(6000);
		Utility.webDriver.manage().window().maximize();
		Thread.sleep(6000);
// Robot class throws AWT Exception
		robot.keyPress(KeyEvent.VK_CONTROL);
		robot.keyPress(KeyEvent.VK_SHIFT);
		robot.keyPress(KeyEvent.VK_I);
		Thread.sleep(3000);
		robot.keyRelease(KeyEvent.VK_CONTROL);
		robot.keyRelease(KeyEvent.VK_SHIFT);
		robot.keyRelease(KeyEvent.VK_I);
		Thread.sleep(6000);
		robot.keyPress(KeyEvent.VK_CONTROL);
		robot.keyPress(KeyEvent.VK_SHIFT);
		robot.keyPress(KeyEvent.VK_M);
		robot.keyRelease(KeyEvent.VK_CONTROL);
		robot.keyRelease(KeyEvent.VK_SHIFT);
		robot.keyRelease(KeyEvent.VK_M);
		Thread.sleep(3000);

		WebElement z = Utility.webDriver.findElement(By.xpath(".//*[contains(text(),'Send email link')]"));
		((JavascriptExecutor) Utility.webDriver).executeScript("arguments[0].click();", z);

        Robot rb = null;
        try {
            rb = new Robot();

        } catch (AWTException e) {
            e.printStackTrace();
        }
        Thread.sleep(6000);
        Utility.webDriver.manage().window().maximize();
        Thread.sleep(6000);
        rb.keyPress(KeyEvent.VK_CONTROL);
        rb.keyPress(KeyEvent.VK_SHIFT);
        rb.keyPress(KeyEvent.VK_M);
        rb.keyRelease(KeyEvent.VK_CONTROL);
        rb.keyRelease(KeyEvent.VK_SHIFT);
        rb.keyRelease(KeyEvent.VK_M);
        Thread.sleep(2000);

        Robot mob = null;
        try {
            mob = new Robot();

        } catch (AWTException e) {
            e.printStackTrace();
        }
        Thread.sleep(6000);
        Utility.webDriver.manage().window().maximize();
        Thread.sleep(6000);
        mob.keyPress(KeyEvent.VK_CONTROL);
        mob.keyPress(KeyEvent.VK_SHIFT);
        mob.keyPress(KeyEvent.VK_I);
        mob.keyRelease(KeyEvent.VK_CONTROL);
        mob.keyRelease(KeyEvent.VK_SHIFT);
        mob.keyRelease(KeyEvent.VK_I);

		CommonAppMethodsIdVerification.selectPhotoIDDocument(strPhotoIDDocument);
        Thread.sleep(5000);
		WebElement ele;
		Actions ac = new Actions(Utility.webDriver);
		ele= Utility.webDriver.findElement(By.xpath(".//*[contains(text(),'Scan front')]"));
		ac.moveToElement(ele).click().perform();
		Thread.sleep(2000);
		
		Runtime.getRuntime().exec("C:\\MyWorkPlace\\AutoIt-workspace\\GemaltoID\\DL_Front.exe");
//		Runtime.getRuntime().exec( strGemaltoIDPath + "DL_Front.exe");
		Thread.sleep(6000);

		ele= Utility.webDriver.findElement(By.xpath(".//*[contains(text(),'Scan back')]"));
		ac.moveToElement(ele).click().perform();
		Thread.sleep(2000);
		
		Runtime.getRuntime().exec("C:\\MyWorkPlace\\AutoIt-workspace\\GemaltoID\\DL_Back.exe");
	//	Runtime.getRuntime().exec( strGemaltoIDPath + "DL_Back.exe");
        Thread.sleep(7000);

		ele = Utility.webDriver.findElement(By.xpath(".//*[contains(text(),'Continue')]"));
		ac = new Actions(Utility.webDriver);
		ac.moveToElement(ele).click().perform();
 
       // Utility.clickObject("ehome.scanPhoto.ContinueBtn", "Continue Button in Check your document");

		Thread.sleep(7000);
		ele = Utility.webDriver.findElement(By.xpath(".//*[contains(text(),'Take a selfie')]"));
		ac = new Actions(Utility.webDriver);
		ac.moveToElement(ele).click().perform();
		Thread.sleep(2000);
		Runtime.getRuntime().exec("C:\\MyWorkPlace\\AutoIt-workspace\\GemaltoID\\DL_Selfie.exe");
//		Runtime.getRuntime().exec( strGemaltoIDPath + "DL_Selfie.exe");

		Thread.sleep(6000);
		ele = Utility.webDriver.findElement(By.xpath(".//*[contains(text(),'Continue')]"));
		ac = new Actions(Utility.webDriver);
		ac.moveToElement(ele).click().perform();
       // Utility.clickObject("ehome.scanPhoto.ContinueBtn", "Continue Button in Received photoID");

		Thread.sleep(6000);
		ele = Utility.webDriver.findElement(By.xpath(".//*[contains(text(),'Agree & continue')]"));
		ac = new Actions(Utility.webDriver);
		ac.moveToElement(ele).click().perform();
       // Utility.clickObject("ehome.termsAndConditions.AgreeContinue", "Agree & continue Radio Button");

		Thread.sleep(6000);
		ele = Utility.webDriver.findElement(By.xpath(".//*[contains(text(),'Yes, I consent')]"));
		ac = new Actions(Utility.webDriver);
		ac.moveToElement(ele).click().perform();
       // Utility.clickObject("ehome.CreditCheck.Yes", "Yes, I consent Radio Button");

		Thread.sleep(6000);
		ele = Utility.webDriver.findElement(By.xpath(".//*[contains(text(),'Continue')]"));
		ac = new Actions(Utility.webDriver);
		ac.moveToElement(ele).click().perform();
       // Common.continueButtonClicked();

    }			
			
		@When("^Verify Application Summary and Submit Application$")
	  	public void Verify_Application_Summary_and_Submit_Application() throws Throwable {
			QAFExtendedWebElement strMortgageRequest= new QAFExtendedWebElement("ehome.appSummary.MortgageRequested");
			QAFExtendedWebElement strFixedRate= new QAFExtendedWebElement("ehome.appSummary.FixedRate");
			QAFExtendedWebElement strMortgageTerm= new QAFExtendedWebElement("ehome.appSummary.MortgageTerm");
			QAFExtendedWebElement strPaymentAmount= new QAFExtendedWebElement("ehome.appSummary.PaymentAmount");
			QAFExtendedWebElement strFirstPaymentDate= new QAFExtendedWebElement("ehome.appSummary.FirstPaymentDate");
			QAFExtendedWebElement strAmortizationPeriod= new QAFExtendedWebElement("ehome.appSummary.AmortizationPeriod");
			QAFExtendedWebElement strRateExpiryDate= new QAFExtendedWebElement("ehome.appSummary.RateExpiryDate");
	
//			String strExcelFields= "MortgageRequest,FirstPaymentDate,RateExpiryDate";
//			String strExcelInsertValues= strMortgageRequest.getText() + "," + strFirstPaymentDate.getText() + "," + strRateExpiryDate.getText() ;
//			String strInsertExcelData = "MortgageRequest='2000',FirstPaymentDate ='February 14, 2019',RateExpiryDate = 'February 14, 2020'";

			String strInsertExcelData = "MortgageRequest='" + strMortgageRequest.getText() + "',FirstPaymentDate ='" + strFirstPaymentDate.getText() + "',RateExpiryDate = '"+ strRateExpiryDate.getText() + "'";
			Utility.writeApplicationData(strfullPathToFile, sheetE2E_InputData,strtestCaseID,strInsertExcelData);
			
		       //Utility.clickObject("ehome.applicationSummary.Submitapp", "Submit application Button");

			Thread.sleep(3000);
//			ele = Utility.webDriver.findElement(By.xpath(".//*[contains(text(),'Submit application')]"));
//			ac = new Actions(Utility.webDriver);
//			ac.moveToElement(ele).click().perform();
    }
}
