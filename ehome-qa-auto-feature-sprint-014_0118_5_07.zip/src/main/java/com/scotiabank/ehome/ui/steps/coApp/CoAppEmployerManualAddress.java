package com.scotiabank.ehome.ui.steps.coApp;
import com.qmetry.qaf.automation.step.QAFTestStepProvider;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.quantum.utils.ConfigurationUtils;
import com.scotiabank.ehome.ui.steps.Common;
import com.scotiabank.ehome.ui.steps.Utility;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import java.util.List;
import java.util.concurrent.TimeUnit;
import static com.scotiabank.ehome.ui.steps.Utility.*;

@QAFTestStepProvider

public class CoAppEmployerManualAddress {
	
	public static WebDriverWait wait=Utility.getWait();	
	  String testCaseID = Utility.getScenarioID();
	@Given("^Customer should login and navigates to CoApp Employer address Manual screen$")
	public void customer_should_login_and_navigates_to_CoApp_Employer_address_screen() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
//		 String strtestCaseID = Utility.getScenarioID();
//		  if (strtestCaseID.contains("CoApp"))
//		  {
//			  Common.TraverseToNewHomeSectionBreaker();
//			  Thread.sleep(10000);
//			  Common.TraverseFromNewHomeToRateSectionBreaker(strtestCaseID,"Co-App_InputData");
//			  Common.TraverseRateSectionToEmploymentSectionBreaker();
//			  Common.TraverseFromEmploymentSectionToLandOnCoApplicantPage();
//			  CoAppIntro.startSectionButtonClicked();
//		  }
	   
	}

	
	

	@When("^Verify \"([^\"]*)\" should be on the CoApp Employer manual address screen$")
	public void verify_should_be_on_the_CoApp_Employer_address_screen(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   
	}

	@Then("^Verify \"([^\"]*)\" headertext should be on the CoApp Employer manual address screen$")
	public void verify_headertext_should_be_on_the_CoApp_Employer_address_screen(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   
	}


	@When("^Enter \"([^\"]*)\" street number in the CoApp Employer manual address screen$")
	public void enter_street_number_in_the_CoApp_Employer_address_screen(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   
	}

	@Then("^\"([^\"]*)\" error message should be displayed in the street number$")
	public void error_message_should_be_displayed_in_the_street_number(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   
	}

	@When("^Enter \"([^\"]*)\" street name in the CoApp Employer manual address screen$")
	public void enter_street_name_in_the_CoApp_Employer_address_screen(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   
	}

	@Then("^\"([^\"]*)\" error message should be displayed in the street name$")
	public void error_message_should_be_displayed_in_the_street_name(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   
	}

	@When("^Enter \"([^\"]*)\" unitNumber in the CoApp Employer manual address screen$")
	public void enter_unitNumber_in_the_CoApp_Employer_address_screen(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   
	}

	@Then("^\"([^\"]*)\" error message should be displayed in the Unit number$")
	public void error_message_should_be_displayed_in_the_Unit_number(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   
	}

	@When("^Enter \"([^\"]*)\" city in the CoApp Employer manual address screen$")
	public void enter_city_in_the_CoApp_Employer_address_screen(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   
	}

	@Then("^\"([^\"]*)\" error message should be displayed in the city$")
	public void error_message_should_be_displayed_in_the_city(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   
	}

	@When("^Enter \"([^\"]*)\" postalCode in the CoApp Employer manual address screen$")
	public void enter_postalCode_in_the_CoApp_Employer_address_screen(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   
	}

	@Then("^\"([^\"]*)\" error message should be displayed in the postalCode$")
	public void error_message_should_be_displayed_in_the_postalCode(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   
	}



}
