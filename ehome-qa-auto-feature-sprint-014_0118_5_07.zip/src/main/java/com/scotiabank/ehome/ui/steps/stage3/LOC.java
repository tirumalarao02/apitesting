package com.scotiabank.ehome.ui.steps.stage3;
import com.qmetry.qaf.automation.step.QAFTestStepProvider;
import com.qmetry.qaf.automation.ui.WebDriverTestBase;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebDriver;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.quantum.utils.ConfigurationUtils;

import com.scotiabank.ehome.ui.steps.Utility;
import cucumber.api.PendingException;
import gherkin.lexer.Th;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.FluentWait;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.beans.PropertyChangeListener;

import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.Callable;
import java.util.concurrent.TimeUnit;

import static com.scotiabank.ehome.ui.steps.Utility.*;
@QAFTestStepProvider

public class LOC {

    private QAFExtendedWebDriver webDriver = new WebDriverTestBase().getDriver();
    public Actions action = null;
    WebDriverWait wait = new WebDriverWait(webDriver,50000);

    String testCaseID = Utility.getScenarioID();

    QAFExtendedWebElement TypeofPropertyhouseselect= new QAFExtendedWebElement("ehome.detailsofdownpayment.TypeofPropertyhouseselect");
    QAFExtendedWebElement Detached= new QAFExtendedWebElement("ehome.detailsofdownpayment.Detached");
    QAFExtendedWebElement eleAddress = new QAFExtendedWebElement(By.xpath("//*[@id='app']/div/div[1]/div[1]/section/div[3]/div/div[1]/div/div[2]/div/ul"));
    QAFExtendedWebElement ContinueButton= new QAFExtendedWebElement("ehome.detailsofdownpayment.ContinueButton");
    QAFExtendedWebElement ContinueButtonDetails= new QAFExtendedWebElement("ehome.detailsofdownpayment.ContinueButtonDetails");
    QAFExtendedWebElement sqft= new QAFExtendedWebElement("ehome.detailsofdownpayment.sqft");
    QAFExtendedWebElement purchasePrice= new QAFExtendedWebElement("ehome.detailsofdownpayment.purchasePrice");
    QAFExtendedWebElement downPayment= new QAFExtendedWebElement("ehome.detailsofdownpayment.downPayment");
    QAFExtendedWebElement bankAccountOption= new QAFExtendedWebElement("ehome.detailsofdownpayment.bankAccountOption");

    QAFExtendedWebElement closedate = new QAFExtendedWebElement("ehome.loc.datePicker");
    QAFExtendedWebElement closedateSelection = new QAFExtendedWebElement("ehome.loc.dateSelection.datePicker");
    QAFExtendedWebElement closedateSel = new QAFExtendedWebElement("ehome.loc.dateSelection.date");
    QAFExtendedWebElement ContinueButtonOnClosingDate = new QAFExtendedWebElement("ehome.loc.ContinueOnClosingDate");

    QAFExtendedWebElement bankAccountAmount= new QAFExtendedWebElement("ehome.detailsofdownpayment.bankAccountAmount");
    QAFExtendedWebElement Continue = new QAFExtendedWebElement("ehome.tellus.continue.button");
    QAFExtendedWebElement address = new QAFExtendedWebElement("ehome.whatstheaddress.addressList.list");
    QAFExtendedWebElement addressFirstOption = new QAFExtendedWebElement("ehome.whatstheaddress.addressList.firstOption");
    QAFExtendedWebElement continueWhattypeofproperty= new QAFExtendedWebElement("ehome.enteraddressmanually.continue.button");
    QAFExtendedWebElement eHomeHeader= new QAFExtendedWebElement("ehome.rate.Header.text");

    QAFExtendedWebElement LOCScreenMessage= new QAFExtendedWebElement("ehome.loc.LOCScreenMessage");
    QAFExtendedWebElement LOCScreenHeader= new QAFExtendedWebElement("ehome.loc.LOCScreenHeader");
    QAFExtendedWebElement LOCScreenContent1= new QAFExtendedWebElement("ehome.loc.LOCScreenContent1");
    QAFExtendedWebElement LOCScreenContent2= new QAFExtendedWebElement("ehome.loc.LOCScreenContent2");
    QAFExtendedWebElement LOCScreenContent3= new QAFExtendedWebElement("ehome.loc.LOCScreenContent3");
    QAFExtendedWebElement LOCScreenContent4= new QAFExtendedWebElement("ehome.loc.LOCScreenContent4");
    QAFExtendedWebElement LOCScreenContent5= new QAFExtendedWebElement("ehome.loc.LOCScreenContent5");
    QAFExtendedWebElement LOCScreenContent6= new QAFExtendedWebElement("ehome.loc.LOCScreenContent6");
    QAFExtendedWebElement LOCScreenContent7= new QAFExtendedWebElement("ehome.loc.LOCScreenContent7");
    QAFExtendedWebElement LOCScreenContent8= new QAFExtendedWebElement("ehome.loc.LOCScreenContent8");
    QAFExtendedWebElement YesImInterested = new QAFExtendedWebElement("ehome.loc.YesImInterested");
    QAFExtendedWebElement Nothanks= new QAFExtendedWebElement("ehome.loc.NoThanks");
    QAFExtendedWebElement LOCConfirmationHeader = new QAFExtendedWebElement("ehome.loc.LOCScreenContent9");
    QAFExtendedWebElement MortgageSummaryHeader = new QAFExtendedWebElement("ehome.loc.MortgageSummaryHeader");
    QAFExtendedWebElement Back= new QAFExtendedWebElement("ehome.loc.Back");
    QAFExtendedWebElement StepHeader= new QAFExtendedWebElement("ehome.loc.STEP");

    //1
    @Given("^Customer should login and navigates to LOC Screen$")
    public void customerShouldLoginAndNavigatesToLOCScreen() throws Throwable {

        Utility.launchURL(ConfigurationUtils.getBaseBundle().getPropertyValue("env.baseurl1"));
        Continue.click();

        QAFExtendedWebElement Enteraddress= new QAFExtendedWebElement("ehome.Address.address.text");
        String addressFromExcel = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage03_Rate_InputData",testCaseID , "Address");
        Enteraddress.sendKeys(addressFromExcel);

        //wait.until(ExpectedConditions.elementToBeClickable(address));
        Thread.sleep(8000);
        addressFirstOption.click();
        //TO click on continue button is address screen
        wait.until(ExpectedConditions.visibilityOf(continueWhattypeofproperty));
        continueWhattypeofproperty.click();

        //wait.pollingEvery(30, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.elementToBeClickable(TypeofPropertyhouseselect));
        Thread.sleep(10000);
        TypeofPropertyhouseselect.click();

        Thread.sleep(3000);
        Detached.click();

        wait.pollingEvery(5, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(sqft));
        String sqftFromExcel = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage03_Rate_InputData",testCaseID , "SQFT");
        sqft.sendKeys(sqftFromExcel);

        wait.until(ExpectedConditions.visibilityOf(ContinueButton));
        ContinueButton.click();

        wait.until(ExpectedConditions.visibilityOf(purchasePrice));
        String PurchasePriceFromExcel = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage03_Rate_InputData",testCaseID , "Purchase_Price");
        purchasePrice.sendKeys(PurchasePriceFromExcel);
        ContinueButton.click();

        wait.until(ExpectedConditions.visibilityOf(downPayment));
        String DownPaymentFromExcel = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage03_Rate_InputData",testCaseID , "Down_Payment_Amount");
        downPayment.sendKeys(DownPaymentFromExcel);

        wait.until(ExpectedConditions.visibilityOf(ContinueButton));
        ContinueButton.click();

        Thread.sleep(5000);
        bankAccountOption.click();

        ContinueButton.click();

        String BankAccountAmountFromExcel = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage03_Rate_InputData",testCaseID , "Bank_Account_Amount");
        bankAccountAmount.sendKeys(BankAccountAmountFromExcel);

        ContinueButtonDetails.click();

        Thread.sleep(1000);
        closedate.click();
        Select closedateSelect =  new Select(closedateSelection);
        closedateSelect.selectByIndex(2);
        closedateSel.click();

        ContinueButtonOnClosingDate.click();

        ContinueButtonDetails.click();

        wait.until(ExpectedConditions.visibilityOf(eHomeHeader));
        Continue.click();

        QAFExtendedWebElement selectFixed= new QAFExtendedWebElement("ehome.typeofrate.selectfixed.radio");
        selectFixed.click ();

        QAFExtendedWebElement twoyears= new QAFExtendedWebElement("ehome.termsofrate.2years.radio");
        if(!twoyears.verifyPresent())
            throw new AssertionError("Couldn't find 2 years button");
        Thread.sleep(2000);
        twoyears.click();

        QAFExtendedWebElement twoyear= new QAFExtendedWebElement("ehome.ratepresentation.twoyears.select");
	    if(!twoyear.verifyPresent())
	        throw new AssertionError("Couldn't find 2 years button");
        wait.until(ExpectedConditions.elementToBeClickable(twoyear));
        twoyear.click();

        QAFExtendedWebElement LockandHold= new QAFExtendedWebElement("ehome.ratelock.LockandHold");
        if(!LockandHold.verifyPresent())
           throw new AssertionError("Couldn't find Lock & Hold on the screen");
        Thread.sleep(2000);
        wait.until(ExpectedConditions.elementToBeClickable(LockandHold));
        LockandHold.click();

        QAFExtendedWebElement RateCustomizationContinuebutton= new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[7]/div/button[2]");
		RateCustomizationContinuebutton.click();
		 
		QAFExtendedWebElement Continueinstep= new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[3]/div/button[2]");
		Continueinstep.isPresent();
		Continueinstep.click();
    }
    @Then("^Verify 'LOC Screen Message' and 'LOC Screen Header' and 'Page Content' and Should be displayed in LOC Screen$")
    public void verifyLOCScreenMessageAndLOCScreenHeaderAndPageContentAndShouldBeDisplayedInLOCScreen() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	String LOC_Screen_Message =  Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage03_Rate_ExpectedData",testCaseID , "LOC_Screen_Message");
        Assert.assertEquals(LOCScreenMessage.getText(), LOC_Screen_Message, "Some exciting news! not present");

        String LOC_Screen_Header= Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage03_Rate_ExpectedData",testCaseID , "LOC_Screen_Header");
        Assert.assertEquals(LOCScreenHeader.getText(), LOC_Screen_Header, "With the Scotia Total Equity® Plan, you may be eligible for a $40,000 secured line of credit1 not present");

        String LOC_Screen_Content1 = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage03_Rate_ExpectedData",testCaseID , "LOC_Screen_Content1");
        Assert.assertEquals(LOCScreenContent1.getText(), LOC_Screen_Content1, "This flexible borrowing solution is secured against the equity in your home under the borrowing limit of your STEP. It can be used to renovate your home, to pay off higher interest debt - anything you like! not present");

        String LOC_Screen_Content2 = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage03_Rate_ExpectedData",testCaseID , "LOC_Screen_Content2");
        Assert.assertEquals(LOCScreenContent2.getText(), LOC_Screen_Content2, "How we calculated your secured line of credit not present");

        String LOC_Screen_Content3= Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage03_Rate_ExpectedData",testCaseID , "LOC_Screen_Content3");
        Assert.assertEquals(LOCScreenContent3.getText(), LOC_Screen_Content3, "Not interested? No problem! This will not have any impact on your mortgage application. not present");

        String LOC_Screen_Content4 = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage03_Rate_ExpectedData",testCaseID , "LOC_Screen_Content4");
        Assert.assertEquals(LOCScreenContent4.getText(), LOC_Screen_Content4, "1Your eligibility will be assessed with your mortgage application. The annual interest rate for this secured line of credit offer is Prime -0.4 %. The interest rate will change automatically as Scotiabank’s Prime Rate changes. This offer is subject to change and terms and conditions apply. not present");
      }


    @Then("^It should display content regarding Secured Line of Credit in LOC Screen$")
    public void itShouldDisplayContentRegardingSecuredLineOfCreditInLOCScreen() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        String LOC_Screen_Content5 = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage03_Rate_ExpectedData",testCaseID , "LOC_Screen_Content5");
        Assert.assertEquals(LOCScreenContent5.getText(),LOC_Screen_Content5, "Overall borrowing limit: $80,000 not present");

        String LOC_Screen_Content6 = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage03_Rate_ExpectedData",testCaseID , "LOC_Screen_Content6");
        Assert.assertEquals(LOCScreenContent6.getText(), LOC_Screen_Content6, "Loan requested: $60,000 not present");
        
        String LOC_Screen_Content7 = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage03_Rate_ExpectedData",testCaseID , "LOC_Screen_Content7");
        Assert.assertEquals(LOCScreenContent7.getText(), LOC_Screen_Content7, "Secured line of credit: $20,000 not present");

        String  LOC_Screen_Content8 = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage03_Rate_ExpectedData",testCaseID , "LOC_Screen_Content8");
        Assert.assertEquals(LOCScreenContent8.getText(), LOC_Screen_Content8, "$60,000 was used from your global borrowing limit of $80,000, leaving a secured line of credit of $20,000 not present");
        
    }
    //3
    @When("^Customer click on Yes, I'm interested button in LOC Screen$")
    public void CustomerclickonYesIminterestedbuttoninLOCScreen() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        YesImInterested.isPresent();
        YesImInterested.click();
      }
    
    @Then("^It should navigate to LOCConfirmation screen screen$")
    public void ItshouldnavigatetoLOCConfirmationscreen() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	QAFExtendedWebElement LOCConfirmationHeader= new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[1]/div[3]");
       Assert.assertEquals(LOCConfirmationHeader.getText(), "We’ll assess your eligibility for a $40,000 secured line of credit");
     }
    //4
    @When("^Customer click on No thanks button in LOC Screen$")
    public void CustomerclickonNothanksbuttoninLOCScreen() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        Nothanks.isPresent();
        Nothanks.click();
      }
    
    @Then("^It should navigate to Mortgage Summary screen or rate-review screen$")
    public void ItshouldnavigatetoMortgageSummaryscreenorratereviewscreen() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    String Mortgage_Summary_Header = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage03_Rate_ExpectedData",testCaseID , "Mortgage_Summary_Header");
    Assert.assertEquals(MortgageSummaryHeader.getText(),Mortgage_Summary_Header, "Let's review your eHOME request");
     }
    //5
    @When("^Customer click on Back button in LOC Screen$")
    public void CustomerclickonBackbuttoninLOCScreen() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
       Back.isPresent();
       Back.click();
      }
    
    @Then("^It should navigate to Site screen or rate-benefits screen$")
    public void ItshouldnavigatetoSitescreenorratebenefitsscreen() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    String STEP_Header = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage03_Rate_ExpectedData",testCaseID , "STEP_Header");
    Assert.assertEquals(StepHeader.getText(),STEP_Header,"With eHOME, your mortgage will be set up as a Scotia Total Equity ® Plan (STEP)");
     }

    @Then("^User should be navigate to LOCConfirmation screen$")
    public void userShouldBeNavigateToLOCConfirmationScreen() throws Throwable {
        String LOC_Confirmation_Header = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage03_Rate_ExpectedData",testCaseID , "LOC_Confirmation_Header");
        Assert.assertEquals(LOCConfirmationHeader.getText(), LOC_Confirmation_Header,"We’ll assess your eligibility for a $40,000 secured line of credit");

    }
}
