package com.scotiabank.ehome.ui.steps;

import com.qmetry.qaf.automation.step.QAFTestStepProvider;
import com.qmetry.qaf.automation.ui.WebDriverTestBase;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebDriver;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.quantum.utils.ConfigurationUtils;
import com.scotiabank.ehome.ui.steps.valueObjects.TypeOfRateVO;

import cucumber.api.PendingException;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.FluentWait;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.beans.PropertyChangeListener;

@QAFTestStepProvider

public class RateType {
	 private QAFExtendedWebDriver webDriver = null;
	    public Actions action = null;
	    public WebDriverWait wait=null;
	    //public FluentWait<WebDriver> fwait=null;

	    //Scenario: Rate_Type_001

	    @Given("^Customer should login and navigates to Stage 3 Rate Type$")
	    public void CustomershouldloginandnavigatestoStage3RateType() throws Throwable {
	        // Write code here that turns the phrase above into concrete actions
	        webDriver = new WebDriverTestBase().getDriver();
	        webDriver.get(ConfigurationUtils.getBaseBundle ().getPropertyValue ( "env.baseurl" ) );
	        webDriver.manage().window().maximize();
	        QAFExtendedWebElement buttonContinue= new QAFExtendedWebElement("ehome.rate.continue.button");
			buttonContinue.click();
			Actions action = new Actions(webDriver);
	        WebDriverWait wait= new WebDriverWait ( webDriver,10 );
	        QAFExtendedWebElement whatTypeOfRate= new QAFExtendedWebElement("ehome.whattypeofrate.header");
	         if(!whatTypeOfRate.verifyText( "What type of rate are you looking for?"  ))
	            throw new AssertionError("Not able to launch what type of rate page");
	    } 
	    //Scenario: Rate_Type_002
	    @When("^Verify \"([^\"]*)\" in Rate Type Screen$")
	    public void VerifyLetsgetstartedinRateTypeScreen(String expectedText) throws Throwable {
	        // Write code here that turns the phrase above into concrete actions
	        QAFExtendedWebElement letsGetStarted= new QAFExtendedWebElement("ehome.whattypeofrate.letsgetstarted.text");
	        Assert.assertEquals(letsGetStarted.getText(), expectedText,"Couldn't find the Lets get started");
	    }

	    @Then("^\"([^\"]*)\" text should be displayed in Rate Type Screen$")
	    public void WhattypeofrateareyoulookingfortextshouldbedisplayedinRateTypeScreen(String expectedText) throws Throwable {
	        // Write code here that turns the phrase above into concrete actions
	    	 QAFExtendedWebElement whatTypeOfRateText= new QAFExtendedWebElement("ehome.whattypeofrate.header");
	         Assert.assertEquals(whatTypeOfRateText.getText(), expectedText,"What type of Rate you are looking is not displayed");
	    }
	  //Scenario: Rate_Type_003
	    @When("^Verify \"([^\"]*)\" and \"([^\"]*)\" text in a separate Box in Rate Type Screen$")
	    public void VerifyFixedandInterestratewontchangeforthetermofyourmortgagetextinaseparateBoxinRateTypeScreen(String expectedText1, String expectedText2) throws Throwable {
	        // Write code here that turns the phrase above into concrete actions
	    	QAFExtendedWebElement fixedText= new QAFExtendedWebElement("ehome.whattypeofrate.fixed.text");
	    	Assert.assertEquals(fixedText.getText(), expectedText1,"Couldn't find the Fixed text");
	    	QAFExtendedWebElement contentInFixedBox= new QAFExtendedWebElement("ehome.whattypeofrate.contentinfixedbox.text");
	    	Assert.assertEquals(contentInFixedBox.getText(), expectedText2,"Interest rate won’t change for the term of your mortgage is not displayed");
	    }

	    @Then("^Check the select fixed radio button in Rate type screen$")
	    public void ChecktheselectfixedradiobuttoninRatetypescreen() throws Throwable {
	        // Write code here that turns the phrase above into concrete actions
			//To check the select text
			QAFExtendedWebElement SelectFixed= new QAFExtendedWebElement("ehome.whattypeofrate.selectfixed.radio");
			SelectFixed.assertText("Select");
			//To check the select deselected by default
			String result=SelectFixed.getCssValue("color");
			Assert.assertEquals("rgba(117, 117, 117, 1)",result);
			//To check On hover on the select button
			webDriver = new WebDriverTestBase().getDriver();
			Actions action = new Actions(webDriver);
			action = new Actions(webDriver);
			action.moveToElement (SelectFixed).build ().perform ();
			//TO check Select button should be highlighted
			action.moveToElement (SelectFixed).build ().perform ();
			QAFExtendedWebElement selectFixedUpt= new QAFExtendedWebElement("ehome.whattypeofrate.selectfixed.background");
			String color=selectFixedUpt.getCssValue("background-color");
			String hex = Utility.convertRGBToHex(color);
			Assert.assertEquals("#8230df",hex);
			if(!hex.contentEquals("#8230df"))
				throw new AssertionError("Select on hover is not highlighted with #8230df color");

	    }
		@When("^click on radio button Select for the rate type Fixed component in What type of Rate you are looking for Screen Select label should be disappeared and the radio button Select should be highlighted and checked$")
		public void click_on_radio_button_Select_for_the_rate_type_Fixed_component_in_What_type_of_Rate_you_are_looking_for_Screen() throws Throwable {
			// Write code here that turns the phrase above into concrete actions
			QAFExtendedWebElement selectFixed= new QAFExtendedWebElement("ehome.whattypeofrate.selectfixed.radio");
			selectFixed.click ();
			TypeOfRateVO.getInstance().setTypeOfRate(TypeOfRateVO.TYPE_OF_RATE_FIXED_RATE);
			Thread.sleep(3000);
			QAFExtendedWebElement backButtonwhatmortgagetermareyoulookingfor = new QAFExtendedWebElement("ehome.whatmortgagetermareyoulookingfor.back.button");
			Assert.assertEquals(backButtonwhatmortgagetermareyoulookingfor.getText(), "Back", "Back Button text does not matched");
			backButtonwhatmortgagetermareyoulookingfor.click ();
			Thread.sleep(3000);
			QAFExtendedWebElement selectchecked= new QAFExtendedWebElement("ehome.whattypeofrateselectchecked.input");
			String checked=selectchecked.getAttribute("checked");
			if(checked==null || !checked.contentEquals("true"))
				throw new AssertionError("Couldn't find the checked");
			QAFExtendedWebElement selectFixedUpt= new QAFExtendedWebElement("ehome.whattypeofrate.selectfixed.background");
			String color=selectFixedUpt.getCssValue("background-color");
			String hex = Utility.convertRGBToHex(color);
			Assert.assertEquals("#8230df",hex);
			if(!hex.contentEquals("#8230df"))
				throw new AssertionError("Select on hover is not highlighted with #8230df color");
		}

		@Then("^It should navigate to What mortgage term are you looking for screen$")
		public void the_Select_label_should_be_disappeared_and_the_radio_button_Select_should_be_highlighted_and_checked_and_navigate_to_What_mortgage_term_are_you_looking_for_screen() throws Throwable {
			// Write code here that turns the phrase above into concrete actions
			QAFExtendedWebElement whatmortgagetermareyoulookingfor = new QAFExtendedWebElement("ehome.whatmortgagetermareyoulookingfor.header");
			QAFExtendedWebElement continuewhaytypeofrate = new QAFExtendedWebElement("ehome.whattypeofrate.continue.button");
			Assert.assertEquals(continuewhaytypeofrate.getText(), "Continue", "Continue Button text does not matched");
			Assert.assertEquals(Utility.convertRGBToHex(continuewhaytypeofrate.getCssValue("color")), "#ed722", "Continue button not in Red color");
			continuewhaytypeofrate.click();
			whatmortgagetermareyoulookingfor.assertText ( "What mortgage term are you looking for?" );
			if(!whatmortgagetermareyoulookingfor.verifyText( "What mortgage term are you looking for?"  ))
				throw new AssertionError("Not able to launch What mortgage term are you looking for? page");
			QAFExtendedWebElement backButtonwhatmoremorgageterm = new QAFExtendedWebElement("ehome.whatmortgagetermareyoulookingfor.back.button");
			Assert.assertEquals(backButtonwhatmoremorgageterm.getText(), "Back", "Back Button text does not matched");
			backButtonwhatmoremorgageterm.click();

		}
	//Scenario: Rate_Type_004
	@When("^Verify \"([^\"]*)\" text and \"([^\"]*)\" text in a separate Box in Rate Type Screen$")
	public void VerifyVariabletextandInterestratemaychangeoverthetermofyourmortgagetextinaseparateBoxinRateTypeScreen(String expectedText1, String expectedText2) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
        QAFExtendedWebElement variableText = new QAFExtendedWebElement("ehome.whattypeofrate.variable.text");
		Assert.assertEquals(variableText.getText(), expectedText1,"Couldn't find the variable text");
        QAFExtendedWebElement contentinvariablebox = new QAFExtendedWebElement("ehome.whattypeofrate.contentinvariablebox.text");
		Assert.assertEquals(contentinvariablebox.getText(), expectedText2,"Interest rate may change over the term of your mortgage. is not displayed");
	}

	@Then("^Check the select variable radio button in Rate type screen$")
	public void ChecktheselectvariableradiobuttoninRatetypescreen() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		//To check the select text
		QAFExtendedWebElement selectVariable= new QAFExtendedWebElement("ehome.whattypeofrate.selectvariable.radio");
		selectVariable.assertText("Select");
		//To check the select deselected by default
		String result=selectVariable.getCssValue("color");
		Assert.assertEquals("rgba(117, 117, 117, 1)",result);
		if(!selectVariable.getCssValue("color").contentEquals( "rgba(117, 117, 117, 1)"  ))
			throw new AssertionError("Variable select is not deselected");
		//To check On hover on the select button
		QAFExtendedWebElement selectVarible= new QAFExtendedWebElement("ehome.whattypeofrate.selectvariable.background");
		webDriver = new WebDriverTestBase().getDriver();
		Actions action = new Actions(webDriver);
		action = new Actions(webDriver);
		action.moveToElement (selectVarible).build ().perform ();
		String color=selectVarible.getCssValue("background-color");
		String hex = Utility.convertRGBToHex(color);
		Assert.assertEquals("#8230df",hex);
		if(!hex.contentEquals("#8230df"))
			throw new AssertionError("Select on hover is not highlighted with #8230df color");


	}
	@When("^click on radio button Select for the rate type variable component in What type of Rate you are looking for Screen Select label should be disappeared and the radio button Select should be highlighted and checked$")
	public void click_on_radio_button_Select_for_the_rate_type_Variable_component_in_What_type_of_Rate_you_are_looking_for_Screen() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		QAFExtendedWebElement selectVariable= new QAFExtendedWebElement("ehome.whattypeofrate.selectvariable.radio");
		selectVariable.click ();
		TypeOfRateVO.getInstance().setTypeOfRate(TypeOfRateVO.TYPE_OF_RATE_VARIABLE_RATE);
		Thread.sleep(3000);
		//QAFExtendedWebElement backButtonYouSelectVariablePage = new QAFExtendedWebElement("//*[@id=\"app\"]/div/div/div[2]/button");
		//QAFExtendedWebElement backButtonYouSelectVariablePage = new QAFExtendedWebElement("css=\"button.nav-button nav-button--prev\"");
		//QAFExtendedWebElement backButtonYouSelectVariablePage = new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[2]/div[11]/button");
		QAFExtendedWebElement backButtonYouSelectVariablePage = new QAFExtendedWebElement("ehome.onlineExclusiveMorgage.back.button");
		Assert.assertEquals(backButtonYouSelectVariablePage.getText(), "Back", "Back Button text does not matched");
		backButtonYouSelectVariablePage.click ();
		Thread.sleep(3000);
		QAFExtendedWebElement selectchecked= new QAFExtendedWebElement("ehome.whattypeofrateselectvariblechecked.input");
		String checked=selectchecked.getAttribute("checked");
		if(checked==null || !checked.contentEquals("true"))
			throw new AssertionError("Couldn't find the checked");
		QAFExtendedWebElement selectFixedUpt= new QAFExtendedWebElement("ehome.whattypeofrate.selectvariable.background");
		String color=selectFixedUpt.getCssValue("background-color");
		String hex = Utility.convertRGBToHex(color);
		Assert.assertEquals("#8230df",hex);
		System.out.println("HEX"+hex);
		if(!hex.contentEquals("#8230df"))
			throw new AssertionError("Select on hover is not highlighted with #8230df color");

	}
	@Then("^It should navigate to online exclusive mortgage offers screen$")
	public void it_should_navigate_to_online_exclusive_mortgage_offers_screen() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		QAFExtendedWebElement continuewhaytypeofrate = new QAFExtendedWebElement("ehome.whattypeofrate.continue.button");
		Assert.assertEquals(continuewhaytypeofrate.getText(), "Continue", "Contnue Button text does not matched");
		Assert.assertEquals(Utility.convertRGBToHex(continuewhaytypeofrate.getCssValue("color")), "#ed722", "Continue button not in Red color");
		continuewhaytypeofrate.click();
		QAFExtendedWebElement youselectedvariable = new QAFExtendedWebElement("ehome.youselectedvariable.header");
		youselectedvariable.assertText ( "Choose from these online exclusive mortgage offers we have just for you!" );
		if(!youselectedvariable.verifyText( "Choose from these online exclusive mortgage offers we have just for you!"  ))
			throw new AssertionError("Not able to launch scren 'Choose from these online exclusive mortgage offers we have just for you!'");
		QAFExtendedWebElement backButtononlineexclusivemortgage = new QAFExtendedWebElement("ehome.onlineExclusiveMorgage.back.button");
		Assert.assertEquals(backButtononlineexclusivemortgage.getText(), "Back", "Back Button text does not matched");
		backButtononlineexclusivemortgage.click();
        /*
        youselectedvariable.assertText ( "You selected variable");
        if(!youselectedvariable.verifyText( "You selected variable"  ))
            throw new AssertionError("Page didn't navigate to right URL");*/


	}

}
