package com.scotiabank.ehome.ui.steps.stage5;
import com.qmetry.qaf.automation.step.QAFTestStepProvider;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebDriver;
import com.quantum.java.pages.ExtentReportHelper;
import com.quantum.utils.ConfigurationUtils;
import com.scotiabank.ehome.ui.steps.Common;
import com.scotiabank.ehome.ui.steps.CommonAppMethodsAssetLiabilities;
import com.scotiabank.ehome.ui.steps.CommonAppMethodsEmployment;
import com.scotiabank.ehome.ui.steps.CommonApplicationMethods;
import com.scotiabank.ehome.ui.steps.Utility;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.support.ui.WebDriverWait;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;

import java.util.Map;
import java.util.concurrent.TimeUnit;
import static com.scotiabank.ehome.ui.steps.Utility.*;

@QAFTestStepProvider

public class LiabilityDetailsforRetired {
	public static WebDriverWait wait=Utility.getWait();
	  static String curDir = System.getProperty("user.dir");
	  static String strfullPathToFile = curDir + "\\src\\main\\resources\\data\\eHomeTestData.xlsx"; // File Path
		
	  static String sheetStage05_InputData ="Stage05_AssetLiabilty_InputData";
	  static String sheetStage05_ExpectedData ="Stage05_AsetLiblty_ExpectedData";
		  
	  //String strtestCaseID = "LiabilitySourcesDetails-Retired-TC-005";
	  
	  String strtestCaseID = Utility.getScenarioID();
		  
	  @Then("^Verify 'Liability Details' Screen and presence of all objects on 'Liability Details' Screen$")
		public void Verify_Liability_Details_Screen_and_presence_of_all_objects_on_Liability_Details_Screen() throws Throwable {
		  
		  Map<String, String> Stage05_ExpectedData =  Utility.readTestData(strfullPathToFile, sheetStage05_ExpectedData,strtestCaseID);
		  
		  String strSrcOfLiabDetails_Header_ExpectedTitle	= Stage05_ExpectedData.get("Liability_Sources_Details_Title");
		  Common.continueButtonClicked();
		  
		  Utility.verifyIsObjectPresent("ehome.liabilitySrcsDetails.AlimonyTxt", "Alimony Details Text Box");
		  Utility.verifyIsObjectPresent("ehome.liabilitySrcsDetails.ChildSupportTxt", "ChildSupport Details Text Box");
		  Utility.verifyIsObjectPresent("ehome.liabilitySrcsDetails.Privatedebt.BalOwingTxt", "Bal Owing Txt");
		  Utility.verifyIsObjectPresent("ehome.liabilitySrcsDetails.Privatedebt.MonthlyPymtTxt", "Private debt Monthly Pymt Txt");
		  Utility.verifyIsObjectPresent("ehome.liabilitySrcsDetails.Privatedebt.DescTxt", "Privatedebt Desc Txt");
		  Utility.verifyIsObjectPresent("ehome.liabilitySrcsDetails.Continue", "Continue");
		  Utility.verifyIsObjectPresent("ehome.liabilitySrcsDetails.Back", "Back");
			  
		  Utility.verifyIsTextPresent("ehome.liabilitySrcDetails.Title", "Heading Centre Text", strSrcOfLiabDetails_Header_ExpectedTitle);
		 
		  
	  }
	
		@Then("^Verify 'Liability' Screen when Click on 'Back' button on 'Liability Details' Screen$")
		public void Verify_Liability_Screen_when_Click_on_Back_button_on_Liability_Details_Screen() throws Throwable {
			
			  Map<String, String> Stage05_ExpectedData =  Utility.readTestData(strfullPathToFile, sheetStage05_ExpectedData,strtestCaseID);
			  Common.continueButtonClicked();
			  Thread.sleep(500);
			  String Liability_Header_ExpectedTitle	= Stage05_ExpectedData.get("Liability_Sources_Title");
			  Utility.clickObject("ehome.liabilitySrcsDetails.Back", "Back Button in Liability detail");
			  Thread.sleep(500);
			  Utility.verifyIsTextPresent("ehome.liabilitySrcs.Title", "Heading Centre Text", Liability_Header_ExpectedTitle);
			}
		
		
		@Then("^Enter 'Liability Details' and Select 'Continue' on 'Liability Details' Screen$")
		public void Enter_LiabilityDetails_and_Select_Continue_on_Liability_Details_Screen() throws Throwable {
			
			Map<String, String> Stage05_InputData =  Utility.readTestData(strfullPathToFile, sheetStage05_InputData,strtestCaseID);
			String strChildSupport_Input = Stage05_InputData.get("LiabilitySources_ChildSupport");
			String strAlimony_Input = Stage05_InputData.get("LiabilitySources_Alimony");
			String strPrivate_debt_Input = Stage05_InputData.get("LiabilitySources_PrivateDebt");
						
			String strChildSupport_Amt = Stage05_InputData.get("LiabilitySources_ChildSupport_Monthly_Pymt");
			String strAlimony_Amt = Stage05_InputData.get("LiabilitySources_Alimony_Monthly_Pymt");
			String strPrivate_debt_BalOwingAmt = Stage05_InputData.get("LiabilitySources_BalanceOwing__Monthly_Pymt");
			String strPrivate_debt_MonthlyPymtAmt = Stage05_InputData.get("LiabilitySources_PrivateDebt_Monthly_Pymt");
			String strPrivate_debt_Desc = Stage05_InputData.get("LiabilitySources_PrivateDebt_Descr");
		
			Common.continueButtonClicked();
			
			if (strAlimony_Input != "" && strAlimony_Amt != "")
			{
				CommonAppMethodsAssetLiabilities.EnterLiabilityCalculateAmount(strAlimony_Input, strAlimony_Amt);
			}
			
			if (strChildSupport_Input != "" && strChildSupport_Amt != "")
			{
				CommonAppMethodsAssetLiabilities.EnterLiabilityCalculateAmount(strChildSupport_Input, strChildSupport_Amt); 
			}
				if (strPrivate_debt_Input != "" && strPrivate_debt_MonthlyPymtAmt != "")
			{
				CommonAppMethodsAssetLiabilities.EnterLiabilityCalculateAmount(strPrivate_debt_Input, strPrivate_debt_MonthlyPymtAmt);
			}
					
			Utility.clickObject("ehome.liabilitySrcsDetails.Continue", "Continue in Liability Details");
		}
		
		
		@Then("^Verify 'Document Upload' Screen when enter 'liability details' on 'Liability Detail' Screen$")
		public void Verify_DocumentUpload_with_Details_when_Click_on_Continue_button_on_Liability_Details_Screen() throws Throwable {
			  Map<String, String> Stage05_ExpectedData =  Utility.readTestData(strfullPathToFile, sheetStage05_ExpectedData,strtestCaseID);
			  String ehomedocUploadSectionBrkrTitle	= Stage05_ExpectedData.get("Document_Upload_Section_Breaker_Title");
			  Utility.verifyIsTextPresent("ehome.docUploadSectionBrkr.Title", "Document Upload Title", ehomedocUploadSectionBrkrTitle);
			}
		
		@Then("^Verify 'Err Message' when enter without 'Liability Details' on 'Liability Details' Screen$")
		public void Verify_ErrMessage_without_Details_when_Click_on_Continue_button_on_Liability_Details_Screen() throws Throwable {
			  Map<String, String> Stage05_ExpectedData =  Utility.readTestData(strfullPathToFile, sheetStage05_ExpectedData,strtestCaseID);
			  String Liability_details_MandError_Msg	= Stage05_ExpectedData.get("Liability_Sources_Details_MandryErrMsg");
			  Thread.sleep(250);
			  Utility.verifyIsTextPresent("ehome.liabilitySrcsDetails.MandErrMsg","Mandatory Error Mssage", Liability_details_MandError_Msg);
			}
		
		
		@Then("^Verify 'Remove entire source' links on 'Liability Details' Screen$")
		public void Verify_Remove_entire_source_links_on_Liability_Details_Screen() throws Throwable {
			Map<String, String> Stage05_InputData =  Utility.readTestData(strfullPathToFile, sheetStage05_InputData,strtestCaseID);
			String strChildSupport_Input = Stage05_InputData.get("LiabilitySources_ChildSupport");
			String strAlimony_Input = Stage05_InputData.get("LiabilitySources_Alimony");
			String strPrivate_debt_Input = Stage05_InputData.get("LiabilitySources_PrivateDebt");
						
			String strChildSupport_Amt = Stage05_InputData.get("LiabilitySources_ChildSupport_Monthly_Pymt");
			String strAlimony_Amt = Stage05_InputData.get("LiabilitySources_Alimony_Monthly_Pymt");
			String strPrivate_debt_BalOwingAmt = Stage05_InputData.get("LiabilitySources_BalanceOwing__Monthly_Pymt");
			String strPrivate_debt_MonthlyPymtAmt = Stage05_InputData.get("LiabilitySources_PrivateDebt_Monthly_Pymt");
			String strPrivate_debt_Desc = Stage05_InputData.get("LiabilitySources_PrivateDebt_Descr");
		
			Common.continueButtonClicked();
			
			if (strAlimony_Amt == "")
			{
				CommonAppMethodsAssetLiabilities.EnterLiabilityCalculateAmount(strAlimony_Input, strAlimony_Amt);
				Utility.verifyIsObjectPresent("ehome.liabilitySrcsDetails.AlimonyRemove", "Alimony Details Remove");
			}
			
			if (strChildSupport_Amt == "")
			{
				CommonAppMethodsAssetLiabilities.EnterLiabilityCalculateAmount(strChildSupport_Input, strChildSupport_Amt); 
				Utility.verifyIsObjectPresent("ehome.liabilitySrcsDetails.ChildSupportRemove", "ChildSupport Details Remove");
			}
			
			if (strPrivate_debt_MonthlyPymtAmt == "")
			{
				CommonAppMethodsAssetLiabilities.EnterLiabilityCalculateAmount(strPrivate_debt_Input, strPrivate_debt_MonthlyPymtAmt);
				Utility.verifyIsObjectPresent("ehome.liabilitySrcsDetails.PrivatedebtRemove", "Private debt Details Remove");
			}
			
		}
		
		
		@Then("^Verify 'Remove entire source' functionality on 'Liability Details' Screen$")
		public void Verify_Remove_entire_source_functionality_on_Liability_Details_Screen() throws Throwable {
			Map<String, String> Stage05_InputData =  Utility.readTestData(strfullPathToFile, sheetStage05_InputData,strtestCaseID);
				String strAlimony_Input = Stage05_InputData.get("LiabilitySources_Alimony");
						
				String strAlimony_Amt = Stage05_InputData.get("LiabilitySources_Alimony_Monthly_Pymt");
				Common.continueButtonClicked();
				
			if (strAlimony_Amt == "")
			{
				CommonAppMethodsAssetLiabilities.EnterLiabilityCalculateAmount(strAlimony_Input, strAlimony_Amt);
				Utility.clickObject("ehome.liabilitySrcsDetails.AlimonyRemove", "Alimony Details Remove");
				}
		}
	}
