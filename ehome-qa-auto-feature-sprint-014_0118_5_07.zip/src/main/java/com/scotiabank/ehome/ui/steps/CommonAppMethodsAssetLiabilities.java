package com.scotiabank.ehome.ui.steps;
import org.apache.poi.ss.formula.functions.Column;
import org.apache.poi.ss.usermodel.*;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.qmetry.qaf.automation.step.QAFTestStepProvider;
import com.qmetry.qaf.automation.ui.WebDriverTestBase;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebDriver;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.quantum.utils.ConfigurationUtils;

import cucumber.api.java.en.Given;

import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;
@QAFTestStepProvider

public class CommonAppMethodsAssetLiabilities {

	/* *************************************************************************************************************************************************
	 Author: 	  RameshChalumuri
	 Stage:       Stage 04
	 Method Name: employmentSelectAssetsSources
	 Purpose: 	  This method is for selecting Asset Sources
	 Created on:  16-October-2018
	 Updated By: 
	 Updated on:
	 *************************************************************************************************************************************************** */
public static void SelectAssetsSources(String EmpAssetSources) throws InterruptedException{
	
	   switch(EmpAssetSources) {
	   	case "Automobile" :
	   		Utility.clickObject("ehome.assetSrcs.Automobile", "Automobile Button");
	   		break;
	   	case "Cash" :
	   		Utility.clickObject("ehome.assetSrcs.Cash", "Button");
	   		break;
	   	case "GIC/Term deposit" :
	   		Utility.clickObject("ehome.assetSrcs.GICTermDeposit", "Button");
	   		break;
	   	case "Primary residence" :
	   		Utility.clickObject("ehome.assetSrcs.PrimaryResidence", "Button");
	   		break;
	   	case "Rental property" :
	   		Utility.clickObject("ehome.assetSrcs.RentalProperty", "Button");
	   		break;
	   	case "RRSP" :
	   		Utility.clickObject("ehome.assetSrcs.RRSP", "Button");
	   		break;
	   	case "Secondary property" :
	   		Utility.clickObject("ehome.assetSrcs.SecondaryProperty", "Button");
	   		break;
	   	case "Stock/Bond" :
	   		Utility.clickObject("ehome.assetSrcs.StockBond", "Button");
	   		break;
	   	case "Other assets" :
	   		Utility.clickObject("ehome.assetSrcs.OtherAssets", "Button");
	   		break;
	   	case "No assets" :
	   		Utility.clickObject("ehome.assetSrcs.NoAssets.Link", "Button");
	   		break;
	   	default :
        System.out.println("Invalid Asset Sources");
 	   }
}



/* *************************************************************************************************************************************************
Author: 	  RameshChalumuri
Stage:       Stage 04
Method Name: employmentEnterAssetCalculateAmount
Purpose: 	  This method is for entering Asset Calculate Amount
Created on:  17-October-2018  
Updated By: 
Updated on:
*************************************************************************************************************************************************** */
public static void EnterAssetCalculateAmount(String AssetSrcs,String AssetSrcsCalcAmount) throws InterruptedException{

	switch(AssetSrcs) {
 	case "Automobile" :
 		Utility.sendKeys("//*[@id=\"automobile-automobile-0\"]", AssetSrcsCalcAmount);
 		Utility.sendKeys("//*[@id=\"automobile-description-0\"]", "Entered" + " " + AssetSrcsCalcAmount + " for " + AssetSrcs);
 		//Utility.clickObject("//input[@placeholder='Automobile']//parent::span//parent::div//parent::div//parent::div//parent::div//*[contains(text(),'Yes')]", "Button");
 		Utility.clickObject("//input[@id='automobile-automobile-0']//parent::span//parent::div//parent::div//parent::div//parent::div//*[contains(text(),'No')]", "Button");
	 
 		break;
 	case "Cash" :
 		Utility.clickObject("//*[@id=\"app\"]/div/div[1]/div[3]/div/div[1]/div[2]/button", "Button");
 		//Thread.sleep(2000);
 		Utility.sendKeys("//*[@id=\"cash-cash-0\"]", AssetSrcsCalcAmount);
 		Utility.sendKeys("//*[@id=\"cash-description-0\"]", "Entered" + " " + AssetSrcsCalcAmount + " for " + AssetSrcs);
 		//Utility.clickObject("//input[@placeholder='Cash']//parent::span//parent::div//parent::div//parent::div//parent::div//*[contains(text(),'Yes')]", "Button");
 		Utility.clickObject("//input[@id='cash-cash-0']//parent::span//parent::div//parent::div//parent::div//parent::div//*[contains(text(),'No')]", "Button");
 		break;
 	case "GIC/Term deposit" :
 		Utility.clickObject("//*[@id=\"app\"]/div/div[1]/div[3]/div/div[1]/div[3]/button", "Button");
 		//Thread.sleep(2000);
 		Utility.sendKeys("//*[@id=\"gic-term-deposit-gic-term-deposit-0\"]", AssetSrcsCalcAmount);
 		Utility.sendKeys("//*[@id=\"gic-term-deposit-description-0\"]", "Entered" + " " + AssetSrcsCalcAmount + " for " + AssetSrcs);
 		//Utility.clickObject("//input[@placeholder='GIC / Term deposit']//parent::span//parent::div//parent::div//parent::div//parent::div//*[contains(text(),'Yes')]", "Button");
 		Utility.clickObject("//input[@id='gic-term-deposit-gic-term-deposit-0']//parent::span//parent::div//parent::div//parent::div//parent::div//*[contains(text(),'No')]", "Button");
 		break;
 	case "Primary residence" :
 		Utility.clickObject("//*[@id=\"app\"]/div/div[1]/div[3]/div/div[1]/div[4]/button", "Button");
 		//Thread.sleep(2000);
 		Utility.sendKeys("//*[@id=\"primary-residence-primary-residence-0\"]", AssetSrcsCalcAmount);
 		Utility.sendKeys("//*[@id=\"primary-residence-description-0\"]", "Entered" + " " + AssetSrcsCalcAmount + " for " + AssetSrcs);
 		//Utility.clickObject("//input[@placeholder='Primary residence']//parent::span//parent::div//parent::div//parent::div//parent::div//*[contains(text(),'Yes')]", "Button");
 		Utility.clickObject("//input[@id='primary-residence-description-0']//parent::span//parent::div//parent::div//parent::div//parent::div//*[contains(text(),'No')]", "Button");
 		break;
 	case "Rental property" :
 		Utility.clickObject("//*[@id=\"app\"]/div/div[1]/div[3]/div/div[1]/div[5]/button", "Button");
 		//Thread.sleep(2000);
 		Utility.sendKeys("//*[@id=\"rental-property-rental-property-0\"]", AssetSrcsCalcAmount);
 		Utility.sendKeys("//*[@id=\"rental-property-description-0\"]", "Entered" + " " + AssetSrcsCalcAmount + " for " + AssetSrcs);
 		//Utility.clickObject("//input[@placeholder='Rental property']//parent::span//parent::div//parent::div//parent::div//parent::div//*[contains(text(),'Yes')]", "Button");
 		Utility.clickObject("//input[@id='rental-property-rental-property-0']//parent::span//parent::div//parent::div//parent::div//parent::div//*[contains(text(),'No')]", "Button");
 		break;
 	case "RRSP" :
 		Utility.clickObject("//*[@id=\"app\"]/div/div[1]/div[3]/div/div[1]/div[6]/button", "Button");
 		//Thread.sleep(2000);
 		Utility.sendKeys("//*[@id=\"rrsp-rrsp-0\"]", AssetSrcsCalcAmount);
 		Utility.sendKeys("//*[@id=\"rrsp-description-0\"]", "Entered" + " " + AssetSrcsCalcAmount + " for " + AssetSrcs);
 		break;
 	case "Secondary property" :
 		Utility.clickObject("//*[@id=\"app\"]/div/div[1]/div[3]/div/div[1]/div[7]/button", "Button");
 		//Thread.sleep(2000);
 		Utility.sendKeys("//*[@id=\"secondary-property-secondary-property-0\"]", AssetSrcsCalcAmount);
 		Utility.sendKeys("//*[@id=\"secondary-property-description-0\"]", "Entered" + " " + AssetSrcsCalcAmount + " for " + AssetSrcs);
 		//Utility.clickObject("//input[@placeholder='Secondary property']//parent::span//parent::div//parent::div//parent::div//parent::div//*[contains(text(),'Yes')]", "Button");
 		Utility.clickObject("//input[@id='secondary-property-secondary-property-0']//parent::span//parent::div//parent::div//parent::div//parent::div//*[contains(text(),'No')]", "Button");
 		break;
 	case "Stock/Bond" :
 		Utility.clickObject("//*[@id=\"app\"]/div/div[1]/div[3]/div/div[1]/div[8]/button", "Button");
 		//Thread.sleep(2000);
 		Utility.sendKeys("//*[@id=\"stock-bond-stock-bond-0\"]", AssetSrcsCalcAmount);
 		Utility.sendKeys("//*[@id=\"stock-bond-description-0\"]", "Entered" + " " + AssetSrcsCalcAmount + " for " + AssetSrcs);
 		//Utility.clickObject("//input[@placeholder='Stock / Bond']//parent::span//parent::div//parent::div//parent::div//parent::div//*[contains(text(),'Yes')]", "Button");
 		Utility.clickObject("//input[@id='stock-bond-stock-bond-0']//parent::span//parent::div//parent::div//parent::div//parent::div//*[contains(text(),'No')]", "Button");
 		break;
 	case "Other assets" :
 		Utility.clickObject("//*[@id=\"app\"]/div/div[1]/div[3]/div/div[1]/div[9]/button", "Button");
 		//Thread.sleep(2000);
 		Utility.sendKeys("//*[@id=\"other-assets-other-assets-0\"]", AssetSrcsCalcAmount);
 		Utility.sendKeys("//*[@id=\"other-assets-description-0\"]", "Entered" + " " + AssetSrcsCalcAmount + " for " + AssetSrcs);
 		//Utility.clickObject("//input[@placeholder='Other assets']//parent::span//parent::div//parent::div//parent::div//parent::div//*[contains(text(),'Yes')]", "Button");
 		Utility.clickObject("//input[@id='other-assets-other-assets-0']//parent::span//parent::div//parent::div//parent::div//parent::div//*[contains(text(),'No')]", "Button");
 		break;
 	default :
 		System.out.println("Invalid Asset Calculator");
 
}
}


/* *************************************************************************************************************************************************
Author: 	  RameshChalumuri
Stage:       Stage 04
Method Name: employmentSelectLiabilitySources
Purpose: 	  This method is for selecting Liability Sources
Created on:  17-October-2018
Updated By: 
Updated on:
*************************************************************************************************************************************************** */
public static void SelectLiabilitySources(String EmpLiabilitySources) throws InterruptedException{

switch(EmpLiabilitySources) {
	case "Alimony" :
		Utility.clickObject("ehome.liabilitySrcs.Alimony.Btn", "Button");
		break;
	case "Child support" :
		Utility.clickObject("ehome.liabilitySrcs.ChildSupport.Btn", "Button");
		break;
	case "Private debt" :
		Utility.clickObject("ehome.liabilitySrcs.PrivateDebt.Btn", "Button");
		break;
	case "No liabilities" :
		Utility.clickObject("//*[@id=\"app\"]/div/div[1]/div[2]/button[2]/span", "Button");
		break;
	default :
   System.out.println("Invalid Liability Sources");
}
}

/* *************************************************************************************************************************************************
Author: 	  RameshChalumuri
Stage:       Stage 04
Method Name: employmentEnterLiabilityCalculateAmount
Purpose: 	  This method is for entering Liability Calculate Amount
Created on:  17-October-2018  
Updated By: 
Updated on:
*************************************************************************************************************************************************** */
public static void EnterLiabilityCalculateAmount(String LiabilitySrcs,String LiabilitySrcsPaymentAmount) throws InterruptedException{

	switch(LiabilitySrcs) {
 	case "Alimony" :
 		Utility.sendKeys("//*[@id=\"alimony-monthly-payment-0\"]", LiabilitySrcsPaymentAmount);
  		break;
 	case "Child support" : 
 		Utility.clickObject("//*[@id=\"app\"]/div/div[1]/div[3]/div/div[1]/div[2]/button", "Button");
 		Utility.sendKeys("//*[@id=\"child-support-monthly-payment-0\"]", LiabilitySrcsPaymentAmount);
 		break;
 		
 	case "Private debt" : 
 		Utility.clickObject("//*[@id=\"app\"]/div/div[1]/div[3]/div/div[1]/div[3]/button", "Button");
 		
 		Utility.sendKeys("//*[@id=\"private-debt-balance-owing-0\"]", LiabilitySrcsPaymentAmount);
 		Utility.sendKeys("//*[@id=\"private-debt-monthly-payment-0\"]", "1000");
 		Utility.sendKeys("//*[@id=\"private-debt-description-0\"]", "Private Deb Description");
 		Utility.clickObject("//label[contains(text(),'Yes')]", "Button");
 		break;
 		
  		
 	default :
 	      System.out.println("Invalid Liability Sources");
	}
	
}

     
	/* *************************************************************************************************************************************************
	Author: 	  RameshChalumuri
	Stage:       Stage 05
	Method Name: employmentSelectLiabilitySources
	Purpose: 	  This method is for selecting CoApplicant current employment status
	Created on:  18-October-2018
	Updated By: 
	Updated on:
	*************************************************************************************************************************************************** */
	public static void SelectCoAppCurrentEmpStatus(String CoAppCurrentEmpStatus) throws InterruptedException{

	switch(CoAppCurrentEmpStatus) {
		case "Employed" :	
			Utility.clickObject("//*[@id=\"app\"]/div/div[1]/div/div/div[3]/div/div/section/div/div/div/div/fieldset/div/span[1]/label", "Button");
			Thread.sleep(500);
			break;
		case "Unemployed" :
			Utility.clickObject("//*[@id=\"app\"]/div/div[1]/div/div/div[3]/div/div/section/div/div/div/div/fieldset/div/span[2]/label", "Button");
			Thread.sleep(500);
			break;
		case "Retired" :
			Utility.clickObject("//*[@id=\"app\"]/div/div[1]/div/div/div[3]/div/div/section/div/div/div/div/fieldset/div/span[3]/label", "Button");
			Thread.sleep(500);
			break;
		default :
	    System.out.println("Invalid Current Employment Status");
	}
	}


	/* *************************************************************************************************************************************************
	Author: 	  RameshChalumuri
	Stage:       Stage 05
	Method Name: employmentSelectLiabilitySources
	Purpose: 	  This method is for selecting CoApplicant Sources Of Income
	Created on:  18-October-2018
	Updated By: 
	Updated on:
	*************************************************************************************************************************************************** */
	public static void SelectCoAppSrcsOfIncome(String CoAppSrcsOfIncome, String CoAppSrcsOfIncomeAmt ) throws InterruptedException{

	switch(CoAppSrcsOfIncome) {
		case "No other sources" :	
			Utility.clickObject("//*[@id=\"coAppNoOtherSources\"]", "Button");
			//Thread.sleep(1000);
			break;
		case "Child Support" :
			Utility.clickObject("//*[@id=\"app\"]/div/div[1]/div/div/div[3]/div/div[2]/section/div/div[1]/div/div[3]/div/div/div[1]/button", "Button");
			Utility.sendKeys("//*[@id=\"child-support-0\"]", CoAppSrcsOfIncomeAmt);
			break;
		case "Investments" :
			Utility.clickObject("", "Button");
			Utility.sendKeys("", CoAppSrcsOfIncomeAmt);
			break;
		case "Pension/Disability" :
			Utility.clickObject("", "Button");
			Utility.sendKeys("", CoAppSrcsOfIncomeAmt);
			break;
		case "No other sources of income" :
			Utility.clickObject("", "Button");
			break;
		default :
	    System.out.println("Invalid Current Employment Status");
	}
	}

}
   
   
   
   
