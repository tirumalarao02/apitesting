//package com.scotiabank.ehome.ui.steps.stage2;
//import java.util.List;
//import org.openqa.selenium.By;
//import org.openqa.selenium.Keys;
//import org.openqa.selenium.WebElement;
//import org.openqa.selenium.interactions.Actions;
//import org.openqa.selenium.support.ui.ExpectedConditions;
//import org.openqa.selenium.support.ui.WebDriverWait;
//import org.testng.Assert;
//import com.qmetry.qaf.automation.step.QAFTestStepProvider;
//import com.qmetry.qaf.automation.ui.WebDriverTestBase;
//import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebDriver;
//import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
//import com.quantum.utils.ConfigurationUtils;
//import cucumber.api.PendingException;
//import cucumber.api.java.en.And;
//import cucumber.api.java.en.Given;
//import cucumber.api.java.en.Then;
//import cucumber.api.java.en.When;


package com.scotiabank.ehome.ui.steps.stage2;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.cucumber.listener.Reporter;
import com.qmetry.qaf.automation.step.QAFTestStepProvider;
import com.qmetry.qaf.automation.ui.WebDriverTestBase;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebDriver;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.quantum.java.pages.ExtentReportHelper;
import com.quantum.utils.ConfigurationUtils;
import com.scotiabank.ehome.ui.steps.CommonApplicationMethods;
import com.scotiabank.ehome.ui.steps.Utility;

import cucumber.api.PendingException;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

@QAFTestStepProvider

public class downPaymentSources {
	
	private QAFExtendedWebDriver webDriver = null;
    public Actions action = null;
    public WebDriverWait wait=null;
    
    static String curDir = System.getProperty("user.dir");
    static String strfullPathToFile = curDir + "\\src\\main\\resources\\data\\eHomeTestData.xlsx"; // File Path
        
     
    static String  strCommonObjects = "CommonObjects";
    static String  strTotalDownPaymentSourcesSheet = "TotalDownPaymtSources";
    
    
    QAFExtendedWebElement BankAccountimg    = new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[1]/section/div[4]/div/div/fieldset/div/span[1]/label/span[1]/div/img");
    QAFExtendedWebElement BankAccountSelectBtn    = new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[1]/section/div[4]/div/div/fieldset/div/span[1]/label/span[2]/span[2]");
    QAFExtendedWebElement BankAccountRemoveBtn= new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[1]/section/div[4]/div/div/fieldset/div/span[1]/label/span[2]/span[1]");
    
    QAFExtendedWebElement InvestmentAcctimg = new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[1]/section/div[4]/div/div/fieldset/div/span[2]/label/span[1]/div/img");
    QAFExtendedWebElement InvestmentAcctSelectBtn = new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[1]/section/div[4]/div/div/fieldset/div/span[2]/label/span[2]/span[2]");
    QAFExtendedWebElement InvestmentAcctRemoveBtn = new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[1]/section/div[4]/div/div/fieldset/div/span[2]/label/span[2]/span[1]");
    
    
     QAFExtendedWebElement FamilyGiftimg    = new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[1]/section/div[4]/div/div/fieldset/div/span[3]/label/span[1]/div/img");
     QAFExtendedWebElement FamilyGiftSelectBtn    = new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[1]/section/div[4]/div/div/fieldset/div/span[3]/label/span[2]/span[2]");
     QAFExtendedWebElement FamilyGiftRemoveBtn    = new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[1]/section/div[4]/div/div/fieldset/div/span[3]/label/span[2]/span[1]");
     
     QAFExtendedWebElement RRSPwithdrawalimg = new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[1]/section/div[4]/div/div/fieldset/div/span[4]/label/span[1]/div/img");
     QAFExtendedWebElement RRSPwithdrawalSelectBtn = new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[1]/section/div[4]/div/div/fieldset/div/span[4]/label/span[2]/span[2]");
     QAFExtendedWebElement RRSPwithdrawalRemoveBtn    = new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[1]/section/div[4]/div/div/fieldset/div/span[4]/label/span[2]/span[1]");
     
     
     QAFExtendedWebElement SaleofassetImg = new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[1]/section/div[4]/div/div/fieldset/div/span[5]/label/span[1]/div/img");
     QAFExtendedWebElement SaleofassetSelectBtn = new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[1]/section/div[4]/div/div/fieldset/div/span[5]/label/span[2]/span[2]");
     QAFExtendedWebElement SaleofassetRemoveBtn    = new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[1]/section/div[4]/div/div/fieldset/div/span[5]/label/span[2]/span[1]");
     
    QAFExtendedWebElement SaleofexistingpropertyImg = new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[1]/section/div[4]/div/div/fieldset/div/span[6]/label/span[1]/div/img");
    QAFExtendedWebElement SaleofexistingpropertySelectBtn = new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[1]/section/div[4]/div/div/fieldset/div/span[6]/label/span[2]/span[2]");
    QAFExtendedWebElement SaleofexistingpropertyRemoveBtn    = new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[1]/section/div[4]/div/div/fieldset/div/span[6]/label/span[2]/span[1]");
    
    QAFExtendedWebElement Continue = new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[2]/button[2]");
    
           @Given("^Customer should login and navigate to Down Payment Sources Screen$")
           public void Customer_should_login_and_navigate_to_DownPaymentSources_Screen() throws Throwable {
        	   
        	   Utility.launchURL(ConfigurationUtils.getBaseBundle ().getPropertyValue ("env.baseurl1")); 
           	Thread.sleep(1000);
           	
           	Utility.clickObject("//*[@id=\"app\"]/div/div[1]/div[2]/div/div[3]/div/button", "Continue Button in New Home");

           	Thread.sleep(1000);
           	CommonApplicationMethods.enterAddressManually();
           	Thread.sleep(3000);
           	QAFExtendedWebElement TypeofPropertyOption= new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[1]/section/div[3]/div/fieldset/div/span[1]/label/span[2]/span");
           	TypeofPropertyOption.click();
           	Thread.sleep(2000);
           	QAFExtendedWebElement TypeofHouseOption= new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[1]/section/div[3]/div/fieldset/div/span[1]/label");
           	TypeofHouseOption.click();
           	Thread.sleep(1000);
           	QAFExtendedWebElement ValueAreaofProperty= new QAFExtendedWebElement("//*[@id=\"sqFeet\"]");
           	ValueAreaofProperty.sendKeys("5000");
           	Thread.sleep(1000);
           	QAFExtendedWebElement Continue3 = new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[2]/button[2]");
           	Continue3.click();
           	
           	Thread.sleep(3000);
                               
              // Enter Amount More than Zero into purchase price text field in Purchase Price screen 
                  QAFExtendedWebElement ValuePurchasePrice= new QAFExtendedWebElement("ehome.PurchasePrice.inputtextbox");
                  ValuePurchasePrice.sendKeys("100000");
                  Thread.sleep(3000);
                  
                  QAFExtendedWebElement PurchasePriceContinue = new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[2]/button[2]");
                  PurchasePriceContinue.click();
                  Thread.sleep(3000);
                  
                  QAFExtendedWebElement DownPaymentInputbox= new QAFExtendedWebElement("//*[@id=\"downPayment\"]");
                  DownPaymentInputbox.sendKeys("40000");
                  Thread.sleep(3000);
                  
                  QAFExtendedWebElement Continue7 = new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[2]/button[2]");
                  Continue7.click();
                  Thread.sleep(3000);
             	   
            }
   
      
         // Verifying Title 'What are the sources of your down payment?' of the sources of down payment screen
         @Then("^Total Down Payment Sources Title screen with title \"([^\"]*)\" is present$")
         public void Verify_Display_DownPaymtSrcs_Title(String expectedText) throws Throwable {
               List<String> ExcelData = Utility.ExcelData(strfullPathToFile, strTotalDownPaymentSourcesSheet, expectedText) ;
        	   String ExpectedResult =ExcelData.get(1); 
        	   QAFExtendedWebElement ActualResult= new QAFExtendedWebElement("ehome.TotalDownPaymentSources.Title.Name");
        	   Assert.assertEquals(ActualResult.getText(), ExpectedResult,"Actual and Expected Result are NOT Matched");
         }
    
         
      // Verifying label "Great!"
         @And("^Great label as \"([^\"]*)\" is present in DownPaymtSrc$")
         public void Verify_Display_GreatLabel_DownPaymtSrc(String expectedText) throws Throwable {
               List<String> ExcelData = Utility.ExcelData(strfullPathToFile, strTotalDownPaymentSourcesSheet, expectedText) ;
        	   String ExpectedResult =ExcelData.get(1); 
        	   QAFExtendedWebElement ActualResult= new QAFExtendedWebElement("ehome.TotalDownPaymentSources.Great.Label");
        	   Assert.assertEquals(ActualResult.getText(),ExpectedResult,"Actual and Expected Result are NOT Matched");
         }
         
      // Verifying label "Please select all that apply"
         @And("^Please select all that apply label as \"([^\"]*)\" is present in DownPaymtSrc$")
         public void Verify_Display_Please_select_all_that_apply_label_DownPaymtSrc(String expectedText) throws Throwable {
               List<String> ExcelData = Utility.ExcelData(strfullPathToFile, strTotalDownPaymentSourcesSheet, expectedText) ;
        	   String ExpectedResult =ExcelData.get(1); 
        	   QAFExtendedWebElement ActualResult= new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[1]/section/div[3]/p");
        	   Assert.assertEquals(ActualResult.getText(),ExpectedResult,"Actual and Expected Result are NOT Matched");
         }
    
       // Verifying Payment Source option "Bank account" button as "Bank account" is present with image and deselected by default with label Select
       @And("^Payment Source option Bank account button as \"([^\"]*)\" is present with image and deselected bydefault with label Select$")
       public void Verify_Display_DownPaymtSrcOpt_BankAccount(String expectedText) throws Throwable {
    	   
    	   // Verify Payment Source option "Bank account" button name
           List<String> ExcelData = Utility.ExcelData(strfullPathToFile, strTotalDownPaymentSourcesSheet, expectedText) ;
    	   String ExpectedResult =ExcelData.get(1); 
    	   QAFExtendedWebElement ActualResult= new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[1]/section/div[4]/div/div/fieldset/div/span[1]/label/span[1]/span");
    	   Assert.assertEquals(ActualResult.getText(),ExpectedResult,"Actual and Expected Result are NOT Matched");
    	   
    	 //Verify Payment Source option "Bank account" image
    	   if(!BankAccountimg.verifyPresent())
               throw new AssertionError("Couldn't find Bank Account Image");
    	   
    	   // Verify Select button by default deselected
    	   if(!BankAccountSelectBtn.verifyPresent())
               throw new AssertionError("Couldn't find Bank Account Image");
    	   
    	   Thread.sleep(3000);
    	   
     }
       
       // Verifying Payment Source option "Investment account" button as "Investment account" is present with image and deselected by default with label Select
       @And("^Payment Source option Invesment account button as \"([^\"]*)\" is present with image and deselected bydefault with label Select$")
       public void Verify_Display_DownPaymtSrcOpt_InvestmentAccount(String expectedText) throws Throwable {
    	   
    	   // Verify Payment Source option "Investment account" button name
           List<String> ExcelData = Utility.ExcelData(strfullPathToFile, strTotalDownPaymentSourcesSheet, expectedText) ;
    	   String ExpectedResult =ExcelData.get(1); 
    	   QAFExtendedWebElement ActualResult= new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[1]/section/div[4]/div/div/fieldset/div/span[2]/label/span[1]/span");
    	   Assert.assertEquals(ActualResult.getText(),ExpectedResult,"Actual and Expected Result are NOT Matched");
    	   
    	 //Verify Payment Source option "Investment account" image
    	   if(!InvestmentAcctimg.verifyPresent())
               throw new AssertionError("Couldn't find Investment Account Image");
    	   
    	   // Verify Select button by default deselected
    	   if(!InvestmentAcctSelectBtn.verifyPresent())
               throw new AssertionError("Couldn't find Investment Account Select Button");
    	   
     }      
       
       // Verifying Payment Source option "A Gift from Family" button as "A Gift from Family" is present with image and deselected by default with label Select
       @And("^Payment Source option A Gift from Family button as \"([^\"]*)\" is present with image and deselected bydefault with label Select$")
       public void Verify_Display_DownPaymtSrcOpt_AGiftfromFamily(String expectedText) throws Throwable {
    	   
    	   // Verify Payment Source option "Investment account" button name
           List<String> ExcelData = Utility.ExcelData(strfullPathToFile, strTotalDownPaymentSourcesSheet, expectedText) ;
    	   String ExpectedResult =ExcelData.get(1); 
    	   QAFExtendedWebElement ActualResult= new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[1]/section/div[4]/div/div/fieldset/div/span[3]/label/span[1]/span");
    	   Assert.assertEquals(ActualResult.getText(),ExpectedResult,"Actual and Expected Result are NOT Matched");
    	   
    	 //Verify Payment Source option "A Gift from Family" image
    	   if(!FamilyGiftimg.verifyPresent())
               throw new AssertionError("Couldn't find A Gift from Family Image");
    	   
    	   // Verify Select button by default deselected
    	   if(!FamilyGiftSelectBtn.verifyPresent())
               throw new AssertionError("Couldn't find A Gift from Family Select Button");
    	   
     }      
       
       // Verifying Payment Source option "RRSP withdrawal" button as "RRSP withdrawal" is present with image and deselected by default with label Select
       @And("^Payment Source option RRSP withdrawal button as \"([^\"]*)\" is present with image and deselected bydefault with label Select$")
       public void Verify_Display_DownPaymtSrcOpt_RRSPwithdrawal(String expectedText) throws Throwable {
    	   
    	   // Verify Payment Source option "RRSP withdrawal" button name
           List<String> ExcelData = Utility.ExcelData(strfullPathToFile, strTotalDownPaymentSourcesSheet, expectedText) ;
    	   String ExpectedResult =ExcelData.get(1); 
    	   QAFExtendedWebElement ActualResult= new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[1]/section/div[4]/div/div/fieldset/div/span[4]/label/span[1]/span");
    	   Assert.assertEquals(ActualResult.getText(),ExpectedResult,"Actual and Expected Result are NOT Matched");
    	   
    	 //Verify Payment Source option "RRSP withdrawal" image
   	   if(!RRSPwithdrawalimg.verifyPresent())
               throw new AssertionError("Couldn't find RRSP withdrawal Image");
    	   
    	   // Verify Select button by default deselected
    	   if(!RRSPwithdrawalSelectBtn.verifyPresent())
               throw new AssertionError("Couldn't find RRSP withdrawal Select Button");
    	   
     }      
       
       
       // Verifying Payment Source option "Sale of asset" button as "Sale of asset" is present with image and deselected by default with label Select
       @And("^Payment Source option Sale of asset button as \"([^\"]*)\" is present with image and deselected bydefault with label Select$")
       public void Verify_Display_DownPaymtSrcOpt_Saleofasset(String expectedText) throws Throwable {
    	   
    	   // Verify Payment Source option "Sale of asset" button name
           List<String> ExcelData = Utility.ExcelData(strfullPathToFile, strTotalDownPaymentSourcesSheet, expectedText) ;
    	   String ExpectedResult =ExcelData.get(1); 
    	   QAFExtendedWebElement ActualResult= new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[1]/section/div[4]/div/div/fieldset/div/span[5]/label/span[1]/span");
    	   Assert.assertEquals(ActualResult.getText(),ExpectedResult,"Actual and Expected Result are NOT Matched");
    	   
    	 //Verify Payment Source option "Sale of asset" image
     	   if(!SaleofassetImg.verifyPresent())
               throw new AssertionError("Couldn't find Sale of asset Image");
    	   
    	   // Verify Select button by default deselected
    	   if(!SaleofassetSelectBtn.verifyPresent())
               throw new AssertionError("Couldn't find Sale of asset Select Button");
    	   
     }      
       
       // Verifying Payment Source option "Sale of existing property" button as "Sale of existing property" is present with image and deselected by default with label Select
       @And("^Payment Source option Sale of existing property button as \"([^\"]*)\" is present with image and deselected bydefault with label Select$")
       public void Verify_Display_DownPaymtSrcOpt_Saleofexistingproperty(String expectedText) throws Throwable {
    	   
    	   // Verify Payment Source option "Sale of existing property" button name
           List<String> ExcelData = Utility.ExcelData(strfullPathToFile, strTotalDownPaymentSourcesSheet, expectedText) ;
    	   String ExpectedResult =ExcelData.get(1); 
    	   QAFExtendedWebElement ActualResult= new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[1]/section/div[4]/div/div/fieldset/div/span[6]/label/span[1]/span");
    	   Assert.assertEquals(ActualResult.getText(),ExpectedResult,"Actual and Expected Result are NOT Matched");
    	   
    	 //Verify Payment Source option "Sale of existing property" image
     	   if(!SaleofexistingpropertyImg.verifyPresent())
               throw new AssertionError("Couldn't find Sale of existing property Image");
    	   
    	   // Verify Select button by default deselected
    	   if(!SaleofexistingpropertySelectBtn.verifyPresent())
               throw new AssertionError("Couldn't find Sale of existing property Select Button");
    	   
     }   
     

         
//        // Verify Remove options when select for Down payment source option1: Bank account
         @When("^Select an option Bank account$")
         public void Select_an_option_Bank_account() throws Throwable {
        	 BankAccountSelectBtn.click();
        	 Thread.sleep(3000);
         }
         
         @Then("^Continue button as \"([^\"]*)\" is present in DownPaymtSrc$")
         public void Continue_button_is_Present_DownPaymtSrc(String expectedText) throws Throwable {
            // Write code here that turns the phrase above into concrete actions
           List<String> exceldata = Utility.ExcelData(strfullPathToFile, strCommonObjects, expectedText) ;
     	   String ExpectedResult =exceldata.get(1); 
     	   Assert.assertEquals(Continue.getText(), ExpectedResult,"Continue button is NOT Present");
           Thread.sleep(3000);
         }
         
         @And("^Option Bank account is selected and label is changed from Select to Remove$")
         public void Verify_BankAccountOptionRemove() throws Throwable {
         	 if(!BankAccountRemoveBtn.verifyPresent())
                 throw new AssertionError("Couldn't find Bank Account Remove Button");
         }
         
//       // Verify Select option when unselect for Down payment source option1: Bank account
        @When("^UnSelect an option Bank account$")
        public void UnSelect_an_option_Bank_account() throws Throwable {
        	BankAccountRemoveBtn.click();
        	 Thread.sleep(3000);
        }
        
        @Then("^Continue button as \"([^\"]*)\" is NOT present in DownPaymtSrc$")
        public void Continue_button_is_NOTPresent_DownPaymtSrc(String expectedText) throws Throwable {
           // Write code here that turns the phrase above into concrete actions
           String ExpectedResult = "";
           Thread.sleep(3000);
    	   Assert.assertEquals(Continue.getText(), ExpectedResult,"Continue button IS Present");
    	   Thread.sleep(3000);
        }
        
        @And("^Option Bank account is unselected and label is changed from Remove to Select$")
        public void Verify_BankAccountOptionSelect() throws Throwable {
        	 if(!BankAccountSelectBtn.verifyPresent())
                throw new AssertionError("Couldn't find Bank Account Select Button");
        }
        
       
//      // Verify Remove options when select for Investment account source option2: Investment account
       @When("^Select an option Investment account$")
       public void Select_an_option_Investmentaccount() throws Throwable {
    	   InvestmentAcctSelectBtn.click();
      	 Thread.sleep(3000);
       }
       @And("^Option Investment account is selected and label is changed from Select to Remove$")
       public void Verify_InvestmentAccountOptionRemove() throws Throwable {
       	 if(!InvestmentAcctRemoveBtn.verifyPresent())
               throw new AssertionError("Couldn't find Investment account Remove Button");
       }
      
//     // Verify Select option when unselect for Down payment source option2: Investment account
      @When("^UnSelect an option Investment account$")
      public void UnSelect_an_option_Investment_account() throws Throwable {
    	  InvestmentAcctRemoveBtn.click();
      	 Thread.sleep(3000);
      }
      @And("^Option Investment account is unselected and label is changed from Remove to Select$")
      public void Verify_InvestmentaccountOptionSelect() throws Throwable {
      	 if(!InvestmentAcctSelectBtn.verifyPresent())
              throw new AssertionError("Couldn't find Investment account Select Button");
      }
       
       
//    // Verify Remove options when select for A gift from family source option3: A gift from family
     @When("^Select an option A gift from family$")
     public void Select_an_option_Agiftfromfamily() throws Throwable {
    	 FamilyGiftSelectBtn.click();
    	 Thread.sleep(3000);
     }
     @And("^Option A gift from family is selected and label is changed from Select to Remove$")
     public void Verify_AgiftfromfamilyOptionRemove() throws Throwable {
     	 if(!FamilyGiftRemoveBtn.verifyPresent())
             throw new AssertionError("Couldn't find A gift from family Remove Button");
     }
    
//   // Verify Select option when unselect for Down payment source option3: A gift from family
    @When("^UnSelect an option A gift from family$")
    public void UnSelect_an_option_Agiftfromfamily() throws Throwable {
    	FamilyGiftRemoveBtn.click();
    	 Thread.sleep(3000);
    }
    @And("^Option A gift from family is unselected and label is changed from Remove to Select$")
    public void Verify_AgiftfromfamilyOptionSelect() throws Throwable {
    	 if(!FamilyGiftSelectBtn.verifyPresent())
            throw new AssertionError("Couldn't find A gift from family Select Button");
    }
       
     
  // Verify Remove options when select for RRSP withdrawal source option3: RRSP withdrawal
    @When("^Select an option RRSP withdrawal$")
    public void Select_an_option_RRSPwithdrawal() throws Throwable {
    	RRSPwithdrawalSelectBtn.click();
   	 Thread.sleep(3000);
    }
    @And("^Option RRSP withdrawal is selected and label is changed from Select to Remove$")
    public void Verify_RRSPwithdrawalOptionRemove() throws Throwable {
    	 if(!RRSPwithdrawalRemoveBtn.verifyPresent())
            throw new AssertionError("Couldn't find RRSP withdrawal Remove Button");
    }
   
//  // Verify Select option when unselect for Down payment source option3: A gift from family
   @When("^UnSelect an option RRSP withdrawal$")
   public void UnSelect_an_option_RRSPwithdrawal() throws Throwable {
	   RRSPwithdrawalRemoveBtn.click();
   	 Thread.sleep(3000);
   }
   @And("^Option RRSP withdrawal is unselected and label is changed from Remove to Select$")
   public void Verify_RRSPwithdrawalOptionSelect() throws Throwable {
   	 if(!RRSPwithdrawalSelectBtn.verifyPresent())
           throw new AssertionError("Couldn't find RRSP withdrawal Select Button");
   }
    
   
   
   // Verify Remove options when select for Sale of asset source option3: Sale of asset
   @When("^Select an option Sale of asset$")
   public void Select_an_option_Saleofasset() throws Throwable {
	   SaleofassetSelectBtn.click();
  	 Thread.sleep(3000);
   }
   @And("^Option Sale of asset is selected and label is changed from Select to Remove$")
   public void Verify_SaleofassetOptionRemove() throws Throwable {
   	 if(!SaleofassetRemoveBtn.verifyPresent())
           throw new AssertionError("Couldn't find Sale of asset Remove Button");
   }
  
// // Verify Select option when unselect for Down payment source option3: A gift from family
  @When("^UnSelect an option Sale of asset$")
  public void UnSelect_an_option_Saleofasset() throws Throwable {
	  SaleofassetRemoveBtn.click();
  	 Thread.sleep(3000);
  }
  @And("^Option Sale of asset is unselected and label is changed from Remove to Select$")
  public void Verify_SaleofassetOptionSelect() throws Throwable {
  	 if(!SaleofassetSelectBtn.verifyPresent())
          throw new AssertionError("Couldn't find Sale of asset Select Button");
  }
   
  // Verify Remove options when select for Sale of existing property source option3: Sale of existing property
  @When("^Select an option Sale of existing property$")
  public void Select_an_option_Saleofexistingproperty() throws Throwable {
	  SaleofexistingpropertySelectBtn.click();
 	 Thread.sleep(3000);
  }
  @And("^Option Sale of existing property is selected and label is changed from Select to Remove$")
  public void Verify_SaleofexistingpropertyOptionRemove() throws Throwable {
  	 if(!SaleofexistingpropertyRemoveBtn.verifyPresent())
          throw new AssertionError("Couldn't find Sale of existing property Remove Button");
  }
 
//// Verify Select option when unselect for Down payment source option3: A gift from family
 @When("^UnSelect an option Sale of existing property$")
 public void UnSelect_an_option_Saleofexistingproperty() throws Throwable {
	 SaleofexistingpropertyRemoveBtn.click();
 	 Thread.sleep(3000);
 }
 @And("^Option Sale of existing property is unselected and label is changed from Remove to Select$")
 public void Verify_SaleofexistingpropertyOptionSelect() throws Throwable {
 	 if(!SaleofexistingpropertySelectBtn.verifyPresent())
         throw new AssertionError("Couldn't find Sale of existing property Select Button");
 }
 
 
 @When("^Select Continue button in Down Payment Sources$")
 public void Select_Continue_Button_in_DownPayment_Sources() throws Throwable {
 	 Continue.click();
 }
 
 
//Verifying Title 'Total Down Payment Details screen
 @Then("^Total Down Payment Details Title screen with title \"([^\"]*)\" is present$")
 public void Total_Down_Payment_Details_Title_screen_with_title(String expectedText) throws Throwable {
       List<String> ExcelData = Utility.ExcelData(strfullPathToFile, strTotalDownPaymentSourcesSheet, expectedText) ;
	   String ExpectedResult =ExcelData.get(1); 
	   QAFExtendedWebElement ActualResult= new QAFExtendedWebElement("ehome.detailsofdownpayment.detailsOfDownPaymentHeader");
	   Assert.assertEquals(ActualResult.getText(), ExpectedResult,"Total Down Payment Details screen is NOT displayed");
 }
 
//Verifying Please select your sources for downpayment message
@Then("^Verify Please select your sources for downpayment message \"([^\"]*)\" is present$")
public void Please_Select_Sources_for_DownPayment_Messages(String expectedText) throws Throwable {
      List<String> ExcelData = Utility.ExcelData(strfullPathToFile, strTotalDownPaymentSourcesSheet, expectedText) ;
	   String ExpectedResult =ExcelData.get(1); 
	   QAFExtendedWebElement ActualResult= new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[1]/section/div[2]/div[2]/div/div/div[2]/p");
	   Assert.assertEquals(ActualResult.getText(), ExpectedResult,"Please select your sources for downpayment message is NOT displayed");
}

    
}
