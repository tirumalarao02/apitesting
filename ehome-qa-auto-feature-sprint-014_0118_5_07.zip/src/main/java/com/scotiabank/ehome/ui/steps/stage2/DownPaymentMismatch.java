package com.scotiabank.ehome.ui.steps.stage2;

import com.qmetry.qaf.automation.step.QAFTestStepProvider;
import com.qmetry.qaf.automation.ui.WebDriverTestBase;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebDriver;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.quantum.utils.ConfigurationUtils;
import com.scotiabank.ehome.ui.steps.Utility;
import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import java.util.concurrent.TimeUnit;

@QAFTestStepProvider
public class DownPaymentMismatch {

    QAFExtendedWebDriver webDriver = new WebDriverTestBase().getDriver();
    public Actions action = null;
    WebDriverWait wait = new WebDriverWait(webDriver,50000);

    String testCaseID = Utility.getScenarioID();

    QAFExtendedWebElement TypeofPropertyhouseselect= new QAFExtendedWebElement("ehome.detailsofdownpayment.TypeofPropertyhouseselect");
    QAFExtendedWebElement Detached= new QAFExtendedWebElement("ehome.detailsofdownpayment.Detached");
    QAFExtendedWebElement eleAddress = new QAFExtendedWebElement(By.xpath("//*[@id='app']/div/div[1]/div[1]/section/div[3]/div/div[1]/div/div[2]/div/ul"));
    QAFExtendedWebElement ContinueButton= new QAFExtendedWebElement("ehome.detailsofdownpayment.ContinueButton");
    QAFExtendedWebElement ContinueButtonDetails= new QAFExtendedWebElement("ehome.detailsofdownpayment.ContinueButtonDetails");
    QAFExtendedWebElement sqft= new QAFExtendedWebElement("ehome.detailsofdownpayment.sqft");
    QAFExtendedWebElement purchasePrice= new QAFExtendedWebElement("ehome.detailsofdownpayment.purchasePrice");
    QAFExtendedWebElement downPayment= new QAFExtendedWebElement("ehome.detailsofdownpayment.downPayment");
    QAFExtendedWebElement bankAccountOption= new QAFExtendedWebElement("ehome.detailsofdownpayment.bankAccountOption");
    QAFExtendedWebElement saleOfExistingProperty= new QAFExtendedWebElement("ehome.detailsofdownpayment.saleOfExistingProperty");
    QAFExtendedWebElement investmentAccount= new QAFExtendedWebElement("ehome.detailsofdownpayment.investmentAccount");

    QAFExtendedWebElement bankAccountAmount= new QAFExtendedWebElement("ehome.detailsofdownpayment.bankAccountAmount");
    QAFExtendedWebElement saleOfExistingAmount= new QAFExtendedWebElement("ehome.detailsofdownpayment.saleOfExistingAmount");
    QAFExtendedWebElement investmentAccountAmount= new QAFExtendedWebElement("ehome.detailsofdownpayment.investmentAccountAmount");

    QAFExtendedWebElement bankAccountAmountProperty= new QAFExtendedWebElement("ehome.detailsofdownpayment.bankAccountAmountProperty");
    QAFExtendedWebElement investmentAccountAmountProperty= new QAFExtendedWebElement("ehome.detailsofdownpayment.investmentAccountAmountProperty");
    QAFExtendedWebElement saleOfExistingPropertyAmountProperty= new QAFExtendedWebElement("ehome.detailsofdownpayment.saleOfExistingPropertyAmountProperty");

    QAFExtendedWebElement saleOfExistingAmountProperty= new QAFExtendedWebElement("ehome.detailsofdownpayment.saleOfExistingAmountProperty");
    QAFExtendedWebElement saleOfExistingCalender= new QAFExtendedWebElement("ehome.detailsofdownpayment.saleOfExistingCalender");
    QAFExtendedWebElement saleOfExistingMonth= new QAFExtendedWebElement("ehome.detailsofdownpayment.saleOfExistingMonth");

    QAFExtendedWebElement scotiabankLogo= new QAFExtendedWebElement("ehome.scotiabanklogo.image");
    QAFExtendedWebElement applicationTracter= new QAFExtendedWebElement("ehome.applicationstatustracker.image");
    QAFExtendedWebElement userloginname= new QAFExtendedWebElement("ehome.userloginname.image");
    QAFExtendedWebElement Back= new QAFExtendedWebElement("ehome.detailsofdownpayment.Back");

    QAFExtendedWebElement downPaymentMismatchHeader= new QAFExtendedWebElement("ehome.detailsofdownpayment.detailsOfDownPaymentHeader");
    QAFExtendedWebElement AmazingText= new QAFExtendedWebElement("ehome.detailsofdownpayment.AmazingText");
    QAFExtendedWebElement DownPaymentText= new QAFExtendedWebElement("ehome.detailsofdownpayment.DownPaymentText");
    QAFExtendedWebElement DetailsOfDownPaymentBanner= new QAFExtendedWebElement("ehome.detailsofdownpayment.detailsOfDownPaymentBanner");

    QAFExtendedWebElement MinimumdownpaymentAmount= new QAFExtendedWebElement("ehome.detailsofdownpayment.MinimumdownpaymentAmount");
    QAFExtendedWebElement Minimumdownpaymentpercentage= new QAFExtendedWebElement("ehome.detailsofdownpayment.Minimumdownpaymentpercentage");
    QAFExtendedWebElement AddAnother= new QAFExtendedWebElement("ehome.detailsofdownpayment.AddAnother");
    QAFExtendedWebElement NewRow= new QAFExtendedWebElement("ehome.detailsofdownpayment.NewRow");
    QAFExtendedWebElement RemoveEntireSource= new QAFExtendedWebElement("ehome.detailsofdownpayment.RemoveEntireSource");
    QAFExtendedWebElement RemoveEntireSourceYes= new QAFExtendedWebElement("ehome.detailsofdownpayment.RemoveEntireSourceYes");
    QAFExtendedWebElement RemoveEntireSourceNo= new QAFExtendedWebElement("ehome.detailsofdownpayment.RemoveEntireSourceNo");

    QAFExtendedWebElement saleofexistingpropertydate = new QAFExtendedWebElement("ehome.detailsofdownpayment.saleofexistingpropertydate");

    QAFExtendedWebElement PurpleTick= new QAFExtendedWebElement("ehome.detailsofdownpayment.PurpleTick");
    QAFExtendedWebElement GreenTick= new QAFExtendedWebElement("ehome.detailsofdownpayment.GreenTick");
    QAFExtendedWebElement ValidEntry= new QAFExtendedWebElement("ehome.detailsofdownpayment.ValidEntry");

    QAFExtendedWebElement Remove= new QAFExtendedWebElement("ehome.detailsofdownpayment.Remove");
    QAFExtendedWebElement ShowOtherSources= new QAFExtendedWebElement("ehome.detailsofdownpayment.ShowOtherSources");
    QAFExtendedWebElement ShowOtherSourcesText= new QAFExtendedWebElement("ehome.detailsofdownpayment.ShowOtherSourcesText");
    QAFExtendedWebElement SourcesofDownPayment= new QAFExtendedWebElement("ehome.detailsofdownpayment.SourcesofDownPayment");
    QAFExtendedWebElement SourcesofDownPaymentHeader= new QAFExtendedWebElement("ehome.sourcesofdownpayment.Header");

    QAFExtendedWebElement MinDownPayText= new QAFExtendedWebElement("ehome.detailsofdownpayment.MinDownPayText");
    QAFExtendedWebElement downpaymentdoesnotmatchHeader= new QAFExtendedWebElement("ehome.downpaymentdoesnotmatch.Header");

    QAFExtendedWebElement Continue = new QAFExtendedWebElement("ehome.tellus.continue.button");
    QAFExtendedWebElement address = new QAFExtendedWebElement("ehome.whatstheaddress.addressList.list");
    QAFExtendedWebElement addressFirstOption = new QAFExtendedWebElement("ehome.whatstheaddress.addressList.firstOption");
    QAFExtendedWebElement continueWhattypeofproperty= new QAFExtendedWebElement("ehome.enteraddressmanually.continue.button");

    QAFExtendedWebElement AllSourcesDownPaymentErrorMessage= new QAFExtendedWebElement("ehome.detailsofdownpayment.AllSourcesDPErrorMessage");

    QAFExtendedWebElement DownPaymentMismatchMessage = new QAFExtendedWebElement("ehome.downPaymentMismatch.message");
    QAFExtendedWebElement DownPaymentMismatchHeader = new QAFExtendedWebElement("ehome.downPaymentMismatch.header");
    QAFExtendedWebElement DownPaymentMismatchTotalDownPaymentAmount = new QAFExtendedWebElement("ehome.downPaymentMismatch.TotalDownPaymentAmount");
    QAFExtendedWebElement DownPaymentMismatchTotalSourcesAmount = new QAFExtendedWebElement("ehome.downPaymentMismatch.TotalSourcesAmount");
    QAFExtendedWebElement DownPaymentMismatchTotalDownPaymentAmountValue = new QAFExtendedWebElement("ehome.downPaymentMismatch.TotalDownPaymentAmount.value");
    QAFExtendedWebElement DownPaymentMismatchTotalSourcesAmountValue = new QAFExtendedWebElement("ehome.downPaymentMismatch.TotalSourcesAmount.value");
    QAFExtendedWebElement DownPaymentMismatchQuestion = new QAFExtendedWebElement("ehome.downPaymentMismatch.question");
    QAFExtendedWebElement DownPaymentMismatchButton1 = new QAFExtendedWebElement("ehome.downPaymentMismatch.YesUpdateAndContinue");
    QAFExtendedWebElement DownPaymentMismatchButton2 = new QAFExtendedWebElement("ehome.downPaymentMismatch.NoEditTheDetails");

    QAFExtendedWebElement closingDateHeaderText= new QAFExtendedWebElement("ehome.whenistheclosingdate.ClosingDateHeader");
    QAFExtendedWebElement detailsOfDownPaymentHeader= new QAFExtendedWebElement("ehome.detailsofdownpayment.detailsOfDownPaymentHeader");



    @Given("^Customer should login and navigate to What are the details of your down payment sources and one or more options are selected$")
    public void customer_should_login_and_navigate_to_What_are_the_details_of_your_down_payment_sources_and_one_or_more_options_are_selected() throws Throwable {

        Utility.launchURL(ConfigurationUtils.getBaseBundle().getPropertyValue("env.baseurl1"));
        //webDriver.findElement(By.xpath("//*[@id='app']/div/div[3]/div/div/div/button")).click();
        Continue.click();
        QAFExtendedWebElement Enteraddress= new QAFExtendedWebElement("ehome.Address.address.text");
        String addressFromExcel = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_InputData",testCaseID , "Address");
        Enteraddress.sendKeys(addressFromExcel);

        //wait.until(ExpectedConditions.elementToBeClickable(address)); //Commenting this line due to failure over Grid
        Thread.sleep(8000);
        addressFirstOption.click();
        //TO click on continue button is address screen
        wait.until(ExpectedConditions.visibilityOf(continueWhattypeofproperty));
        continueWhattypeofproperty.click();

        //wait.pollingEvery(30, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.elementToBeClickable(TypeofPropertyhouseselect));
        Thread.sleep(10000);
        TypeofPropertyhouseselect.click();

        Thread.sleep(3000);
        Detached.click();

        wait.pollingEvery(5, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(sqft));
        String sqftFromExcel = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_InputData",testCaseID , "SQFT");
        sqft.sendKeys(sqftFromExcel);

        wait.until(ExpectedConditions.visibilityOf(ContinueButton));
        ContinueButton.click();

        wait.until(ExpectedConditions.visibilityOf(purchasePrice));
        String PurchasePriceFromExcel = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_InputData",testCaseID , "Purchase_Price");
        purchasePrice.sendKeys(PurchasePriceFromExcel);
        ContinueButton.click();

        wait.until(ExpectedConditions.visibilityOf(downPayment));
        String DownPaymentFromExcel = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_InputData",testCaseID , "Down_Payment_Amount");
        downPayment.sendKeys(DownPaymentFromExcel);

        wait.until(ExpectedConditions.visibilityOf(ContinueButton));
        ContinueButton.click();

        Thread.sleep(5000);
        bankAccountOption.click();
        investmentAccount.click();

        ContinueButton.click();

        wait.until(ExpectedConditions.visibilityOf(bankAccountAmountProperty));
        if(bankAccountAmountProperty.getAttribute("aria-expanded").contentEquals("false")) {
            bankAccountAmountProperty.click();
            String BankAccountAmountFromExcel = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_InputData",testCaseID , "Bank_Account_Amount");
            bankAccountAmount.sendKeys(BankAccountAmountFromExcel);
        }
        else {
            String BankAccountAmountFromExcel = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_InputData",testCaseID , "Bank_Account_Amount");
            bankAccountAmount.sendKeys(BankAccountAmountFromExcel);
        }
        Thread.sleep(5000);
        if(investmentAccountAmountProperty.getAttribute("aria-expanded").contentEquals("false")) {
            investmentAccountAmountProperty.click();
            String InvestmentAccountAmountFromExcel = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_InputData",testCaseID , "Investment_Account_Amount");
            investmentAccountAmount.sendKeys(InvestmentAccountAmountFromExcel);
        }
        else {
            String InvestmentAccountAmountFromExcel = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_InputData",testCaseID , "Investment_Account_Amount");
            investmentAccountAmount.sendKeys(InvestmentAccountAmountFromExcel);
        }
    }

    @When("^Click on continue button from What are the details of your down payment sources page$")
    public void clickOnContinueButtonFromWhatAreTheDetailsOfYourDownPaymentSourcesPage() throws Throwable {
        ContinueButtonDetails.click();

    }

    @Then("^Verify 'Down Payment Mismatch Header', 'Scotiabank Logo', 'Application status' tracker', 'Login username', 'chat icon' functionality on the DownPayment Mismatch Screen$")
    public void verifyDownPaymentMismatchHeaderScotiabankLogoApplicationStatusTrackerLoginUsernameChatIconFunctionalityOnTheDownPaymentMismatchScreen() throws Throwable {

        if(!downPaymentMismatchHeader.verifyText( "The down payment information you have provided does not match."  ))
            throw new AssertionError("Not able to launch details of down payment sources page");

        scotiabankLogo.assertPresent ("Couldn't find the ScotiaBank logo"  );
        if(!scotiabankLogo.verifyPresent())
            throw new AssertionError("Couldn't find the ScotiaBank logo");

        //To Check Application status tracker
        applicationTracter.assertPresent ( "Application status tracker image is missing" );
        if(!applicationTracter.verifyPresent())
            throw new AssertionError("Couldn't find the Application status tracker");
    }

    @When("^Verify 'Down Payment Mismatch Screen Message and Header' in LOC Confirmation Screen$")
    public void verifyDownPaymentMismatchScreenMessageAndHeaderInLOCConfirmationScreen() throws Throwable {

        String DownPayment_Mismatch_Message = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_ExpectedData", testCaseID, "DownPayment_Mismatch_Message");
        Assert.assertEquals(DownPaymentMismatchMessage.getText(),DownPayment_Mismatch_Message,"Message is not present");

        String DownPayment_Mismatch_Header = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_ExpectedData", testCaseID, "DownPayment_Mismatch_Header");
        Assert.assertEquals(DownPaymentMismatchHeader.getText(),DownPayment_Mismatch_Header,"Message is not present");
    }

    @Then("^Verify the Down Payment Values which are mismatched on the Down Payment Mismatch Screen$")
    public void verifyTheDownPaymentValuesWhichAreMismatchedOnTheDownPaymentMismatchScreen() throws Throwable {

        String DownPayment_Mismatch_TotalDownPayment_Amount = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_ExpectedData", testCaseID, "DownPayment_Mismatch_TotalDownPayment_Amount");
        Assert.assertEquals(DownPaymentMismatchTotalDownPaymentAmount.getText(),DownPayment_Mismatch_TotalDownPayment_Amount,"Message is not present");

        String DownPayment_Mismatch_TotalSources_Amount = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_ExpectedData", testCaseID, "DownPayment_Mismatch_TotalSources_Amount");
        Assert.assertEquals(DownPaymentMismatchTotalSourcesAmount.getText(),DownPayment_Mismatch_TotalSources_Amount,"Message is not present");

        String DownPayment_Mismatch_TotalDownPayment_Amount_Value = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_ExpectedData", testCaseID, "DownPayment_Mismatch_TotalDownPayment_Amount_Value");
        Assert.assertEquals(DownPaymentMismatchTotalDownPaymentAmountValue.getText(),DownPayment_Mismatch_TotalDownPayment_Amount_Value,"Message is not present");

        String DownPaymentMismatch_TotalSources_Amount_Value = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_ExpectedData", testCaseID, "DownPaymentMismatch_TotalSources_Amount_Value");
        Assert.assertEquals(DownPaymentMismatchTotalSourcesAmountValue.getText(),DownPaymentMismatch_TotalSources_Amount_Value,"Message is not present");

    }

    @Then("^Verify Message and buttons present on the Down Payment Mismatch Screen$")
    public void verifyMessageAndButtonsPresentOnTheDownPaymentMismatchScreen() throws Throwable {

        String DownPayment_Mismatch_Question = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_ExpectedData", testCaseID, "DownPayment_Mismatch_Question");
        Assert.assertEquals(DownPaymentMismatchQuestion.getText(),DownPayment_Mismatch_Question,"Message is not present");

        String DownPayment_Mismatch_Button1 = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_ExpectedData", testCaseID, "DownPayment_Mismatch_Button1");
        Assert.assertEquals(DownPaymentMismatchButton1.getText(),DownPayment_Mismatch_Button1,"Message is not present");

        String DownPayment_Mismatch_Button2 = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_ExpectedData", testCaseID, "DownPayment_Mismatch_Button2");
        Assert.assertEquals(DownPaymentMismatchButton2.getText(),DownPayment_Mismatch_Button2,"Message is not present");
    }

    @When("^Verify the system is navigated to Closing Date screen when Yes, Update and Continue is clicked in Down Payment Mismatch Screen$")
    public void verifyTheSystemIsNavigatedToClosingDateScreenWhenYesUpdateAndContinueIsClickedInDownPaymentMismatchScreen() throws Throwable {

        DownPaymentMismatchButton1.click();
        closingDateHeaderText.isPresent();
        String ClosingDateHeader = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_ExpectedData",testCaseID , "Closing_Date_Header");
        Assert.assertEquals(closingDateHeaderText.getText(), ClosingDateHeader,"Couldn't found expected header Text, 'Closing Date Header Text' not found");

    }

    @When("^Verify the system is navigated to Details of Down Payment Sources screen when No, edit the details of my down payment sources is clicked in Down Payment Mismatch Screen$")
    public void verifyTheSystemIsNavigatedToDetailsOfDownPaymentSourcesScreenWhenNoEditTheDetailsOfMyDownPaymentSourcesIsClickedInDownPaymentMismatchScreen() throws Throwable {

        DownPaymentMismatchButton2.click();
        detailsOfDownPaymentHeader.isPresent();
        String DetailsOfDownPaymentHeader = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_ExpectedData",testCaseID , "Down_Payment_Header");
        Assert.assertEquals(detailsOfDownPaymentHeader.getText(), DetailsOfDownPaymentHeader,"Not able to view the text Total down payment amount: Text");

    }
}
