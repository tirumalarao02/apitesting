package com.scotiabank.ehome.ui.steps.stage2;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import com.qmetry.qaf.automation.step.QAFTestStepProvider;
import com.qmetry.qaf.automation.ui.WebDriverTestBase;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebDriver;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.quantum.utils.ConfigurationUtils;
import com.scotiabank.ehome.ui.steps.CommonApplicationMethods;
import com.scotiabank.ehome.ui.steps.Utility;

import cucumber.api.PendingException;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

@QAFTestStepProvider

public class TotalDownPaymentSources {
	
	private QAFExtendedWebDriver webDriver = null;
    public Actions action = null;
    public WebDriverWait wait=null;
    
    
    static String curDir = System.getProperty("user.dir");
    static String strfullPathToFile = curDir + "\\src\\main\\resources\\data\\eHomeTestData.xlsx"; // File Path
      
    static String  strErrMesgsSheet = "CommonErrorMessages";
    static String  strCommonObjects = "CommonObjects";
    static String  strTotalDownPaymentSheet = "TotalDownPayment";
    static String strPurchasePriceSheet = "Purchase_Price";
    
           @Given("^Customer should login and navigate to Down Payment Screen$")
           public void CustomershouldloginandnavigatetoDownPaymentScreen() throws Throwable {
         	   webDriver = new WebDriverTestBase().getDriver();
               webDriver.get(ConfigurationUtils.getBaseBundle ().getPropertyValue ( "env.baseurl1" ) );
               webDriver.manage().window().maximize();
               //To click Continue in Section breaker
                
               Thread.sleep(1000);
           	QAFExtendedWebElement ContinueStage2Section= new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[2]/div/div[3]/div/button/span");
           	ContinueStage2Section.click();
           	Thread.sleep(1000);
           	CommonApplicationMethods.enterAddressManually();
           	Thread.sleep(1000);
           	QAFExtendedWebElement TypeofPropertyOption= new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[1]/section/div[3]/div/fieldset/div/span[1]/label/span[2]/span");
           	TypeofPropertyOption.click();
           	Thread.sleep(3000);
           	QAFExtendedWebElement TypeofHouseOption= new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[1]/section/div[3]/div/fieldset/div/span[1]/label");
           	TypeofHouseOption.click();
           	Thread.sleep(1000);
       	                   
           	QAFExtendedWebElement ValueAreaofProperty= new QAFExtendedWebElement("//*[@id=\"sqFeet\"]");
           	ValueAreaofProperty.sendKeys("5000");
           	Thread.sleep(1000);
           	
           	QAFExtendedWebElement Continue3 = new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[2]/button[2]");
           	Continue3.click();
           	Thread.sleep(1000);
       	        	   
           	// Enter Amount More than Zero into purchase price text field in Purchase Price screen 
           	QAFExtendedWebElement ValuePurchasePrice= new QAFExtendedWebElement("ehome.PurchasePrice.inputtextbox");
           	ValuePurchasePrice.sendKeys("1000");
       	    Thread.sleep(3000);
       	                  
       	    QAFExtendedWebElement PurchasePriceContinue = new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[2]/button[2]");
       	    PurchasePriceContinue.click();
       	    Thread.sleep(3000);
             }
           
                 
         @Then("^Down Payment Title screen with title \"([^\"]*)\" is present$")
         public void Verify_Display_DownPayment_Title(String expectedText) throws Throwable {
             List<String> ExcelData = Utility.ExcelData(strfullPathToFile, strTotalDownPaymentSheet, expectedText);
             String Expected_ErrorMessages =ExcelData.get(1);
        	   QAFExtendedWebElement ActualErrMsg= new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[1]/section/div[2]/div/p");
         	   Assert.assertEquals(ActualErrMsg.getText(), Expected_ErrorMessages,"Expected and Actual Error Message is NOT Matched");
         }
           
        @And("^OK label as \"([^\"]*)\" is present$")
         public void Ok_label_is_present(String expectedText) throws Throwable {
       	   List<String> ExcelData = Utility.ExcelData(strfullPathToFile, strTotalDownPaymentSheet, expectedText) ;
      	   String Expected_ErrorMessages =ExcelData.get(1); 
       	   QAFExtendedWebElement ActualErrMsg= new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[1]/section/div[1]/h2");
      	   Assert.assertEquals(ActualErrMsg.getText(), Expected_ErrorMessages,"Expected and Actual Error Message is NOT Matched");
    }
         
         @And("^DownPayment input box is present with \"([^\"]*)\" symbol$")
         public void DownPayment_input_box_is_present_with_$_symbol(String expectedText) throws Throwable {
              QAFExtendedWebElement DownPaymentInput= new QAFExtendedWebElement("//*[@id=\"downPayment\"]");
             if(!DownPaymentInput.verifyPresent())
                 throw new AssertionError("Couldn't find DownPayment Input Box");
             
             List<String> ExcelData = Utility.ExcelData(strfullPathToFile, strCommonObjects, expectedText) ;
        	   String Expected_ErrorMessages =ExcelData.get(1); 
         	   QAFExtendedWebElement ActualErrMsg= new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[1]/section/div[3]/div/div/div/div/span/span[1]");
        	   Assert.assertEquals(ActualErrMsg.getText(), Expected_ErrorMessages,"Expected and Actual Error Message is NOT Matched");
         }   
   
         @And("^Bulb symbol is present$")
         public void Bulb_symbol_is_present() throws Throwable {
             // Write code here that turns the phrase above into concrete actions
     	  //     Thread.sleep(3000);
             QAFExtendedWebElement BulbSymbol= new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[1]/section/div[5]/div/div/div[1]/img");
               if(!BulbSymbol.verifyPresent())
                 throw new AssertionError("Couldn't find Bulb Symbol");
         }
         
            
        @And("^Bulb Symbol Text as \"([^\"]*)\" is present in DownPayment$")
             public void Bulb_SymboltoolTip_Content_present_in_DownPayment(String expectedText) throws Throwable {
               List<String> ExcelData = Utility.ExcelData(strfullPathToFile, strTotalDownPaymentSheet, expectedText) ;
          	   String Expected_ErrorMessages =ExcelData.get(1); 
          	  QAFExtendedWebElement ActualErrMsg= new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[1]/section/div[5]/div/div/div[2]");
           	   Assert.assertEquals(ActualErrMsg.getText(), Expected_ErrorMessages,"Expected and Actual Error Message is NOT Matched");
             }
        
        
       @And("^Back button in Down Payment Screen as \"([^\"]*)\" is present$")
                 public void Back_button_is_Present_in_DownPaymentScreen(String expectedText) throws Throwable {
                     // Write code here that turns the phrase above into concrete actions
                   List<String> exceldata = Utility.ExcelData(strfullPathToFile, strCommonObjects, expectedText) ;
              	   String Expected_ErrorMessages =exceldata.get(1); 
              	   QAFExtendedWebElement ActualErrMsg= new QAFExtendedWebElement("ehome.PurchasePrice.Backbutton");  
              	   Assert.assertEquals(ActualErrMsg.getText(), Expected_ErrorMessages,"Expected and Actual Error Message is NOT Matched");
                  }
         
         
         @And("^Down payment requirements hyperlink as \"([^\"]*)\" is present$")
       public void Down_Payment_requirements_hyperlink(String expectedText) throws Throwable {
           // Write code here that turns the phrase above into concrete actions
         List<String> exceldata = Utility.ExcelData(strfullPathToFile, strTotalDownPaymentSheet, expectedText) ;
    	   String Expected_ErrorMessages =exceldata.get(1); 
    	   QAFExtendedWebElement ActualErrMsg= new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[1]/section/div[6]/button/span");  
    	   Assert.assertEquals(ActualErrMsg.getText(), Expected_ErrorMessages,"Expected and Actual Error Message is NOT Matched");
         ActualErrMsg.click();
         Thread.sleep(2000);
        
       }
           
         @And("^Down payment requirements Title as \"([^\"]*)\" is present$")
       public void Down_Payment_requirements_Title(String expectedText) throws Throwable {
           // Write code here that turns the phrase above into concrete actions
         List<String> exceldata = Utility.ExcelData(strfullPathToFile, strTotalDownPaymentSheet, expectedText) ;
    	   String Expected_ErrorMessages =exceldata.get(1); 
     	   QAFExtendedWebElement ActualErrMsg= new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[3]/div/div/div[2]/div/div[1]/div/h3");  
    	   Assert.assertEquals(ActualErrMsg.getText(), Expected_ErrorMessages,"Expected and Actual Error Message is NOT Matched");
          }
         
         @And("^Down payment requirements Description as \"([^\"]*)\" is present$")
         public void Down_Payment_requirements_Description(String expectedText) throws Throwable {
             // Write code here that turns the phrase above into concrete actions
           List<String> exceldata = Utility.ExcelData(strfullPathToFile, strTotalDownPaymentSheet, expectedText) ;
      	   String Expected_ErrorMessages =exceldata.get(1);                
      	   QAFExtendedWebElement ActualErrMsg= new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[3]/div/div/div[2]/div/div[2]/div/p");  
      	   Assert.assertEquals(ActualErrMsg.getText(), Expected_ErrorMessages,"Expected and Actual Error Message is NOT Matched");
            }
 
         @And("^Less than or equal expanded button as \"([^\"]*)\" is present$")
         public void Less_than_or_equal_to_$500000_expanded_button(String expectedText) throws Throwable {
             // Write code here that turns the phrase above into concrete actions
           List<String> exceldata = Utility.ExcelData(strfullPathToFile, strTotalDownPaymentSheet, expectedText) ;
      	   String Expected_ErrorMessages =exceldata.get(1); 
      	
      	  // QAFExtendedWebElement ActualErrMsg= new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[3]/div/div[2]/div/div[3]/div/div/div[1]/button");  
      	 QAFExtendedWebElement ActualErrMsg= new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[3]/div/div/div[2]/div/div[3]/div/div/div[1]/button");
      	   Assert.assertEquals(ActualErrMsg.getText(), Expected_ErrorMessages,"Expected and Actual Error Message is NOT Matched");
            }
         
         @And("^Greater than and less than expanded button as \"([^\"]*)\" is present$")
         public void Greater_than_and_less_than_expanded_button(String expectedText) throws Throwable {
             // Write code here that turns the phrase above into concrete actions
           List<String> exceldata = Utility.ExcelData(strfullPathToFile, strTotalDownPaymentSheet, expectedText) ;
      	   String Expected_ErrorMessages =exceldata.get(1); 
      	
      	 QAFExtendedWebElement ActualErrMsg= new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[3]/div/div/div[2]/div/div[3]/div/div/div[2]/button");
      	  // QAFExtendedWebElement ActualErrMsg= new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[3]/div/div[2]/div/div[3]/div/div/div[2]/button");  
      	   Assert.assertEquals(ActualErrMsg.getText(), Expected_ErrorMessages,"Expected and Actual Error Message is NOT Matched");
             }
         
         @And("^OneMillion or More expanded button as \"([^\"]*)\" is present$")
         public void OneMillion_or_More_expanded_button_as_expanded_button(String expectedText) throws Throwable {
             // Write code here that turns the phrase above into concrete actions
           List<String> exceldata = Utility.ExcelData(strfullPathToFile, strTotalDownPaymentSheet, expectedText) ;
      	   String Expected_ErrorMessages =exceldata.get(1); 
      	
      	 QAFExtendedWebElement ActualErrMsg= new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[3]/div/div/div[2]/div/div[3]/div/div/div[3]/button");
      	 //  QAFExtendedWebElement ActualErrMsg= new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[3]/div/div[2]/div/div[3]/div/div/div[3]/button");  
      	   Assert.assertEquals(ActualErrMsg.getText(), Expected_ErrorMessages,"Expected and Actual Error Message is NOT Matched");
           }	
         
         @And("^More about Mortgage Default Insurance and how its calculated Text as \"([^\"]*)\" is present$")
         public void More_about_Mortg_Default_Ins_and_itscalculated_Text(String expectedText) throws Throwable {
             // Write code here that turns the phrase above into concrete actions
           List<String> exceldata = Utility.ExcelData(strfullPathToFile, strTotalDownPaymentSheet, expectedText) ;
      	   String Expected_ErrorMessages =exceldata.get(1); 
      	 QAFExtendedWebElement ActualErrMsg= new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[3]/div/div/div[2]/div/div[4]/div/p");
      	 //  QAFExtendedWebElement ActualErrMsg= new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[3]/div/div[2]/div/div[4]/div/p");  
      	   Assert.assertEquals(ActualErrMsg.getText(), Expected_ErrorMessages,"Expected and Actual Error Message is NOT Matched");
          }	
         
         @And("^Click here hyperlink as \"([^\"]*)\" is present in DownPaymentReqs$")
         public void Click_here_hyperlink_DownPaymtReqs(String expectedText) throws Throwable {
             // Write code here that turns the phrase above into concrete actions
        	
        	 QAFExtendedWebElement Clickherehyperlink= new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[3]/div/div/div[2]/div/div[4]/div/p/a/span"); 
       	  // QAFExtendedWebElement Clickherehyperlink= new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[3]/div/div[2]/div/div[4]/div/p/a/span");  
        	 if(!Clickherehyperlink.verifyPresent())
                 throw new AssertionError("Couldn't find click here hyperlink");
             Thread.sleep(5000);
           }	
         
        
         @When("^click on Less than or equal expanded button in DownPaymentReqs$")
         public void click_on_Less_than_or_equal_expanded_button_in_DownPaymentReqs() throws Throwable {
             // Write code here that turns the phrase above into concrete actions                      
       	   //QAFExtendedWebElement Less_than_or_equal_to_$500K_expandedBtn= new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[3]/div/div[2]/div/div[3]/div/div/div[1]/button");  
        	 QAFExtendedWebElement Less_than_or_equal_to_$500K_expandedBtn= new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[3]/div/div/div[2]/div/div[3]/div/div/div[1]/button");
        	 Less_than_or_equal_to_$500K_expandedBtn.click();
       	  Thread.sleep(3000);
     
           }  
         
         @Then("^Less_than_or_equal_expanded_Text as \"([^\"]*)\" is present$")
         public void Verify_Less_than_or_equal_expanded_Text(String expectedText) throws Throwable {
             // Write code here that turns the phrase above into concrete actions
        	 List<String> exceldata = Utility.ExcelData(strfullPathToFile, strTotalDownPaymentSheet, expectedText) ;
    	   String Expected_ErrorMessages =exceldata.get(1);
    	   QAFExtendedWebElement ActualErrMsg= new QAFExtendedWebElement("//*[@id=\"Less than or equal to $500,000\"]/div/p");
    	   //QAFExtendedWebElement ActualErrMsg= new QAFExtendedWebElement("//*[@id=\"Less than or equal to $500,000\"]/p");  
    	   Assert.assertEquals(ActualErrMsg.getText(), Expected_ErrorMessages,"Expected and Actual Error Message is NOT Matched");
    	   Thread.sleep(3000);
     
           }  
         
         @Then("^Less_than_or_equal_expanded_Text as \"([^\"]*)\" is NOT present$")
         public void Verify_Less_than_or_equal_expanded_TextNOT(String expectedText) throws Throwable {
             // Write code here that turns the phrase above into concrete actions
       // 	 List<String> exceldata = Utility.ExcelData(strfullPathToFile, strTotalDownPaymentSheet, expectedText) ;
    	//   String Expected_ErrorMessages =exceldata.get(1);
        	 String Expected_ErrorMessages = "";
        	 QAFExtendedWebElement ActualErrMsg= new QAFExtendedWebElement("//*[@id=\"Less than or equal to $500,000\"]/div/p");
    	   //QAFExtendedWebElement ActualErrMsg= new QAFExtendedWebElement("//*[@id=\"Less than or equal to $500,000\"]/p");  
    	   Assert.assertEquals(ActualErrMsg.getText(), Expected_ErrorMessages,"Expected and Actual Error Message is NOT Matched");
    	   Thread.sleep(3000);
            }  
         
         
         @When("^click on Greater than and less than expanded button in DownPaymentReqs$")
         public void click_on_Greater_than_and_less_than_expanded_button_in_DownPaymentReqs() throws Throwable {
             // Write code here that turns the phrase above into concrete actions
       	//   QAFExtendedWebElement Greater_than_and_less_than_expanded_button= new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[3]/div/div[2]/div/div[3]/div/div/div[2]/button");  
       	QAFExtendedWebElement Greater_than_and_less_than_expanded_button= new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[3]/div/div/div[2]/div/div[3]/div/div/div[2]/button");
       	   Greater_than_and_less_than_expanded_button.click();
       	Thread.sleep(3000);
      
           }  
         
         @Then("^Greater than and less than expanded button Text as \"([^\"]*)\" is present$")
         public void Verify_Greater_than_and_less_than_expanded_Text(String expectedText) throws Throwable {
             // Write code here that turns the phrase above into concrete actions
        	 List<String> exceldata = Utility.ExcelData(strfullPathToFile, strTotalDownPaymentSheet, expectedText) ;
    	   String Expected_ErrorMessages =exceldata.get(1);
    	   //QAFExtendedWebElement ActualErrMsg= new QAFExtendedWebElement("//*[@id=\"Greater than $500,000 and less than $1 million\"]/p"); 
    	   QAFExtendedWebElement ActualErrMsg= new QAFExtendedWebElement("//*[@id=\"Greater than $500,000 and less than $1 million\"]/div/p");
    	   Assert.assertEquals(ActualErrMsg.getText(), Expected_ErrorMessages,"Expected and Actual Error Message is NOT Matched");
    	   Thread.sleep(3000);
    	 
           }  
         
         @Then("^Greater than and less than expanded button Text as \"([^\"]*)\" is NOT present$")
         public void Verify_Greater_than_and_less_than_expanded_TextNOT(String expectedText) throws Throwable {
             // Write code here that turns the phrase above into concrete actions
       // 	 List<String> exceldata = Utility.ExcelData(strfullPathToFile, strTotalDownPaymentSheet, expectedText) ;
    	//   String Expected_ErrorMessages =exceldata.get(1);
        	 String Expected_ErrorMessages = "";
        	 QAFExtendedWebElement ActualErrMsg= new QAFExtendedWebElement("//*[@id=\"Greater than $500,000 and less than $1 million\"]/div/p");
    	  // QAFExtendedWebElement ActualErrMsg= new QAFExtendedWebElement("//*[@id=\"Greater than $500,000 and less than $1 million\"]/p");  
    	   Assert.assertEquals(ActualErrMsg.getText(), Expected_ErrorMessages,"Expected and Actual Error Message is NOT Matched");
    	   Thread.sleep(3000);
     
           }  
         
         
       @When("^click on one million or more expanded button in DownPaymentReqs$")
       public void click_on_one_million_or_more_expanded_button_in_DownPaymentReqs() throws Throwable {
           // Write code here that turns the phrase above into concrete actions
    	 
    	   QAFExtendedWebElement OneMillionBtn= new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[3]/div/div/div[2]/div/div[3]/div/div/div[3]/button");
     	  // QAFExtendedWebElement OneMillionBtn= new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[3]/div/div[2]/div/div[3]/div/div/div[3]/button");  
     	   OneMillionBtn.click();
     	  Thread.sleep(3000);
   
         }  
       
       @Then("^one million or more expanded button Text as \"([^\"]*)\" is present$")
       public void Verify_one_million_or_more_expanded_Text(String expectedText) throws Throwable {
           // Write code here that turns the phrase above into concrete actions
      	 List<String> exceldata = Utility.ExcelData(strfullPathToFile, strTotalDownPaymentSheet, expectedText) ;
  	   String Expected_ErrorMessages =exceldata.get(1);
  	
  	 //  QAFExtendedWebElement ActualErrMsg= new QAFExtendedWebElement("//*[@id=\"$1 million or more\"]/p");
  	 QAFExtendedWebElement ActualErrMsg= new QAFExtendedWebElement("//*[@id=\"$1 million or more\"]/div/p");  
  	   Assert.assertEquals(ActualErrMsg.getText(), Expected_ErrorMessages,"Expected and Actual Error Message is NOT Matched");
  	 Thread.sleep(3000);
   
         }  
       
       @Then("^one million or more expanded button Text as \"([^\"]*)\" is NOT present$")
       public void Verify_one_million_or_more_expanded_TextNOT(String expectedText) throws Throwable {
           // Write code here that turns the phrase above into concrete actions
     // 	 List<String> exceldata = Utility.ExcelData(strfullPathToFile, strTotalDownPaymentSheet, expectedText) ;
  	//   String Expected_ErrorMessages =exceldata.get(1);
      	 String Expected_ErrorMessages = "";
  	  // QAFExtendedWebElement ActualErrMsg= new QAFExtendedWebElement("//*[@id=\"$1 million or more\"]/p");
      	QAFExtendedWebElement ActualErrMsg= new QAFExtendedWebElement("//*[@id=\"$1 million or more\"]/div/p");  
  	   Assert.assertEquals(ActualErrMsg.getText(), Expected_ErrorMessages,"Expected and Actual Error Message is NOT Matched");
  	 Thread.sleep(3000);
   
         }  
         
       @And("^Close button as \"([^\"]*)\" is present and Click on Close button in DownPaymentReqs$")
       public void Close_button_DownPaymtReqs(String expectedText) throws Throwable {
           // Write code here that turns the phrase above into concrete actions
      	 
      	 List<String> exceldata = Utility.ExcelData(strfullPathToFile, strTotalDownPaymentSheet, expectedText) ;
      	   String Expected_ErrorMessages =exceldata.get(1); 
      	
             // QAFExtendedWebElement CloseBtn= new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[3]/div/div[1]/button"); 
              QAFExtendedWebElement CloseBtn= new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[3]/div/div/div[1]/button");  
      	   Assert.assertEquals(CloseBtn.getText(), Expected_ErrorMessages,"Expected and Actual Error Message is NOT Matched");
              CloseBtn.click();
     	 
        }	
       
       @And("^Verify click here hyperlink button and functionality$")
       public void click_here_hyperlink_button_and_functionality() throws Throwable {
           // Write code here that turns the phrase above into concrete actions
    	   Thread.sleep(250);
     	   QAFExtendedWebElement clickhereBtn= new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[3]/div/div/div[2]/div/div[4]/div/p/a/span");
    	    if(!clickhereBtn.verifyPresent())
            throw new AssertionError("Couldn't find click here Button");
    	  	clickhereBtn.click();
        }	
       
       @Then("^Click Back button and Verify Purchase Price screen \"([^\"]*)\" is present$")
       public void Click_Back_button_and_Verify_Purchase_Price_screen_is_present(String expectedText) throws Throwable {
    	   QAFExtendedWebElement BackBtn= new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[2]/button[1]/span");
    	   BackBtn.click();
    	   Thread.sleep(250);
           List<String> ExcelData = Utility.ExcelData(strfullPathToFile, strPurchasePriceSheet, expectedText);
           String Expected_ErrorMessages =ExcelData.get(1);
      	   QAFExtendedWebElement ActualErrMsg= new QAFExtendedWebElement("ehome.PurchasePrice.title");
       	   Assert.assertEquals(ActualErrMsg.getText(), Expected_ErrorMessages,"Purchase Price Title is NOT as expected.");
       }
       
       @When("^Click on Continue button in downpayment screen$")
       public void Click_Continue_button_in_downpayment_screen() throws Throwable {
    	   QAFExtendedWebElement ContinueBtn= new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[2]/button[2]/span");
    	   ContinueBtn.click();
    	   Thread.sleep(250);
           }
       
       
       @Then("^Verify valid error message \"([^\"]*)\" without downpayment amount$")
       public void Verify_valid_error_message_without_downpayment_amount(String expectedText) throws Throwable {
           List<String> ExcelData = Utility.ExcelData(strfullPathToFile, strTotalDownPaymentSheet, expectedText);
           String Expected_ErrorMessages =ExcelData.get(1);
      	   QAFExtendedWebElement ActualErrMsg= new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[1]/section/div[2]/div[2]/div/div/div[2]/p");
       	   Assert.assertEquals(ActualErrMsg.getText(), Expected_ErrorMessages,"Please fill a valid downpayment amount.Err message is NOT as expected.");
       }
    
        
  }