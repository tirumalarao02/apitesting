package com.scotiabank.ehome.ui.steps.stage1;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.step.QAFTestStepProvider;
import com.qmetry.qaf.automation.ui.WebDriverTestBase;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebDriver;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.quantum.utils.ConfigurationUtils;
import com.scotiabank.ehome.ui.steps.Common;
import com.scotiabank.ehome.ui.steps.ExcelDataToDataTable;
import com.scotiabank.ehome.ui.steps.Utility;
import com.scotiabank.ehome.ui.steps.valueObjects.Tuple;
import com.scotiabank.ehome.ui.steps.valueObjects.TypeOfRateVO;
import com.thoughtworks.qdox.model.expression.Add;

import org.junit.runner.RunWith;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;

import cucumber.api.CucumberOptions;
import cucumber.api.DataTable;
import cucumber.api.PendingException;
import cucumber.api.Transform;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import cucumber.api.junit.Cucumber;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import static com.scotiabank.ehome.ui.steps.BusinessCalculations.*;
import static com.scotiabank.ehome.ui.steps.Utility.*;

import org.openqa.selenium.Keys;
@QAFTestStepProvider

public class MaritalStatus {
	public static WebDriverWait wait=Utility.getWait();	
	@Given("^Customer should login and navigates to marital status screen$")
	public void customer_should_login_and_navigates_to_marital_status_screen() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Utility.launchURL(ConfigurationUtils.getBaseBundle().getPropertyValue ("env.baseurl0"));
		Welcome.viewOurPrivacyAgreementButtonClicked();
		PrivacyAgreement.acceptAndContinuetButtonClicked();
		SOLCustomerQuestion.triageQuestionsButtonClicked();
	    SOLCustomerQuestion.noButtonClicked();
//	    String value1=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage01_Registration_ExpectedDa","Legal-Name-TC-008" , "Title");
//		String value2=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage01_Registration_ExpectedDa","Legal-Name-TC-008" , "LegalFirstName");
//		String value3=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage01_Registration_ExpectedDa","Legal-Name-TC-008" , "MiddleInitial");
//		String value4=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage01_Registration_ExpectedDa","Legal-Name-TC-008", "LegalLastName");
//		LegalName.validlegalname(value1, value2, value3,value4);
		LegalName.validlegalname("Mrs", "Delna", "Dr", "Press");
	    Common.continueButtonClicked();
	   
	}

	@When("^Verify \"([^\"]*)\" message should be on the marital status screen$")
	public void verify_message_should_be_on_the_marital_status_screen(String dataPointer) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String testCaseID = Utility.getScenarioID();
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage01_Registration_ExpectedDa", testCaseID, dataPointer);
		QAFExtendedWebElement message= new QAFExtendedWebElement("ehome.MaritalStatus.message");
		 wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(message));
		 Assert.assertEquals(message.getText(), value,"Couldn't found expected header message");
	   
	}

	@Then("^Verify \"([^\"]*)\" headertext should be on marital status screen$")
	public void verify_headertext_should_be_on_marital_status_screen(String dataPointer) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String testCaseID = Utility.getScenarioID();
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage01_Registration_ExpectedDa", testCaseID, dataPointer);
		QAFExtendedWebElement title= new QAFExtendedWebElement("ehome.MaritalStatus.Title");
		 wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(title));
		Assert.assertEquals(title.getText(), value,"Couldn't found expected header message");
	   
	}

	 public static void maritalstatusselect(String value1) throws InterruptedException {
		 QAFExtendedWebElement maritalstatus= new QAFExtendedWebElement("ehome.MaritalStatus.Status");
			wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(maritalstatus));
			maritalstatus.click();
			Thread.sleep(2000);
			Select maritalstatusSelect = new Select(maritalstatus);
			maritalstatusSelect.selectByVisibleText(value1);
					
		 }


	@When("^Select title from the drop down in marital status screen$")
	public void select_title_from_the_drop_down_in_marital_status_screen() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		QAFExtendedWebElement maritalstatus= new QAFExtendedWebElement("ehome.MaritalStatus.Status");
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(maritalstatus));
		maritalstatus.click();
		Thread.sleep(2000);
		Select maritalstatusSelect = new Select(maritalstatus);
		maritalstatusSelect.selectByVisibleText("Married");
		maritalstatusSelect.selectByVisibleText("Single");
		maritalstatusSelect.selectByVisibleText("Divorced");
		maritalstatusSelect.selectByVisibleText("Widowed");
		maritalstatusSelect.selectByVisibleText("Common-law");
		maritalstatusSelect.selectByVisibleText("Separated");
	}



}
