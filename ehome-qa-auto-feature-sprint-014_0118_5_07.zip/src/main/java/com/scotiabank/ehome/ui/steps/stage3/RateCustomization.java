package com.scotiabank.ehome.ui.steps.stage3;

import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.qmetry.qaf.automation.step.QAFTestStepProvider;
import com.qmetry.qaf.automation.ui.WebDriverTestBase;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebDriver;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.quantum.utils.ConfigurationUtils;
import com.scotiabank.ehome.ui.steps.valueObjects.TypeOfRateVO;

import cucumber.api.PendingException;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import static com.scotiabank.ehome.ui.steps.Utility.*;
@QAFTestStepProvider
public class RateCustomization {
	
	private QAFExtendedWebDriver webDriver = null;
    public Actions action = null;
    public WebDriverWait wait=null;
    
	
    @Given("^Customer should login and navigates to Rate Customization by selecting \"([^\"]*)\"$")
    public void Customer_should_login_and_navigates_to_Rate_Customization_Screen(String expectedText) throws Throwable {
   	    	// Write code here that turns the phrase above into concrete actions
    	if (expectedText.contentEquals("fixed")) {
   	           	webDriver = new WebDriverTestBase().getDriver();
   	            webDriver.get(ConfigurationUtils.getBaseBundle().getPropertyValue("env.baseurl"));
   	            webDriver.manage().window().maximize();
   	            QAFExtendedWebElement buttonContinue= new QAFExtendedWebElement("ehome.rate.continue.button");
   	            buttonContinue.click();
   	           // Actions action = new Actions(webDriver);
   	            //WebDriverWait wait = new WebDriverWait(webDriver, 10);
   	            QAFExtendedWebElement whatTypeOfRate = new QAFExtendedWebElement("ehome.typeofrate.header");
   	            if (!whatTypeOfRate.verifyText("What type of rate are you looking for?"))
   	                throw new AssertionError("Not able to launch what type of rate page");
   	            QAFExtendedWebElement selectFixed= new QAFExtendedWebElement("ehome.typeofrate.selectfixed.radio");
   	            selectFixed.click ();
   	            Thread.sleep(3000);
   	            QAFExtendedWebElement twoyears= new QAFExtendedWebElement("ehome.termsofrate.2years.radio");
   	            if(!twoyears.verifyPresent())
   	                throw new AssertionError("Couldn't find 2 years button");
   	            twoyears.click();
   	            QAFExtendedWebElement twoyear= new QAFExtendedWebElement("ehome.ratepresentation.twoyears.select");
   		        if(!twoyear.verifyPresent())
   		            throw new AssertionError("Couldn't find 2 years button");
   		        twoyear.click();  
   		     QAFExtendedWebElement LockandHold= new QAFExtendedWebElement("ehome.ratelock.LockandHold");
   	        if(!LockandHold.verifyPresent())
   	            throw new AssertionError("Couldn't find Lock & Hold on the screen");
   	        LockandHold.click();
	   	     Thread.sleep(2000);
	    	 QAFExtendedWebElement RateCustomizationHeader= new QAFExtendedWebElement("ehome.RateCustomization.Unlockyourrate");
	    	 Assert.assertEquals(RateCustomizationHeader.getText(), "Unlock your rate");
	    	// TypeOfRateVO.getInstance().setTypeOfRate(TypeOfRateVO.TYPE_OF_RATE_FIXED_RATE);
	   	    }
    	else if (expectedText.contentEquals("variable")) {
            webDriver = new WebDriverTestBase().getDriver();
            webDriver.get(ConfigurationUtils.getBaseBundle().getPropertyValue("env.baseurl"));
            webDriver.manage().window().maximize();
            QAFExtendedWebElement buttonContinue = new QAFExtendedWebElement("ehome.rate.continue.button");
            buttonContinue.click();
            // Actions action = new Actions(webDriver);
            // WebDriverWait wait = new WebDriverWait(webDriver, 10);
            QAFExtendedWebElement typeofrate = new QAFExtendedWebElement("ehome.typeofrate.header");
            if (!typeofrate.verifyText("What type of rate are you looking for?"))
                throw new AssertionError("Not able to launch what type of rate page");
            QAFExtendedWebElement selectVariable = new QAFExtendedWebElement(
                    "ehome.typeofrate.selectvariable.radio");
            selectVariable.click();
            QAFExtendedWebElement twoyear= new QAFExtendedWebElement("ehome.ratepresentation.twoyears.select");
		        if(!twoyear.verifyPresent())
		            throw new AssertionError("Couldn't find 2 years button");
		        twoyear.click();  
		     QAFExtendedWebElement LockandHold= new QAFExtendedWebElement("ehome.ratelock.LockandHold");
	        if(!LockandHold.verifyPresent())
	            throw new AssertionError("Couldn't find Lock & Hold on the screen");
	        LockandHold.click();
   	     Thread.sleep(2000);
    	 QAFExtendedWebElement RateCustomizationHeader= new QAFExtendedWebElement("ehome.RateCustomization.Unlockyourrate");
    	 Assert.assertEquals(RateCustomizationHeader.getText(), "Unlock your rate");
         // TypeOfRateVO.getInstance().setTypeOfRate(TypeOfRateVO.TYPE_OF_RATE_VARIABLE_RATE);
        }
    	
    }
    
  //Scenario: Rate_Customization_003
    
    
    @When("^Verify \"([^\"]*)\" \"([^\"]*)\" in Rate Customization Screen$")
    public void  Verify_Your_rate_is_locked_and_will_be_guaranteed_until_in_Rate_Customization_Screen(String expectedText1,String expectedText2) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	QAFExtendedWebElement term= new QAFExtendedWebElement("ehome.RateCustomization.term.text");
    	Assert.assertEquals(term.getText(), expectedText1,"Couldn't find 'Term:'");
    	TypeOfRateVO typeOfRateVO = TypeOfRateVO.getInstance();
    	QAFExtendedWebElement yearsClosed= new QAFExtendedWebElement("ehome.RateCustomization.yearsClosed.text");
        Assert.assertEquals(getYearsClosedToNumber(yearsClosed.getText()), String.valueOf(typeOfRateVO.getNumberOfYears()),"Couldn't find '"+typeOfRateVO.getNumberOfYears()+" year closed'");
    	
        /*if (expectedText2.contentEquals("2 year closed")) {
	        QAFExtendedWebElement yearsClosed= new QAFExtendedWebElement("ehome.RateCustomization.yearsClosed.text");
	        Assert.assertEquals(getYearsClosedToNumber(yearsClosed.getText()), String.valueOf(typeOfRateVO.getNumberOfYears()),"Couldn't find '"+typeOfRateVO.getNumberOfYears()+" year closed'");
    	 /*}*/
    	 /*else if (expectedText2.contentEquals("3 year closed")) {
    		QAFExtendedWebElement yearsClosed= new QAFExtendedWebElement("ehome.RateCustomization.yearsClosed.text");
 	        Assert.assertEquals(yearsClosed.getText(), expectedText2,"Couldn't find '3 year closed'");
			
		}
    	 else if (expectedText2.contentEquals("4 year closed")) {
    		QAFExtendedWebElement yearsClosed= new QAFExtendedWebElement("ehome.RateCustomization.yearsClosed.text");
 	        Assert.assertEquals(yearsClosed.getText(), expectedText2,"Couldn't find '4 year closed'");
			
		}
    	 else if (expectedText2.contentEquals("5 year closed")) {
    		QAFExtendedWebElement yearsClosed= new QAFExtendedWebElement("ehome.RateCustomization.yearsClosed.text");
 	        Assert.assertEquals(yearsClosed.getText(), expectedText2,"Couldn't find '5 year closed'");
			
		}*/
        
    }
    
    @Then("^\"([^\"]*)\" \"([^\"]*)\" should be displayed in Rate Customization Screen$")
    public void should_be_displayed_in_Rate_Customization_Screen(String expectedText1,String expectedText2) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	if (expectedText1.contentEquals("Fixed rate:")) {
	    	QAFExtendedWebElement rate= new QAFExtendedWebElement("ehome.RateCustomization.rate.text");
	    	Assert.assertEquals(rate.getText(), expectedText1,"Couldn't find 'Fixed rate:'");  
	    	TypeOfRateVO typeOfRateVO = TypeOfRateVO.getInstance();
	    	QAFExtendedWebElement ratePercentage= new QAFExtendedWebElement("ehome.RateCustomization.ratePercentage.text");
	        Assert.assertEquals(ratePercentage.getText(), typeOfRateVO.getRateOfInterest()+"%","Couldn't find '2.75%'");
    	}
    	else if (expectedText1.contentEquals("Variable rate:")) {
    		QAFExtendedWebElement rate= new QAFExtendedWebElement("ehome.RateCustomization.rate.text");
        	Assert.assertEquals(rate.getText(), expectedText1,"Couldn't find 'Variable rate:'"); 
        	TypeOfRateVO typeOfRateVO = TypeOfRateVO.getInstance();
        	QAFExtendedWebElement ratePercentage= new QAFExtendedWebElement("ehome.RateCustomization.ratePercentage.text");
            Assert.assertEquals(ratePercentage.getText(),"Prime - "+ typeOfRateVO.getRateOfInterest()+"%","Couldn't find 'Prime - 0.45%'");
    		
		}
    	
      
    	
    	/*if (expectedText2.contentEquals("2.75%")) {
	        QAFExtendedWebElement ratePercentage= new QAFExtendedWebElement("ehome.RateCustomization.ratePercentage.text");
	        Assert.assertEquals(ratePercentage.getText(), expectedText2,"Couldn't find '2.75%'");
    	 }
    	 else if (expectedText2.contentEquals("3.3%")) {
    		QAFExtendedWebElement ratePercentage= new QAFExtendedWebElement("ehome.RateCustomization.ratePercentage.text");
 	        Assert.assertEquals(ratePercentage.getText(), expectedText2,"Couldn't find '3.3%'");
			
		}
    	 else if (expectedText2.contentEquals("3.55%")) {
    		QAFExtendedWebElement ratePercentage= new QAFExtendedWebElement("ehome.RateCustomization.ratePercentage.text");
 	        Assert.assertEquals(ratePercentage.getText(), expectedText2,"Couldn't find '3.55%'");
			
		}
    	 else if (expectedText2.contentEquals("4.6%")) {
    		QAFExtendedWebElement ratePercentage= new QAFExtendedWebElement("ehome.RateCustomization.ratePercentage.text");
 	        Assert.assertEquals(ratePercentage.getText(), expectedText2,"Couldn't find '4.6%'");
			
		}
    	 else if (expectedText2.contentEquals("Prime - 0.45%")) {
     		QAFExtendedWebElement ratePercentage= new QAFExtendedWebElement("ehome.RateCustomization.ratePercentage.text");
  	        Assert.assertEquals(ratePercentage.getText(), expectedText2,"Couldn't find 'Prime - 0.45%'");
 			
 		}*/
    }
    
    @When("^Verify \"([^\"]*)\" and click on the Amortization period information icon in Rate Customization Screen$")
    public void verify_and_click_on_the_Amortization_period_information_icon_in_Rate_Customization_Screen(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	QAFExtendedWebElement amortizationPeriod= new QAFExtendedWebElement("ehome.RateCustomization.Amortizationperiod.text");
	    Assert.assertEquals(amortizationPeriod.getText(), arg1,"Couldn't find 'Amortization period'");
	    QAFExtendedWebElement amortizationPeriodInformation= new QAFExtendedWebElement("ehome.RateCustomization.Amortizationperiod.informationicon.button");
	    amortizationPeriodInformation.click();
	    QAFExtendedWebElement amortizationPeriodInformationClose= new QAFExtendedWebElement("ehome.RateCustomization.Amortizationperiod.informationicon.close.button");
	    amortizationPeriodInformationClose.click();
    }

    @Then("^Years and months selected by the customer should be displayed in Rate Customization Screen$")
    public void years_and_months_selected_by_the_customer_should_be_displayed_in_Rate_Customization_Screen() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        
    }

    @When("^Verify \"([^\"]*)\" and click on the Payment schedule information icon in Rate Customization Screen$")
    public void verify_and_click_on_the_Payment_schedule_information_icon_in_Rate_Customization_Screen(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	QAFExtendedWebElement paymentSchedule= new QAFExtendedWebElement("ehome.RateCustomization.Paymentschedule.text");
        Assert.assertEquals(paymentSchedule.getText(), arg1,"Couldn't find 'Payment schedule'");
	    QAFExtendedWebElement paymentScheduleInformation= new QAFExtendedWebElement("ehome.RateCustomization.Paymentschedule.informationicon.button");
	    paymentScheduleInformation.click();
	    QAFExtendedWebElement paymentScheduleInformationClose= new QAFExtendedWebElement("ehome.RateCustomization.Paymentschedule.informationicon.close.button");
	    paymentScheduleInformationClose.click();
       
    }

    @Then("^Schedule selected by the customer should be displayed in Rate Customization Screen$")
    public void schedule_selected_by_the_customer_should_be_displayed_in_Rate_Customization_Screen() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        
    }

    @When("^Verify \"([^\"]*)\" and click on the First payment date information icon in Rate Customization Screen$")
    public void verify_and_click_on_the_First_payment_date_information_icon_in_Rate_Customization_Screen(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	QAFExtendedWebElement firstPaymentDate= new QAFExtendedWebElement("ehome.RateCustomization.FirstPaymentDate.text");
        Assert.assertEquals(firstPaymentDate.getText(), arg1,"Couldn't find 'First payment date'");
	    QAFExtendedWebElement firstPaymentDateInformation= new QAFExtendedWebElement("ehome.RateCustomization.FirstPaymentDate.informationicon.button");
	    firstPaymentDateInformation.click();
	    QAFExtendedWebElement firstPaymentDateInformationClose= new QAFExtendedWebElement("ehome.RateCustomization.FirstPaymentDate.informationicon.close.button");
	    //firstPaymentDateInformationClose.click();
        
    }

    @Then("^Date selected by the customer should be displayed in Rate Customization Screen$")
    public void date_selected_by_the_customer_should_be_displayed_in_Rate_Customization_Screen() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        
    }
    @When("^Verify \"([^\"]*)\" and click on the Payment amount information icon in Rate Customization Screen$")
    public void verify_and_click_on_the_Payment_amount_information_icon_in_Rate_Customization_Screen(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	QAFExtendedWebElement paymentAmount= new QAFExtendedWebElement("ehome.RateCustomization.PaymentAmount.text");
	    Assert.assertEquals(paymentAmount.getText(), arg1,"Couldn't find 'Amortization period'");
	    QAFExtendedWebElement paymentAmountInformation= new QAFExtendedWebElement("ehome.RateCustomization.PaymentAmount.informationicon.button");
	    paymentAmountInformation.click();
	    QAFExtendedWebElement paymentAmountInformationClose= new QAFExtendedWebElement("ehome.RateCustomization.PaymentAmount.informationicon.close.button");
	    paymentAmountInformationClose.click();
       
    }

    @Then("^Payment amount and schedule should be displayed in Rate Customization Screen$")
    public void payment_amount_and_schedule_should_be_displayed_in_Rate_Customization_Screen() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        
    }

    @And("^Years year term and Amortization periods should be displayed in Rate Customization Screen$")
    public void years_year_term_and_Amortization_periods_should_be_displayed_in_Rate_Customization_Screen() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        
    }



    
   

    
	
	
}
