package com.scotiabank.ehome.ui.steps.coApp;
import com.qmetry.qaf.automation.step.QAFTestStepProvider;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.quantum.utils.ConfigurationUtils;
import com.scotiabank.ehome.ui.steps.Common;
import com.scotiabank.ehome.ui.steps.Utility;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.support.ui.WebDriverWait;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;
import java.util.concurrent.TimeUnit;
import static com.scotiabank.ehome.ui.steps.Utility.*;


@QAFTestStepProvider
public class CoAppEmpStatus {
	 public static WebDriverWait wait=Utility.getWait();	
	  String testCaseID = Utility.getScenarioID();
	  @Given("^Customer should login and navigates to Co App Employment status$")
	  public void customer_should_login_and_navigates_to_Co_App_Employment_status() throws Throwable {
	      // Write code here that turns the phrase above into concrete actions
//			 String strtestCaseID = Utility.getScenarioID();
//		  if (strtestCaseID.contains("CoApp"))
//		  {
//			  Common.TraverseToNewHomeSectionBreaker();
//			  Thread.sleep(10000);
//			  Common.TraverseFromNewHomeToRateSectionBreaker(strtestCaseID,"Co-App_InputData");
//			  Common.TraverseRateSectionToEmploymentSectionBreaker();
//			  Common.TraverseFromEmploymentSectionToLandOnCoApplicantPage();
//			  CoAppIntro.startSectionButtonClicked();
//		  }
		Utility.launchURL(ConfigurationUtils.getBaseBundle().getPropertyValue ("env.baseurl3"));
		CoAppIntro.startSectionButtonClicked();
    
	}
	//Employment_Status_002
	  @When("^Verify \"([^\"]*)\" should be on the Co-App Employment status screen$")
	  public void verify_should_be_on_the_Co_App_Employment_status_screen(String dataPointer) throws Throwable {
	      // Write code here that turns the phrase above into concrete actions
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Co-App_ExpectedData", testCaseID, dataPointer);
		QAFExtendedWebElement headerMessage= new QAFExtendedWebElement("ehome.CoApp.HeaderMessage");
		 wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(headerMessage));
		Assert.assertEquals(headerMessage.getText(), value,"Couldn't found expected header text");
	}

	  @Then("^Verify \"([^\"]*)\" headertext should be on the Co-App Employment status screen$")
	  public void verify_headertext_should_be_on_the_Co_App_Employment_status_screen(String dataPointer) throws Throwable {
	      // Write code here that turns the phrase above into concrete actions
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Co-App_ExpectedData", testCaseID, dataPointer);
		Assert.assertEquals(Common.headertext(), value,"Couldn't found expected header text");
	    
	}
	//Employment_Status_003
	public static void employedButtonClicked() {
		QAFExtendedWebElement employed= new QAFExtendedWebElement("ehome.empstatus.employed.label");
       wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(employed));
	    employed.click();
	    
	}
	public static void unemployedButtonClicked() {
		QAFExtendedWebElement unemployed= new QAFExtendedWebElement("ehome.empstatus.unemployment.label");
       wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(unemployed));
       unemployed.click();
	}
	public static void retiredButtonClicked() {
		QAFExtendedWebElement employed= new QAFExtendedWebElement("ehome.empstatus.retired.label");
       wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(employed));
	    employed.click();
	}
	@When("^verify \"([^\"]*)\" button and click on it in Co-App Employment status screen$")
	public void verify_button_and_click_on_it_in_Co_App_Employment_status_screen(String dataPointer) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //TO click on Employed button is employment screen
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Co-App_ExpectedData", testCaseID, dataPointer);
		
			if(value.contentEquals("Employed")) {
				employedButtonClicked();
						
			}
			else if (value.contentEquals("Unemployed")) {
				unemployedButtonClicked();
				
			}
			else if (value.contentEquals("Retired")) {
				retiredButtonClicked();
			}
	        
	}
	@Then("^It should be highlighted with the check mark and navigate to Employment type screen and click continue button and check \"([^\"]*)\"$")
	public void it_should_be_highlighted_with_the_check_mark_and_navigate_to_Employment_type_screen_and_click_continue_button_and_check(String dataPointer) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		Thread.sleep(3000);
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Co-App_ExpectedData", testCaseID, dataPointer);
		Assert.assertEquals(Common.headertext(), value,"Couldn't found expected header text");
       //TO click on back button
		 Common.backButtonClicked();
       //TO check radio button Select should be highlighted with the check mark
          QAFExtendedWebElement employedchecked= new QAFExtendedWebElement("ehome.empstatus.employedchecked.input");
          String checked=employedchecked.getAttribute("checked");
          if(checked==null || !checked.contentEquals("true"))
              throw new AssertionError("Couldn't find the checked");
          QAFExtendedWebElement employed= new QAFExtendedWebElement("ehome.empstatus.employed.label");
          String color=employed.getCssValue("background-color");
          String hex = convertRGBToHex(color);
          Assert.assertEquals("#8230df",hex);
          System.out.println("HEX"+hex);
          if(!hex.contentEquals("#8230df"))
              throw new AssertionError("Select when cliked is not highlighted with #8230df color");
          //To check the continue button is there and it should be in red color and click on the continue button
          QAFExtendedWebElement continuebutton = new QAFExtendedWebElement("ehome.Continue.button");
          Assert.assertEquals(continuebutton.getText(), "Continue", "Contnue Button text does not matched");
          Assert.assertEquals(convertRGBToHex(continuebutton.getCssValue("color")), "#ed722", "Continue button not in Red color");
          continuebutton.click();
 	}

	@Then("^It should be highlighted with the check mark and navigate to Retired duration screen and click continue button and check \"([^\"]*)\"$")
	public void it_should_be_highlighted_with_the_check_mark_and_navigate_to_Retired_duration_screen_and_click_continue_button_and_check(String dataPointer) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		Thread.sleep(3000);
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Co-App_ExpectedData", testCaseID, dataPointer);
       Assert.assertEquals(Common.headertext(), value,"Couldn't found expected header text");
     //TO click on back button
		 Common.backButtonClicked();
      //TO check radio button Select should be highlighted with the check mark
          QAFExtendedWebElement retiredchecked= new QAFExtendedWebElement("ehome.empstatus.retiredchecked.input");
          String checked=retiredchecked.getAttribute("checked");
          if(checked==null || !checked.contentEquals("true"))
              throw new AssertionError("Couldn't find the checked");
          QAFExtendedWebElement retired= new QAFExtendedWebElement("ehome.empstatus.retired.label");
          String color=retired.getCssValue("background-color");
          String hex = convertRGBToHex(color);
          Assert.assertEquals("#8230df",hex);
          System.out.println("HEX"+hex);
          if(!hex.contentEquals("#8230df"))
              throw new AssertionError("Select when cliked is not highlighted with #8230df color");
          //To check the continue button is there and it should be in red color and click on the continue button
          QAFExtendedWebElement continuebutton = new QAFExtendedWebElement("ehome.Continue.button");
          Assert.assertEquals(continuebutton.getText(), "Continue", "Contnue Button text does not matched");
          Assert.assertEquals(convertRGBToHex(continuebutton.getCssValue("color")), "#ed722", "Continue button not in Red color");
          continuebutton.click();
	}
	@Then("^It should be highlighted with the check mark and navigate to Unemployment screen and click continue button and check \"([^\"]*)\"$")
	public void it_should_be_highlighted_with_the_check_mark_and_navigate_to_Sources_of_Income_screen_and_click_continue_button_and_check(String dataPointer) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		Thread.sleep(3000);
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Co-App_ExpectedData", testCaseID, dataPointer);
       QAFExtendedWebElement headertext= new QAFExtendedWebElement("ehome.Header.text");
       wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(headertext));
       Assert.assertEquals(headertext.getText(), value,"Couldn't found expected header text");
       
     //TO click on back button
          Common.backButtonClicked();
        //TO check radio button Select should be highlighted with the check mark
          QAFExtendedWebElement unemployedchecked= new QAFExtendedWebElement("ehome.empstatus.unemploymentchecked");
          String checked=unemployedchecked.getAttribute("checked");
          if(checked==null || !checked.contentEquals("true"))
              throw new AssertionError("Couldn't find the checked in unemployment");
          QAFExtendedWebElement unemployment= new QAFExtendedWebElement("ehome.empstatus.unemployment.label");
          String color=unemployment.getCssValue("background-color");
          String hex = convertRGBToHex(color);
          Assert.assertEquals("#8230df",hex);
          System.out.println("HEX"+hex);
          if(!hex.contentEquals("#8230df"))
              throw new AssertionError("Select when cliked is not highlighted with #8230df color");
          //To check the continue button is there and it should be in red color and click on the continue button
          QAFExtendedWebElement continuebutton = new QAFExtendedWebElement("ehome.Continue.button");
          Assert.assertEquals(continuebutton.getText(), "Continue", "Contnue Button text does not matched");
          Assert.assertEquals(convertRGBToHex(continuebutton.getCssValue("color")), "#ed722", "Continue button not in Red color");
          continuebutton.click();    	    
	}

	//Employment_Status_004

	@Then("^It should navigate to employment-co-app-intro$")
	public void it_should_navigate_to_employment_co_app_intro() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		QAFExtendedWebElement headerText= new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[1]/div/h2");
		if(!headerText.isPresent()) {
			Assert.fail("Couldn't see the employment-section-breaker");
		}
		    
	}
	
	
	
	
	

}
