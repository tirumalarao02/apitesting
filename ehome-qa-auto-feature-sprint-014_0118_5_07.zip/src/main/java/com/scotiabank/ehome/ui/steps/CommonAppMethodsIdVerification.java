package com.scotiabank.ehome.ui.steps;
import org.apache.poi.ss.formula.functions.Column;
import org.apache.poi.ss.usermodel.*;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.qmetry.qaf.automation.step.QAFTestStepProvider;
import com.qmetry.qaf.automation.ui.WebDriverTestBase;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebDriver;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.quantum.utils.ConfigurationUtils;

import cucumber.api.java.en.Given;

import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;
@QAFTestStepProvider

public class CommonAppMethodsIdVerification {
 
	 /* *************************************************************************************************************************************************
	 Author:      RameshChalumuri
	 Stage:       Stage 07  
	 Method Name: selectPhotoIDDocument
	 Purpose:     This method is for selecting Photo ID
	 Created on:  07-January-2019
	 Updated By: 
	 Updated on:
	 *************************************************************************************************************************************************** */
   public static void selectPhotoIDDocument(String photoIDDocument) throws InterruptedException{
	   
	   switch (photoIDDocument) {
	   		case "Canadian Driver’s License" :
	   			WebElement Drivers = Utility.webDriver.findElement(By.xpath(".//*[contains(text(),'Canadian Driver’s License')]"));
	   			((JavascriptExecutor) Utility.webDriver).executeScript("arguments[0].click();", Drivers);
	   			break;
   			case "Canadian Passport" :
   				WebElement Passport = Utility.webDriver.findElement(By.xpath(".//*[contains(text(),'Canadian Passport')]"));
	   			((JavascriptExecutor) Utility.webDriver).executeScript("arguments[0].click();", Passport);
	   			break;
			case "Canadian Citizenship Card" :
				WebElement Citizenship = Utility.webDriver.findElement(By.xpath(".//*[contains(text(),'Canadian Citizenship Card')]"));
	   			((JavascriptExecutor) Utility.webDriver).executeScript("arguments[0].click();", Citizenship);
	   			break;
   	   		case "Canadian Permanent Residence Card" :
   	   			WebElement Permanent = Utility.webDriver.findElement(By.xpath(".//*[contains(text(),'Canadian Permanent Residence Card')]"));
   	   			((JavascriptExecutor) Utility.webDriver).executeScript("arguments[0].click();", Permanent);
   	   			break;
   	   		case "U.S. Driver's License" :
   	   			WebElement License = Utility.webDriver.findElement(By.xpath(".//*[contains(text(),'U.S. Driver's License')]"));
   	   			((JavascriptExecutor) Utility.webDriver).executeScript("arguments[0].click();", License);
   	   			break;
   	   		case "U.S. Passport" :
   	   			WebElement USPassport = Utility.webDriver.findElement(By.xpath(".//*[contains(text(),'U.S. Passport')]"));
	   			((JavascriptExecutor) Utility.webDriver).executeScript("arguments[0].click();", USPassport);
	   			break;
   	   		default :
   	   			System.out.println("Invalid photo ID Document");
              
       }
  }
 	

}
   
   
   
   
