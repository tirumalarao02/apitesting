package com.scotiabank.ehome.ui.steps.stage7;
import com.qmetry.qaf.automation.step.QAFTestStepProvider;
import com.qmetry.qaf.automation.ui.WebDriverTestBase;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.quantum.java.pages.ExtentReportHelper;
import com.quantum.utils.ConfigurationUtils;
import com.scotiabank.ehome.ui.steps.Common;
import com.scotiabank.ehome.ui.steps.CommonAppMethodsAssetLiabilities;
import com.scotiabank.ehome.ui.steps.CommonAppMethodsEmployment;
import com.scotiabank.ehome.ui.steps.CommonApplicationMethods;
import com.scotiabank.ehome.ui.steps.Utility;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;

import java.util.Map;
import java.util.concurrent.TimeUnit;
import static com.scotiabank.ehome.ui.steps.Utility.*;

@QAFTestStepProvider

public class Congratulations {
	
	  public static WebDriverWait wait=Utility.getWait();
	  static String curDir = System.getProperty("user.dir");
	  static String strfullPathToFile = curDir + "\\src\\main\\resources\\data\\eHomeTestData.xlsx"; // File Path
		
	  static String sheetStage07_InputData ="Stage07_InputData";
	  static String sheetStage07_ExpectedData ="Stage07_ExpectedData";
	  
	  String strtestCaseID = "Congratulations-001";
	//  String strtestCaseID = Utility.getScenarioID();
	  
	  QAFExtendedWebElement strCongrats= new QAFExtendedWebElement("ehome.congratulations.Congrats");
	  QAFExtendedWebElement strAppSubmit= new QAFExtendedWebElement("ehome.congratulations.AppSubmit");
	  QAFExtendedWebElement strNext= new QAFExtendedWebElement("ehome.congratulations.Next");
	  QAFExtendedWebElement strContent1= new QAFExtendedWebElement("ehome.congratulations.Content1");
	  QAFExtendedWebElement strContent2= new QAFExtendedWebElement("ehome.congratulations.Content2");
	  QAFExtendedWebElement strContent3= new QAFExtendedWebElement("ehome.congratulations.Content3");
	  QAFExtendedWebElement strContent4= new QAFExtendedWebElement("ehome.congratulations.Content4");
	  QAFExtendedWebElement strTrackMyApp= new QAFExtendedWebElement("ehome.kcongratulations.TrackMyApp");
			  
	  @When("^Customer should navigate to 'Congratulations' screen$")
		public void Customer_should_navigate_to_Congratulations_screen() throws Throwable {
		  
		  Map<String, String> Stage07_InputData =  Utility.readTestData(strfullPathToFile, sheetStage07_InputData,strtestCaseID);
		  
		  	String strCongratsExpected	= Stage07_InputData.get("Congrats");
			String strAppSubmitExpected=  Stage07_InputData.get("AppSubmit");
			String strNextExpected=  Stage07_InputData.get("Next");
			String strContent1Expected	= Stage07_InputData.get("Content1"); 
			String strContent2Expected	= Stage07_InputData.get("Content2");
			String strContent3Expected= Stage07_InputData.get("Content3");
			String strContent4Expected = Stage07_InputData.get("Content4");
	
			Utility.verifyIsTextPresent("ehome.congratulations.Congrats", "Label", strCongratsExpected);
			Utility.verifyIsTextPresent("ehome.congratulations.Congrats", "Label", strAppSubmitExpected);
			Utility.verifyIsTextPresent("ehome.congratulations.Congrats", "Label", strNextExpected);
			Utility.verifyIsTextPresent("ehome.congratulations.Congrats", "Label", strContent1Expected);
			Utility.verifyIsTextPresent("ehome.congratulations.Congrats", "Label", strContent2Expected);
			Utility.verifyIsTextPresent("ehome.congratulations.Congrats", "Label", strContent3Expected);
			Utility.verifyIsTextPresent("ehome.congratulations.Congrats", "Label", strContent4Expected);
			
	
		
	  }
	  
	
}
