package com.scotiabank.ehome.ui.steps;

import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.util.function.BiFunction;

public class BusinessCalculations {
	public static BiFunction<Double, Double, Double> calculateLoanRequested = (purchasePrice,downPayment) -> purchasePrice - downPayment;
	
	public static Double calculateLoanRequested(Double purchasePrice, Double downPayment) {
		return purchasePrice - downPayment;
	}
	public static Boolean isDownPaymentLessThan20Percent(Double purchasePrice, Double downPayment) {
		return (downPayment / purchasePrice) < 0.2; 
	}
	public static Double getInterestFactor(Double effectiveRate) {
		double v1 = 1.0 + (effectiveRate/200.0);
		double v2 = Math.pow(v1, (1.0/6.0))-1;
		double v3 = Math.round((v2*1200.0)*100000d)/100000d;
		double v4 = Math.round((v3/1200.0)*1000000000d)/1000000000d;
		//double val = (Math.pow((1d + effectiveRate/200d),(1d/6d)) - 1)*1200d;
		//return (Math.round(val*100000.0)/100000.0)/1200d;
		return v4;
	}
	public static Double getMonthlyPayment(Double loanRequested, Double interestFactor, Integer amortizationPeriod) {
		double val = ((loanRequested * (interestFactor/(1d-Math.pow((1d+interestFactor), -amortizationPeriod.doubleValue()))))*100d);
		Integer valint = (new Double(val)).intValue();
		double valdob = valint.doubleValue()/100d;
		return Math.round(valdob*100.0)/100.0;
	}
	public static Double getWeeklyPayment(Double loanRequested, Double interestFactor, Integer amortizationPeriod) {
		double monthlyPayment = getMonthlyPayment(loanRequested, interestFactor, amortizationPeriod);
		double val =  monthlyPayment/4d;
		return Math.round(val*100.0)/100.0;
	}
	public static Double getBiWeeklyPayment(Double loanRequested, Double interestFactor, Integer amortizationPeriod) {
		double monthlyPayment = getMonthlyPayment(loanRequested, interestFactor, amortizationPeriod);
		double val =  monthlyPayment/2d;
		return Math.round(val*100.0)/100.0;
	}
	public static void main(String[] args) {
		double val = getInterestFactor(4.6);
		System.out.println(val);
		//val=0.003797108;
		//double val1 = ((600000d * (val/(1d-Math.pow((1d+val), -300d))))*100d)/100d;
		double val1 = getMonthlyPayment(600000.00, val, 191);
		System.out.println(val1);
		
		double val2 = getWeeklyPayment(600000.00, val, 191);
		System.out.println(val2);
		
		double val3 = getBiWeeklyPayment(600000.00, val, 191);
		System.out.println(val3);
	}
}
