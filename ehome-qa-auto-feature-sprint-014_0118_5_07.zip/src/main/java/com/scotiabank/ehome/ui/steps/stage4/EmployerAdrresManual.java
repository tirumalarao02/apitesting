package com.scotiabank.ehome.ui.steps.stage4;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.step.QAFTestStepProvider;
import com.qmetry.qaf.automation.ui.WebDriverTestBase;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebDriver;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.quantum.utils.ConfigurationUtils;
import com.scotiabank.ehome.ui.steps.Common;
import com.scotiabank.ehome.ui.steps.ExcelDataToDataTable;
import com.scotiabank.ehome.ui.steps.Utility;
import com.scotiabank.ehome.ui.steps.valueObjects.Tuple;
import com.scotiabank.ehome.ui.steps.valueObjects.TypeOfRateVO;
import com.thoughtworks.qdox.model.expression.Add;

import org.junit.runner.RunWith;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;

import cucumber.api.CucumberOptions;
import cucumber.api.DataTable;
import cucumber.api.PendingException;
import cucumber.api.Transform;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import cucumber.api.junit.Cucumber;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import static com.scotiabank.ehome.ui.steps.BusinessCalculations.*;
import static com.scotiabank.ehome.ui.steps.Utility.*;

import org.openqa.selenium.Keys;
@QAFTestStepProvider
public class EmployerAdrresManual {
	public static WebDriverWait wait=Utility.getWait();
	  String testCaseID = Utility.getScenarioID();
    
    private Map<String,Map<String,Boolean>> employerManualAddressDataset = getScreenDataset(Utility.getExcelFilePath("eHomeTestDatastage-4.xlsx"), "EmployerAddressManual");
   @Given("^Customer should login and navigates to employer address manual$")
    public void customer_should_login_and_navigates_to_employer_address_manual() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	Utility.launchURL(ConfigurationUtils.getBaseBundle().getPropertyValue ("env.baseurl2"));
		Common.sessionBreakerContinueButtonClick();
        EmpStatus.employedButtonClicked();
        EmpType.commissionedSalesButtonClicked();
        Thread.sleep(3000);
        String jobField=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage04_Employment_InputData", testCaseID, "Industry_JobTitle_Field_of_work");
        IndustryAndJobTitle.jobField(jobField);
        Thread.sleep(3000);
        String jobTitle=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage04_Employment_InputData", testCaseID, "Industry_JobTitle_Job_Title");
        IndustryAndJobTitle.jobTitle(jobTitle);
        Common.continueButtonClicked();
        String employername=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage04_Employment_InputData", testCaseID, "Employer_Details_employername");
        EmployerDetails.employername(employername);
        String employerphone=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage04_Employment_InputData", testCaseID, "Employer_Details_employerphone");
        EmployerDetails.employerphone(employerphone);
        Common.continueButtonClicked();
      
       
        QAFExtendedWebElement manualAddresss = new QAFExtendedWebElement("ehome.employeraddress.manualaddress");
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(manualAddresss));
		manualAddresss.click();
    }
    //Employment-Address-Manuall-TC-002
    
    @When("^Verify \"([^\"]*)\" should be on the employer address manual screen$")
    public void verify_should_be_on_the_employer_address_manual_screen1(String dataPointer) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	Thread.sleep(3000);
//		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage04_Employment_ExpectedData", testCaseID, dataPointer);
//		QAFExtendedWebElement message= new QAFExtendedWebElement("//*[@id='app']//section/div/div[1]/p");
//		Assert.assertEquals(message.getText(), value,"Couldn't found expected message text");
    	String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage04_Employment_ExpectedData", testCaseID, dataPointer);
		Assert.assertEquals(Common.headerMessage(), value,"Couldn't found expected header text");
    }

    @Then("^Verify \"([^\"]*)\" headertext should be on the employer address manual screen$")
    public void verify_should_be_on_the_employer_address_manual_screen(String dataPointer) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	//TO Check the header text 
    	String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage04_Employment_ExpectedData", testCaseID, dataPointer);
		Assert.assertEquals(Common.headertext(), value,"Couldn't found expected header text");
        
    }
   // Employment-Address-Manuall-TC-004
    public static void streetNumber(String value) throws InterruptedException {
    	QAFExtendedWebElement streetNumber= new QAFExtendedWebElement("ehome.employmentManualaddress.streetNumber");
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(streetNumber));
		streetNumber.clear();
		streetNumber.sendKeys(value);
	 }

    @When("^Enter \"([^\"]*)\" street number in the employer address manual screen$")
    public void enter_street_number_in_the_employer_address_manual_screen(String dataPointer) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	String col="InputValues";
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "CommonErrorMessages", dataPointer,col);
    	streetNumber(value);
    }
    @Then("^\"([^\"]*)\" error message should be displayed in the street number$")
    public void error_message_should_be_displayed_in_the_street_number(String dataPointer) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage04_Employment_ExpectedData", testCaseID, dataPointer);
		QAFExtendedWebElement streetnumbererrormessage= new QAFExtendedWebElement("ehome.employmentManualaddress.streetNumber.errormessage");
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(streetnumbererrormessage));
		Assert.assertEquals(streetnumbererrormessage.getText(), value,"Couldn't found expected error message text");
      
    }
 // Employment-Address-Manuall-TC-005
    public static void streetName(String value) throws InterruptedException {
    	QAFExtendedWebElement streetName= new QAFExtendedWebElement("ehome.employmentManualaddress.streetName");
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(streetName));
		streetName.clear();
		streetName.sendKeys(value);
	 }
    @When("^Enter \"([^\"]*)\" street name in the employer address manual screen$")
    public void enter_streetname_in_the_employer_address_manual_screen(String dataPointer) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	String col="InputValues";
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "CommonErrorMessages", dataPointer,col);
		streetName(value);
        
    }
    @Then("^\"([^\"]*)\" error message should be displayed in the street name$")
    public void error_message_should_be_displayed_in_the_street_name(String dataPointer) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage04_Employment_ExpectedData", testCaseID, dataPointer);
		QAFExtendedWebElement streetnameerrormessage= new QAFExtendedWebElement("ehome.employmentManualaddress.streetName.errormessage");
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(streetnameerrormessage));
		Assert.assertEquals(streetnameerrormessage.getText(), value,"Couldn't found expected error message text");
       
    }
 // Employment-Address-Manuall-TC-006
    public static void unitNumber(String value) throws InterruptedException {
    	QAFExtendedWebElement unitNumber= new QAFExtendedWebElement("ehome.employmentManualaddress.unitNumber");
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(unitNumber));
		unitNumber.clear();
		unitNumber.sendKeys(value);
	 }
    @When("^Enter \"([^\"]*)\" unitNumber in the employer address manual screen$")
    public void enter_unitNumber_in_the_employer_address_manual_screen(String dataPointer) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	String col="InputValues";
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "CommonErrorMessages", dataPointer,col);
    	unitNumber(value);
        
    }
    @Then("^\"([^\"]*)\" error message should be displayed in the Unit number$")
    public void error_message_should_be_displayed_in_the_unit_number(String arg1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
       
    }
    
    //Employment-Address-Manual-TC-007
    public static void city(String value) throws InterruptedException {
    	QAFExtendedWebElement city= new QAFExtendedWebElement("ehome.employmentManualaddress.city");
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(city));
		city.clear();
		city.sendKeys(value);
	 }
    @When("^Enter \"([^\"]*)\" city in the employer address manual screen$")
    public void enter_city_in_the_employer_address_manual_screen(String dataPointer) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	String col="InputValues";
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "CommonErrorMessages", dataPointer,col);
    	city(value);
        
    }
    @Then("^\"([^\"]*)\" error message should be displayed in the city$")
    public void error_message_should_be_displayed_in_the_city(String dataPointer) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage04_Employment_ExpectedData", testCaseID, dataPointer);
		QAFExtendedWebElement streetnameerrormessage= new QAFExtendedWebElement("ehome.employmentManualaddress.city.errormessage");
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(streetnameerrormessage));
		Assert.assertEquals(streetnameerrormessage.getText(), value,"Couldn't found expected error message text");
    	
       
    }
    //Employment-Address-Manual-TC-008
    public static void postalCode(String value) throws InterruptedException {
    	QAFExtendedWebElement postalCode= new QAFExtendedWebElement("ehome.employmentManualaddress.postalCode");
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(postalCode));
		postalCode.clear();
		postalCode.sendKeys(value);
	 }
    @When("^Enter \"([^\"]*)\" postalCode in the employer address manual screen$")
    public void enter_postalCode_in_the_employer_address_manual_screen(String dataPointer) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	String col="InputValues";
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "CommonErrorMessages", dataPointer,col);
    	postalCode(value);
        
    }
    
    @Then("^\"([^\"]*)\" error message should be displayed in the postalCode$")
    public void error_message_should_be_displayed_in_the_postalCode(String dataPointer) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage04_Employment_ExpectedData", testCaseID, dataPointer);
		QAFExtendedWebElement streetnameerrormessage= new QAFExtendedWebElement("ehome.employmentManualaddress.postalCode.errormessage");
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(streetnameerrormessage));
		Assert.assertEquals(streetnameerrormessage.getText(), value,"Couldn't found expected error message text");
       
    }
    //Employment-Address-Manual-TC-009
    public static void manualAddress(String value1,String value2,String value3,String value4,String value5,String value6,String value7,String value8) throws InterruptedException {
    	streetNumber(value1);
    	streetName(value2);
    	QAFExtendedWebElement direction= new QAFExtendedWebElement("ehome.employmentManualaddress.direction");
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(direction));
		direction.click();
		Select directionSelect = new Select(direction);
		directionSelect.selectByVisibleText(value3);
    	unitNumber(value4);
    	city(value5);
    	QAFExtendedWebElement province= new QAFExtendedWebElement("ehome.employmentManualaddress.province");
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(province));
		province.click();
		Select provinceSelect = new Select(province);
		provinceSelect.selectByVisibleText(value6);
    	postalCode(value7);
    	QAFExtendedWebElement country= new QAFExtendedWebElement("ehome.employmentManualaddress.country");
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(country));
		province.click();
		Select countrySelect = new Select(country);
		countrySelect.selectByVisibleText(value8);
	 }
    
    @When("^Enter \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" in the employer address manual screen$")
    public void enter_in_the_employer_address_manual_screen(String dataPointer1, String dataPointer2, String dataPointer3, String dataPointer4, String dataPointer5, String dataPointer6, String dataPointer7, String dataPointer8) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	String value1 = Utility.getLabelValueForDataPointer(employerManualAddressDataset, dataPointer1);
    	String value2 = Utility.getLabelValueForDataPointer(employerManualAddressDataset, dataPointer2);
    	String value3 = Utility.getLabelValueForDataPointer(employerManualAddressDataset, dataPointer3);
    	String value4 = Utility.getLabelValueForDataPointer(employerManualAddressDataset, dataPointer4);
    	String value5 = Utility.getLabelValueForDataPointer(employerManualAddressDataset, dataPointer5);
    	String value6 = Utility.getLabelValueForDataPointer(employerManualAddressDataset, dataPointer6);
    	String value7 = Utility.getLabelValueForDataPointer(employerManualAddressDataset, dataPointer7);
    	String value8 = Utility.getLabelValueForDataPointer(employerManualAddressDataset, dataPointer8);
    	
    	
    }
   

    @When("^Enter \"([^\"]*)\" StreetNumber in the employer address manual screen$")
    public void enter_StreetNumber_in_the_employer_address_manual_screen(String dataPointer1) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	String value1 = Utility.getLabelValueForDataPointer(employerManualAddressDataset, dataPointer1);
    	streetNumber(value1);
    }

}
