package com.scotiabank.ehome.ui.steps.stage2;

import java.util.List;
import java.util.Map;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import com.qmetry.qaf.automation.step.QAFTestStepProvider;
import com.qmetry.qaf.automation.ui.WebDriverTestBase;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebDriver;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.quantum.utils.ConfigurationUtils;
import com.scotiabank.ehome.ui.steps.CommonApplicationMethods;
import com.scotiabank.ehome.ui.steps.Utility;

import cucumber.api.PendingException;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

@QAFTestStepProvider

public class PurchasePrice {
	
	private QAFExtendedWebDriver webDriver = null;
    public Actions action = null;
    public WebDriverWait wait=null;
    
    static String curDir = System.getProperty("user.dir");
    static String strfullPathToFile = curDir + "\\src\\main\\resources\\data\\eHomeTestData.xlsx"; // File Path
    static String  strErrMesgsSheet = "CommonErrorMessages";
    static String  strCommonObjects = "CommonObjects";
    static String  strStage02NewHomeSheet = "Stage02_NewHome_ExpectedData"; 
    
    @Given("^Customer should login and navigate to Purchase Price screen$")
    public void CustomershouldloginandnavigatetoPurchasePriceScreen() throws Throwable {
    	String strtestCaseID = Utility.getScenarioID();
    	//String strtestCaseID = "Purchase-Price-TC-001";
    	
    	Map<String, String> Stage02_NewHome_ExptData =  Utility.readTestData(strfullPathToFile, strStage02NewHomeSheet,strtestCaseID);
    	String strPurchasePriceTitle= Stage02_NewHome_ExptData.get("Purchase_Price_Title");
    	String strPurchasePriceLabel= Stage02_NewHome_ExptData.get("Purchase_Price_Label");
    	String strBulbSymbolToolTip= Stage02_NewHome_ExptData.get("BulbSymbol_ToolTip");
    	String strBulbSymbol = Stage02_NewHome_ExptData.get("$_Symbol");

    	Utility.launchURL(ConfigurationUtils.getBaseBundle ().getPropertyValue ("env.baseurl1")); 
    	Thread.sleep(1000);
    	QAFExtendedWebElement ContinueStage2Section= new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[2]/div/div[3]/div/button/span");
    	ContinueStage2Section.click();
    	Thread.sleep(1000);
    	CommonApplicationMethods.enterAddressManually();
    	Thread.sleep(2000);
    	QAFExtendedWebElement TypeofPropertyOption= new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[1]/section/div[3]/div/fieldset/div/span[1]/label/span[2]/span");
    	TypeofPropertyOption.click();
    	Thread.sleep(2000);
    	QAFExtendedWebElement TypeofHouseOption= new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[1]/section/div[3]/div/fieldset/div/span[1]/label");
    	TypeofHouseOption.click();
    	Thread.sleep(1000);
    	QAFExtendedWebElement ValueAreaofProperty= new QAFExtendedWebElement("//*[@id=\"sqFeet\"]");
    	ValueAreaofProperty.sendKeys("5000");
    	Thread.sleep(1000);
    	QAFExtendedWebElement Continue3 = new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[2]/button[2]");
    	Continue3.click();
    	Thread.sleep(1000);
    	if (strtestCaseID.contentEquals("Purchase-Price-TC-001")) {
    		QAFExtendedWebElement purchasePriceTitleActualMsg= new QAFExtendedWebElement("ehome.PurchasePrice.title");
    		Assert.assertEquals(purchasePriceTitleActualMsg.getText(), strPurchasePriceTitle,"Purchase Price Title is NOT as expected.");
    		
    		QAFExtendedWebElement purchasePriceLabelActualMsg= new QAFExtendedWebElement("ehome.ExcellentStuff.label");
    		Assert.assertEquals(purchasePriceLabelActualMsg.getText(), strPurchasePriceLabel,"Purchase Price Label is NOT as expected.");
    		
    		QAFExtendedWebElement bulbSymbolActualMsg= new QAFExtendedWebElement("ehome.PurchasePrice.bulbSymbolText");
    		Assert.assertEquals(bulbSymbolActualMsg.getText(), strBulbSymbolToolTip,"Bulb Symbol Tool Tip Text is NOT as expected.");
    		
    		QAFExtendedWebElement $SymbolActualMsg= new QAFExtendedWebElement("ehome.PurchasePrice.$symbol");
    		Assert.assertEquals($SymbolActualMsg.getText(), strBulbSymbol,"Bulb Symbol is NOT as expected.");
    	}
                
    } 
           
    @Then("^Purchase Price Title screen with title \"([^\"]*)\" is present$")
    public void Verify_Display_Purchase_Price_Title(String expectedText) throws Throwable {
        	 
//             List<String> ExcelData = Utility.ExcelData(strfullPathToFile, strPurchasePriceSheet, expectedText) ;
//        	   String Expected_ErrorMessages =ExcelData.get(1); 
//         	   QAFExtendedWebElement ActualErrMsg= new QAFExtendedWebElement("ehome.PurchasePrice.title");
  //       	   Assert.assertEquals(ActualErrMsg.getText(), strPurchasePriceTitle,"Expected and Actual Error Message is NOT Matched");
    	
         }
           
         @And("^Excellent stuff label as \"([^\"]*)\" is present$")
         public void Excellent_stuff_label_is_present(String expectedText) throws Throwable {
        	 
//      	   List<String> ExcelData = Utility.ExcelData(strfullPathToFile, strPurchasePriceSheet, expectedText) ;
//      	   String Expected_ErrorMessages =ExcelData.get(1); 
//       	   QAFExtendedWebElement ActualErrMsg= new QAFExtendedWebElement("ehome.ExcellentStuff.label");
//      	   Assert.assertEquals(ActualErrMsg.getText(), Expected_ErrorMessages,"Expected and Actual Error Message is NOT Matched");
     }
         
         
         @And("^Purchase price input box is present with \"([^\"]*)\" symbol$")
         public void Purchase_price_input_box_is_present_with_$_symbol(String expectedText) throws Throwable {
//       	   Thread.sleep(3000);
//             QAFExtendedWebElement purchasePriceInput= new QAFExtendedWebElement("ehome.PurchasePrice.inputtextbox");
//             if(!purchasePriceInput.verifyPresent())
//                 throw new AssertionError("Couldn't find Purchase Price Input Box");
//             
//             List<String> ExcelData = Utility.ExcelData(strfullPathToFile, strCommonObjects, expectedText) ;
//        	   String Expected_ErrorMessages =ExcelData.get(1); 
//         	   QAFExtendedWebElement ActualErrMsg= new QAFExtendedWebElement("ehome.PurchasePrice.$symbol");
//        	   Assert.assertEquals(ActualErrMsg.getText(), Expected_ErrorMessages,"Expected and Actual Error Message is NOT Matched");
              
         }   
           
         
         @And("^Bulb symbol is present in Purchase$")
         public void Bulb_symbol_is_present_in_Purchase() throws Throwable {
             // Write code here that turns the phrase above into concrete actions
     	       Thread.sleep(3000);
             QAFExtendedWebElement BulbSymbol= new QAFExtendedWebElement("ehome.PurchasePrice.bulbSymbol");
             
              if(!BulbSymbol.verifyPresent())
                 throw new AssertionError("Couldn't find Bulb Symbol");
         }
         
             
        @And("^Bulb Symbol Text as \"([^\"]*)\" is present$")
             public void Bulb_SymboltoolTip_Content_present(String expectedText) throws Throwable {
//               List<String> ExcelData = Utility.ExcelData(strfullPathToFile, strPurchasePriceSheet, expectedText) ;
//          	   String Expected_ErrorMessages =ExcelData.get(1); 
//          	  QAFExtendedWebElement ActualErrMsg= new QAFExtendedWebElement("ehome.PurchasePrice.bulbSymbolText");
//           	   Assert.assertEquals(ActualErrMsg.getText(), Expected_ErrorMessages,"Expected and Actual Error Message is NOT Matched");
             }
        
        
       @And("^Back button as \"([^\"]*)\" is present$")
                 public void Back_button_is_Present(String expectedText) throws Throwable {
                     // Write code here that turns the phrase above into concrete actions
                   List<String> exceldata = Utility.ExcelData(strfullPathToFile, strCommonObjects, expectedText) ;
              	   String Expected_ErrorMessages =exceldata.get(1); 
              	   QAFExtendedWebElement ActualErrMsg= new QAFExtendedWebElement("ehome.PurchasePrice.Backbutton");  
              	   Assert.assertEquals(ActualErrMsg.getText(), Expected_ErrorMessages,"Expected and Actual Error Message is NOT Matched");
                   Thread.sleep(1000);
                  
                 }
       
           // Verify Error message when enter ALPHA characters into purchase price text field in Purchase Price screen         
           @When("^Enter Alpha Characters as \"([^\"]*)\" into purchase price text field in Purchase Price screen$")
           public void Enter_Alpha_CharactersValues_into_PurchasePrice(String expectedText) throws Throwable {
        	   System.err.println("Is it reaching here ???");
        	   Thread.sleep(5000);
        	   List<String> exceldata = Utility.ExcelData(strfullPathToFile, strErrMesgsSheet, expectedText) ;
        	   		String strValues= exceldata.get(0);
        	   		QAFExtendedWebElement ValuePurchasePrice= new QAFExtendedWebElement("ehome.PurchasePrice.inputtextbox");  
        	   		ValuePurchasePrice.sendKeys(strValues);
        	   		
          }
           
           @Then ("^Display Error Message for Alpha Chars as \"([^\"]*)\"$")
           public void Display_Error_Message_for_AlphaChars(String expectedText) throws Throwable {
               List<String> exceldata = Utility.ExcelData(strfullPathToFile, strErrMesgsSheet, expectedText) ;
          	   String Expected_ErrorMessages =exceldata.get(1); 
           	  	   
          	   QAFExtendedWebElement ActualErrMsg= new QAFExtendedWebElement("ehome.PurchasePrice.invalidMessage");  
          	   Assert.assertEquals(ActualErrMsg.getText(), Expected_ErrorMessages,"Expected and Actual Error Message is NOT Matched");
               Thread.sleep(1000);
           }
           
           // Verify Error message when enter ALPHANumeric into purchase price text field in Purchase Price screen         
           @When("^Enter Alpha Numeric as \"([^\"]*)\" into purchase price text field in Purchase Price screen$")
           public void Enter_Alpha_NumericValues_into_PurchasePrice(String expectedText) throws Throwable {
               List<String> exceldata = Utility.ExcelData(strfullPathToFile, strErrMesgsSheet, expectedText) ;
          	   String strValues= exceldata.get(0);
               QAFExtendedWebElement ValuePurchasePrice= new QAFExtendedWebElement("ehome.PurchasePrice.inputtextbox");
               ValuePurchasePrice.clear();
           	   ValuePurchasePrice.sendKeys(strValues);
               Thread.sleep(1000);
          }
           
           @Then ("^Display Error Message for Alpha Numeric as \"([^\"]*)\"$")
           public void Display_Error_Message_for_AlphaNumeric(String expectedText) throws Throwable {
               List<String> exceldata = Utility.ExcelData(strfullPathToFile, strErrMesgsSheet, expectedText) ;
          	   String Expected_ErrorMessages =exceldata.get(1); 
           	  	   
          	   QAFExtendedWebElement ActualErrMsg= new QAFExtendedWebElement("ehome.PurchasePrice.invalidMessage");  
          	   Assert.assertEquals(ActualErrMsg.getText(), Expected_ErrorMessages,"Expected and Actual Error Message is NOT Matched");
               Thread.sleep(1000);
           } 
           
            
           // Verify Error message when enter SPECIAL characters into purchase price text field in Purchase Price screen         
           @When("^Enter Special Characters as \"([^\"]*)\" into purchase price text field in Purchase Price screen$")
           public void Enter_Special_CharactersValues_into_PurchasePrice(String expectedText) throws Throwable {
               List<String> exceldata = Utility.ExcelData(strfullPathToFile, strErrMesgsSheet, expectedText) ;
          	   String strValues= exceldata.get(0);
               QAFExtendedWebElement ValuePurchasePrice= new QAFExtendedWebElement("ehome.PurchasePrice.inputtextbox"); 
               ValuePurchasePrice.clear();
           	   ValuePurchasePrice.sendKeys(strValues);
               Thread.sleep(1000);
          }
           
           @Then ("^Display Error Message for Special Chars as \"([^\"]*)\"$")
           public void Display_Error_Message_for_SpecialChars(String expectedText) throws Throwable {
               List<String> exceldata = Utility.ExcelData(strfullPathToFile, strErrMesgsSheet, expectedText) ;
          	   String Expected_ErrorMessages =exceldata.get(1); 
           	  	   
          	   QAFExtendedWebElement ActualErrMsg= new QAFExtendedWebElement("ehome.PurchasePrice.invalidMessage");  
          	   Assert.assertEquals(ActualErrMsg.getText(), Expected_ErrorMessages,"Expected and Actual Error Message is NOT Matched");
               Thread.sleep(1000);
           }
         
           // Verify Error message when enter Negative Values into purchase price text field in Purchase Price screen         
           @When("^Enter Negative Data as \"([^\"]*)\" into purchase price text field in Purchase Price screen$")
           public void Enter_NegativeValues_into_PurchasePrice(String expectedText) throws Throwable {
               List<String> exceldata = Utility.ExcelData(strfullPathToFile, strErrMesgsSheet, expectedText) ;
          	   String strValues= exceldata.get(0);
               QAFExtendedWebElement ValuePurchasePrice= new QAFExtendedWebElement("ehome.PurchasePrice.inputtextbox"); 
               ValuePurchasePrice.clear();
           	   ValuePurchasePrice.sendKeys(strValues);
               Thread.sleep(1000);
          }
           
           @Then ("^Display Error Message for Negative Data as \"([^\"]*)\"$")
           public void Display_Error_Message_for_NegativeValues(String expectedText) throws Throwable {
               List<String> exceldata = Utility.ExcelData(strfullPathToFile, strErrMesgsSheet, expectedText) ;
          	   String Expected_ErrorMessages =exceldata.get(1); 
           	  	   
          	   QAFExtendedWebElement ActualErrMsg= new QAFExtendedWebElement("ehome.PurchasePrice.invalidMessage");  
          	   Assert.assertEquals(ActualErrMsg.getText(), Expected_ErrorMessages,"Expected and Actual Error Message is NOT Matched");
               Thread.sleep(1000);
           }
      
           
        // Verify Error message when enter Amount Zero into purchase price text field in Purchase Price screen 
           @When("^Enter Amount Zero as \"([^\"]*)\" into purchase price text field in Purchase Price screen$")
           public void Enter_Amount_ZeroValue_into_PurchasePrice(String expectedText) throws Throwable {
        	   
               List<String> exceldata = Utility.ExcelData(strfullPathToFile, strErrMesgsSheet, expectedText) ;
          	   String strValues= exceldata.get(0);
               QAFExtendedWebElement ValuePurchasePrice= new QAFExtendedWebElement("ehome.PurchasePrice.inputtextbox");
               ValuePurchasePrice.clear();
               ValuePurchasePrice.sendKeys(strValues);
           	   
         }
           
           @Then ("^Display Error Message for AmountZero as \"([^\"]*)\"$")
           public void Display_Error_Message_for_Amount_Zero(String expectedText) throws Throwable {
               List<String> exceldata = Utility.ExcelData(strfullPathToFile, strErrMesgsSheet, expectedText) ;
          	   String Expected_ErrorMessages =exceldata.get(1); 
          //	   QAFExtendedWebElement ActualErrMsg= new QAFExtendedWebElement("//*[@id=\"purchasePrice-group-invalid\"]"); 
        	   QAFExtendedWebElement ActualErrMsg= new QAFExtendedWebElement("ehome.PurchasePrice.invalidMessage"); 
          	   Assert.assertEquals(ActualErrMsg.getText(), Expected_ErrorMessages,"Expected and Actual Error Message is NOT Matched");
               Thread.sleep(1000);
           }
           
           
        // Enter Amount More than Zero into purchase price text field in Purchase Price screen 
           @When("^Enter Amount More Than Zero as \"([^\"]*)\" into purchase price text field in Purchase Price screen$")
           public void Enter_Amount_MoreThanZeroValue_into_PurchasePrice(String expectedText) throws Throwable {
        	   
                List<String> exceldata = Utility.ExcelData(strfullPathToFile, strErrMesgsSheet, expectedText) ;
          	   String strValues= exceldata.get(0);
           	   QAFExtendedWebElement ValuePurchasePrice= new QAFExtendedWebElement("ehome.PurchasePrice.inputtextbox");
               ValuePurchasePrice.clear();
               ValuePurchasePrice.sendKeys(strValues);
               Thread.sleep(1000);
               
             
         }
           
           @Then("^Continue button as \"([^\"]*)\" is present in PurchasePrice Screen$")
            public void Continue_button_is_Present_PurchasePrice(String expectedText) throws Throwable {
               // Write code here that turns the phrase above into concrete actions
        	   
        	   System.err.println(expectedText + "RAM>>");
        	   List<String> exceldata = Utility.ExcelData(strfullPathToFile, strErrMesgsSheet, expectedText) ;
          	   String strValues= exceldata.get(0);
           	   QAFExtendedWebElement ValuePurchasePrice= new QAFExtendedWebElement("ehome.PurchasePrice.inputtextbox");
               ValuePurchasePrice.clear();
               ValuePurchasePrice.sendKeys(strValues);
               Thread.sleep(1000);
        	   
              List<String> exceldata1 = Utility.ExcelData(strfullPathToFile, strCommonObjects, expectedText) ;
        	   String Expected_ErrorMessages =exceldata1.get(1); 
        	   Thread.sleep(1000);
        	   QAFExtendedWebElement PurchasePriceContinue = new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[2]/button[2]/span");
                 Assert.assertEquals(PurchasePriceContinue.getText(), Expected_ErrorMessages,"Expected and Actual Error Message is NOT Matched");
                  PurchasePriceContinue.click();
                 Thread.sleep(1000);
               
       
    
}
           
}


        
