package com.quantum.utility;

import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.quantum.java.pages.ScotiaQuantumReportListener;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.io.IOUtils;
import org.apache.commons.io.filefilter.DirectoryFileFilter;
import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.testng.Assert;

import java.io.FileReader;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Random;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import static com.quantum.config.SystemProperties.JSON_FILE_NAME;

public class Utils {
    //public static String FEATURE_FILE = null;
    public static String XRAY_ISSUE_KEYS = null;
    private static final int BUFFER_SIZE = 4096;
    public static String ZIP_FILE_PATH = null;
    public static String TEST_PLAN_KEY = null;
    public static File LATEST_DIR = null;

    private static String encodeBase64String(String inputString) {
        System.out.println(Base64.encodeBase64URLSafeString(inputString.getBytes()));
        return Base64.encodeBase64URLSafeString(inputString.getBytes());
    }

    public static void importTestsFromJIRAUsingHTTPClient(String username, String password, String jiraURL, String jiraKeys, String pathToOutputFile, String featureFileName) throws Exception {

        /*if (ConfigurationManager.getBundle().getString("xray.issue.keys").equals(""))
        {
            jiraKeys = Utils.XRAY_ISSUE_KEYS;
        }

        else if (ConfigurationManager.getBundle().getString("xray.issue.keys", "").contains(","))
        {
            jiraKeys = ConfigurationManager.getBundle().getString("xray.issue.keys").toString().replace(',', ';');
        }*/

        if (ConfigurationManager.getBundle().getString("xray.issue.keys", "").contains(","))
        {
            jiraKeys = ConfigurationManager.getBundle().getString("xray.issue.keys").toString().replace(',', ';');
        }

        String url = jiraURL + "/rest/raven/1.0/export/test?keys=" + jiraKeys + "&fz=true";
        URL obj = new URL(url);
        HttpURLConnection con = (HttpURLConnection) obj.openConnection();

        con.setRequestMethod("GET");
        con.setRequestProperty("Authorization", "Basic " + encodeBase64String(username + ":" + password));
        con.setDoOutput(true);

        int responseCode = con.getResponseCode();
        System.out.println("Response Code : " + responseCode);

        if (responseCode == HttpURLConnection.HTTP_OK) {
            String fileName = "";
            String disposition = con.getHeaderField("Content-Disposition");
            String contentType = con.getContentType();
            int contentLength = con.getContentLength();

            if (disposition != null) {
                // extracts file name from header field
                int index = disposition.indexOf("filename=");
                if (index > 0) {
                    fileName = disposition.substring(index + 10,
                            disposition.length() - 1);
                }
            } else {
                // extracts file name from URL
                fileName = url.substring(url.lastIndexOf("/") + 1,
                        url.length());
            }

            System.out.println("Content-Type = " + contentType);
            System.out.println("Content-Disposition = " + disposition);
            System.out.println("Content-Length = " + contentLength);
            System.out.println("fileName = " + fileName);

            // opens input stream from the HTTP connection
            InputStream inputStream = con.getInputStream();
            String saveFilePath = pathToOutputFile + File.separator + fileName;
            Utils.ZIP_FILE_PATH = saveFilePath;
            System.out.println(saveFilePath);

            // opens an output stream to save into file
            FileOutputStream outputStream = new FileOutputStream(saveFilePath);

            int bytesRead = -1;
            byte[] buffer = new byte[BUFFER_SIZE];
            while ((bytesRead = inputStream.read(buffer)) != -1) {
                outputStream.write(buffer, 0, bytesRead);
            }

            outputStream.close();
            inputStream.close();

            System.out.println("File downloaded");
        } else {
            System.out.println("No file to download. Server replied HTTP code: " + responseCode);
        }
        con.disconnect();

        unzip(Utils.ZIP_FILE_PATH, pathToOutputFile, featureFileName);
    }

    public static void exportReportToJIRAUsingHTTPClient(String username, String password, String jiraURL) {
        try {

            for (File file : Utils.LATEST_DIR.listFiles()) {
                if (file.getName().startsWith("cucumber_")) {
                    System.out.println(file);

                    JSONParser parser = new JSONParser();
                    Object object = null;
                    try {
                        object = parser.parse(new FileReader(file));
                    } catch (IOException e) {
                        e.printStackTrace();
                    } catch (ParseException e) {
                        e.printStackTrace();
                    }

                    System.out.println(object.toString());
                    String urlParameters = object.toString();
                    String url = jiraURL + "/rest/raven/1.0/import/execution";
                    URL obj = null;
                    obj = new URL(url);

                    HttpURLConnection con = null;
                    try {
                        con = (HttpURLConnection) obj.openConnection();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    con.setDoOutput(true);
                    con.setRequestMethod("POST");
                    con.setRequestProperty("Authorization", "Basic " + encodeBase64String(username + ":" + password));
                    con.setRequestProperty("Content-Type", "application/json");
                    con.setRequestProperty("charset", "utf-8");
                    con.setUseCaches(false);
                    con.connect();

                    try (DataOutputStream wr = new DataOutputStream(con.getOutputStream())) {
                        wr.writeBytes(urlParameters);
                        System.out.println("Response Code : " + con.getResponseCode());
                        wr.flush();
                        wr.close();
                    }
                }
            }

        } catch (Exception ex) {
            System.out.println(ex);
        }
    }

    public static void exportTestNGReportToJIRAUsingHTTPClient(String username, String password, String jiraURL, String reportFilePath) throws Exception {
        String url = jiraURL + "/rest/raven/1.0/import/execution/testng?projectKey=QCR";
        CloseableHttpClient client = HttpClients.createDefault();
        HttpPost httpPost = new HttpPost(url);

        MultipartEntityBuilder builder = MultipartEntityBuilder.create();
        builder.addBinaryBody("file", new File(reportFilePath));
        HttpEntity multipart = builder.build();

        httpPost.setHeader("Authorization", "Basic " + encodeBase64String(username + ":" + password));
        httpPost.setEntity(multipart);

        CloseableHttpResponse response = client.execute(httpPost);
        System.out.println(response.getStatusLine().getStatusCode());
        client.close();
    }

    public static void importCucumberFeatureFilesToJIRAUsingHTTPClient(String username, String password, String jiraURL, String projectKey, String featuresFilePath) throws Exception {
        String url = jiraURL + "/rest/raven/1.0/import/feature?projectKey="+projectKey;
        CloseableHttpClient client = HttpClients.createDefault();
        HttpPost httpPost = new HttpPost(url);

        MultipartEntityBuilder builder = MultipartEntityBuilder.create();
        builder.addBinaryBody("file", new File(featuresFilePath));
        HttpEntity multipart = builder.build();

        httpPost.setHeader("Authorization", "Basic " + encodeBase64String(username + ":" + password));
        httpPost.setEntity(multipart);

        CloseableHttpResponse response = client.execute(httpPost);

        String responseJSON = EntityUtils.toString(response.getEntity());
        JSONArray jsonArray = new JSONArray(responseJSON);

        for(int i = 0; i < jsonArray.length(); i++) {
            JSONObject jsonObject = jsonArray.getJSONObject(i);
            System.out.println("Xray Issue Id: " + jsonObject.get("key"));

            if (Utils.XRAY_ISSUE_KEYS == null) {
                Utils.XRAY_ISSUE_KEYS = jsonObject.get("key").toString();
            }
            else
            {
                Utils.XRAY_ISSUE_KEYS = Utils.XRAY_ISSUE_KEYS + ";" + jsonObject.get("key").toString();
            }
        }

        System.out.println(response.getStatusLine().getStatusCode());
        client.close();
    }

    public static void generateCucumberJSONReport(String username, String password, String jiraURL) throws Exception {

        String testPlanKeys[] = ConfigurationManager.getBundle().getString("xray.issue.keys").toString().split(",");

        //Find the latest result directory
        File latestDirLoc = latestDir();
        System.out.println(latestDirLoc);

        Utils.LATEST_DIR = latestDirLoc;

        for (int j = 0; j <= testPlanKeys.length - 1; j++) {

            ArrayList<String> testKeys = getTestKeys(testPlanKeys[j], username, password, jiraURL);

            JSONArray xrayArr = new JSONArray();
            JSONObject xrayObj = new JSONObject();

            for (int a = 0; a <= testKeys.size() - 1; a++) {

                try {
                	/******Looping with respect to number of Test Folders Generated*******/
                	List<String> dirsTest=Utils.findFoldersInDirectory(latestDirLoc + "/");        
                    for (String dirTest: dirsTest) {
                	/******************/
	                	//Generate cucumber.json report
	                	//File file=new File(latestDirLoc + "/BDDTest");  //Added this code to search the meta-info.json file for "scenario outline" case
                    	File file=new File(latestDirLoc + "/" + dirTest);  //Added this code to search the meta-info.json file for "scenario outline" case
	                	File[] subdirs = file.listFiles((FileFilter) DirectoryFileFilter.DIRECTORY);
	                    for (File dir : subdirs) {
	                        System.out.println("Directory: " + dir.getName());
	                        JSONTokener obj = new JSONTokener(new FileReader(dir + "/meta-info.json"));
	                        JSONObject jsonObject = new JSONObject(obj);
	
	                        System.out.println(" ************************ " + (j + 1) + " ************************");
	
	                        JSONArray jsonMethods = jsonObject.getJSONArray("methods");
	
	                        for (int i = 0; i < jsonMethods.length(); i++) {
	
	                            JSONObject jobj = jsonMethods.getJSONObject(i);
	
	                            JSONObject jmetaObj = jobj.getJSONObject("metaData");
	                            JSONArray jmetaArr = jmetaObj.getJSONArray("groups");
	
	                            for (int k = 0; k <= jmetaArr.length() - 1; k++) {
	
	                                if (testKeys.get(a).equals(jmetaArr.get(k).toString().split("@")[1])) {
	
	                                    Utils.TEST_PLAN_KEY = testPlanKeys[j];
	
	                                    System.out.println("testKey : " + jmetaArr.get(0).toString().split("@")[1]);
	
	                                    System.out.println("startTime : " + jobj.get("startTime").toString());
	                                    Long start = new Long(jobj.get("startTime").toString());
	                                    String startdate = convertDate(start);
	
	                                    System.out.println("duration : " + jobj.get("duration").toString());
	                                    Long duration = new Long(jobj.get("duration").toString());
	                                    long finish = start + duration;
	                                    String finishdate = convertDate(finish);
	
	                                    System.out.println("result : " + jobj.get("result").toString());
	
	                                    JSONObject result = new JSONObject();
	                                    result.put("testKey", jmetaArr.get(0).toString().split("@")[1]);
	                                    result.put("start", startdate);
	                                    result.put("finish", finishdate);
	                                    result.put("status", jobj.get("result").toString().toUpperCase());
	                                    xrayArr.put(result);
	                                }
	                            }
	                        }
	                    }
	
	                    xrayObj.put("tests", xrayArr);
                    }
                } catch (IOException e) {
                }
            }

            JSONObject xrayObj1 = new JSONObject();
            //xrayObj1.put("summary", "Execution of Automated Tests");
            xrayObj1.put("summary", ConfigurationManager.getBundle().getString("xray.issue.keys")+" > "+ ScotiaQuantumReportListener.reportname);
            xrayObj1.put("testPlanKey", Utils.TEST_PLAN_KEY);
            xrayObj.put("info", xrayObj1);

            try (FileWriter file = new FileWriter(latestDirLoc + "/" + JSON_FILE_NAME.split("\\.")[0] + "_" + j + ".json")) {
                file.write(xrayObj.toString());
            } catch (IOException e) {
            }
        }
    }
    
    
    
    public static ArrayList<String> getTestKeys (String testPlanKey, String username, String password, String jiraURL) throws Exception
    {
        ArrayList<String> testKeys = new ArrayList<String>();
        String url = jiraURL + "/rest/raven/1.0/api/testplan/" + testPlanKey + "/test";
        URL obj = new URL(url);
        HttpURLConnection con = (HttpURLConnection) obj.openConnection();
        con.setRequestMethod("GET");
        con.setRequestProperty("Authorization", "Basic " + encodeBase64String(username + ":" + password));
        con.setDoOutput(true);
        int responseCode = con.getResponseCode();
        System.out.println("\nSending 'GET' request to URL : " + url);
        System.out.println("Response Code : " + responseCode);

        if(responseCode != 200)
        {
            System.out.println("*********************************************************");
            System.out.println("Please contact TCoE team");
            System.out.println("*********************************************************");
        }

        InputStream in = con.getInputStream();
        String encoding = con.getContentEncoding();
        encoding = encoding == null ? "UTF-8" : encoding;
        String body = IOUtils.toString(in, encoding);

        System.out.println(body);

        JSONArray xrayArr = new JSONArray(body);

        for (int i = 0; i < xrayArr.length(); i++) {
            testKeys.add(xrayArr.getJSONObject(i).get("key").toString());
        }

        return testKeys;
    }

    public static String convertDate(Long dateInMilis) {
        Date date = new Date(dateInMilis);
        SimpleDateFormat sdf;
        sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX");
        String convertedDate = sdf.format(date);
        return convertedDate;
    }

    public static File latestDir() {
        File dir = new File("./test-results");
        File max = null;
        for (File file : dir.listFiles()) {
            if (file.isDirectory() && (max == null || max.lastModified() < file.lastModified())) {
                max = file;
            }
        }
        return max;
    }

    public static void featureFilesCleanup() {
        File folder = new File(".\\src\\main\\resources\\scenarios");

        for (File file : folder.listFiles()) {
            if (file.getName().startsWith("downloadXray")) {
                file.delete();
            }
        }
        System.out.println("All the feature files start with downloadXray deleted successfully");
    }

    public static void unzip(String zipFilePath, String destDir, String featureFileName) {
        int counter = 0;
        int max = 999;
        int min = 111;

        File dir = new File(destDir);
        // create output directory if it doesn't exist
        if(!dir.exists()) dir.mkdirs();
        FileInputStream fis;

        //buffer for read and write data to file
        byte[] buffer = new byte[1024];
        try {
            fis = new FileInputStream(zipFilePath);
            ZipInputStream zis = new ZipInputStream(fis);
            ZipEntry ze = zis.getNextEntry();
            while(ze != null){
                String fileName = ze.getName();
                File newFile = new File(destDir + File.separator + fileName);
                System.out.println("Unzipping to "+newFile.getAbsolutePath());

                //create directories for sub directories in zip
                new File(newFile.getParent()).mkdirs();
                FileOutputStream fos = new FileOutputStream(newFile);

                int len;
                while ((len = zis.read(buffer)) > 0) {
                    fos.write(buffer, 0, len);
                }
                fos.close();

                //close this ZipEntry
                zis.closeEntry();

                //Rename the downloaded file from xray
                Random rn = new Random();
                int  n = rn.nextInt(max) + min;

                File fileNewName = new File(destDir + "\\"+ featureFileName + "_" + n + "_" + new SimpleDateFormat("yyyyMMddHHmmSS'.feature'").format(new Date()));
                if(newFile.renameTo(fileNewName)){
                    System.out.println("File rename success");
                }else{
                    System.out.println("File rename failed");
                }

                ze = zis.getNextEntry();
                counter++;
            }

            //close last ZipEntry
            zis.closeEntry();
            zis.close();
            fis.close();
            System.out.println("Total number of downloaded feature files are: " + counter);
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
    
    public static List<String> findFoldersInDirectory(String directoryPath) {
        File directory = new File(directoryPath);
    	
        FileFilter directoryFileFilter = new FileFilter() {
            public boolean accept(File file) {
                return file.isDirectory();
            }
        };
    		
        File[] directoryListAsFile = directory.listFiles(directoryFileFilter);
        List<String> foldersInDirectory = new ArrayList<String>(directoryListAsFile.length);
        for (File directoryAsFile : directoryListAsFile) {
            foldersInDirectory.add(directoryAsFile.getName());
        }

        return foldersInDirectory;
    }
    
    public static String encryptString(String strText) {
    	String encryptedStr = Base64.encodeBase64String(strText.getBytes());
    	return encryptedStr;
    }
    
    public static String decryptString(String strText) {
    	byte[] valueDecoded = Base64.decodeBase64(strText.getBytes()); 
    	return new String(valueDecoded);
    }
    
    public static void main(String[] args) {
    	System.out.println("Encrypted Password: "+Utils.encryptString("XXXXXX"));
    	System.out.println("Decoded value is " + Utils.decryptString("XXXXX"));
    }
}