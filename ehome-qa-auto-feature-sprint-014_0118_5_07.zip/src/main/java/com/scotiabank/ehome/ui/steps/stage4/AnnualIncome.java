package com.scotiabank.ehome.ui.steps.stage4;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.step.QAFTestStepProvider;
import com.qmetry.qaf.automation.ui.WebDriverTestBase;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebDriver;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.quantum.utils.ConfigurationUtils;
import com.scotiabank.ehome.ui.steps.Common;
import com.scotiabank.ehome.ui.steps.ExcelDataToDataTable;
import com.scotiabank.ehome.ui.steps.Utility;
import com.scotiabank.ehome.ui.steps.valueObjects.Tuple;
import com.scotiabank.ehome.ui.steps.valueObjects.TypeOfRateVO;
import com.thoughtworks.qdox.model.expression.Add;

import org.junit.runner.RunWith;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;

import cucumber.api.CucumberOptions;
import cucumber.api.DataTable;
import cucumber.api.PendingException;
import cucumber.api.Transform;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import cucumber.api.junit.Cucumber;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import static com.scotiabank.ehome.ui.steps.BusinessCalculations.*;
import static com.scotiabank.ehome.ui.steps.Utility.*;

import org.openqa.selenium.Keys;
@QAFTestStepProvider

public class AnnualIncome {
	
	public static WebDriverWait wait=Utility.getWait();
	  String testCaseID = Utility.getScenarioID();
    
	  private Map<String,Map<String,Boolean>> annualIncomeDataset = getScreenDataset(Utility.getExcelFilePath("eHomeTestDatastage-4.xlsx"), "AnnualIncome");
    
	
	@Given("^Customer should login and navigates to Employment annual income$")
	public void customer_should_login_and_navigates_to_Employment_annual_income() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		Utility.launchURL(ConfigurationUtils.getBaseBundle().getPropertyValue ("env.baseurl2"));
		Common.sessionBreakerContinueButtonClick();
        EmpStatus.employedButtonClicked();
        EmpType.commissionedSalesButtonClicked();
        String jobField=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage04_Employment_InputData", testCaseID, "Industry_JobTitle_Field_of_work");
        IndustryAndJobTitle.jobField(jobField);
        String jobTitle=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage04_Employment_InputData", testCaseID, "Industry_JobTitle_Job_Title");
        IndustryAndJobTitle.jobTitle(jobTitle);
        Common.continueButtonClicked();
        String employername=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage04_Employment_InputData", testCaseID, "Employer_Details_employername");
        EmployerDetails.employername(employername);
        String employerphone=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage04_Employment_InputData", testCaseID, "Employer_Details_employerphone");
        EmployerDetails.employerphone(employerphone);
        Common.continueButtonClicked();
        String address=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage04_Employment_InputData", testCaseID, "Employer_Address");
        EmpAddress.employeraddress(address);
        Common.continueButtonClicked();
				
 	}
	

	// Employment_Annual_Income_TC-002
	
	@When("^Verify \"([^\"]*)\" message should be on the Employment annual income screen$")
	public void verify_should_be_on_the_Employment_annual_income_screen(String dataPointer) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage04_Employment_ExpectedData", testCaseID, dataPointer);
		Assert.assertEquals(Common.headerMessage(), value,"Couldn't found expected header text");
	  
	}

	@Then("^Verify \"([^\"]*)\" header text should be on the Employment annual income screen$")
	public void verify_should_be_on_the_Employment_annual_income_screen1(String dataPointer) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions 
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage04_Employment_ExpectedData", testCaseID, dataPointer);
		Assert.assertEquals(Common.headertext(), value,"Couldn't found expected header text");
	}
	// Employment_Annual_Income_TC-003

	

	// Employment_Annual_Income_TC-004

	@When("^Enter \"([^\"]*)\" invalid salary in Employment annual income screen$")
	public void enter_invalid_salary_in_Employment_annual_income_screen(String dataPointer) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String col="InputValues";
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "CommonErrorMessages", dataPointer,col);
		QAFExtendedWebElement salary= new QAFExtendedWebElement("ehome.annualIncome.salary");
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(salary));
		salary.clear();
		salary.sendKeys(value);
	  
	}
	@Then("^\"([^\"]*)\" should be displayed for salary in the annual income screen$")
	public void error_message_should_be_displayed_in_the_salary_in_the_annual_income_screen(String dataPointer) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage04_Employment_ExpectedData", testCaseID, dataPointer);
		QAFExtendedWebElement salaryErrorMessage= new QAFExtendedWebElement("ehome.annualIncome.salary.errormessage");
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(salaryErrorMessage));
        Assert.assertEquals(salaryErrorMessage.getText(), value,"Couldn't found expected header text");
	    
	}
	//Bonus
	
	@When("^Enter \"([^\"]*)\" invalid bonus in Employment annual income screen$")
	public void enter_invalid_bonus_in_Employment_annual_income_screen(String dataPointer) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String col="InputValues";
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "CommonErrorMessages", dataPointer,col);
		QAFExtendedWebElement bonus= new QAFExtendedWebElement("ehome.annualIncome.bonus");
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(bonus));
		bonus.clear();
		bonus.sendKeys(value);
	  
	}
	@Then("^\"([^\"]*)\" should be displayed for bonus in the annual income screen$")
	public void error_message_should_be_displayed_in_the_bonus_in_the_annual_income_screen(String dataPointer) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage04_Employment_ExpectedData", testCaseID, dataPointer);
		QAFExtendedWebElement bonusErrorMessage= new QAFExtendedWebElement("ehome.annualIncome.bonus.errormessage");
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(bonusErrorMessage));
        Assert.assertEquals(bonusErrorMessage.getText(), value,"Couldn't found expected header text");
	    
	}
	
	//overtime
	@When("^Enter \"([^\"]*)\" invalid overtime in Employment annual income screen$")
	public void enter_invalid_overtime_in_Employment_annual_income_screen(String dataPointer) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String col="InputValues";
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "CommonErrorMessages", dataPointer,col);
		QAFExtendedWebElement overtime= new QAFExtendedWebElement("ehome.annualIncome.overtime");
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(overtime));
		overtime.clear();
		overtime.sendKeys(value);
	  
	}
	@Then("^\"([^\"]*)\" should be displayed for overtime in the annual income screen$")
	public void should_be_displayed_for_overtime_in_the_annual_income_screen(String dataPointer) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage04_Employment_ExpectedData", testCaseID, dataPointer);
		QAFExtendedWebElement overtimeErrorMessage= new QAFExtendedWebElement("ehome.annualIncome.overtime.errormessage");
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(overtimeErrorMessage));
        Assert.assertEquals(overtimeErrorMessage.getText(), value,"Couldn't found expected header text");
	    
	}
	
	
	// Employment_Annual_Income_TC-005
	 public static void annualincomeSalary(String amount) {
		 QAFExtendedWebElement salary= new QAFExtendedWebElement("ehome.annualIncome.salary");
			wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(salary));
			salary.clear();
			salary.sendKeys(amount);
			QAFExtendedWebElement bonus= new QAFExtendedWebElement("ehome.annualIncome.bonus");
			bonus.clear();
			QAFExtendedWebElement overtime= new QAFExtendedWebElement("ehome.annualIncome.overtime");
			overtime.clear();
			overtime.sendKeys("0");
		 }
	@When("^Enter \"([^\"]*)\" salary in Employment annual income screen$")
	public void enter_valid_salary_in_Employment_annual_income_screen(String dataPointer) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage04_Employment_InputData", testCaseID, dataPointer);
		annualincomeSalary(value);
	  
	}
	
	@When("^Enter \"([^\"]*)\" Bonus in Employment annual income screen$")
	public void enter_valid_Bonus_in_Employment_annual_income_screen(String dataPointer) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage04_Employment_InputData", testCaseID, dataPointer);
		QAFExtendedWebElement bonus= new QAFExtendedWebElement("ehome.annualIncome.bonus");
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(bonus));
		bonus.clear();
		bonus.sendKeys(value);
	  
	}
	@When("^Enter \"([^\"]*)\" Overtime in Employment annual income screen$")
	public void enter_valid_Overtime_in_Employment_annual_income_screen(String dataPointer) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage04_Employment_InputData", testCaseID, dataPointer);
		QAFExtendedWebElement overtime= new QAFExtendedWebElement("ehome.annualIncome.overtime");
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(overtime));
		overtime.clear();
		overtime.sendKeys(value);
	  
	}

}
