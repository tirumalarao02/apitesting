package com.scotiabank.ehome.ui.steps.stage4;
import com.qmetry.qaf.automation.step.QAFTestStepProvider;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebDriver;
import com.quantum.java.pages.ExtentReportHelper;
import com.quantum.utils.ConfigurationUtils;
import com.scotiabank.ehome.ui.steps.Common;
import com.scotiabank.ehome.ui.steps.CommonAppMethodsAssetLiabilities;
import com.scotiabank.ehome.ui.steps.CommonAppMethodsEmployment;
import com.scotiabank.ehome.ui.steps.CommonApplicationMethods;
import com.scotiabank.ehome.ui.steps.Utility;
import com.scotiabank.ehome.ui.steps.coApp.CoAppIntro;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.support.ui.WebDriverWait;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;

import java.util.Map;
import java.util.concurrent.TimeUnit;
import static com.scotiabank.ehome.ui.steps.Utility.*;

@QAFTestStepProvider

public class otherIncomeSourceDetailsforRetirement {
	  public static WebDriverWait wait=Utility.getWait();
	  static String curDir = System.getProperty("user.dir");
	  static String strfullPathToFile = curDir + "\\src\\main\\resources\\data\\eHomeTestData.xlsx"; // File Path
		
	  static String sheetStage04_InputData ="Stage04_Employment_InputData";
	  static String sheetStage04_ExpectedData ="Stage04_Employment_ExpectedData";
	  //String strtestCaseID = "OtherIncome-Source-Details-Retirement-TC-013";
	 String strtestCaseID = Utility.getScenarioID();

	  QAFExtendedWebElement srcOfincomeInvestmentAccord = new QAFExtendedWebElement("ehome.otherIncomeSrcDetails.InvestmentAccord");
	  QAFExtendedWebElement srcOfincomePensionDisabilityAccord = new QAFExtendedWebElement("ehome.otherIncomeSrcDetails.PensionDisabilityAccord");
	  QAFExtendedWebElement srcOfincomeRIFLIFAccord = new QAFExtendedWebElement("ehome.otherIncomeSrcDetails.RIFLIFAccord");
	  
	  QAFExtendedWebElement srcOfincomeDetailsContinueBtn = new QAFExtendedWebElement("ehome.otherIncomeSrcDetails.Continue");
	  QAFExtendedWebElement srcOfincomeDetailsNoOtherSourcesBtn = new QAFExtendedWebElement("ehome.otherIncomeSrcDetails.NoOtherSourcesOfIncome");
	  QAFExtendedWebElement srcOfincomeDetailsBackBtn= new QAFExtendedWebElement("ehome.otherIncomeSrcDetails.Back");

	  
	  @Given("^Customer should login and navigates to 'Sources of Income for Retirement' Screen$")
		public void Customer_should_login_and_navigates_to_Sources_of_Income_for_Retirement_Screen() throws Throwable {
		  if (strtestCaseID.contains("CoApp"))
		  {
			  Utility.launchURL(ConfigurationUtils.getBaseBundle().getPropertyValue("env.baseurl4"));
			  String UserName = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Co-App_InputData", strtestCaseID, "eHomeUserName");
			  String Password = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Co-App_InputData", strtestCaseID, "Password");
			  Common.loginToeHomeHub(UserName,Password);
			  Common.TraverseToNewHomeSectionBreaker();
			  Thread.sleep(2000);
			  Common.TraverseFromNewHomeToRateSectionBreaker(strtestCaseID,"Co-App_InputData");
			  Common.TraverseRateSectionToEmploymentSectionBreaker();
			  Common.TraverseFromEmploymentSectionToLandOnCoApplicantPage();
			  CoAppIntro.startSectionButtonClicked();
		  }
		  else {
			  Utility.launchURL(ConfigurationUtils.getBaseBundle().getPropertyValue("env.baseurl2"));
			  Common.sessionBreakerContinueButtonClick();
		  }
		  	Map<String, String> Stage04_InputData =  Utility.readTestData(strfullPathToFile, sheetStage04_InputData,strtestCaseID);
			String strCurrentEmpStatus	= Stage04_InputData.get("Empmt_Status"); 	// Retrieve "Current Employment status" from Excel
			String strDurationYear=  Stage04_InputData.get("Years");
			String strDurationMonth=  Stage04_InputData.get("Months");

		  if (!(Utility.getDriver().findElement("ehome.employmentDuration.years").isPresent()))
		  {
			  Common.continueButtonClicked();
		  }
		  CommonAppMethodsEmployment.SelectEmpStatus(strCurrentEmpStatus);
			Thread.sleep(1000);
				
			if (strDurationYear != "") {
				CommonApplicationMethods.selectValuefromDropDownListBox("ehome.employmentDuration.years", strDurationYear);
		 			Thread.sleep(250);
			}
			if (strDurationMonth != "") {
				CommonApplicationMethods.selectValuefromDropDownListBox("ehome.employmentDuration.months", strDurationMonth);
				Thread.sleep(250);
			}
				Thread.sleep(500);
				Common.continueButtonClicked();
				Thread.sleep(500);
		}

		
	@Then("^Verify presence of all objects on 'Other Income Source Details for Retirement' Screen$")
	public void Verify_Sources_Of_Income_Retirement_Duration_Screen() throws Throwable {
		
		Thread.sleep(500);
		if(srcOfincomeInvestmentAccord.isPresent())
		{
			ExtentReportHelper.StepPass("'" + srcOfincomeInvestmentAccord.getText() + "' option button is displayed.");
		}
		else
		{
			ExtentReportHelper.StepFail("'" + srcOfincomeInvestmentAccord.getText() + "' option button is NOT displayed.");
		}
		if(srcOfincomePensionDisabilityAccord.isPresent())
		{
			ExtentReportHelper.StepPass("'" + srcOfincomePensionDisabilityAccord.getText() + "' option button is displayed.");
		}
		else
		{
			ExtentReportHelper.StepFail("'" + srcOfincomePensionDisabilityAccord.getText() + "' option button is NOT displayed.");
		}	
		if(srcOfincomeRIFLIFAccord.isPresent())
		{
			ExtentReportHelper.StepPass("'" + srcOfincomeRIFLIFAccord.getText() + "' option button is displayed.");
		}
		else
		{
			ExtentReportHelper.StepFail("'" + srcOfincomeRIFLIFAccord.getText() + "' option button is NOT displayed.");
		}	
		
		if(srcOfincomeDetailsContinueBtn.isPresent())
		{
			ExtentReportHelper.StepPass("'" + srcOfincomeDetailsContinueBtn.getText() + "' option button is displayed.");
		}
		else
		{
			ExtentReportHelper.StepFail("'" + srcOfincomeDetailsContinueBtn.getText() + "' option button is NOT displayed.");
		}	
		
		if(srcOfincomeDetailsBackBtn.isPresent())
		{
			ExtentReportHelper.StepPass("'" + srcOfincomeDetailsBackBtn.getText() + "' option button is displayed.");
		}
		else
		{
			ExtentReportHelper.StepFail("'" + srcOfincomeDetailsBackBtn.getText() + "' option button is NOT displayed.");
		}	
	 		}

	@Then("^Verify 'Sources of Income' Screen when Click on 'Back' button on 'Other sources income details' screen$")
	public void Verify_Sources_of_Income_Screen_when_Click_on_Back_button_on_Other_sources_income_details() throws Throwable {

			Thread.sleep(500);
			srcOfincomeDetailsBackBtn.click();
			Thread.sleep(500);

if (strtestCaseID.contains("CoApp")){
	if (!(Utility.getDriver().findElement("ehome.coAppOtherSrcsOfIncome.SrcOfIncomeTitle").getText().contains("been retired")))
		throw new AssertionError("Title is incorrect");
}
else {
	Map<String, String> Stage04_ExpectedData =  Utility.readTestData(strfullPathToFile, sheetStage04_ExpectedData,strtestCaseID);
	String strotherSrcsOfIncome_ExpectedTitle	= Stage04_ExpectedData.get("Emplmt_Srcs_Of_Income_Title");

	QAFExtendedWebElement strotherSrcsOfIncome_ActualTitle= new QAFExtendedWebElement("ehome.otherSrcsOfIncome.SrcOfIncomeTitle");
	if (strotherSrcsOfIncome_ExpectedTitle.contentEquals(strotherSrcsOfIncome_ActualTitle.getText())) {
		ExtentReportHelper.StepPass(strotherSrcsOfIncome_ExpectedTitle + " Screen# is displayed.");
	}
	else
	{
		Assert.assertEquals(strotherSrcsOfIncome_ActualTitle.getText(), strotherSrcsOfIncome_ExpectedTitle,"'Sources of Income' Screen is NOT as Expected.");
	}
}
}



	
	
	@Then("^Verify 'Error Message' on 'Other sources income details' screen when click on 'Continue' with Blank values$")
	public void Verify_Error_Message_on_Other_sources_income_details_screen_when_click_on_Continue_with_Blank_values() throws Throwable {
		
			Map<String, String> Stage04_ExpectedData =  Utility.readTestData(strfullPathToFile, sheetStage04_ExpectedData,strtestCaseID);
				String strMandatry_ExpectedErrMesg	= Stage04_ExpectedData.get("Other_Srcs_income_details_MandError_Msg");

			srcOfincomeDetailsContinueBtn.click();
			Thread.sleep(500);
			QAFExtendedWebElement strMandatry_ActualErrMesg= new QAFExtendedWebElement("ehome.otherIncomeSrcDetails.MandtryErrMsg");
    		if (strMandatry_ExpectedErrMesg.contentEquals(strMandatry_ActualErrMesg.getText())) {
    			ExtentReportHelper.StepPass("'" + strMandatry_ExpectedErrMesg + " ' Message# is displayed.");
    		}
    		else
    		{
    			Assert.assertEquals(strMandatry_ActualErrMesg.getText(), strMandatry_ExpectedErrMesg,"'Mandatory Error Message' is NOT as Expected.");
    		}	
		}
	
	
	@Then("^Verify 'Asset-section-breaker' screen when click on 'Continue' with annual incomes on 'Other sources income details'$")
	public void Verify_Assetsectionbreaker_screen_when_click_on_Continue_with_annual_income_on_Other_sources_income_details() throws Throwable {
		
		Map<String, String> Stage04_InputData =  Utility.readTestData(strfullPathToFile, sheetStage04_InputData,strtestCaseID);
		String strInvestment_ExpectedInput	= Stage04_InputData.get("EmpOtherSrcsOfIncome_Investments"); 
		String strInvestmentAmt_ExpectedInput	= Stage04_InputData.get("EmpOtherSrcsOfIncome_Investments_Amt");
		
		String strPensionDisability_ExpectedInput	= Stage04_InputData.get("EmpOtherSrcsOfIncome_PensionDisability"); 
		String strPensionDisabilityAmt_ExpectedInput	= Stage04_InputData.get("EmpOtherSrcsOfIncome_PensionDisability_Amt");
		
		String strRIFLIF_ExpectedInput	= Stage04_InputData.get("EmpOtherSrcsOfIncome_RIFLIF"); 
		String strRIFLIFAmt_ExpectedInput	= Stage04_InputData.get("EmpOtherSrcsOfIncome_RIFLIF_Amt"); 
			

			if (strInvestment_ExpectedInput != "" | strInvestmentAmt_ExpectedInput != "") {
				CommonAppMethodsEmployment.EnterRetiredAnualIncomeSourceAmount(strInvestment_ExpectedInput, strInvestmentAmt_ExpectedInput);
			}
			if (strPensionDisability_ExpectedInput != "" | strPensionDisabilityAmt_ExpectedInput != "") {
				CommonAppMethodsEmployment.EnterRetiredAnualIncomeSourceAmount(strPensionDisability_ExpectedInput, strPensionDisabilityAmt_ExpectedInput);
			}
			if (strRIFLIF_ExpectedInput != "" | strRIFLIFAmt_ExpectedInput != "") {
				CommonAppMethodsEmployment.EnterRetiredAnualIncomeSourceAmount(strRIFLIF_ExpectedInput, strRIFLIFAmt_ExpectedInput);
			}
			srcOfincomeDetailsContinueBtn.click();

		Map<String, String> Stage04_ExpectedData =  Utility.readTestData(strfullPathToFile, sheetStage04_ExpectedData,strtestCaseID);
		String strassetSectionBrk_ExpectedTitle	= Stage04_ExpectedData.get("Asset_Section_Breaker_Title");

		QAFExtendedWebElement strassetSectionBrk_ActualTitle= new QAFExtendedWebElement("ehome.assetSectionBrkr.Title");


    		if (strassetSectionBrk_ExpectedTitle.contentEquals(strassetSectionBrk_ActualTitle.getText())) {
    			ExtentReportHelper.StepPass(strassetSectionBrk_ExpectedTitle + " Screen# is displayed.");
    		}
    		else
    		{
    			Assert.assertEquals(strassetSectionBrk_ActualTitle.getText(), strassetSectionBrk_ExpectedTitle,"'Asset-section-breaker' Screen is NOT as Expected.");
    		}	
		}

}
