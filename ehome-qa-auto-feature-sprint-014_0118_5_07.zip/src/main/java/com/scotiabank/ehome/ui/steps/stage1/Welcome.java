package com.scotiabank.ehome.ui.steps.stage1;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.step.QAFTestStepProvider;
import com.qmetry.qaf.automation.ui.WebDriverTestBase;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebDriver;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.quantum.utils.ConfigurationUtils;
import com.scotiabank.ehome.ui.steps.Common;
import com.scotiabank.ehome.ui.steps.ExcelDataToDataTable;
import com.scotiabank.ehome.ui.steps.Utility;
import com.scotiabank.ehome.ui.steps.valueObjects.Tuple;
import com.scotiabank.ehome.ui.steps.valueObjects.TypeOfRateVO;
import com.thoughtworks.qdox.model.expression.Add;

import org.junit.runner.RunWith;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;

import cucumber.api.CucumberOptions;
import cucumber.api.DataTable;
import cucumber.api.PendingException;
import cucumber.api.Transform;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import cucumber.api.junit.Cucumber;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import static com.scotiabank.ehome.ui.steps.BusinessCalculations.*;
import static com.scotiabank.ehome.ui.steps.Utility.*;

import org.openqa.selenium.Keys;
@QAFTestStepProvider

public class Welcome {
	public static WebDriverWait wait=Utility.getWait();	
	//Welcome-TC-001
	@Given("^Customer should login and navigates to welcome screen$")
	public void customer_should_login_and_navigates_to_welcome_screen() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
	Utility.launchURL(ConfigurationUtils.getBaseBundle().getPropertyValue ("env.baseurl0"));
	}
	public static void viewOurPrivacyAgreementButtonClicked() {
    	QAFExtendedWebElement viewOurPrivacyAgreement= new QAFExtendedWebElement("ehome.welcome.viewOurPrivacyAgreement");
        wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(viewOurPrivacyAgreement));
        viewOurPrivacyAgreement.click();
	}
	//Welcome-TC-002
	@When("^Verify the \"([^\"]*)\" on the welcome screen$")
	public void verify_the_on_the_welcome_screen(String dataPointer) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String testCaseID = Utility.getScenarioID();
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage01_Registration_ExpectedDa", testCaseID, dataPointer);
		QAFExtendedWebElement title= new QAFExtendedWebElement("ehome.welcome.title");
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(title));
		Assert.assertEquals(title.getText(), value,"Couldn't found expected header message");
	   
	}

	@Then("^\"([^\"]*)\" should be displayed on the welcome screen$")
	public void should_be_displayed_on_the_welcome_screen(String dataPointer) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String testCaseID = Utility.getScenarioID();
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage01_Registration_ExpectedDa", testCaseID, dataPointer);
		QAFExtendedWebElement titlecontent= new QAFExtendedWebElement("ehome.welcome.titlecontent");
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(titlecontent));
		Assert.assertEquals(titlecontent.getText(),value,"Couldn't found expected header message");
	}
	//Welcome-TC-003
	@When("^Verify the \"([^\"]*)\" Preferred Rates on the welcome screen$")
	public void verify_the_Preferred_Rates_on_the_welcome_screen(String dataPointer) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String testCaseID = Utility.getScenarioID();
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage01_Registration_ExpectedDa", testCaseID, dataPointer);
		QAFExtendedWebElement preferredRates= new QAFExtendedWebElement("ehome.welcome.preferredRates");
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(preferredRates));
		Assert.assertEquals(preferredRates.getText(),value,"Couldn't found expected text");
	    
	}

	@Then("^\"([^\"]*)\" Preferred Rates content should be displayed on the welcome screen$")
	public void preferred_Rates_content_should_be_displayed_on_the_welcome_screen(String dataPointer) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String testCaseID = Utility.getScenarioID();
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage01_Registration_ExpectedDa", testCaseID, dataPointer);
		QAFExtendedWebElement preferredRatescontent= new QAFExtendedWebElement("ehome.welcome.preferredRatescontent");
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(preferredRatescontent));
		Assert.assertEquals(preferredRatescontent.getText(),value,"Couldn't found expected text");
	    
	}
	//Welcome-TC-004
	@When("^Verify the \"([^\"]*)\" Simple and Secure Process on the welcome screen$")
	public void verify_the_Simple_and_Secure_Process_on_the_welcome_screen(String dataPointer) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String testCaseID = Utility.getScenarioID();
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage01_Registration_ExpectedDa", testCaseID, dataPointer);
		QAFExtendedWebElement simpleandSecureProcess= new QAFExtendedWebElement("ehome.welcome.simpleandSecureProcess");
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(simpleandSecureProcess));
		Assert.assertEquals(simpleandSecureProcess.getText(),value,"Couldn't found expected text");
	    
	}

	@Then("^\"([^\"]*)\" Simple and Secure Process content should be displayed on the welcome screen$")
	public void simple_and_Secure_Process_content_should_be_displayed_on_the_welcome_screen(String dataPointer) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String testCaseID = Utility.getScenarioID();
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage01_Registration_ExpectedDa", testCaseID, dataPointer);
		QAFExtendedWebElement simpleandSecureProcesscontent= new QAFExtendedWebElement("ehome.welcome.simpleandSecureProcesscontent");
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(simpleandSecureProcesscontent));
		Assert.assertEquals(simpleandSecureProcesscontent.getText(),value,"Couldn't found expected text");
	    
	}
	//Welcome-TC-005
	@When("^Verify the \"([^\"]*)\" Real-Time Updates on the welcome screen$")
	public void verify_the_Real_Time_Updates_on_the_welcome_screen(String dataPointer) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String testCaseID = Utility.getScenarioID();
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage01_Registration_ExpectedDa", testCaseID, dataPointer);
		QAFExtendedWebElement realTimeUpdates= new QAFExtendedWebElement("ehome.welcome.realTimeUpdates");
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(realTimeUpdates));
		Assert.assertEquals(realTimeUpdates.getText(),value,"Couldn't found expected text");
	    
	}

	@Then("^\"([^\"]*)\" Real-Time Updates content should be displayed on the welcome screen$")
	public void real_Time_Updates_content_should_be_displayed_on_the_welcome_screen(String dataPointer) throws Throwable {
	    // Write code here threalTimeUpdatesat turns the phrase above into concrete actions
		String testCaseID = Utility.getScenarioID();
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage01_Registration_ExpectedDa", testCaseID, dataPointer);
		QAFExtendedWebElement realTimeUpdatescontent= new QAFExtendedWebElement("ehome.welcome.realTimeUpdatescontent");
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(realTimeUpdatescontent));
		Assert.assertEquals(realTimeUpdatescontent.getText(),value,"Couldn't found expected text");
	   
	}
	//Welcome-TC-006
	@When("^Verify the \"([^\"]*)\" Fully Digital Application on the welcome screen$")
	public void verify_the_Fully_Digital_Application_on_the_welcome_screen(String dataPointer) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		 // Write code here that turns the phrase above into concrete actions
		String testCaseID = Utility.getScenarioID();
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage01_Registration_ExpectedDa", testCaseID, dataPointer);
		QAFExtendedWebElement fullyDigital= new QAFExtendedWebElement("ehome.welcome.fullyDigital");
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(fullyDigital));
		Assert.assertEquals(fullyDigital.getText(),value,"Couldn't found expected text");
	    
	}

	@Then("^\"([^\"]*)\" Fully Digital Application content should be displayed on the welcome screen$")
	public void fully_Digital_Application_content_should_be_displayed_on_the_welcome_screen(String dataPointer) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String testCaseID = Utility.getScenarioID();
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage01_Registration_ExpectedDa", testCaseID, dataPointer);
		QAFExtendedWebElement fullyDigitalcontent= new QAFExtendedWebElement("ehome.welcome.fullyDigitalcontent");
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(fullyDigitalcontent));
		Assert.assertEquals(fullyDigitalcontent.getText(),value,"Couldn't found expected text");
	}
	//Welcome-TC-007
	@When("^Verify the \"([^\"]*)\" Before we get started content on the welcome screen$")
	public void verify_the_Before_we_get_started_content_on_the_welcome_screen(String dataPointer) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String testCaseID = Utility.getScenarioID();
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage01_Registration_ExpectedDa", testCaseID, dataPointer);
		QAFExtendedWebElement beforewegetstarted= new QAFExtendedWebElement("ehome.welcome.beforewegetstarted");
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(beforewegetstarted));
		Assert.assertEquals(beforewegetstarted.getText(),value,"Couldn't found expected text");
	}

	@Then("^\"([^\"]*)\" eHOME can only process content should be displayed on the welcome screen$")
	public void ehome_can_only_process_content_should_be_displayed_on_the_welcome_screen(String dataPointer) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		// Write code here that turns the phrase above into concrete actions
				String testCaseID = Utility.getScenarioID();
				String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage01_Registration_ExpectedDa", testCaseID, dataPointer);
				QAFExtendedWebElement eHOME_canonlyprocess= new QAFExtendedWebElement("ehome.welcome.eHOME_canonlyprocesst");
				wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(eHOME_canonlyprocess));
				Assert.assertEquals(eHOME_canonlyprocess.getText(),value,"Couldn't found expected text");
			}
	//Welcome-TC-008
	@When("^Click on the View our privacy agreement$")
	public void click_on_the_View_our_privacy_agreement() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		viewOurPrivacyAgreementButtonClicked();
	}

	@Then("^It should navigate to \"([^\"]*)\" privacy policy screen$")
	public void it_should_navigate_to_privacy_policy_screen(String dataPointer) throws Throwable {
    // Write code here that turns the phrase above into concrete actions
		String testCaseID = Utility.getScenarioID();
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage01_Registration_ExpectedDa", testCaseID, dataPointer);
		QAFExtendedWebElement headerText= new QAFExtendedWebElement("ehome.Header.text");
		Assert.assertEquals(headerText.getText(), value,"Couldn't found expected header text");
	}
	//Welcome-TC-009
	
	@When("^Click on the Contact one today on the welcome screen$")
	public void click_on_the_Contact_one_today_on_the_welcome_screen() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		QAFExtendedWebElement contactonetoday= new QAFExtendedWebElement("ehome.welcome.contactonetoday");
	    wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(contactonetoday));
	    contactonetoday.click();
	    
	}

	@Then("^It should navigate to \"([^\"]*)\" screen$")
	public void it_should_navigate_to_screen(String dataPointer) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String testCaseID = Utility.getScenarioID();
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage01_Registration_ExpectedDa", testCaseID, dataPointer);
		String windowHandleBefore = getDriver().getWindowHandle();
		 for(String winHandle: getDriver().getWindowHandles()) {
			 getDriver().switchTo().window(winHandle);
		 }
		 Assert.assertEquals(getDriver().getCurrentUrl(), value,"Couldn't found expected Home Financing Advisor URL");
		 getDriver().close();
		 getDriver().switchTo().window(windowHandleBefore);
	    
	}

}
