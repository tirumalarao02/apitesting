package com.scotiabank.ehome.ui.steps.stage4;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.step.QAFTestStepProvider;
import com.qmetry.qaf.automation.ui.WebDriverTestBase;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebDriver;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.quantum.utils.ConfigurationUtils;
import com.scotiabank.ehome.ui.steps.Common;
import com.scotiabank.ehome.ui.steps.ExcelDataToDataTable;
import com.scotiabank.ehome.ui.steps.Utility;
import com.scotiabank.ehome.ui.steps.valueObjects.Tuple;
import com.scotiabank.ehome.ui.steps.valueObjects.TypeOfRateVO;
import com.thoughtworks.qdox.model.expression.Add;

import org.junit.runner.RunWith;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;

import cucumber.api.CucumberOptions;
import cucumber.api.DataTable;
import cucumber.api.PendingException;
import cucumber.api.Transform;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import cucumber.api.junit.Cucumber;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import static com.scotiabank.ehome.ui.steps.BusinessCalculations.*;
import static com.scotiabank.ehome.ui.steps.Utility.*;

import org.openqa.selenium.Keys;
@QAFTestStepProvider

public class EmploymentDuration {

	public static WebDriverWait wait=Utility.getWait();
	String testCaseID = Utility.getScenarioID();
  
    @Given("^Customer should login and navigates to Employment Duration$")
    public void customer_should_login_and_navigates_to_Employment_Duration() throws Throwable {
    	// Write code here that turns the phrase above into concrete actions
    	Utility.launchURL(ConfigurationUtils.getBaseBundle().getPropertyValue ("env.baseurl2"));
		Common.sessionBreakerContinueButtonClick();
        EmpStatus.employedButtonClicked();
        EmpType.commissionedSalesButtonClicked();
        String jobField=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage04_Employment_InputData", testCaseID, "Industry_JobTitle_Field_of_work");
        IndustryAndJobTitle.jobField(jobField);
        String jobTitle=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage04_Employment_InputData", testCaseID, "Industry_JobTitle_Job_Title");
        IndustryAndJobTitle.jobTitle(jobTitle);
        Common.continueButtonClicked();
        String employername=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage04_Employment_InputData", testCaseID, "Employer_Details_employername");
        EmployerDetails.employername(employername);
        String employerphone=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage04_Employment_InputData", testCaseID, "Employer_Details_employerphone");
        EmployerDetails.employerphone(employerphone);
        Common.continueButtonClicked();
        String address=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage04_Employment_InputData", testCaseID, "Employer_Address");
        EmpAddress.employeraddress(address);
        Common.continueButtonClicked();	
        String annualincomeSalary=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage04_Employment_InputData", testCaseID, "Employer_AnnualIncome_Salary");
        AnnualIncome.annualincomeSalary(annualincomeSalary);
        Common.continueButtonClicked();
    	  		    
	}
	// Employment_Duration_TC-002
	
    @When("^Verify \"([^\"]*)\" message should be on the Employment Duration screen$")
    public void verify_should_be_on_the_Employment_Duration_screen123(String dataPointer) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
    	String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage04_Employment_ExpectedData", testCaseID, dataPointer);
		Assert.assertEquals(Common.headerMessage(), value,"Couldn't found expected header text");
	  
	}

    @Then("^Verify \"([^\"]*)\" header text should be on the Employment Duration screen$")
    public void verify_should_be_on_the_Employment_Duration_screen(String dataPointer) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions 
    	String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage04_Employment_ExpectedData", testCaseID, dataPointer);
		Assert.assertEquals(Common.headertext(), value,"Couldn't found expected header text");
	  
	}

	// Employment_Duration_TC-003

	
	// Employment_Duration_TC-004
    public static void employmentDuration(String year, String month) throws InterruptedException {
    	QAFExtendedWebElement yearbutton= new QAFExtendedWebElement("ehome.employmentDuration.years");
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(yearbutton));
		yearbutton.click();
		Select yearSelect = new Select(yearbutton);
		yearSelect.selectByVisibleText(year);
		
		QAFExtendedWebElement monthbutton= new QAFExtendedWebElement("ehome.employmentDuration.months");
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(monthbutton));
		monthbutton.click();
		Thread.sleep(5000);
		Select monthSelect = new Select(monthbutton);
		monthSelect.selectByVisibleText(month);
		 
		 }

	@When("^Enter \"([^\"]*)\" years and \"([^\"]*)\" months in Employment Duration screen$")
	public void enter_invalid_duration_in_Employment_Duration_screen(String dataPointer, String  dataPointer1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage04_Employment_InputData", testCaseID, dataPointer);
		String value1=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage04_Employment_InputData", testCaseID, dataPointer1);
		employmentDuration(value, value1);
	    
	}



	
	

	
	
}
