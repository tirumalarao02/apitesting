package com.scotiabank.ehome.ui.steps.stage2;
import com.qmetry.qaf.automation.step.QAFTestStepProvider;
import com.qmetry.qaf.automation.ui.WebDriverTestBase;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebDriver;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.quantum.utils.ConfigurationUtils;
import com.scotiabank.ehome.ui.steps.Common;
import com.scotiabank.ehome.ui.steps.ExcelDataToDataTable;
import com.scotiabank.ehome.ui.steps.Utility;
import com.scotiabank.ehome.ui.steps.valueObjects.Tuple;
import com.scotiabank.ehome.ui.steps.valueObjects.TypeOfRateVO;
import com.thoughtworks.qdox.model.expression.Add;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;

import cucumber.api.DataTable;
import cucumber.api.Transform;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import static com.scotiabank.ehome.ui.steps.BusinessCalculations.*;
import static com.scotiabank.ehome.ui.steps.Utility.*;
@QAFTestStepProvider

public class TypeOfHouse {
	public static WebDriverWait wait=Utility.getWait();
    private Map<String,Map<String,Boolean>> typeOfHouseDataset = getScreenDataset(Utility.getExcelFilePath("eHomeTestData.xlsx"), "Type_of_House");
  
    	@Given("^Customer should login and navigates to Type of House screen$")
	    public void CustomershouldloginandnavigatetoTypeofHousescreen() throws Throwable {
    		 // Write code here that turns the phrase above into concrete actions
        	Utility.launchURL(ConfigurationUtils.getBaseBundle().getPropertyValue ("env.baseurl1"));
            //To click Continue in Section breaker
            Common.sessionBreakerContinueButtonClick();
            //To enter manual address 
           	Common.enterAddressManually();
           	//To select house
	 	     PropertyType.houseButtonClicked();
	         Thread.sleep(2000);        
	 	     
        } 
	  //Scenario: Type_of_House_002 
	    @When("^verify \"([^\"]*)\" in Type of House screen$")
	    public void verify_Exciting_in_Type_of_House_screen(String dataPointer) throws Throwable {
	        // Write code here that turns the phrase above into concrete actions
	    	//TO Check the header message
	    	String testCaseID = Utility.getScenarioID();
			String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_ExpectedData", testCaseID, dataPointer);
			Assert.assertEquals(Common.headerMessage(), value,"Couldn't found expected header text");
	    }
	    
	    @Then("^\"([^\"]*)\" should be displayed in Type of House screen$")
	    public void What_type_of_house_is_this_should_be_displayed_in_Type_of_House_screen(String dataPointer) throws Throwable {
	        // Write code here that turns the phrase above into concrete actions
	    	//TO Check the header text 
	    	QAFExtendedWebElement Detached= new QAFExtendedWebElement("ehome.TypeOfHouse.Detached.button");
	    	wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(Detached));
	    	String testCaseID = Utility.getScenarioID();
			String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_ExpectedData", testCaseID, dataPointer);
			Assert.assertEquals(Common.headertext(), value,"Couldn't found expected header text");
	    }
	    
	    //Scenario: Type_of_House_004
	    public static void typeOfHouseButtonClicked(String expectedText) {
	    	if (expectedText.contentEquals("Detached")) {
		    	QAFExtendedWebElement Detached= new QAFExtendedWebElement("ehome.TypeOfHouse.Detached.button");
		    	wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(Detached));
		    	Detached.click();
		    	
	            
	    	 } 
	    	 else if (expectedText.contentEquals("Semi-detached")) {
		    	 QAFExtendedWebElement Semidetached= new QAFExtendedWebElement("ehome.TypeOfHouse.Semi-detached.button");
		    	 wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(Semidetached));
		     	 Semidetached.click();
			     
			}
	    	 else if (expectedText.contentEquals("Freehold townhouse")) {
		    	 QAFExtendedWebElement Freeholdtownhouse= new QAFExtendedWebElement("ehome.TypeOfHouse.Freeholdtownhouse.button");
		    	 wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(Freeholdtownhouse));
		     	 Freeholdtownhouse.click();
			}
	      
		}
	 
	    @When("^verify \"([^\"]*)\" check button and then click on Detached in Type of House screen$")
	    public void verifyCheckButtonAndThenClickOnDetachedInTypeOfHouseScreen(String dataPointer) throws Throwable {
	        // Write code here that turns the phrase above into concrete actions
	    	String testCaseID = Utility.getScenarioID();
			String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_ExpectedData", testCaseID, dataPointer);
			 typeOfHouseButtonClicked(value);
	    		        
	    }
	    		
	    @Then("^It should navigate to type of House screen and check \"([^\"]*)\" is highlighted and checked$")
	    public void itShouldNavigateToTypeOfHouseScreenAndCheckIsHighlightedAndChecked(String expectedText) throws Throwable {
	        // Write code here that turns the phrase above into concrete actions
	        QAFExtendedWebElement headerTypeofHouse= new QAFExtendedWebElement("ehome.Header.text");
	        headerTypeofHouse.isPresent();
	        if (expectedText.contentEquals("Detached")) {
		    	QAFExtendedWebElement Detached= new QAFExtendedWebElement("ehome.TypeOfHouse.Detached.button");
		    	 String color = Detached.getCssValue("background-color");
		         String hex = Utility.convertRGBToHex(color);
		         Assert.assertEquals("#8230df", hex);
		         if (!hex.contentEquals("#8230df"))
		             throw new AssertionError("houseSelect is not highlighted with #8230df color");
	            Thread.sleep(3000);
	    	 } 
	    	 else if (expectedText.contentEquals("Semi-detached")) {
		    	 QAFExtendedWebElement Semidetached= new QAFExtendedWebElement("ehome.TypeOfHouse.Semi-detached.button");
		    	 String color = Semidetached.getCssValue("background-color");
		         String hex = Utility.convertRGBToHex(color);
		         Assert.assertEquals("#8230df", hex);
		         if (!hex.contentEquals("#8230df"))
		             throw new AssertionError("houseSelect is not highlighted with #8230df color");
	            Thread.sleep(3000);
			}
	    	 else if (expectedText.contentEquals("Freehold townhouse")) {
		    	 QAFExtendedWebElement Freeholdtownhouse= new QAFExtendedWebElement("ehome.TypeOfHouse.Freeholdtownhouse.button");
		    	 String color = Freeholdtownhouse.getCssValue("background-color");
		         String hex = Utility.convertRGBToHex(color);
		         Assert.assertEquals("#8230df", hex);
		         if (!hex.contentEquals("#8230df"))
		             throw new AssertionError("houseSelect is not highlighted with #8230df color");
	            Thread.sleep(3000);
				
			}
	    }
	  //Scenario: Type_of_House_004
	   
		@Then("^It should navigate to Property Type screen$")
	    public void It_should_navigate_to_Property_Type_screen() throws Throwable {
	        // Write code here that turns the phrase above into concrete actions
	        QAFExtendedWebElement PropertyTypeheader= new QAFExtendedWebElement("ehome.Header.text");
	        PropertyTypeheader.isPresent();
	        	//Assert.assertEquals(Propertytype.getText(), expectedText,"What type of property have you made an offer on? is not displayed");
	    }

}
