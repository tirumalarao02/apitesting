package com.scotiabank.ehome.ui.steps.stage3;

import com.qmetry.qaf.automation.step.QAFTestStepProvider;
import com.qmetry.qaf.automation.ui.WebDriverTestBase;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebDriver;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.quantum.utils.ConfigurationUtils;
//import com.scotiabank.ehome.ui.steps.valueObjects.TypeOfRateVO;

import com.scotiabank.ehome.ui.steps.Common;
import com.scotiabank.ehome.ui.steps.Utility;
import com.scotiabank.ehome.ui.steps.valueObjects.TypeOfRateVO;
import cucumber.api.PendingException;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.testng.Assert;

import static com.scotiabank.ehome.ui.steps.BusinessCalculations.calculateLoanRequested;
import static com.scotiabank.ehome.ui.steps.Utility.*;
@QAFTestStepProvider

public class RateUnlock {
    private QAFExtendedWebDriver webDriver = new WebDriverTestBase().getDriver();
    public Actions action = null;
    WebDriverWait wait = new WebDriverWait(webDriver, 50000);

    String testCaseID = Utility.getScenarioID();

    QAFExtendedWebElement Continue = new QAFExtendedWebElement("ehome.tellus.continue.button");
    QAFExtendedWebElement eHomeHeader = new QAFExtendedWebElement("ehome.rate.Header.text");

    QAFExtendedWebElement LockandHold= new QAFExtendedWebElement("ehome.ratelock.LockandHold");
    QAFExtendedWebElement RateCustomizationHeader= new QAFExtendedWebElement("ehome.RateCustomization.Unlockyourrate");
    QAFExtendedWebElement RateCustomizationBackbutton= new QAFExtendedWebElement("ehome.RateCustomization.Back.Button");

    QAFExtendedWebElement Purchasepricevalue = new QAFExtendedWebElement("ehome.purchaseprice.span");
    QAFExtendedWebElement downpaymentvalue = new QAFExtendedWebElement("ehome.downpayment.span");

    QAFExtendedWebElement mortgagesummarytitle = new QAFExtendedWebElement("ehome.mortgagesummarytitle.text");
    QAFExtendedWebElement Purchaseprice = new QAFExtendedWebElement("ehome.purchaseprice.text");
    QAFExtendedWebElement downpayment = new QAFExtendedWebElement("ehome.downpayment.text");
    QAFExtendedWebElement loanrequested = new QAFExtendedWebElement("ehome.loanrequested.text");
    QAFExtendedWebElement loanrequestedvalue = new QAFExtendedWebElement("ehome.loanrequested.span");

    QAFExtendedWebElement headertext1 = new QAFExtendedWebElement("ehome.ratelock.headertext1");
    QAFExtendedWebElement headertext2 = new QAFExtendedWebElement("ehome.ratelock.headertext2");
    QAFExtendedWebElement p1= new QAFExtendedWebElement("ehome.rateunlock.p1");
    QAFExtendedWebElement p2= new QAFExtendedWebElement("ehome.rateunlock.p2");


    QAFExtendedWebElement selectFixed = new QAFExtendedWebElement("ehome.typeofrate.selectfixed.radio");
    QAFExtendedWebElement twoyearss = new QAFExtendedWebElement("ehome.termsofrate.2years.radio");
    QAFExtendedWebElement twoyear = new QAFExtendedWebElement("ehome.ratepresentation.twoyears.select");

    QAFExtendedWebElement Mortgage = new QAFExtendedWebElement("ehome.ratelock.Mortgage");
	
    @Given("^Customer should login and navigates to Rate Unlock$")
    public void customerShouldLoginAndNavigatesToRateUnLock() throws Throwable {

        Common.stage2ToStage3(testCaseID);
        wait.until(ExpectedConditions.visibilityOf(eHomeHeader));
        Continue.click();
        selectFixed.click();
        if (!twoyearss.verifyPresent())
            throw new AssertionError("Couldn't find 2 years button");
        Thread.sleep(2000);
        twoyearss.click();
        if (!twoyear.verifyPresent())
            throw new AssertionError("Couldn't find 2 years button");
        wait.until(ExpectedConditions.elementToBeClickable(twoyear));
        twoyear.click();

        if(!LockandHold.verifyPresent())
            throw new AssertionError("Couldn't find Lock & Hold on the screen");
        LockandHold.click();
        Thread.sleep(2000);
        String Rate_UnLock_Link_Text = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage03_Rate_ExpectedData", testCaseID, "Rate_UnLock_Link_Text");
        Assert.assertEquals(RateCustomizationHeader.getText(),Rate_UnLock_Link_Text,"Unlock your rate is not present");
        RateCustomizationBackbutton.click();
    }
    //Rate_Unlock_003
    @When("^Verify Rate UnLock Screen Message and Header Text in Rate UnLock Screen$")
    public void verifyRateUnLockScreenMessageAndHeaderTextInRateUnLockScreen() throws Throwable {

        headertext1.assertPresent();
        String Rate_UnLock_Message = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage03_Rate_ExpectedData", testCaseID, "Rate_UnLock_Message");
        Assert.assertEquals(headertext1.getText(),Rate_UnLock_Message, "Hold on, Janet!");

        headertext2.assertPresent( );
        String Rate_UnLock_Header = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage03_Rate_ExpectedData", testCaseID, "Rate_UnLock_Header");
        Assert.assertEquals(headertext2.getText(),Rate_UnLock_Header, "You’re about to unlock your exclusive eHOME rate");
    	}

    @Then("^Verify 'If you unlock your rate' and 'Do you want to Continue' and its content in Rate UnLock Screen$")
    public void verifyIfYouUnlockYourRateAndDoYouWantToContinueAndItsContentInRateUnLockScreen() throws Throwable {

    	p1.assertPresent( );
        String Rate_UnLock_P1 = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage03_Rate_ExpectedData", testCaseID, "Rate_UnLock_P1");
        Assert.assertEquals(p1.getText(),Rate_UnLock_P1, "Couldn't find If you unlock your rate, the rate guarantee will no longer apply, the eHOME offers previously presented to you may no longer be available and some of the information you previously entered may be reset and require re-entry.");

        p2.assertPresent();
        String Rate_UnLock_Continue_Message = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage03_Rate_ExpectedData", testCaseID, "Rate_UnLock_Continue_Message");
        Assert.assertEquals(p2.getText(),Rate_UnLock_Continue_Message, "Couldn't find Do you want to continue?");
    }
    //Rate_Unlock_005
    
    @When("^Click on the No keep my rate button on Rate Unlock Screen$")
    public void clickOnTheNoKeepMyRateButtonOnRateUnlockScreen() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        QAFExtendedWebElement Nokeepmyrate= new QAFExtendedWebElement("ehome.rateunlock.Nokeepmyrate");
        if(!Nokeepmyrate.verifyPresent())
            throw new AssertionError("Couldn't find  No keep my rate button on the screen");
        Nokeepmyrate.click();

    }
    
/*//Already this method is present in RateLock.java, so commenting out this method adn reusing the method present in the other java file.
    @Then("^It should navigate to rate customization Screen$")
    public void It_should_navigate_to_rate_customization_Screen() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	 Thread.sleep(2000);
    	 QAFExtendedWebElement RateCustomizationHeader= new QAFExtendedWebElement("ehome.RateCustomization.Unlockyourrate");
        Assert.assertEquals(RateCustomizationHeader.getText(), "Unlock your rate");

    }
*/
  //Rate_UnLock_005
    @When("^Click on the Yes unlock my rate button in Rate Unlock Screen$")
    public void Click_on_the_Select_a_differnt_rate_in_Rate_Lock_Screen() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        QAFExtendedWebElement Yesunlockmyrate= new QAFExtendedWebElement("ehome.rateunlock.Yesunlockmyrate");
          if(!Yesunlockmyrate.verifyPresent())
            throw new AssertionError("Couldn't find Select a different rate on the screen");
          Yesunlockmyrate.click();
    }
    
    @Then("^It should navigate to Rate Type Screen$")
    public void itShouldNavigateToRateTypeScreen() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	//Thread.sleep(2000);
    	QAFExtendedWebElement RateType= new QAFExtendedWebElement("ehome.rate.Header.text");
        String Rate_Section_Header = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage03_Rate_ExpectedData", testCaseID, "Rate_Section_Header");
        Assert.assertEquals(RateType.getText(),Rate_Section_Header,"Rate Section is not displayed");

    }
  //Rate_UnLock_006
    @When("^Click on the back button in Rate Customization Screen$")
    public void ClickonthebackbuttoninRateCustomizationScreen() throws Throwable {
          RateCustomizationBackbutton.click();

    } 
    @Then("^It should navigate to Rate Unlock screen$")
    public void itShouldNavigateToRateUnlockScreen() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	 Thread.sleep(2000);
    }


    @When("^Verify Purchase price and Down payment and calculated Loan requested on the Rate UnLock screen when DownPayment is >= (\\d+)%$")
    public void verifyPurchasePriceAndDownPaymentAndCalculatedLoanRequestedOnTheRateUnLockScreenWhenDownPaymentIs(int arg0) throws Throwable {

        mortgagesummarytitle.assertPresent();
        String Mortgage_Summary_Title = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage03_Rate_ExpectedData", testCaseID, "Mortgage_Summary_Title");
        Assert.assertEquals(mortgagesummarytitle.getText(), Mortgage_Summary_Title, "Mortgage summary not present on Rate Presentation");

        //To Check Purchaseprice text
        Purchaseprice.assertPresent();
        String Purchase_Price_Title = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage03_Rate_ExpectedData", testCaseID, "Purchase_Price_Title");
        Assert.assertEquals(Purchaseprice.getText(), Purchase_Price_Title, "Couldn't find the Purchase price:");

        //To Check Purchaseprice value
        Purchasepricevalue.assertPresent();
        String PurchasePriceFromExcel = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage03_Rate_ExpectedData", testCaseID, "Purchase_Price");
        Assert.assertEquals(Purchasepricevalue.getText(), PurchasePriceFromExcel, "Couldn't find the Purchase price value");
        //To Check Down payment text

        downpayment.assertPresent();
        String Down_Payment_Title = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage03_Rate_ExpectedData", testCaseID, "Down_Payment_Title");
        Assert.assertEquals(downpayment.getText(), Down_Payment_Title, "Couldn't find the Down payment:");

        //To Check Down payment Value
        downpaymentvalue.assertPresent();
        String DownPaymentFromExcel = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage03_Rate_ExpectedData", testCaseID, "Down_Payment_Amount");
        Assert.assertEquals(downpaymentvalue.getText(), DownPaymentFromExcel, "Couldn't find the Down payment value");

        //To Check Loanrequested text
        loanrequested.assertPresent();
        String Loan_Requested_Title = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage03_Rate_ExpectedData", testCaseID, "Loan_Requested_Title");
        Assert.assertEquals(loanrequested.getText(), Loan_Requested_Title, "Couldn't find the Loan requested:");

        //To Check Loanrequested Value
        loanrequestedvalue.assertPresent();
        double loanvalue = Utility.convertCurrencyToDouble.apply(loanrequestedvalue.getText());
        double Purchasepricedb = Utility.convertCurrencyToDouble.apply(Purchasepricevalue.getText());
        double downpaymentdb = Utility.convertCurrencyToDouble.apply(downpaymentvalue.getText());
        Double CalculatedLoanRequest = calculateLoanRequested.apply(Purchasepricedb, downpaymentdb);
        System.out.println("CalculatedLoanRequest" + CalculatedLoanRequest + "     " + loanvalue);
        Assert.assertEquals(loanvalue, CalculatedLoanRequest, "There is an error is calculating the loan requested value");

    }

    @When("^Verify the Mortgage as \"([^\"]*)\" in Rate UnLock screen$")
    public void verifyTheMortgageAsInRateUnLockScreen(String expectedText) throws Throwable {
        if (expectedText.contentEquals("2 year closed")) {
            Assert.assertEquals(Mortgage.getText(), expectedText, "Couldn't find Mortgage as 2 years");
        } else if (expectedText.contentEquals("3 year closed")) {
            Assert.assertEquals(Mortgage.getText(), expectedText, "Couldn't find Mortgage as 3 years");
        } else if (expectedText.contentEquals("4 year closed")) {
            Assert.assertEquals(Mortgage.getText(), expectedText, "Couldn't find Mortgage as 4 years");
        } else if (expectedText.contentEquals("5 year closed")) {
            Assert.assertEquals(Mortgage.getText(), expectedText, "Couldn't find Mortgage as 5 years");
        }
    }
}
