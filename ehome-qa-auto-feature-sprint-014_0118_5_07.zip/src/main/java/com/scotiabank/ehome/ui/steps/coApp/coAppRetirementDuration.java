package com.scotiabank.ehome.ui.steps.coApp;

import com.qmetry.qaf.automation.step.QAFTestStepProvider;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.scotiabank.ehome.ui.steps.Common;
import com.scotiabank.ehome.ui.steps.CommonApplicationMethods;
import com.scotiabank.ehome.ui.steps.Utility;
import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.testng.Assert;

@QAFTestStepProvider
public class coAppRetirementDuration {

    String testCaseID = Utility.getScenarioID();


    QAFExtendedWebElement Continue = new QAFExtendedWebElement("ehome.tellus.continue.button");
    QAFExtendedWebElement RetirementDurationHeader = new QAFExtendedWebElement("ehome.coapp.RetirementDuration.header");
    QAFExtendedWebElement RetirementDurationTitle = new QAFExtendedWebElement("ehome.coapp.RetirementDuration.title");
    QAFExtendedWebElement RetirementDurationCoAppCircle = new QAFExtendedWebElement("ehome.coapp.RetirementDuration.coappcircle");
    QAFExtendedWebElement RetirementDurationBackButton = new QAFExtendedWebElement("ehome.coapp.RetirementDuration.Back");
    QAFExtendedWebElement RetiredEmploymentStatus = new QAFExtendedWebElement("ehome.coapp.Retired.EmploymentStatus");
    QAFExtendedWebElement RetiredOtherSourcesOfIncome = new QAFExtendedWebElement("ehome.coapp.Retirement.OtherSourcesOfIncome.title");
    QAFExtendedWebElement RetirementDurationErrorMessage = new QAFExtendedWebElement("ehome.coapp.RetirementDuration.errormessage");

    @Given("^Customer should login and navigates to Co-Applicant Employment status$")
    public void customerShouldLoginAndNavigatesToCoApplicantEmploymentStatus() throws Throwable {
        String sheetNameStage2 = "Co-App_InputData";

        Common.TraverseToNewHomeSectionBreaker();
        Common.TraverseFromNewHomeToRateSectionBreaker(testCaseID,sheetNameStage2);
        Common.TraverseRateSectionToEmploymentSectionBreaker();
        Common.TraverseFromEmploymentSectionToLandOnCoApplicantPage();
        CoAppIntro.startSectionButtonClicked();
    }

    @When("^Customer Selects 'Retired' on 'Co-Applicant Employment status' Screen$")
    public void customerSelectsRetiredOnCoApplicantEmploymentStatusScreen() throws Throwable {
        CoAppEmpStatus.retiredButtonClicked();
    }

    @Then("^Verify 'Retirement Duration' header and title on the Co-App Retirement Duration Screen$")
    public void verifyRetirementDurationHeaderAndTitleOnTheCoAppRetirementDurationScreen() throws Throwable {

        if (!(RetirementDurationHeader.getText().contains("details in progress"))){
            throw new AssertionError("Header is not correct");
        }
        Thread.sleep(2000);
        String retirementDurationTitle= Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Co-App_ExpectedData",testCaseID , "coAppRetirementDuration_Title");
        Assert.assertEquals(RetirementDurationTitle.getText(), retirementDurationTitle,"Couldn't found expected Title");

        if (!RetirementDurationCoAppCircle.isPresent()){
            throw new AssertionError("Co-App Circle is not present");
        }
    }

    @Then("^Verify 'Employment Status' Screen when Click on 'Back' button on the Co-App Retirement Duration Screen$")
    public void verifyEmploymentStatusScreenWhenClickOnBackButtonOnTheCoAppRetirementDurationScreen() throws Throwable {

        Thread.sleep(2000);
        RetirementDurationBackButton.click();
        if (!RetiredEmploymentStatus.isPresent()){
            throw new AssertionError("Retired is not present");
        }
    }

    @When("^Customer selects the 'Retirement Duration' and click 'Continue' from Co-Applicant 'Retirement Duration' Screen$")
    public void customerSelectsTheRetirementDurationAndClickContinueFromCoApplicantRetirementDurationScreen() throws Throwable {
if (testCaseID=="Co-App-Retirement-Duration-TC-005") {
    Thread.sleep(2000);
    CommonApplicationMethods.selectValuefromDropDownListBox("ehome.coapp.RetirementDuration.years", "3 years");
    Thread.sleep(2000);
    CommonApplicationMethods.selectValuefromDropDownListBox("ehome.coapp.RetirementDuration.months", "3 months");
}
else
    Thread.sleep(2000);
        CommonApplicationMethods.selectValuefromDropDownListBox("ehome.coapp.RetirementDuration.years", "0 years");
        Thread.sleep(2000);
        CommonApplicationMethods.selectValuefromDropDownListBox("ehome.coapp.RetirementDuration.months", "0 months");

        Common.continueButtonClicked();
    }

    @Then("^Verify 'Employment Other Sources of Income' Screen in Co-Applicant Section$")
    public void verifyEmploymentOtherSourcesOfIncomeScreenInCoApplicantSection() throws Throwable {

        if (!RetiredOtherSourcesOfIncome.isPresent()){
            throw new AssertionError("Retired Other Sources Of income is not present");
        }
    }

    @Then("^Verify 'Error message' in 'Retirement Duration' Screen when select 'Continue' without giving 'Retirement Duration' on Co-Applicant Retired Duration Screen$")
    public void verifyErrorMessageInRetirementDurationScreenWhenSelectContinueWithoutGivingRetirementDurationOnCoApplicantRetiredDurationScreen() throws Throwable {

        Common.continueButtonClicked();

       if ((!RetirementDurationErrorMessage.isPresent())){
           throw new AssertionError("Error Message is not Displayed");
       }
        String retirementDuration_errorMessage= Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Co-App_ExpectedData",testCaseID , "coAppRetirementDuration_ErrorMessage");
        Assert.assertEquals(RetirementDurationErrorMessage.getText(), retirementDuration_errorMessage,"Couldn't found expected Error Message");
    }
}
