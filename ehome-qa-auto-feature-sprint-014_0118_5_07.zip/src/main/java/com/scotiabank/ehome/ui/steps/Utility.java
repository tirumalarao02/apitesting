package com.scotiabank.ehome.ui.steps;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.text.MessageFormat;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;
import java.util.stream.StreamSupport;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.velocity.test.provider.BoolObj;
import org.apache.poi.ss.formula.functions.Column;
import org.apache.poi.ss.usermodel.*;
import org.openqa.selenium.Keys;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.codoid.products.exception.FilloException;
import com.codoid.products.fillo.Connection;
import com.codoid.products.fillo.Fillo;
import com.codoid.products.fillo.Recordset;
import com.google.common.collect.ImmutableMap;
import com.qmetry.qaf.automation.ui.WebDriverTestBase;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebDriver;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.quantum.java.pages.ExtentReportHelper;
import com.quantum.java.pages.ScotiaQuantumReportListener;
import com.quantum.utils.ConfigurationUtils;

public class Utility {
	static QAFExtendedWebDriver webDriver = null;
	static WebDriverWait wait = null;
	public static MessageFormat messageFormatForInterestTest = new MessageFormat(
			"Failed for AMORT Year {0}, AMORT Month {1}, Payment Schedule {2}, Number of years {3}, Actual value {4}, Expected value {5}");

	public static ImmutableMap<String, ImmutableMap<String, Object>> getYearsAndInterestRates() {
		return new ImmutableMap.Builder<String, ImmutableMap<String, Object>>()
				.put("2", new ImmutableMap.Builder<String, Object>().put("Years", 2).put("Interest", 2.75).build())
				.put("3", new ImmutableMap.Builder<String, Object>().put("Years", 3).put("Interest", 3.3).build())
				.put("4", new ImmutableMap.Builder<String, Object>().put("Years", 4).put("Interest", 3.55).build())
				.put("5", new ImmutableMap.Builder<String, Object>().put("Years", 5).put("Interest", 4.6).build())
				.put("5_VAR", new ImmutableMap.Builder<String, Object>().put("Years", 5).put("Interest", 2.75).build())
				.build();
	}

	public static String convertRGBToHex(String rgStr) {
		String[] numbers = rgStr.replace("rgba(", "").replace(")", "").split(",");
		int r = Integer.parseInt(numbers[0].trim());
		int g = Integer.parseInt(numbers[1].trim());
		int b = Integer.parseInt(numbers[2].trim());
		System.out.println("r: " + r + "g: " + g + "b: " + b);
		String hex = "#" + Integer.toHexString(r) + Integer.toHexString(g) + Integer.toHexString(b);
		return hex;
	}
	public static double getRateFromString(String Str) {
		int iend = Str.indexOf("%");
        String subString = null;
        if (iend != -1) 
        {
             subString= Str.substring(0 , iend); 
        }

        double rate = Double.parseDouble(subString);
		
		return rate;
	}

	public static Function<String, Double> convertCurrencyToDouble = (stringValue) -> {
		Number number = null;
		try {
			number = NumberFormat.getCurrencyInstance(Locale.CANADA).parse(stringValue);
		} catch (Exception exp) {
			exp.printStackTrace();
		}
		return number == null ? null : number.doubleValue();
	};

	public static Integer getNumberOfYearsFromString(String stringVal) {
		return new Integer(stringVal.replace("-years", "").trim());
	}

	public static Integer getNumberOfMonthsFromString(String stringVal) {
		return new Integer(stringVal.replace("-months", "").trim());
	}

	public static Integer getAmortizationPeriodInMonths(Integer amortYears, Integer amortMonths) {
		return (amortYears * 12) + amortMonths;
	}

	public static String getYearsClosedToNumber(String strVal) {
		return strVal.replaceAll("year closed", "").trim();
	}
	

	public static List<Map<String, String>> getRatePresentmentCustomizationDataFromExcel(String fileName,
			String sheetName) throws Exception {
		LinkedList<Map<String,String>> returnList = new LinkedList<>();
		File src = new File(fileName);
		FileInputStream fis = new FileInputStream(src);
		XSSFWorkbook srcBook = new XSSFWorkbook(fis);
		XSSFSheet sourceSheet = srcBook.getSheet(sheetName);
		Iterator<Row> rowIterator = sourceSheet.rowIterator();
		DataFormatter dataFormatter = new DataFormatter();
		int rowIndex = 0;
		Row headerRow = null;
		int columnnCount = 0;
		
		while (rowIterator.hasNext()) {
			Row row = rowIterator.next();
			if(rowIndex==0) {
				headerRow = sourceSheet.getRow(0);
				Iterator<Cell> headerCellIterator = headerRow.cellIterator();
				
				while(headerCellIterator.hasNext()) {
					Cell cell = headerCellIterator.next();
					String cellValue = dataFormatter.formatCellValue(cell);
					if(cellValue == null || cellValue.isEmpty()) {
						break;
					}
					columnnCount++;
				}
			}
			
			
			if (rowIndex != 0) {
				HashMap<String, String> map = new HashMap<>();
				// Now let's iterate over the columns of the current row
				//Iterator<Cell> cellIterator = row.cellIterator();
				int cellColumnIndex = 0;
				for(int i=0; i<columnnCount; i++) {
					Cell cell = row.getCell(i);
					String cellValue = dataFormatter.formatCellValue(cell);

					String headerValue = dataFormatter.formatCellValue(headerRow.getCell(cellColumnIndex));
					cellColumnIndex++;
					map.put(headerValue.trim(), cellValue.trim());
					
				}
				returnList.add(map);
			}
			rowIndex++;
		}
		srcBook.close();
		return returnList;
	}
	public static QAFExtendedWebDriver getDriver() {
		if(webDriver==null) {
			webDriver = new WebDriverTestBase().getDriver();
			webDriver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
			//webDriver.get(ConfigurationUtils.getBaseBundle().getPropertyValue("env.baseurl2"));
	        webDriver.manage().window().maximize();
		}
//		try {
//			Thread.sleep(2000);
//		} catch (InterruptedException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		webDriver.get("http://www.google.com");
//		Actions aObj = new Actions(webDriver);
//		aObj.sendKeys(Keys.chord(Keys.F5)).build().perform();
//
		
		// keyAction.sendKeys(Keys.chord(Keys.CONTROL,Keys.SHIFT,"i")).perform();

//		
        return webDriver;
	}
	
	
	public static WebDriverWait getWait() {
		if(wait==null)
		 wait = new WebDriverWait(getDriver(), 10);
		return wait;
	}
	
	// Reading Excel Data	
	// Passing "Excel Path", "Sheet name", "Test ID" as parameters
	public static List<String> ExcelData(String fullPathToFile ,String sheetName, String DataPointer) {
			
		    List<String> dataList= new ArrayList();
			
		    try {
		       Workbook workbook = null;
		        FileInputStream in = null;
		        in = new FileInputStream(fullPathToFile);
		        workbook = WorkbookFactory.create(in);
		        Sheet sheet = workbook.getSheet(sheetName);
		        int lastRow = sheet.getLastRowNum();
		  
		        DataFormatter formatter = new DataFormatter();
		        for(int i=0;i<=lastRow;i++) {
		        		
		        	  String cellV = formatter.formatCellValue( sheet.getRow(i).getCell(0));
		        	 
		        	  if(cellV.equalsIgnoreCase(DataPointer)) {
		        		  dataList.add(formatter.formatCellValue(sheet.getRow(i).getCell(1)));
			        		 dataList.add(formatter.formatCellValue(sheet.getRow(i).getCell(2)));
			        		 dataList.add(formatter.formatCellValue(sheet.getRow(i).getCell(3)));
			        		 dataList.add(formatter.formatCellValue(sheet.getRow(i).getCell(4)));
			        		 dataList.add(formatter.formatCellValue(sheet.getRow(i).getCell(5)));
			        		 dataList.add(formatter.formatCellValue(sheet.getRow(i).getCell(6)));
			        		 dataList.add(formatter.formatCellValue(sheet.getRow(i).getCell(7)));
			        		 dataList.add(formatter.formatCellValue(sheet.getRow(i).getCell(8)));
			        		 dataList.add(formatter.formatCellValue(sheet.getRow(i).getCell(9)));
			        		 dataList.add(formatter.formatCellValue(sheet.getRow(i).getCell(10)));
			        		 dataList.add(formatter.formatCellValue(sheet.getRow(i).getCell(11)));
			        		 dataList.add(formatter.formatCellValue(sheet.getRow(i).getCell(12)));
			        		 dataList.add(formatter.formatCellValue(sheet.getRow(i).getCell(13)));
			        		 dataList.add(formatter.formatCellValue(sheet.getRow(i).getCell(14)));
			        		 dataList.add(formatter.formatCellValue(sheet.getRow(i).getCell(15)));
			        		 dataList.add(formatter.formatCellValue(sheet.getRow(i).getCell(16)));
			        		 dataList.add(formatter.formatCellValue(sheet.getRow(i).getCell(17)));
			        		 dataList.add(formatter.formatCellValue(sheet.getRow(i).getCell(18)));
			        		 dataList.add(formatter.formatCellValue(sheet.getRow(i).getCell(19)));
			        		 dataList.add(formatter.formatCellValue(sheet.getRow(i).getCell(20)));
			        		 dataList.add(formatter.formatCellValue(sheet.getRow(i).getCell(21)));
			        		 dataList.add(formatter.formatCellValue(sheet.getRow(i).getCell(22)));
			        		 dataList.add(formatter.formatCellValue(sheet.getRow(i).getCell(23)));
			        		 dataList.add(formatter.formatCellValue(sheet.getRow(i).getCell(24)));
			        		 dataList.add(formatter.formatCellValue(sheet.getRow(i).getCell(25)));
			        		 dataList.add(formatter.formatCellValue(sheet.getRow(i).getCell(26)));
		        		 break;
	        		  
		        	  }
		        }

		    } catch (Exception e) {
		    //    Assert.fail("Exception while trying to read data from file " + fullPathToFile + " and the message is" + e.getMessage());
		    }
		    
		    return dataList;
		}
	
	
	  /* *************************************************************************************************************************************************
	   Author: 	  RameshChalumuri
	   Stage:     Any Stage 
	   Method Name: Map<String,String> readTestData(String excelFilePath, String sheetName, String testCaseID) 
	   Purpose:   // This function to read Excel Data by Passing "Excel Path", "Sheet name", "Test ID" as parameters   
	   Created on: 26-Oct-2018   
	   Updated By: 
	   Updated on:
	   *************************************************************************************************************************************************** */
    public static Map<String,String> readTestData(String excelFilePath, String sheetName, String testCaseID) throws FilloException {
    	
        Fillo fillo = new Fillo();
        Connection connection = fillo.getConnection(excelFilePath);
        String strQuery = "Select * from " + sheetName + " where TestCase_ID = \'" + testCaseID + "'";
        //System.err.println("Query>>"+strQuery);
        Recordset recordset = null;
        try {
         recordset = connection.executeQuery(strQuery);
        }catch (Throwable e) {
			e.printStackTrace();
        	// TODO: handle exception
		}
        List<String> ColumnNames = new ArrayList<>();
        Map<String,String> hm =new HashMap<>();
        ColumnNames = recordset.getFieldNames();
        int intFieldValueCnt = 0;
        for (String x : ColumnNames) {
            recordset.next();
            String strfieldVal = recordset.getField(intFieldValueCnt).value();
            intFieldValueCnt++;
            hm.put(x, strfieldVal);
        }
        Set<String> getKeys = hm.keySet();
        System.out.println("_____________________________________________________________"+(String) hm.get("E2E Scenarios"));
        System.out.println("getKeys:" + getKeys);
        System.out.println((String) hm.get("UserName"));
        recordset.close();
        connection.close();
        //System.err.println("Reading completed");
        return hm;
    }
    
    
    /* *************************************************************************************************************************************************
	   Author: 	  RameshChalumuri
	   Stage:     Any Stage 
	   Method Name:  
	   Purpose:    
	   Created on: 13-Jan-2019   
	   Updated By: 
	   Updated on:
	   
	   (String excelFilePath, String sheetName, String testCaseID)
	   String SheetID
	   *************************************************************************************************************************************************** */
 public static void writeApplicationData(String excelFilePath, String sheetName, String testCaseID, String strInsertExcelData) throws FilloException {

	
	 Fillo fillo = new Fillo();
   	 Connection connection = fillo.getConnection(excelFilePath);

	// String strUpdateQuery1 = "Update " + sheetName + " Set MortgageRequest='5000',FirstPaymentDate ='February 5, 2019',RateExpiryDate = 'February 6, 2018' where TestCase_ID = \'" + testCaseID + "'";
	 String strUpdateQuery = "Update " + sheetName + " Set "+strInsertExcelData +" where TestCase_ID = \'" + testCaseID + "'";
	   
	 connection.executeUpdate(strUpdateQuery);
	 System.err.println(connection.executeUpdate(strUpdateQuery));
	 connection.close();
	 
 } 
  
    
    

	  /* *************************************************************************************************************************************************
	   Author: 	  RameshChalumuri
	   Stage:     Any Stage 
	   Method Name: launchURL(String strURL) 
	   Purpose:   // This method is for launching Section Breaker stage URL   
	   Created on: 01-June-2018   
	   Updated By: 
	   Updated on:
	   *************************************************************************************************************************************************** */
    public static void launchURL(String strURL) throws InterruptedException{
   		webDriver = new WebDriverTestBase().getDriver();
		//webDriver.get(ConfigurationUtils.getBaseBundle ().getPropertyValue (strURL) );
   		webDriver.get(strURL);
		webDriver.manage().window().maximize();
   }
    
    
	  /* *************************************************************************************************************************************************
	   Author: 	  RameshChalumuri
	   Stage:     Any Stage 
	   Method Name: clickObject(String xPath,String objectType) 
	   Purpose:   // This method is for Clicking Object  
	   Created on: 05-June-2018   
	   Updated By: 
	   Updated on:
	   *************************************************************************************************************************************************** */
	public static void clickObject(String xPath,String objectType) throws InterruptedException{
		QAFExtendedWebElement Object= new QAFExtendedWebElement(xPath);
		Object.click();
    }
	

	  /* *************************************************************************************************************************************************
	   Author: 	  RameshChalumuri
	   Stage:     Any Stage 
	   Method Name: clickObject(String xPath,String objectType) 
	   Purpose:  // This method is for InputKeys  
	   Created on: 05-June-2018   
	   Updated By: 
	   Updated on:
	   *************************************************************************************************************************************************** */
	public static void sendKeys(String xPath,String KeysToSend) throws InterruptedException{
		QAFExtendedWebElement Object= new QAFExtendedWebElement(xPath);
		Object.sendKeys(KeysToSend);
	}
	
	
	  /* *************************************************************************************************************************************************
	   Author: 	  RameshChalumuri
	   Stage:     Any Stage 
	   Method Name: verifyText(String xPath,String ExpectedResult, String FailedMsg) 
	   Purpose:   This method is for Verify Text is present or not	  
	   Created on:    
	   Updated By: 
	   Updated on:
	   *************************************************************************************************************************************************** */
	public static void verifyText(String xPath,String ExpectedResult, String FailedMsg) throws InterruptedException{
		QAFExtendedWebElement strActualResult= new QAFExtendedWebElement(xPath);
 		Assert.assertEquals(strActualResult.getText(), ExpectedResult,FailedMsg);
	}
	
	
	  /* *************************************************************************************************************************************************
	   Author: 	  RameshChalumuri
	   Stage:     Any Stage 
	   Method Name: verifyIsObjectPresent(String xPathOfObject,String typeOfObject) 
	   Purpose:   This method is for Verify Object is Present or Not	  
	   Created on:    
	   Updated By: 
	   Updated on:
	   *************************************************************************************************************************************************** */
	public static void verifyIsObjectPresent(String xPathOfObject,String typeOfObject) throws InterruptedException, IOException{
		   QAFExtendedWebElement Object= new QAFExtendedWebElement(xPathOfObject);
		   if(Object.isPresent())
			{
				ExtentReportHelper.StepPass("'" + Object.getText()  + "' " + typeOfObject + " is displayed.");
			}
		  else
			{
				ExtentReportHelper.StepFail("'" + Object.getText()  + "' " + typeOfObject + " is NOT displayed.");
			}
	   }
	
	
	  /* *************************************************************************************************************************************************
	   Author: 	  RameshChalumuri
	   Stage:     Any Stage 
	   Method Name: verifyIsObjectPresent(String xPathOfObject,String typeOfObject) 
	   Purpose:   	This method is for Verify Text is Present or Not  
	   Created on:    
	   Updated By: 
	   Updated on:
	   *************************************************************************************************************************************************** */
		public static void verifyIsTextPresent(String xPathOfObject, String typeOfObject, String expectedResult) throws InterruptedException, IOException{
		
			//.//*[contains(text(),"++")]
			
			QAFExtendedWebElement strActualResult= new QAFExtendedWebElement(xPathOfObject); 
			
			
			if (expectedResult.contentEquals(strActualResult.getText())) {
				  ExtentReportHelper.StepPass("'" + expectedResult + "' " + typeOfObject + " is displayed.");
			  }
			  else
			  {
				  Assert.assertEquals(strActualResult.getText(), expectedResult,"' " + typeOfObject + " is NOT displayed.");
			  }
		   }
	
	
	public static Map<String,List<String>> readColumnDataFromExcel(String fileName, String sheetName){
		HashMap<String, List<String>> retHash = new HashMap<>();
		try {			
			XSSFWorkbook srcBook = new XSSFWorkbook(fileName);
			XSSFSheet sourceSheet = srcBook.getSheet(sheetName);
			Iterator<Row> rows = sourceSheet.rowIterator();
			DataFormatter dataFormatter = new DataFormatter();
			HashMap<Integer,String> columnsandIndexes = getColumnsandIndexes(rows);
			while(rows.hasNext()) {
				Row row = rows.next();
				Iterator<Cell> iteratorCell = row.cellIterator();
				while(iteratorCell.hasNext()) {
					Cell cell = iteratorCell.next();
					String columnName = columnsandIndexes.get(cell.getColumnIndex());
					List<String> listVals = null;
					if(retHash.get(columnName)==null) {
						listVals = new LinkedList<>();
					}else {
						listVals = retHash.get(columnName);
					}
					listVals.add(dataFormatter.formatCellValue(cell));
					retHash.put(columnName, listVals);
				}
			}
			srcBook.close();
		}catch(Exception exp) {
			exp.printStackTrace();
		}
		return retHash;
	}
	private static HashMap<Integer,String> getColumnsandIndexes(Iterator<Row> rows){
		HashMap<Integer,String> columnNamesAndIndexes = new HashMap<>(); 
		DataFormatter dataFormatter = new DataFormatter();
		while(rows.hasNext()) {
			Row row = rows.next();
			if(row.getRowNum()==0) {
				Iterator<Cell> iteratorCell = row.cellIterator();
				while(iteratorCell.hasNext()) {
					Cell cell = iteratorCell.next();
					columnNamesAndIndexes.put(cell.getColumnIndex(), dataFormatter.formatCellValue(cell));
				}
				break;
			}
		}
		return columnNamesAndIndexes;
	}
	public static Map<String,Map<String,Boolean>> getScreenDataset(String fileName, String sheetName){
		HashMap<String,Map<String,Boolean>> retVal = new HashMap<>();
		try {			
			XSSFWorkbook srcBook = new XSSFWorkbook(fileName);
			XSSFSheet sourceSheet = srcBook.getSheet(sheetName);
			Iterator<Row> rows = sourceSheet.rowIterator();
			DataFormatter dataFormatter = new DataFormatter();
			HashMap<Integer,String> columnsandIndexes = getColumnsandIndexes(rows);
			while(rows.hasNext()) {
				Row row = rows.next();
				Iterator<Cell> iteratorCell = row.cellIterator();
				String dataPointerName = "";
				String staticValue = "";
				HashMap<String,Boolean> possibleScenarios = new HashMap<>();
				boolean fillMap = false;
				String keyForMap = "";
				while(iteratorCell.hasNext()) {					
					Cell cell = iteratorCell.next();					
					if(cell.getColumnIndex()==0) {
						dataPointerName = dataFormatter.formatCellValue(cell);
					}else if(cell.getColumnIndex()==1) {
						staticValue= dataFormatter.formatCellValue(cell);
					}else {
						if(cell.getColumnIndex()%2 == 0 ) {
							fillMap = true;
							keyForMap = dataFormatter.formatCellValue(cell);
						}else {
							String valueForMap = dataFormatter.formatCellValue(cell);
							if(valueForMap.toUpperCase().startsWith("POS") || valueForMap.equals("+")) {
								possibleScenarios.put(keyForMap, new Boolean(true));
							}else {
								possibleScenarios.put(keyForMap, new Boolean(false));
							}
							fillMap = false;
						}
					}
					
				}
				if(staticValue.equals("")) {
					retVal.put(dataPointerName, possibleScenarios);
				}else {
					possibleScenarios.clear();
					possibleScenarios.put(staticValue, new Boolean(true));
					retVal.put(dataPointerName,possibleScenarios);
				}				
			}
			srcBook.close();
		}catch(Exception exp) {
			exp.printStackTrace();
		}
		return retVal;
	}
	public static String getLabelValueForDataPointer(Map<String,Map<String,Boolean>> dataset,String dataPointer) {
		return dataset.get(dataPointer).keySet().toArray()[0].toString();
	}
	public static Map<String,Boolean> getPossibleValuesForDataPointer(Map<String,Map<String,Boolean>> dataset,String dataPointer) {
		return dataset.get(dataPointer);
	}
	
	public static String getExcelFilePath( String fileName) {
		String returnVal =System.getProperty("user.dir")+"\\src\\main\\resources\\data\\"+fileName;
		return returnVal;
	}
	
	/********
	 * Function to read scenario ID
	 * Make sure Scenario ID part should not contain "_"
	 * ScenarioID and Scenario description should be separated with "_" character.
	 * e.g. SC-EHOME-UI-M-SEARCH-2-TC-001_Verify StageTwo Manual Address Page
	 * @return
	 */
	public static String getScenarioID() {
		String scenarioName = ScotiaQuantumReportListener.testName;
		String[] scenarioID = scenarioName.split("_");
		return scenarioID[0];
	}
	
	public static String getValueFromExcelMatrix(String fileName, String sheetName, String rowPointer, String columnPointer) {
		String returnValue = "";
		try {
			XSSFWorkbook srcBook = new XSSFWorkbook(fileName);
			XSSFSheet sourceSheet = srcBook.getSheet(sheetName);
			Iterator<Row> rows = sourceSheet.rowIterator();
			DataFormatter dataFormatter = new DataFormatter();
			HashMap<Integer,String> columnsandIndexes = getColumnsandIndexes(rows);
			int columnIndex = columnsandIndexes.keySet().stream().filter(index -> columnsandIndexes.get(index).toUpperCase().equals(columnPointer.toUpperCase())).findFirst().get();
			Iterable<Row> iterable = () -> rows;
			returnValue = dataFormatter.formatCellValue(StreamSupport.stream(iterable.spliterator(), false).filter(row -> dataFormatter.formatCellValue(row.getCell(0)).equals(rowPointer)).findFirst().get().getCell(columnIndex));
		}catch(Exception exp) {
			exp.printStackTrace();
		}
		return returnValue;
	}
//	public static void main(String[] args) {
//	//Map<String,Map<String,Boolean>> ppp = getScreenDataset("C:\\Users\\s1518705\\Work\\LocalWork\\ehome-qa-auto-feature-sprint-007-01-Oct-2018-11AM\\src\\main\\resources\\data\\eHomeTestData_Stage4.xlsx","EmpStatus");
//	System.out.println(getValueFromExcelMatrix("C:\\eclipse-workspace\\ehome-qa-auto-feature-sprint-009-Oct-18-2018-\\src\\main\\resources\\data\\eHomeTestDataStage-1.xlsx", "PA", "Privacy-Agreement-TC-003", "PrivacyAgreement_Message"));
//}
	 public static void main(String[] args) {
	       System.out.println("Working Directory = " +
	              System.getProperty("user.dir"));
	  }
	 public static double getDefaultInsuranceValue(String fileName, String sheetName, double purchasePrice, double totalDownPayment){
		 final String PURCHASE_PRICE_LABEL="Purchase price";
		 final String DOWN_PAYMENT_LABEL="Total down payment";
		 final String DEFAULT_INSURANCE_LABEL="Default Insurance";
		 double defaultInsuranceValue = -1d;
			try {			
				XSSFWorkbook srcBook = new XSSFWorkbook(fileName);
				XSSFSheet sourceSheet = srcBook.getSheet(sheetName);
				Iterator<Row> rows = sourceSheet.rowIterator();
				DataFormatter dataFormatter = new DataFormatter();
				boolean setPurchasePrice = false, setDownPayment=false;
				while(rows.hasNext()) {
					Row row = rows.next();
					Iterator<Cell> iteratorCell = row.cellIterator();
					while(iteratorCell.hasNext()) {					
						Cell cell = iteratorCell.next();
						String labelName = dataFormatter.formatCellValue(cell);
						if(labelName.toUpperCase().trim().equals(PURCHASE_PRICE_LABEL.toUpperCase())) {
							iteratorCell.next().setCellValue(purchasePrice);
							setPurchasePrice = true;
							continue;
						}
						else if(labelName.toUpperCase().trim().equals(DOWN_PAYMENT_LABEL.toUpperCase())) {
							iteratorCell.next().setCellValue(totalDownPayment);
							setDownPayment = true;
							continue;
						}
						if(setPurchasePrice && setDownPayment) {
							break;
						}
					}			
					if(setPurchasePrice && setDownPayment) {
						break;
					}
				}
				rows = sourceSheet.rowIterator();
				while(rows.hasNext()) {
					Row row = rows.next();
					Iterator<Cell> iteratorCell = row.cellIterator();
					while(iteratorCell.hasNext()) {					
						Cell cell = iteratorCell.next();
						String labelName = dataFormatter.formatCellValue(cell);
						if(labelName.toUpperCase().trim().equals(DEFAULT_INSURANCE_LABEL.toUpperCase())) {
							defaultInsuranceValue = iteratorCell.next().getNumericCellValue();
							break;
						}						
					}
				}
				srcBook.close();
			}catch(Exception exp) {
				exp.printStackTrace();
			}
			return defaultInsuranceValue;
		}
	 public static String messageFormatName(String pattern, String name) {
		 MessageFormat mf = new MessageFormat(pattern);
		 String[] values = {name};
		 String text = mf.format(values);
		 return text;
	 }
}