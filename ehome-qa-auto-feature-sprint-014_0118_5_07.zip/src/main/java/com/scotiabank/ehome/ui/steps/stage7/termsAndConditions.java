package com.scotiabank.ehome.ui.steps.stage7;

import com.qmetry.qaf.automation.step.QAFTestStepProvider;
import com.qmetry.qaf.automation.ui.WebDriverTestBase;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebDriver;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElementListHandler;
import com.quantum.utils.ConfigurationUtils;
import com.scotiabank.ehome.ui.steps.Utility;
import cucumber.api.PendingException;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.security.Credentials;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import java.awt.*;
import java.awt.event.KeyEvent;
import java.util.List;

@QAFTestStepProvider
public class termsAndConditions {
    QAFExtendedWebDriver webDriver = new WebDriverTestBase().getDriver();
    public Actions action = null;
    WebDriverWait wait = new WebDriverWait(webDriver, 50000);

    String testCaseID = Utility.getScenarioID();

    QAFExtendedWebElement TermsAndConditionsTitles = new QAFExtendedWebElement("ehome.termsAndConditions.list");
    QAFExtendedWebElement TermsAndConditionsHeader = new QAFExtendedWebElement("ehome.termsAndConditions.header");
    QAFExtendedWebElement TermsAndConditionsHeaderSubText = new QAFExtendedWebElement("ehome.termsAndConditions.header_SubText");
    QAFExtendedWebElement TermsAndConditionsGeneralSection = new QAFExtendedWebElement("ehome.termsAndConditions.General.Section");
    QAFExtendedWebElement TermsAndConditionsSection1 = new QAFExtendedWebElement("ehome.termsAndConditions.Section1");
    QAFExtendedWebElement TermsAndConditionsSection2 = new QAFExtendedWebElement("ehome.termsAndConditions.Section2");
    QAFExtendedWebElement TermsAndConditionsSection3 = new QAFExtendedWebElement("ehome.termsAndConditions.Section3");
    QAFExtendedWebElement TermsAndConditionsSection4 = new QAFExtendedWebElement("ehome.termsAndConditions.Section4");
    QAFExtendedWebElement TermsAndConditionsSection5 = new QAFExtendedWebElement("ehome.termsAndConditions.Section5");
    QAFExtendedWebElement TermsAndConditionsSection6 = new QAFExtendedWebElement("ehome.termsAndConditions.Section6");
    QAFExtendedWebElement TermsAndConditionsSection7 = new QAFExtendedWebElement("ehome.termsAndConditions.Section7");
    QAFExtendedWebElement AgreeAndContinueButton = new QAFExtendedWebElement("ehome.termsAndConditions.AgreeContinue");
    QAFExtendedWebElement CreditCheckHeader = new QAFExtendedWebElement("ehome.termsAndConditions.CreditCheckHeader");
    QAFExtendedWebElement CreditCheckTitle = new QAFExtendedWebElement("ehome.termsAndConditions.CreditCheckTitle");
    QAFExtendedWebElement Back = new QAFExtendedWebElement("ehome.termsAndConditions.Back");

    @Given("^Customer should login and navigates to Terms And Conditions Page$")
    public void customerShouldLoginAndNavigatesToTermsAndConditionsPage() throws Throwable {
        Utility.launchURL(ConfigurationUtils.getBaseBundle().getPropertyValue("env.baseurl3"));

        String TermsAndConditions_Header = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage07_ExpectedData", testCaseID, "T&C_Header");
        Assert.assertEquals(TermsAndConditionsHeader.getText(), TermsAndConditions_Header, "Couldn't found header");

        String TermsAndConditions_SubText = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage07_ExpectedData", testCaseID, "T&C_SubText");
        Assert.assertEquals(TermsAndConditionsHeaderSubText.getText(), TermsAndConditions_SubText, "Couldn't found header Sub Text");


        /*//webDriver.get("https://qq@ehome-api-zuul-gateway-ist.apps.stg.azr-use2-pcf.cloud.bns/hub-onboarding");
        //webDriver.get("https://018358100118442@ehome-api-zuul-gateway-ist.apps.stg.azr-use2-pcf.cloud.bns/hub");
        //webDriver.switchTo().alert().sendKeys("qq");
        Thread.sleep(5000);

        //webDriver.switchTo().alert();
        Robot a = new Robot();
        a.keyPress(KeyEvent.VK_Q);
        a.keyPress(KeyEvent.VK_Q);
        a.keyPress(KeyEvent.VK_ENTER);
        Thread.sleep(2000);
        a.keyPress(KeyEvent.VK_0);
        a.keyPress(KeyEvent.VK_1);
        a.keyPress(KeyEvent.VK_8);
        a.keyPress(KeyEvent.VK_3);
        a.keyPress(KeyEvent.VK_5);
        a.keyPress(KeyEvent.VK_8);
        a.keyPress(KeyEvent.VK_1);
        a.keyPress(KeyEvent.VK_0);
        a.keyPress(KeyEvent.VK_0);
        a.keyPress(KeyEvent.VK_0);
        a.keyPress(KeyEvent.VK_5);
        a.keyPress(KeyEvent.VK_3);
        a.keyPress(KeyEvent.VK_4);
        a.keyPress(KeyEvent.VK_2);
        a.keyPress(KeyEvent.VK_1);
        Thread.sleep(10000);
        a.keyPress(KeyEvent.VK_ENTER);
        a.keyRelease(KeyEvent.VK_ENTER);
        Thread.sleep(10000);

        *//*webDriver.switchTo().alert();
        webDriver.switchTo().activeElement().sendKeys("qq");
        webDriver.switchTo().alert().accept();*//*



        //webDriver.switchTo().activeElement().sendKeys("qq");
        //Thread.sleep(10000);*/
    }

    @Then("^Customer verifies the section titles of content of terms and conditions on the screen$")
    public void customerVerifiesTheSectionTitlesOfContentOfTermsAndConditionsOnTheScreen() throws Throwable {

        List<WebElement> termsAndConditionsList = webDriver.findElements(By.xpath("//ol[@class='toc-nav__list']/li"));
        for (int i = 0; i < termsAndConditionsList.size() - 1; i++) {
            String TermsAndConditions_1 = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage07_ExpectedData", testCaseID, "TermsAndConditions_" + (i + 1));
            Assert.assertEquals(termsAndConditionsList.get(i).getText(), TermsAndConditions_1, "Couldn't found Back button, Back button should be present");
        }

        String TermsAndConditions_General_Section = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage07_ExpectedData", testCaseID, "General_Section");
        Assert.assertEquals(TermsAndConditionsGeneralSection.getText(), TermsAndConditions_General_Section, "Couldn't found header");
        System.out.println("General Section is " + TermsAndConditions_General_Section);

        String TermsAndConditions_Section1 = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage07_ExpectedData", testCaseID, "T&C_Section1");
        Assert.assertEquals(TermsAndConditionsSection1.getText(), TermsAndConditions_Section1, "Couldn't found header");
        System.out.println("Section 1 is " + TermsAndConditions_Section1);

        String TermsAndConditions_Section2 = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage07_ExpectedData", testCaseID, "T&C_Section2");
        Assert.assertEquals(TermsAndConditionsSection2.getText(), TermsAndConditions_Section2, "Couldn't found header");
        System.out.println("Section 2 is " + TermsAndConditions_Section2);

        String TermsAndConditions_Section3 = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage07_ExpectedData", testCaseID, "T&C_Section3");
        Assert.assertEquals(TermsAndConditionsSection3.getText(), TermsAndConditions_Section3, "Couldn't found header");
        System.out.println("Section 3 is " + TermsAndConditions_Section3);

        String TermsAndConditions_Section4 = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage07_ExpectedData", testCaseID, "T&C_Section4");
        Assert.assertEquals(TermsAndConditionsSection4.getText(), TermsAndConditions_Section4, "Couldn't found header");
        System.out.println("Section 4 is " + TermsAndConditions_Section4);

        String TermsAndConditions_Section5 = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage07_ExpectedData", testCaseID, "T&C_Section5");
        Assert.assertEquals(TermsAndConditionsSection5.getText(), TermsAndConditions_Section5, "Couldn't found header");
        System.out.println("Section 5 is " + TermsAndConditions_Section5);

        String TermsAndConditions_Section6 = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage07_ExpectedData", testCaseID, "T&C_Section6");
        Assert.assertEquals(TermsAndConditionsSection6.getText(), TermsAndConditions_Section6, "Couldn't found header");
        System.out.println("Section 6 is " + TermsAndConditions_Section6);

        String TermsAndConditions_Section7 = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage07_ExpectedData", testCaseID, "T&C_Section7");
        Assert.assertEquals(TermsAndConditionsSection7.getText(), TermsAndConditions_Section7, "Couldn't found header");
        System.out.println("Section 7 is " + TermsAndConditions_Section7);

    }

    @And("^Customer verifies the two buttons Agree&Continue and Back button and clicks on Agree&Continue Button$")
    public void customerVerifiesTheTwoButtonsAgreeContinueAndBackButtonAndClicksOnAgreeContinueButton() throws Throwable {

        Back.isPresent();
        AgreeAndContinueButton.isPresent();
        AgreeAndContinueButton.click();

        String CreditCheck_Header = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage07_ExpectedData", testCaseID, "Credit_Check_Header");
        Assert.assertEquals(CreditCheckHeader.getText(), CreditCheck_Header, "Couldn't found header");

        String CreditCheck_Title = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage07_ExpectedData", testCaseID, "Credit_Check_Title");
        Assert.assertEquals(CreditCheckTitle.getText(), CreditCheck_Title, "Couldn't found Title");


    }
}

