package com.scotiabank.ehome.ui.steps.stage2;

import java.util.List;
import java.util.concurrent.TimeUnit;

import com.quantum.java.pages.ExtentReportHelper;
import com.scotiabank.ehome.ui.steps.Utility;
import cucumber.api.PendingException;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.qmetry.qaf.automation.step.QAFTestStepProvider;
import com.qmetry.qaf.automation.ui.WebDriverTestBase;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebDriver;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.quantum.utils.ConfigurationUtils;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

@QAFTestStepProvider
public class Detailsofdownpayment {

	QAFExtendedWebDriver webDriver = new WebDriverTestBase().getDriver();
	public Actions action = null;
	WebDriverWait wait = new WebDriverWait(webDriver,50000);

	String testCaseID = Utility.getScenarioID();

	QAFExtendedWebElement TypeofPropertyhouseselect= new QAFExtendedWebElement("ehome.detailsofdownpayment.TypeofPropertyhouseselect");
	QAFExtendedWebElement Detached= new QAFExtendedWebElement("ehome.detailsofdownpayment.Detached");
	QAFExtendedWebElement eleAddress = new QAFExtendedWebElement(By.xpath("//*[@id='app']/div/div[1]/div[1]/section/div[3]/div/div[1]/div/div[2]/div/ul"));
	QAFExtendedWebElement ContinueButton= new QAFExtendedWebElement("ehome.detailsofdownpayment.ContinueButton");
	QAFExtendedWebElement ContinueButtonDetails= new QAFExtendedWebElement("ehome.detailsofdownpayment.ContinueButtonDetails");
	QAFExtendedWebElement sqft= new QAFExtendedWebElement("ehome.detailsofdownpayment.sqft");
	QAFExtendedWebElement purchasePrice= new QAFExtendedWebElement("ehome.detailsofdownpayment.purchasePrice");
	QAFExtendedWebElement downPayment= new QAFExtendedWebElement("ehome.detailsofdownpayment.downPayment");
	QAFExtendedWebElement bankAccountOption= new QAFExtendedWebElement("ehome.detailsofdownpayment.bankAccountOption");
	QAFExtendedWebElement saleOfExistingProperty= new QAFExtendedWebElement("ehome.detailsofdownpayment.saleOfExistingProperty");
	QAFExtendedWebElement investmentAccount= new QAFExtendedWebElement("ehome.detailsofdownpayment.investmentAccount");

	QAFExtendedWebElement bankAccountAmount= new QAFExtendedWebElement("ehome.detailsofdownpayment.bankAccountAmount");
	QAFExtendedWebElement saleOfExistingAmount= new QAFExtendedWebElement("ehome.detailsofdownpayment.saleOfExistingAmount");
	QAFExtendedWebElement investmentAccountAmount= new QAFExtendedWebElement("ehome.detailsofdownpayment.investmentAccountAmount");

	QAFExtendedWebElement bankAccountAmountProperty= new QAFExtendedWebElement("ehome.detailsofdownpayment.bankAccountAmountProperty");
	QAFExtendedWebElement investmentAccountAmountProperty= new QAFExtendedWebElement("ehome.detailsofdownpayment.investmentAccountAmountProperty");
	QAFExtendedWebElement saleOfExistingPropertyAmountProperty= new QAFExtendedWebElement("ehome.detailsofdownpayment.saleOfExistingPropertyAmountProperty");

	QAFExtendedWebElement saleOfExistingAmountProperty= new QAFExtendedWebElement("ehome.detailsofdownpayment.saleOfExistingAmountProperty");
	QAFExtendedWebElement saleOfExistingCalender= new QAFExtendedWebElement("ehome.detailsofdownpayment.saleOfExistingCalender");
	QAFExtendedWebElement saleOfExistingMonth= new QAFExtendedWebElement("ehome.detailsofdownpayment.saleOfExistingMonth");

	QAFExtendedWebElement scotiabankLogo= new QAFExtendedWebElement("ehome.scotiabanklogo.image");
	QAFExtendedWebElement applicationTracter= new QAFExtendedWebElement("ehome.applicationstatustracker.image");
	QAFExtendedWebElement userloginname= new QAFExtendedWebElement("ehome.userloginname.image");
	QAFExtendedWebElement Back= new QAFExtendedWebElement("ehome.detailsofdownpayment.Back");

	QAFExtendedWebElement detailsOfDownPaymentHeader= new QAFExtendedWebElement("ehome.detailsofdownpayment.detailsOfDownPaymentHeader");
	QAFExtendedWebElement AmazingText= new QAFExtendedWebElement("ehome.detailsofdownpayment.AmazingText");
	QAFExtendedWebElement DownPaymentText= new QAFExtendedWebElement("ehome.detailsofdownpayment.DownPaymentText");
	QAFExtendedWebElement DetailsOfDownPaymentBanner= new QAFExtendedWebElement("ehome.detailsofdownpayment.detailsOfDownPaymentBanner");

	QAFExtendedWebElement MinimumdownpaymentAmount= new QAFExtendedWebElement("ehome.detailsofdownpayment.MinimumdownpaymentAmount");
	QAFExtendedWebElement Minimumdownpaymentpercentage= new QAFExtendedWebElement("ehome.detailsofdownpayment.Minimumdownpaymentpercentage");
	QAFExtendedWebElement AddAnother= new QAFExtendedWebElement("ehome.detailsofdownpayment.AddAnother");
	QAFExtendedWebElement NewRow= new QAFExtendedWebElement("ehome.detailsofdownpayment.NewRow");
	QAFExtendedWebElement RemoveEntireSource= new QAFExtendedWebElement("ehome.detailsofdownpayment.RemoveEntireSource");
	QAFExtendedWebElement RemoveEntireSourceYes= new QAFExtendedWebElement("ehome.detailsofdownpayment.RemoveEntireSourceYes");
	QAFExtendedWebElement RemoveEntireSourceNo= new QAFExtendedWebElement("ehome.detailsofdownpayment.RemoveEntireSourceNo");

	QAFExtendedWebElement saleofexistingpropertydate = new QAFExtendedWebElement("ehome.detailsofdownpayment.saleofexistingpropertydate");

	QAFExtendedWebElement PurpleTick= new QAFExtendedWebElement("ehome.detailsofdownpayment.PurpleTick");
	QAFExtendedWebElement GreenTick= new QAFExtendedWebElement("ehome.detailsofdownpayment.GreenTick");
	QAFExtendedWebElement ValidEntry= new QAFExtendedWebElement("ehome.detailsofdownpayment.ValidEntry");

	QAFExtendedWebElement Remove= new QAFExtendedWebElement("ehome.detailsofdownpayment.Remove");
	QAFExtendedWebElement ShowOtherSources= new QAFExtendedWebElement("ehome.detailsofdownpayment.ShowOtherSources");
	QAFExtendedWebElement ShowOtherSourcesText= new QAFExtendedWebElement("ehome.detailsofdownpayment.ShowOtherSourcesText");
	QAFExtendedWebElement SourcesofDownPayment= new QAFExtendedWebElement("ehome.detailsofdownpayment.SourcesofDownPayment");
	QAFExtendedWebElement SourcesofDownPaymentHeader= new QAFExtendedWebElement("ehome.sourcesofdownpayment.Header");

	QAFExtendedWebElement MinDownPayText= new QAFExtendedWebElement("ehome.detailsofdownpayment.MinDownPayText");
	QAFExtendedWebElement downpaymentdoesnotmatchHeader= new QAFExtendedWebElement("ehome.downpaymentdoesnotmatch.Header");

	QAFExtendedWebElement Continue = new QAFExtendedWebElement("ehome.tellus.continue.button");
	QAFExtendedWebElement address = new QAFExtendedWebElement("ehome.whatstheaddress.addressList.list");
	QAFExtendedWebElement addressFirstOption = new QAFExtendedWebElement("ehome.whatstheaddress.addressList.firstOption");
	QAFExtendedWebElement continueWhattypeofproperty= new QAFExtendedWebElement("ehome.enteraddressmanually.continue.button");

	QAFExtendedWebElement AllSourcesDownPaymentErrorMessage= new QAFExtendedWebElement("ehome.detailsofdownpayment.AllSourcesDPErrorMessage");


	@Given("^Customer should login and navigate to What are the sources of your down payment\\? and one or more options are selected$")
	public void customer_should_login_and_navigate_to_What_are_the_sources_of_your_down_payment_and_one_or_more_options_are_selected() throws Throwable {
		// Write code here that turns the phrase above into concrete actions

		Utility.launchURL(ConfigurationUtils.getBaseBundle().getPropertyValue("env.baseurl1"));
		Continue.click();

		QAFExtendedWebElement Enteraddress= new QAFExtendedWebElement("ehome.Address.address.text");
		String addressFromExcel = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_InputData",testCaseID , "Address");
		Enteraddress.sendKeys(addressFromExcel);

		//wait.until(ExpectedConditions.elementToBeClickable(address)); //Commenting this line due to failure over Grid
		Thread.sleep(8000);
		addressFirstOption.click();
		//TO click on continue button is address screen
		wait.until(ExpectedConditions.visibilityOf(continueWhattypeofproperty));
		continueWhattypeofproperty.click();

		//wait.pollingEvery(30, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.elementToBeClickable(TypeofPropertyhouseselect));
		Thread.sleep(10000);
		TypeofPropertyhouseselect.click();

		Thread.sleep(3000);
		Detached.click();

		wait.pollingEvery(5, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(sqft));
		String sqftFromExcel = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_InputData",testCaseID , "SQFT");
		sqft.sendKeys(sqftFromExcel);

		wait.until(ExpectedConditions.visibilityOf(ContinueButton));
		ContinueButton.click();

		wait.until(ExpectedConditions.visibilityOf(purchasePrice));
		String PurchasePriceFromExcel = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_InputData",testCaseID , "Purchase_Price");
		purchasePrice.sendKeys(PurchasePriceFromExcel);
		ContinueButton.click();

		wait.until(ExpectedConditions.visibilityOf(downPayment));
		String DownPaymentFromExcel = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_InputData",testCaseID , "Down_Payment_Amount");
		downPayment.sendKeys(DownPaymentFromExcel);

		wait.until(ExpectedConditions.visibilityOf(ContinueButton));
		ContinueButton.click();

		Thread.sleep(5000);
		bankAccountOption.click();
		investmentAccount.click();

	}

	@Given("^Customer should login and navigate to What are the sources of your down payment\\? and sale of existing property is selected$")
	public void customer_should_login_and_navigate_to_What_are_the_sources_of_your_down_payment_and_sale_of_existing_property_is_selected() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		Utility.launchURL(ConfigurationUtils.getBaseBundle ().getPropertyValue("env.baseurl1"));
		Continue.click();

		QAFExtendedWebElement Enteraddress= new QAFExtendedWebElement("ehome.Address.address.text");
		String addressFromExcel = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_InputData",testCaseID , "Address");
		Enteraddress.sendKeys(addressFromExcel);

		wait.until(ExpectedConditions.elementToBeClickable(address));
		addressFirstOption.click();
		//TO click on continue button is address screen
		wait.until(ExpectedConditions.visibilityOf(continueWhattypeofproperty));
		continueWhattypeofproperty.click();

		//wait.pollingEvery(30, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(TypeofPropertyhouseselect));
		Thread.sleep(10000);
		TypeofPropertyhouseselect.click();

		Thread.sleep(3000);
		Detached.click();

		wait.pollingEvery(5, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(sqft));
		String sqftFromExcel = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_InputData",testCaseID , "SQFT");
		sqft.sendKeys(sqftFromExcel);

		wait.until(ExpectedConditions.visibilityOf(ContinueButton));
		ContinueButton.click();

		wait.until(ExpectedConditions.visibilityOf(purchasePrice));
		String PurchasePriceFromExcel = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_InputData",testCaseID , "Purchase_Price");
		purchasePrice.sendKeys(PurchasePriceFromExcel);
		ContinueButton.click();

		wait.until(ExpectedConditions.visibilityOf(downPayment));
		String DownPaymentFromExcel = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_InputData",testCaseID , "Down_Payment_Amount");
		downPayment.sendKeys(DownPaymentFromExcel);

		wait.until(ExpectedConditions.visibilityOf(ContinueButton));
		ContinueButton.click();

		Thread.sleep(5000);
		saleOfExistingProperty.click();
		Thread.sleep(3000);
	}

	@When("^Click on continue button from What are the sources of your down payment page$")
	public void click_on_continue_button_from_What_are_the_sources_of_your_down_payment_page() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		ContinueButton.click();
		Thread.sleep(5000);
	}

	@Then("^Verify 'Scotiabank Logo', 'Application status' tracker', 'Login username', 'chat icon' functionality on the screen and Back Button should be enabled, Continue Button should be enabled on Details Of DownPayment Screen$")
	public void verifyScotiabankLogoApplicationStatusTrackerLoginUsernameChatIconFunctionalityOnTheScreenAndBackButtonShouldBeEnabledContinueButtonShouldBeEnabledOnDetailsOfDownPaymentScreen() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		if(!detailsOfDownPaymentHeader.verifyText( "What are the details of your down payment sources?"  ))
			throw new AssertionError("Not able to launch details of down payment sources page");

		scotiabankLogo.assertPresent ("Couldn't find the ScotiaBank logo"  );
		if(!scotiabankLogo.verifyPresent())
			throw new AssertionError("Couldn't find the ScotiaBank logo");

		//To Check Application status tracker
		applicationTracter.assertPresent ( "Application status tracker image is missing" );
		if(!applicationTracter.verifyPresent())
			throw new AssertionError("Couldn't find the Application status tracker");

		String Back_Text = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_ExpectedData",testCaseID , "Back_Button_Text");
		Assert.assertEquals(Back.getText(), Back_Text,"Couldn't found Back button, Back button should be present");

		Back.isPresent();
	}

	@Then("^Verify the Content 'Amazing_Header','Total down payment amount', 'down payment banner', the total down payment should be \"([^\"]*)\" and the percentage of total amount from the sources of down payment to that of the total down payment amount should be \"([^\"]*)\"$")
	public void verifyTheContentAmazing_HeaderTotalDownPaymentAmountDownPaymentBannerTheTotalDownPaymentShouldBeAndThePercentageOfTotalAmountFromTheSourcesOfDownPaymentToThatOfTheTotalDownPaymentAmountShouldBe(String arg0, String arg1) throws Throwable {
		// Write code here that turns the phrase above into concrete actions

		String Amazing_Header = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_ExpectedData",testCaseID , "Details_Of_DownPayment_Message");
		Assert.assertEquals(AmazingText.getText(), Amazing_Header,"Not able to view the text Amazing – that’s another box ticked! Text");

		String DetailsOfDownPaymentHeader = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_ExpectedData",testCaseID , "Total_down_payment_amount_subHeader");
		Assert.assertEquals(DownPaymentText.getText(), DetailsOfDownPaymentHeader,"Not able to view the text Total down payment amount: Text");

		DetailsOfDownPaymentBanner.assertPresent ("Couldn't find the Banner");
		if(!DetailsOfDownPaymentBanner.verifyPresent())
			throw new AssertionError("Couldn't find the Banner");

		MinimumdownpaymentAmount.assertPresent ();
		if(!MinimumdownpaymentAmount.verifyPresent())
			throw new AssertionError("Couldn't find the Minimum Downpayment Amount");

		Minimumdownpaymentpercentage.assertPresent ();
		if(!Minimumdownpaymentpercentage.verifyPresent())
			throw new AssertionError("Couldn't find the Minimum Downpayment Percentage");
	}

	@Then("^Verify free text field, Add another link, Remove entire source on details of down payment screen$")
	public void verify_free_text_field_Add_another_link_Remove_entire_source_on_details_of_down_payment_screen() throws Throwable {
		// Write code here that turns the phrase above into concrete actions

		bankAccountAmount.assertPresent();
		if(!bankAccountAmount.verifyPresent())
			throw new AssertionError("Couldn't find the free text field");

		AddAnother.assertPresent();
		if(!AddAnother.verifyPresent())
			throw new AssertionError("Couldn't find the Add Another");

		RemoveEntireSource.assertPresent();
		if(!RemoveEntireSource.verifyPresent())
			throw new AssertionError("Couldn't find the Remove Entire Source");
	}

	@Then("^Verify Select closing date for sale of existing property on details of down payment screen$")
	public void verify_Select_closing_date_for_sale_of_existing_property_on_details_of_down_payment_screen() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		saleofexistingpropertydate.assertPresent ();
		if(!saleofexistingpropertydate.verifyPresent())
			throw new AssertionError("Couldn't find the Sale of existing property date");
	}

	@Then("^Should navigate to the sources of your down payment page$")
	public void should_navigate_to_the_sources_of_your_down_payment_page() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		String Amazing_Header = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_ExpectedData",testCaseID , "Details_Of_DownPayment_Message");
		Assert.assertEquals(AmazingText.getText(), Amazing_Header,"Not able to view the text Another box ticked! Janet");
	}

	@When("^entered text in sources of down payment$")
	public void entered_text_in_sources_of_down_payment() throws Throwable {
		// Write code here that turns the phrase above into concrete actions

		wait.until(ExpectedConditions.visibilityOf(bankAccountAmountProperty));
		String BankAccountAmountFromExcel = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_InputData",testCaseID , "Bank_Account_Amount");
		bankAccountAmount.sendKeys(BankAccountAmountFromExcel);
	}

	@Then("^Verify green and purple tick marks for the source for down payment, allow decimal values also for the free text field$")
	public void verify_green_and_purple_tick_marks_for_the_source_for_down_payment_allow_decimal_values_also_for_the_free_text_field() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		PurpleTick.assertPresent ();
		if(!PurpleTick.verifyPresent())
			throw new AssertionError("Couldn't find the Purple Tick");

		GreenTick.assertPresent ();
		if(!GreenTick.verifyPresent())
			throw new AssertionError("Couldn't find the Green Tick");
	}

	@When("^entered invalid text in sources for down payment$")
	public void entered_invalid_text_in_sources_for_down_payment() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		String SpecialCharectersfromXcel = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_InputData",testCaseID , "Bank_Account_Amount_SpecialCharecters");
		bankAccountAmount.sendKeys(SpecialCharectersfromXcel);


	}

	@Then("^Verify 'Please provide a valid entry' text on details of down payment screen$")
	public void verifyPleaseProvideAValidEntryTextOnDetailsOfDownPaymentScreen() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		String BankAccountAmountErrorMessagefromexcel = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_ExpectedData",testCaseID , "Bank_Account_Amount_ErrorMessage");
		Assert.assertEquals(ValidEntry.getText(), BankAccountAmountErrorMessagefromexcel,"Field is accepting decimal values");
	}

	@Then("^system should allow upto (\\d+) Add another links$")
	public void system_should_allow_upto_Add_another_links(int arg1) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		AddAnother.click();
		Thread.sleep(1000);
		AddAnother.click();
		Thread.sleep(1000);
		AddAnother.click();
		Thread.sleep(1000);
		AddAnother.click();
		Thread.sleep(1000);

		if(NewRow.isPresent())
			throw new AssertionError("There are more than 5 Add Another links");
	}

	@When("^Click on Add Another link$")
	public void click_on_Add_Another_link() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		AddAnother.click();
	}

	@Then("^'free text field' as 'free text field'$")
	public void freeTextFieldAsFreeTextField() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		if(!bankAccountAmount.isPresent())
			throw new AssertionError("There is no free text field");
	}

	@When("^Click on Remove link$")
	public void click_on_Remove_link() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		Remove.click();
	}

	@Then("^free text field and corresponding set should be deleted$")
	public void free_text_field_and_corresponding_set_should_be_deleted() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		if (Remove.isPresent())
			throw new AssertionError("There is no Remove link");
	}

	@When("^Click on Remove entire source link$")
	public void click_on_Remove_entire_source_link() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		Thread.sleep(2000);
		RemoveEntireSource.click();
	}

	@Then("^\"([^\"]*)\" and \"([^\"]*)\" options should be displayed$")
	public void and_options_should_be_displayed(String arg1, String arg2) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		if (!RemoveEntireSourceYes.isPresent())
			throw new AssertionError("There is no Remove Entire Source Yes");
		if (!RemoveEntireSourceNo.isPresent())
			throw new AssertionError("There is no Remove Entire Source No");
	}

	@When("^Selected \"([^\"]*)\"$")
	public void selected(String arg1) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		if (arg1.equals("Yes"))
			RemoveEntireSourceYes.click();
		else
			RemoveEntireSourceNo.click();
	}

	@Then("^downpayment source should be deleted$")
	public void downpayment_source_should_be_deleted() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		if (bankAccountAmountProperty.isPresent())
			throw new AssertionError("Entire Source is not deleted");
	}

	@Then("^downpayment source should NOT be deleted$")
	public void downpayment_source_should_NOT_be_deleted() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		if (!bankAccountAmountProperty.isPresent())
			throw new AssertionError("Entire Source is deleted");
	}

	@When("^Click on show other sources$")
	public void click_on_show_other_sources() throws Throwable {
		// Write code here that turns the phrase above into concrete actions

		ShowOtherSources.click();
	}

	@Then("^sources of downpayment should be displayed$")
	public void sources_of_downpayment_should_be_displayed() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		if (!SourcesofDownPayment.isPresent())
			throw new AssertionError("Sources Of Down Payment options are not Present");
	}

	@When("^Click on hide other sources$")
	public void click_on_hide_other_sources() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		ShowOtherSources.click();
	}

	@Then("^sources of downpayment should be hidden$")
	public void sources_of_downpayment_should_be_hidden() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		List<WebElement> SourcesofDownPaymentList = SourcesofDownPayment.findElements(By.tagName("span"));
		if (!SourcesofDownPaymentList.get(0).isEnabled())
			throw new AssertionError("Sources Of Down Payment options are Present");
	}

	@When("^Amount entered in free field text for down payment sources are greater than (\\d+)%$")
	public void amount_entered_in_free_field_text_for_down_payment_sources_are_greater_than(int arg1) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		wait.until(ExpectedConditions.visibilityOf(bankAccountAmountProperty));
		String BankAccountAmountFromExcel = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_InputData",testCaseID , "Bank_Account_Amount");
		bankAccountAmount.sendKeys(BankAccountAmountFromExcel);
	}

	@Then("^continue button should be enabled on the DownPayment Screen$")
	public void continueButtonShouldBeEnabledOnTheDownPaymentScreen() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		if(!ContinueButtonDetails.isPresent())
			throw new AssertionError("Continue Button is not enabled");
	}

	@When("^Back button is clicked$")
	public void back_button_is_clicked() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		Back.click();
	}

	@Then("^'What are the sources of your down payment\\?' page should be displayed with the earlier down payment source values shown as selected$")
	public void what_are_the_sources_of_your_down_payment_page_should_be_displayed_with_the_earlier_down_payment_source_values_shown_as_selected() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		if (!SourcesofDownPaymentHeader.isPresent())
			throw new AssertionError("It is not navigated to Sources Of Down Payment");
	}

	@When("^entered text which is greater than purchase price$")
	public void entered_text_which_is_greater_than_purchase_price() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		wait.until(ExpectedConditions.visibilityOf(bankAccountAmountProperty));
		String BankAccountAmountFromExcel = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_InputData",testCaseID , "Bank_Account_Amount");
		bankAccountAmount.sendKeys(BankAccountAmountFromExcel);
	}

	@Then("^Verify the text 'To proceed, the minimum down payment should be less than the purchase price'$")
	public void verifyTheTextToProceedTheMinimumDownPaymentShouldBeLessThanThePurchasePrice() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		String MinimumDownPaymentErrorMessageFromExcel = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_ExpectedData",testCaseID , "Minimum_DownPayment_Error_Message");
		Assert.assertEquals(MinDownPayText.getText(), MinimumDownPaymentErrorMessageFromExcel,"Entered value is not greater than down payment");
	}

	@When("^entered amount does not match with the downpayment amount$")
	public void entered_amount_doenot_match_with_the_downpayment_amount() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		wait.until(ExpectedConditions.visibilityOf(bankAccountAmountProperty));
		String BankAccountAmountFromExcel = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_InputData",testCaseID , "Bank_Account_Amount");
		bankAccountAmount.sendKeys(BankAccountAmountFromExcel);
	}

	@When("^click on Continue$")
	public void click_on_Continue() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		ContinueButtonDetails.click();
	}

	@Then("^'The down payment information you have provided does not match\\.' page should be displayed\\.$")
	public void the_down_payment_information_you_have_provided_does_not_match_page_should_be_displayed() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		if(!downpaymentdoesnotmatchHeader.isPresent())
			throw new AssertionError("Not navigated to down payment does not match screen");
	}

	@When("^entered text in one sources of down payment and clicked on Continue Button$")
	public void enteredTextInOneSourcesOfDownPaymentAndClickedOnContinueButton() throws Throwable {

		wait.until(ExpectedConditions.visibilityOf(bankAccountAmountProperty));
		String BankAccountAmountFromExcel = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_InputData",testCaseID , "Bank_Account_Amount");
		bankAccountAmount.sendKeys(BankAccountAmountFromExcel);

		ContinueButtonDetails.click();


	}

	@Then("^Verify the Error message to fill all sources of DownPayment$")
	public void verifyTheErrorMessageToFillAllSourcesOfDownPayment() throws Throwable {

		String AllSourcesDPErrorMessage = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage02_NewHome_ExpectedData",testCaseID , "All_Sources_DP_Error_Message");
		Assert.assertEquals(AllSourcesDownPaymentErrorMessage.getText(), AllSourcesDPErrorMessage,"Text Mismatch");
	}
}
