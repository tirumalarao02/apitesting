package com.scotiabank.ehome.ui.steps.stage7;

import com.qmetry.qaf.automation.step.QAFTestStepProvider;
import com.qmetry.qaf.automation.ui.WebDriverTestBase;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebDriver;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.quantum.utils.ConfigurationUtils;
import com.scotiabank.ehome.ui.steps.Utility;
import cucumber.api.PendingException;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

@QAFTestStepProvider
public class creditCheck {

    QAFExtendedWebDriver webDriver = new WebDriverTestBase().getDriver();
    public Actions action = null;
    WebDriverWait wait = new WebDriverWait(webDriver, 50000);

    String testCaseID = Utility.getScenarioID();

    QAFExtendedWebElement TermsAndConditionsHeader = new QAFExtendedWebElement("ehome.termsAndConditions.header");

    QAFExtendedWebElement AgreeAndContinueButton = new QAFExtendedWebElement("ehome.termsAndConditions.AgreeContinue");
    QAFExtendedWebElement CreditCheckHeader = new QAFExtendedWebElement("ehome.termsAndConditions.CreditCheckHeader");
    QAFExtendedWebElement CreditCheckTitle = new QAFExtendedWebElement("ehome.termsAndConditions.CreditCheckTitle");
    QAFExtendedWebElement Back = new QAFExtendedWebElement("ehome.termsAndConditions.Back");
    QAFExtendedWebElement CreditConsentText = new QAFExtendedWebElement("ehome.CreditCheck.Text");
    QAFExtendedWebElement CreditConsentYes = new QAFExtendedWebElement("ehome.CreditCheck.Yes");
    QAFExtendedWebElement CreditConsentNo = new QAFExtendedWebElement("ehome.CreditCheck.No");
    QAFExtendedWebElement CreditConsentNo_ToolTip = new QAFExtendedWebElement("ehome.CreditCheck.No.tooltip");
    QAFExtendedWebElement Feedback_Page_Header = new QAFExtendedWebElement("ehome.Feedback.Page");


    @Given("^Customer should login and navigates to Credit Check Page$")
    public void customerShouldLoginAndNavigatesToCreditCheckPage() throws Throwable {

        Utility.launchURL(ConfigurationUtils.getBaseBundle().getPropertyValue("env.baseurl3"));
        AgreeAndContinueButton.click();

        String CreditCheck_Header = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage07_ExpectedData", testCaseID, "Credit_Check_Header");
        Assert.assertEquals(CreditCheckHeader.getText(), CreditCheck_Header, "Couldn't found header");

        String CreditCheck_Title = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage07_ExpectedData", testCaseID, "Credit_Check_Title");
        Assert.assertEquals(CreditCheckTitle.getText(), CreditCheck_Title, "Couldn't found Title");


    }

    @Then("^Customer verifies the content of Credit Consent on the screen$")
    public void customerVerifiesTheContentOfCreditConsentOnTheScreen() throws Throwable {

        String CreditCheck_Text = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage07_ExpectedData", testCaseID, "Credit_Check_Text");
        Assert.assertEquals(CreditConsentText.getText(), CreditCheck_Text, "Couldn't found Expected Text");

    }

    @And("^Customer clicks on Yes Button and navigates to Feedback Copy Page$")
    public void customerClicksOnYesButtonAndNavigatesToFeedbackCopyPage() throws Throwable {
        CreditConsentYes.click();

        Feedback_Page_Header.isPresent();

    }

    @And("^Customer clicks on No Button and presented with tool tip message$")
    public void customerClicksOnNoButtonAndPresentedWithToolTipMessage() throws Throwable {

        CreditConsentNo.click();

        String CreditCheck_No_Tool_Tip = Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage07_ExpectedData", testCaseID, "Credit_Check_No_ToolTip");
        Assert.assertEquals(CreditConsentNo_ToolTip.getText(), CreditCheck_No_Tool_Tip, "Couldn't found Expected Text");



    }

    @And("^Customer clicks on the Back button in Credit Check Screen and navigated to Terms&Conditions Screen$")
    public void customerClicksOnTheBackButtonInCreditCheckScreenAndNavigatedToTermsConditionsScreen() throws Throwable {

        Back.click();

        TermsAndConditionsHeader.isPresent();


    }
}

