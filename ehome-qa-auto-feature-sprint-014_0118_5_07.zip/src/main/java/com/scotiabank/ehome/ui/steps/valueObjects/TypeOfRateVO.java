package com.scotiabank.ehome.ui.steps.valueObjects;

import java.util.Date;

public class TypeOfRateVO {
	private static TypeOfRateVO thisInstance;
	
	public static final int TYPE_OF_RATE_NO_SELECTION_MADE=-1;
	public static final int TYPE_OF_RATE_VARIABLE_RATE=1;
	public static final int TYPE_OF_RATE_FIXED_RATE=2;
	
	public static final int PAYMENT_SCHEDULE_FREQUENCY_WEEKLY = 1;
	public static final int PAYMENT_SCHEDULE_FREQUENCY_BI_WEEKLY = 2;
	public static final int PAYMENT_SCHEDULE_FREQUENCY_MONTHLY = 3;
	
	//Object Variables
	private int typeOfRate=TYPE_OF_RATE_NO_SELECTION_MADE;

	
	//Allowed values 2,3,4,5
	private int numberOfYears=0;
	private double purchasePrice = 0;
	private double downPayment = 0;
	private double loanRequested = 0;
	
	public double getLoanRequested() {
		return loanRequested;
	}
	public void setLoanRequested(double loanRequested) {
		this.loanRequested = loanRequested;
	}
	private int amortizationPeriodYears = 0;
	private int amortizationPeriodMonths = 0;
	private int paymentScheduleFrequency = PAYMENT_SCHEDULE_FREQUENCY_MONTHLY;
	private Date approvalDate = null;
	
	//Derived values
	private double rateOfInterest = 0;
	public double getRateOfInterest() {
		return rateOfInterest;
	}
	public void setRateOfInterest(double rateOfInterest) {
		this.rateOfInterest = rateOfInterest;
	}
	private double paymentSchedule = 0.0;
	private Date firstPaymentDate = null;
	private Boolean lessThan20Percent;
	public Boolean getLessThan20Percent() {
		return lessThan20Percent;
	}
	public void setLessThan20Percent(Boolean lessThan20Percent) {
		this.lessThan20Percent = lessThan20Percent;
	}
	public Double getMonthlyPayment() {
		return monthlyPayment;
	}
	public void setMonthlyPayment(Double monthlyPayment) {
		this.monthlyPayment = monthlyPayment;
	}
	public Double getWeeklypayment() {
		return weeklypayment;
	}
	public void setWeeklypayment(Double weeklypayment) {
		this.weeklypayment = weeklypayment;
	}
	public Double getBiWeeklyPayment() {
		return biWeeklyPayment;
	}
	public void setBiWeeklyPayment(Double biWeeklyPayment) {
		this.biWeeklyPayment = biWeeklyPayment;
	}
	private Double monthlyPayment;
	private Double weeklypayment;
	private Double biWeeklyPayment;
	
	private TypeOfRateVO() {
		
	}
	public static TypeOfRateVO getInstance() {
		if(thisInstance==null)
			thisInstance = new TypeOfRateVO();
		return thisInstance;
	}
	public int getTypeOfRate() {
		return typeOfRate; 
	}
	public void setTypeOfRate(int typeOfRate) {
		this.typeOfRate = typeOfRate;
	}
	public int getNumberOfYears() {
		return numberOfYears;
	}
	public void setNumberOfYears(int numberOfYears) {
		this.numberOfYears = numberOfYears;
	}
	public double getPurchasePrice() {
		return purchasePrice;
	}
	public void setPurchasePrice(double purchasePrice) {
		this.purchasePrice = purchasePrice;
	}
	public double getDownPayment() {
		return downPayment;
	}
	public void setDownPayment(double downPayment) {
		this.downPayment = downPayment;
	}
	public int getAmortizationPeriodYears() {
		return amortizationPeriodYears; 
	}
	public void setAmortizationPeriodYears(int amortizationPeriodYears) {
		this.amortizationPeriodYears = amortizationPeriodYears;
	}
	public int getAmortizationPeriodMonths() {
		return amortizationPeriodMonths;
	}
	public void setAmortizationPeriodMonths(int amortizationPeriodMonths) {
		this.amortizationPeriodMonths = amortizationPeriodMonths;
	}
	public int getPaymentScheduleFrequency() {
		return paymentScheduleFrequency;
	}
	public void setPaymentScheduleFrequency(int paymentScheduleFrequency) {
		this.paymentScheduleFrequency = paymentScheduleFrequency;
	}
	public Date getApprovalDate() {
		return approvalDate;
	}
	public void setApprovalDate(Date approvalDate) {
		this.approvalDate = approvalDate;
	}
	//
	public Date getrateOfInterest() {
		return approvalDate;
	}
	public Date getpaymentSchedule() {
		return approvalDate;
	}
	public Date firstPaymentDate() {
		return approvalDate;
	}
	
}
