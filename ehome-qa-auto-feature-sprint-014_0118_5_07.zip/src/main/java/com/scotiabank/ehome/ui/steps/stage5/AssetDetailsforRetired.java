package com.scotiabank.ehome.ui.steps.stage5;
import com.qmetry.qaf.automation.step.QAFTestStepProvider;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebDriver;
import com.quantum.java.pages.ExtentReportHelper;
import com.quantum.utils.ConfigurationUtils;
import com.scotiabank.ehome.ui.steps.Common;
import com.scotiabank.ehome.ui.steps.CommonAppMethodsAssetLiabilities;
import com.scotiabank.ehome.ui.steps.CommonAppMethodsEmployment;
import com.scotiabank.ehome.ui.steps.CommonApplicationMethods;
import com.scotiabank.ehome.ui.steps.Utility;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.support.ui.WebDriverWait;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;

import java.util.Map;
import java.util.concurrent.TimeUnit;
import static com.scotiabank.ehome.ui.steps.Utility.*;

@QAFTestStepProvider

public class AssetDetailsforRetired {
	public static WebDriverWait wait=Utility.getWait();
	  static String curDir = System.getProperty("user.dir");
	  static String strfullPathToFile = curDir + "\\src\\main\\resources\\data\\eHomeTestData.xlsx"; // File Path
		
	  static String sheetStage04_InputData ="Stage04_Employment_InputData";
	  static String sheetStage04_ExpectedData ="Stage04_Employment_ExpectedData";
	  static String sheetStage05_InputData ="Stage05_AssetLiabilty_InputData";
	  static String sheetStage05_ExpectedData ="Stage05_AsetLiblty_ExpectedData";
	  
	  
	  //String strtestCaseID = "AssetDetails-Retired-TC-015";
	  
	  String strtestCaseID = Utility.getScenarioID();
		  
	  @Then("^Verify presence of all objects on 'Asset Sources Detail' Screen$")
		public void Verify_presence_of_all_objects_on_Asset_Details_Screen() throws Throwable {
		  
		  Common.continueButtonClicked();
		  
		  Utility.verifyIsObjectPresent("ehome.assetSourcesDetails.Automobile", "Automobile Details Text Box");
		  Utility.verifyIsObjectPresent("ehome.assetSourcesDetails.Cash", "Cash Details Text Box");
		  Utility.verifyIsObjectPresent("ehome.assetSourcesDetails.GICTermdeposit", "GICTermdeposit Details Text Box");
		  Utility.verifyIsObjectPresent("ehome.assetSourcesDetails.Primaryresidence", "Primaryresidence Details Text Box");
		  Utility.verifyIsObjectPresent("ehome.assetSourcesDetails.Rentalproperty", "Rentalproperty Details Text Box");
		  Utility.verifyIsObjectPresent("ehome.assetSourcesDetails.RRSP", "RRSP Details Text Box");
		  Utility.verifyIsObjectPresent("ehome.assetSourcesDetails.Secondaryproperty", "Secondaryproperty Details Text Box");
		  Utility.verifyIsObjectPresent("ehome.assetSourcesDetails.StockBond", "StockBond Details Text Box");
		  Utility.verifyIsObjectPresent("ehome.assetSourcesDetails.Otherassets", "Otherassets Details Text Box");
		  Utility.verifyIsObjectPresent("ehome.assetSourcesDetails.Continue", "Continue");
		  Utility.verifyIsObjectPresent("ehome.assetSourcesDetails.Back", "Back");
		  
		  }
	
		@Then("^Verify 'Asset' Screen when click on 'Back' button on 'Asset Details' Screen$")
		public void Verify_Asset_Screen_when_Click_on_Back_button_on_Asset_Details_Screen() throws Throwable {
			Map<String, String> Stage05_ExpectedData =  Utility.readTestData(strfullPathToFile, sheetStage05_ExpectedData,strtestCaseID);
			Common.continueButtonClicked();
			String strAsset_Header_ExpectedTitle	= Stage05_ExpectedData.get("Assets_FollowingAssets_Label");
			Utility.clickObject("ehome.assetSourcesDetails.Back", "Back Button in Asset Source detail");
			Utility.verifyIsTextPresent("ehome.assetSrcs.FollowingAssets_Label", "Heading Centre Text", strAsset_Header_ExpectedTitle);
		}
		
		
		@Then("^Enter 'Asset Details' and Select 'Continue' on 'Asset Details' Screen$")
		public void Enter_Asset_and_Select_Continue_on_Asset_Details_Screen() throws Throwable {
			
			Map<String, String> Stage05_InputData =  Utility.readTestData(strfullPathToFile, sheetStage05_InputData,strtestCaseID);
			String strAutomobile_Input = Stage05_InputData.get("AssetSources_Automobile");
			String strCash_Input = Stage05_InputData.get("AssetSources_Cash");
			String strGICTermdeposit_Input = Stage05_InputData.get("AssetSources_GICTermDeposit");
			String strPrimaryresidence_Input = Stage05_InputData.get("AssetSources_PrimaryResidence");
			String strRentalproperty_Input = Stage05_InputData.get("AssetSources_RentalProperty");
			String strRRSP_Input = Stage05_InputData.get("AssetSources_RRSP");
			String strSecondaryproperty_Input = Stage05_InputData.get("AssetSources_SecondaryProperty");
			String strStockBond_Input = Stage05_InputData.get("AssetSources_StockBond");
			String strOtherassets_Input = Stage05_InputData.get("AssetSources_OtherAssets");
			
			
			String strAutomobile_Amt = Stage05_InputData.get("AssetSources_Automobile_Amt");
			String strCash_Amt = Stage05_InputData.get("AssetSources_Cash_Amt");
			String strGICTermdeposit_Amt = Stage05_InputData.get("AssetSources_GICTermDeposit_Amt");
			String strPrimaryresidence_Amt = Stage05_InputData.get("AssetSources_PrimaryResidence_Amt");
			String strRentalproperty_Amt = Stage05_InputData.get("AssetSources_RentalProperty_Amt");
			String strRRSP_Amt = Stage05_InputData.get("AssetSources_RRSP_Amt");
			String strSecondaryproperty_Amt = Stage05_InputData.get("AssetSources_SecondaryProperty_Amt");
			String strStockBond_Amt = Stage05_InputData.get("AssetSources_StockBond_Amt");
			String strOtherassets_Amt = Stage05_InputData.get("AssetSources_OtherAssets_Amt");
			
			Common.continueButtonClicked();
			
			if (strAutomobile_Input != "" && strAutomobile_Amt != "")
			{
				CommonAppMethodsAssetLiabilities.EnterAssetCalculateAmount(strAutomobile_Input, strAutomobile_Amt);
			}
			if (strCash_Input != "" && strCash_Amt != "")
			{
				CommonAppMethodsAssetLiabilities.EnterAssetCalculateAmount(strCash_Input, strCash_Amt);
			}
			if (strGICTermdeposit_Input != "" && strGICTermdeposit_Amt != "")
			{
				CommonAppMethodsAssetLiabilities.EnterAssetCalculateAmount(strGICTermdeposit_Input, strGICTermdeposit_Amt);
			}
			if (strPrimaryresidence_Input != "" && strPrimaryresidence_Amt != "")
			{
				CommonAppMethodsAssetLiabilities.EnterAssetCalculateAmount(strPrimaryresidence_Input, strPrimaryresidence_Amt);
			}
			if (strRentalproperty_Input != "" && strRentalproperty_Amt != "")
			{
				CommonAppMethodsAssetLiabilities.EnterAssetCalculateAmount(strRentalproperty_Input, strRentalproperty_Amt);
			}
			if (strRRSP_Input != "" && strRRSP_Amt != "")
			{
				CommonAppMethodsAssetLiabilities.EnterAssetCalculateAmount(strRRSP_Input, strRRSP_Amt);
			}
			if (strSecondaryproperty_Input != "" && strSecondaryproperty_Amt != "")
			{
				CommonAppMethodsAssetLiabilities.EnterAssetCalculateAmount(strSecondaryproperty_Input, strSecondaryproperty_Amt);
			}
			if (strStockBond_Input != "" && strStockBond_Amt != "")
			{
				CommonAppMethodsAssetLiabilities.EnterAssetCalculateAmount(strStockBond_Input, strStockBond_Amt);
			}
			
			if (strOtherassets_Input != "" && strOtherassets_Amt != "")
			{
				CommonAppMethodsAssetLiabilities.EnterAssetCalculateAmount(strOtherassets_Input, strOtherassets_Amt);
			}
			
			Utility.clickObject("ehome.assetSourcesDetails.Continue", "Continue in assetSourcesDetails");
			
		}
		
		
		@Then("^Verify 'Liability' Screen$")
		public void Verify_Liability_Screen() throws Throwable {
			  Map<String, String> Stage05_ExpectedData =  Utility.readTestData(strfullPathToFile, sheetStage05_ExpectedData,strtestCaseID);
			  String strLiability_Actual_Title	= Stage05_ExpectedData.get("Liability_Sources_Title");
			  Utility.verifyIsTextPresent("ehome.liabilitySrcs.Title", "Mandatory Error Messages", strLiability_Actual_Title);
			}
		
		@Then("^Verify 'Err Message' when enter without 'Asset Details' on 'Asset Details' Screen$")
		public void Verify_ErrMessage_without_Details_when_Click_on_Continue_button_on_Asset_Details_Screen() throws Throwable {
			  Map<String, String> Stage05_ExpectedData =  Utility.readTestData(strfullPathToFile, sheetStage05_ExpectedData,strtestCaseID);
			  String Asset_details_MandError_Msg	= Stage05_ExpectedData.get("Asset_Details_MandryErrMsg");
			  Utility.verifyIsTextPresent("ehome.assetDetails.MandryErrMsg", "Mandatory Error Messages", Asset_details_MandError_Msg);
			}
		
		
		@Then("^Verify 'Remove entire source' links on 'Asset Details' Screen$")
		public void Verify_Remove_entire_source_links_on_Asset_Details_Screen() throws Throwable {
			Map<String, String> Stage05_InputData =  Utility.readTestData(strfullPathToFile, sheetStage05_InputData,strtestCaseID);
			String strAutomobile_Input = Stage05_InputData.get("AssetSources_Automobile");
			String strCash_Input = Stage05_InputData.get("AssetSources_Cash");
			String strGICTermdeposit_Input = Stage05_InputData.get("AssetSources_GICTermDeposit");
			String strPrimaryresidence_Input = Stage05_InputData.get("AssetSources_PrimaryResidence");
			String strRentalproperty_Input = Stage05_InputData.get("AssetSources_RentalProperty");
			String strRRSP_Input = Stage05_InputData.get("AssetSources_RRSP");
			String strSecondaryproperty_Input = Stage05_InputData.get("AssetSources_SecondaryProperty");
			String strStockBond_Input = Stage05_InputData.get("AssetSources_StockBond");
			String strOtherassets_Input = Stage05_InputData.get("AssetSources_OtherAssets");
			
			String strAutomobile_Amt = Stage05_InputData.get("AssetSources_Automobile_Amt");
			String strCash_Amt = Stage05_InputData.get("AssetSources_Cash_Amt");
			String strGICTermdeposit_Amt = Stage05_InputData.get("AssetSources_GICTermDeposit_Amt");
			String strPrimaryresidence_Amt = Stage05_InputData.get("AssetSources_PrimaryResidence_Amt");
			String strRentalproperty_Amt = Stage05_InputData.get("AssetSources_RentalProperty_Amt");
			String strRRSP_Amt = Stage05_InputData.get("AssetSources_RRSP_Amt");
			String strSecondaryproperty_Amt = Stage05_InputData.get("AssetSources_SecondaryProperty_Amt");
			String strStockBond_Amt = Stage05_InputData.get("AssetSources_StockBond_Amt");
			String strOtherassets_Amt = Stage05_InputData.get("AssetSources_OtherAssets_Amt");
			
			Common.continueButtonClicked();
			
			if (strAutomobile_Input != "" && strAutomobile_Amt != "")
			{
				CommonAppMethodsAssetLiabilities.EnterAssetCalculateAmount(strAutomobile_Input, strAutomobile_Amt);
				Utility.verifyIsObjectPresent("ehome.assetSourcesDetails.AutomobileRemove", "Automobile Remove entire Asset Link");
				
			}
			if (strCash_Input != "" && strCash_Amt != "")
			{
				CommonAppMethodsAssetLiabilities.EnterAssetCalculateAmount(strCash_Input, strCash_Amt);
				Utility.verifyIsObjectPresent("ehome.assetSourcesDetails.CashRemove", "Cash Remove entire Asset Link");
			}
			if (strGICTermdeposit_Input != "" && strGICTermdeposit_Amt != "")
			{
				CommonAppMethodsAssetLiabilities.EnterAssetCalculateAmount(strGICTermdeposit_Input, strGICTermdeposit_Amt);
				Utility.verifyIsObjectPresent("ehome.assetSourcesDetails.GICTermdepositRemove", "GICTermdeposit Remove entire Asset Link");
			}
			if (strPrimaryresidence_Input != "" && strPrimaryresidence_Amt != "")
			{
				CommonAppMethodsAssetLiabilities.EnterAssetCalculateAmount(strPrimaryresidence_Input, strPrimaryresidence_Amt);
				Utility.verifyIsObjectPresent("ehome.assetSourcesDetails.PrimaryresidenceRemove", "Primaryresidence Remove entire Asset Link");
			}
			if (strRentalproperty_Input != "" && strRentalproperty_Amt != "")
			{
				CommonAppMethodsAssetLiabilities.EnterAssetCalculateAmount(strRentalproperty_Input, strRentalproperty_Amt);
				Utility.verifyIsObjectPresent("ehome.assetSourcesDetails.RentalpropertyRemove", "Rentalproperty Remove entire Asset Link");
			}
			if (strRRSP_Input != "" && strRRSP_Amt != "")
			{
				CommonAppMethodsAssetLiabilities.EnterAssetCalculateAmount(strRRSP_Input, strRRSP_Amt);
				Utility.verifyIsObjectPresent("ehome.assetSourcesDetails.RRSPRemove", "RRSP Remove entire Asset Link");
			}
			if (strSecondaryproperty_Input != "" && strSecondaryproperty_Amt != "")
			{
				CommonAppMethodsAssetLiabilities.EnterAssetCalculateAmount(strSecondaryproperty_Input, strSecondaryproperty_Amt);
				Utility.verifyIsObjectPresent("ehome.assetSourcesDetails.SecondarypropertyRemove", "Secondaryproperty Remove entire Asset Link");
			}
			if (strStockBond_Input != "" && strStockBond_Amt != "")
			{
				CommonAppMethodsAssetLiabilities.EnterAssetCalculateAmount(strStockBond_Input, strStockBond_Amt);
				Utility.verifyIsObjectPresent("ehome.assetSourcesDetails.StockBondRemove", "StockBond Remove entire Asset Link");
			}
			
			if (strOtherassets_Input != "" && strOtherassets_Amt != "")
			{
				CommonAppMethodsAssetLiabilities.EnterAssetCalculateAmount(strOtherassets_Input, strOtherassets_Amt);
				Utility.verifyIsObjectPresent("ehome.assetSourcesDetails.OtherassetsRemove", "Otherassets Remove entire Asset Link");
			}
			
			Utility.clickObject("ehome.assetSourcesDetails.Continue", "Continue in assetSourcesDetails");
		}
		
		
		@Then("^Verify 'Remove entire source' functionality on 'Asset Details' Screen$")
		public void Verify_Remove_entire_source_functionality_on_Assetdetails_Screen() throws Throwable {
			Map<String, String> Stage05_InputData =  Utility.readTestData(strfullPathToFile, sheetStage05_InputData,strtestCaseID);
			String strAutomobile_Input = Stage05_InputData.get("AssetSources_Automobile");
			String strAutomobile_Amt = Stage05_InputData.get("AssetSources_Automobile_Amt");

			Common.continueButtonClicked();
			
				if (strAutomobile_Input != "" && strAutomobile_Amt != "")
				{
					CommonAppMethodsAssetLiabilities.EnterAssetCalculateAmount(strAutomobile_Input, strAutomobile_Amt);
					Utility.clickObject("ehome.assetSourcesDetails.AutomobileRemove", "Automobile Details Remove entire Asset Link");
					Utility.clickObject("//*[@id=\"app\"]/div/div[1]/div[3]/div/div[1]/div[1]/div/div/div[2]/button[1]", "Are you Sure Button? Yes");
					Utility.verifyIsObjectPresent("ehome.assetSourcesDetails.Showotherassets","Show other assets Link");
			}

		}
		
		
		
		
	
}
