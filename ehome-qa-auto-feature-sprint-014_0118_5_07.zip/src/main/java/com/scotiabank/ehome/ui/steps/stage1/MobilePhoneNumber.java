package com.scotiabank.ehome.ui.steps.stage1;

import static com.scotiabank.ehome.ui.steps.Utility.getScreenDataset;

import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.qmetry.qaf.automation.step.QAFTestStepProvider;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebDriver;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.quantum.utils.ConfigurationUtils;
import com.scotiabank.ehome.ui.steps.Common;
import com.scotiabank.ehome.ui.steps.Utility;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

@QAFTestStepProvider
public class MobilePhoneNumber {
	
	private QAFExtendedWebDriver webDriver = Utility.getDriver();
    public Actions action = null;
    public static WebDriverWait wait=Utility.getWait();	
    
    private Map<String,Map<String,Boolean>> emailAddressExcel = getScreenDataset(Utility.getExcelFilePath("eHomeTestDatastage-4.xlsx"), "MobilePhoneNumber");
    //private Map<String,Map<String,Boolean>> emailAddressDataset = getScreenDataset(Utility.getExcelFilePath("eHomeTestDatastage-4.xlsx"), "IndustryAndJobTitle");
    
    QAFExtendedWebElement headerTitle= new QAFExtendedWebElement("ehome.mobilePhoneNumber.headerTitle");
    QAFExtendedWebElement headerText= new QAFExtendedWebElement("ehome.mobilePhoneNumber.headerText");
    QAFExtendedWebElement footerText= new QAFExtendedWebElement("ehome.mobilePhoneNumber.footerText");
    
    QAFExtendedWebElement MobilePhoneNumber1= new QAFExtendedWebElement("ehome.mobilePhoneNumber.MobilePhoneNumber1");
    QAFExtendedWebElement MobilePhoneNumber2= new QAFExtendedWebElement("ehome.mobilePhoneNumber.MobilePhoneNumber2");
    QAFExtendedWebElement MobilePhoneNumber3= new QAFExtendedWebElement("ehome.mobilePhoneNumber.MobilePhoneNumber3");
    QAFExtendedWebElement inValidMobilePhoneNumber= new QAFExtendedWebElement("ehome.mobilePhoneNumber.inValidMobilePhoneNumber");
    QAFExtendedWebElement whatsyouremailaddresstitle= new QAFExtendedWebElement("ehome.mobilePhoneNumber.headerText");
    QAFExtendedWebElement ehomeSecurityHeader= new QAFExtendedWebElement("ehome.mobilePhoneNumber.ehomeSecurityHeader");
    
	@Given("^Customer should login and navigates to Mobile Phone Number screen$")
	public void customer_should_login_and_navigates_to_Mobile_Phone_Number_screen() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Utility.launchURL(ConfigurationUtils.getBaseBundle().getPropertyValue ("env.baseurl0"));
		Welcome.viewOurPrivacyAgreementButtonClicked();
		PrivacyAgreement.acceptAndContinuetButtonClicked();
		SOLCustomerQuestion.triageQuestionsButtonClicked();
		SOLCustomerQuestion.noButtonClicked();
		LegalName.validlegalname("Mrs", "Delna", "Dr", "Press");
		Common.continueButtonClicked();
		MaritalStatus.maritalstatusselect("Married");
		Common.continueButtonClicked();
		DateOfBirth.dateOfBirth("20", "Mar", "1998");
		Common.continueButtonClicked();
		WhatsYourAddress.ValidWhatsYourAddressValues("2201", "EGLINTON AVE", "TORONTO", "ONTARIO","M1K2M1");
		Common.continueButtonClicked();
		Thread.sleep(2000);
		EmailAddress.ValidEmailAddress("test@test.com", "test@test.com");
		Common.continueButtonClicked();
	}
	
	@Then("^Verify \"([^\"]*)\" message should be on Mobile Phone Number screen$")
	public void verify_message_should_be_mobile_phone_number_screen(String dataPointer) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String testCaseID = Utility.getScenarioID();
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage01_Registration_ExpectedDa", testCaseID, dataPointer);
		 wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(headerTitle));
		 Assert.assertEquals(headerTitle.getText(), value,"Couldn't found expected header message");
	}
	
	@Then("^Verify \"([^\"]*)\" headertext should be on Mobile Phone Number screen$")
	public void verify_headertext_should_be_mobile_phone_number_screen(String dataPointer) throws Throwable {
		   // Write code here that turns the phrase above into concrete actions
				String testCaseID = Utility.getScenarioID();
				String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage01_Registration_ExpectedDa", testCaseID, dataPointer);
				wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(headerText));
				Assert.assertEquals(headerText.getText(), value,"Couldn't found expected header text message");
	}
	
	@Then("^Verify \"([^\"]*)\" footertext should be on Mobile Phone Number screen$")
	public void verify_footertext_should_be_mobile_phone_number_screen(String dataPointer) throws Throwable {
		   // Write code here that turns the phrase above into concrete actions
				String testCaseID = Utility.getScenarioID();
				String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage01_Registration_ExpectedDa", testCaseID, dataPointer);
				wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(footerText));
				Assert.assertEquals(footerText.getText(), value,"Couldn't found expected header text message");
	}
	
	@Then("^Verify Invalid \"([^\"]*)\" Mobile Phone Number on Mobile Phone Number screen$")
	public void verify_invalid_mobile_phone_number_on_mobile_phone_number_screen(String dataPointer) throws Throwable {
		   // Write code here that turns the phrase above into concrete actions
				String testCaseID = Utility.getScenarioID();
				String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage01_Registration_ExpectedDa", testCaseID, dataPointer);
				String MobilePhoneNumberText1=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage01_Registration_InputData", testCaseID, "Phone One");
				String MobilePhoneNumberText2=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage01_Registration_InputData", testCaseID, "Phone Two");
				String MobilePhoneNumberText3=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage01_Registration_InputData", testCaseID, "Phone Three");
				
				MobilePhoneNumber1.sendKeys(MobilePhoneNumberText1);
			    MobilePhoneNumber2.sendKeys(MobilePhoneNumberText2);
			    MobilePhoneNumber3.sendKeys(MobilePhoneNumberText3);
			    wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(inValidMobilePhoneNumber));
			    Assert.assertEquals(inValidMobilePhoneNumber.getText(), value,"Couldn't found expected header text message");
	}
	
	@When("^Back Button is clicked on Mobile Phone Number screen$")
	public void back_button_is_clicked_on_mobile_phone_number_screen() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    Common.backButtonClicked();
	}
	
	@Then("^'Whats your email address?' screen should be displayed.$")
	public void Whats_your_email_address_screen_should_be_displayed() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Assert.assertEquals(whatsyouremailaddresstitle.getText(), "What's your email address?", "Couldn't find the Whats your email address");
	}
	
	
	public static void ValidMobilePhoneNumber(String MobilePhoneNumberText1,String MobilePhoneNumberText2,String MobilePhoneNumberText3) throws InterruptedException {
		 QAFExtendedWebElement MobilePhoneNumber1= new QAFExtendedWebElement("ehome.mobilePhoneNumber.MobilePhoneNumber1");
		 QAFExtendedWebElement MobilePhoneNumber2= new QAFExtendedWebElement("ehome.mobilePhoneNumber.MobilePhoneNumber2");
		 QAFExtendedWebElement MobilePhoneNumber3= new QAFExtendedWebElement("ehome.mobilePhoneNumber.MobilePhoneNumber3");
		 MobilePhoneNumber1.sendKeys(MobilePhoneNumberText1);
		 MobilePhoneNumber2.sendKeys(MobilePhoneNumberText2);
		 MobilePhoneNumber3.sendKeys(MobilePhoneNumberText3);
	}
	
	@When("^Continue button is clicked on Mobile Phone Number screen after entering valid \"([^\"]*)\" , \"([^\"]*)\" and \"([^\"]*)\"$")
	public void Continue_button_is_clicked_on_mobile_phone_number_screen_after_entering_valid(String dataPointer1,String dataPointer2,String dataPointer3) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String testCaseID = Utility.getScenarioID();
		String MobilePhoneNumberText1=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage01_Registration_InputData", testCaseID, dataPointer1);
		String MobilePhoneNumberText2=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage01_Registration_InputData", testCaseID, dataPointer2);
		String MobilePhoneNumberText3=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage01_Registration_InputData", testCaseID, dataPointer3);
		ValidMobilePhoneNumber(MobilePhoneNumberText1,MobilePhoneNumberText2,MobilePhoneNumberText3);
		Thread.sleep(2000);
		Common.continueButtonClicked();
	}
	
	@Then("^'Enter the eHOME security code here' screen should be displayed$")
	public void Enter_the_ehome_security_code_here_screen_should_be_displayed() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		 wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(ehomeSecurityHeader));
		if(!ehomeSecurityHeader.isPresent())
			throw new AssertionError("Not navigated to EHome Security screen");
	}
}
