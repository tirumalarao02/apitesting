package com.scotiabank.ehome.ui.steps;

import java.util.List;

import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.qmetry.qaf.automation.step.QAFTestStepProvider;
import com.qmetry.qaf.automation.ui.WebDriverTestBase;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebDriver;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.quantum.java.pages.ScotiaQuantumReportListener;
import com.quantum.utility.Utils;
import com.quantum.utils.ConfigurationUtils;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

@QAFTestStepProvider
public class Debug {
	
	 private QAFExtendedWebDriver webDriver = null;
	    public Actions action = null;
	    public WebDriverWait wait=null;
	    //public FluentWait<WebDriver> fwait=null;

	    //Scenario: Type_Of_Rate_001
	    
	    @Given("^Customer should login and navigates to Stage 2 Type of Rate$")
	    public void CustomershouldloginandnavigatestoStage2TypeofRate() throws Throwable {
	        // Write code here that turns the phrase above into concrete actions
	        webDriver = new WebDriverTestBase().getDriver();
	        webDriver.get(ConfigurationUtils.getBaseBundle ().getPropertyValue ( "env.baseurl" ) );
	        
	    } 
	    
	    @Given("^Customer Should able to navigate to stageTwo \"([^\"]*)\"$")
	    public void customer_Should_able_to_navigate_to_stageTwo(String expectedTitle) throws Throwable {
	    	// Write code here that turns the phrase above into concrete actions 
	    	webDriver = new WebDriverTestBase().getDriver();
	    	System.out.println("Browser Capabilities : " + webDriver.getCapabilities().toString());
	        System.out.println("Driver : " + webDriver.getWindowHandle());
	        webDriver.get(ConfigurationUtils.getBaseBundle ().getPropertyValue ( "env.baseurl1" ) );
	        QAFExtendedWebElement continueBtn = new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div/div/div[3]/div/button");
	        continueBtn.click();
		    QAFExtendedWebElement pageTitle = new QAFExtendedWebElement("//*[@id='app']/div/div[1]/div[1]/section/div[2]/div/p");
		    Thread.sleep(5000);
		    Assert.assertEquals(pageTitle.getText(), expectedTitle,	"Title Mismatched");
		    System.out.println("Scenario ID: "+Utility.getScenarioID());
	    }
	    
	    @When("^Click on Manual Address button from StageTwo Address Screen and Verify page title \"([^\"]*)\"$")
	    public void click_on_Manual_Address_button_from_StageTwo_Address_Screen_and_Verify_page_title(String expectedTitle) throws Throwable {
	    	// Write code here that turns the phrase above into concrete actions
	    	QAFExtendedWebElement manualAddressLink = new QAFExtendedWebElement("//*[@id='app']/div/div[1]/div[1]/section/div[3]/div/div[2]/button/span");
	    	Thread.sleep(5000);
	    	manualAddressLink.click();
	    	QAFExtendedWebElement pageTitle = new QAFExtendedWebElement("//*[@id='app']/div/div[1]/div[1]/section/div[2]/div/p");
	    	Thread.sleep(5000);
	    	Assert.assertEquals(pageTitle.getText(), expectedTitle,	"Title Mismatched");
	    	System.out.println("Scenario ID: "+Utility.getScenarioID());
	    	
	    }
	    
	    @Given("^I am on Google Search Page$")
		public void I_am_on_Google_Search_Page() throws Throwable {
			new WebDriverTestBase().getDriver().get("https://www.google.com/");
			System.out.println("Scenario ID: "+Utility.getScenarioID());
		}
		@When("^I search for \"([^\"]*)\"$")
		public void I_search_for(String searchKey) throws Throwable {
			QAFExtendedWebElement searchBoxElement = new QAFExtendedWebElement("search.text.box");
			QAFExtendedWebElement searchBtnElement = new QAFExtendedWebElement("search.button");
			Thread.sleep(5000);
			searchBoxElement.clear();
			searchBoxElement.sendKeys(searchKey);
			Thread.sleep(5000);
			searchBtnElement.click();
			System.out.println("Scenario ID: "+Utility.getScenarioID());

		}
		@Then("^it should have \"([^\"]*)\" in search results$")
		public void it_should_have_in_search_results(String result) throws Throwable {
			QAFExtendedWebElement searchResultElement =
					new QAFExtendedWebElement("partialLink=" + result);
			Thread.sleep(5000);
			searchResultElement.verifyPresent(result);
			System.out.println("Scenario ID: "+Utility.getScenarioID());
		}

		@Then("^it should have following search results:$")
		public void it_should_have_all_in_search_results(List<String> results) throws Throwable{
			QAFExtendedWebElement searchResultElement;
			for (String result : results) {
				searchResultElement = new QAFExtendedWebElement("partialLink=" + result);
				Thread.sleep(5000);
				searchResultElement.verifyPresent(result);
				System.out.println("Scenario ID: "+Utility.getScenarioID());
			}
		}
		
		public static void main(String[] args) {
	    	System.out.println("Encrypted Password: "+Utils.encryptString("XXXXXXXXX"));
	    }

}
