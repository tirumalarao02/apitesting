package com.scotiabank.ehome.ui.steps.stage4;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.step.QAFTestStepProvider;
import com.qmetry.qaf.automation.ui.WebDriverTestBase;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebDriver;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.quantum.utils.ConfigurationUtils;
import com.scotiabank.ehome.ui.steps.Common;
import com.scotiabank.ehome.ui.steps.ExcelDataToDataTable;
import com.scotiabank.ehome.ui.steps.Utility;
import com.scotiabank.ehome.ui.steps.valueObjects.Tuple;
import com.scotiabank.ehome.ui.steps.valueObjects.TypeOfRateVO;
import com.thoughtworks.qdox.model.expression.Add;

import org.junit.runner.RunWith;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;

import cucumber.api.CucumberOptions;
import cucumber.api.DataTable;
import cucumber.api.PendingException;
import cucumber.api.Transform;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import cucumber.api.junit.Cucumber;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import static com.scotiabank.ehome.ui.steps.BusinessCalculations.*;
import static com.scotiabank.ehome.ui.steps.Utility.*;

import org.openqa.selenium.Keys;
@QAFTestStepProvider

public class PreviousEmployerDetails {
	public static WebDriverWait wait=Utility.getWait();
	String testCaseID = Utility.getScenarioID();
    
    @Given("^Customer should login and navigates to Previous Employer details$")
    public void customer_should_login_and_navigates_to_Previous_Employer_details() throws Throwable {
    	// Write code here that turns the phrase above into concrete actions
    	Utility.launchURL(ConfigurationUtils.getBaseBundle().getPropertyValue ("env.baseurl2"));
		Common.sessionBreakerContinueButtonClick();
        EmpStatus.employedButtonClicked();
        EmpType.commissionedSalesButtonClicked();
        String jobField=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage04_Employment_InputData", testCaseID, "Industry_JobTitle_Field_of_work");
        IndustryAndJobTitle.jobField(jobField);
        String jobTitle=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage04_Employment_InputData", testCaseID, "Industry_JobTitle_Job_Title");
        IndustryAndJobTitle.jobTitle(jobTitle);
        Common.continueButtonClicked();
        String employername=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage04_Employment_InputData", testCaseID, "Employer_Details_employername");
        EmployerDetails.employername(employername);
        String employerphone=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage04_Employment_InputData", testCaseID, "Employer_Details_employerphone");
        EmployerDetails.employerphone(employerphone);
        Common.continueButtonClicked();
        String address=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage04_Employment_InputData", testCaseID, "Employer_Address");
        EmpAddress.employeraddress(address);
        Common.continueButtonClicked();	
        String annualincomeSalary=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage04_Employment_InputData", testCaseID, "Employer_AnnualIncome_Salary");
        AnnualIncome.annualincomeSalary(annualincomeSalary);
        Common.continueButtonClicked();
        String year=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage04_Employment_InputData", testCaseID, "Employer_Duration_lessThan2Years_years");
		String month=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage04_Employment_InputData", testCaseID, "Employer_Duration_lessThan2Years_months");
		EmploymentDuration.employmentDuration(year, month);
        Common.continueButtonClicked();
        
	    
	}
	    
	// Previous_Employer _Details_TC-002
	@When("^Verify \"([^\"]*)\" message should be on the Previous Employer details screen$")
	public void verify_should_be_on_the_Previous_Employer_details_screen1(String dataPointer) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage04_Employment_ExpectedData", testCaseID, dataPointer);
		QAFExtendedWebElement headerMessage= new QAFExtendedWebElement("ehome.Header.Message1");
		Assert.assertEquals(headerMessage.getText(), value,"Couldn't found expected message text");
	    
	}

	@Then("^Verify \"([^\"]*)\" header text should be on the Previous Employer details screen$")
	public void verify_header_should_be_on_the_Previous_Employer_details_screen(String dataPointer) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions 
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage04_Employment_ExpectedData", testCaseID, dataPointer);
		QAFExtendedWebElement headertext= new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[1]/section/div/div[2]/div/p");
		Assert.assertEquals(headertext.getText(), value,"Couldn't found expected header text");
	    
	}
	// Previous_Employer _Details_TC-004

	@When("^Enter the \"([^\"]*)\" invalid Employer name in the Previous Employer details screen$")
	public void NegativeValues_Data(String dataPointer) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String col="InputValues";
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "CommonErrorMessages", dataPointer,col);
		QAFExtendedWebElement previousEmployerName= new QAFExtendedWebElement("ehome.previousEmployerDetails.employerName");
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(previousEmployerName));
		previousEmployerName.clear();
		previousEmployerName.sendKeys(value);
	    
	}

	@Then("^\"([^\"]*)\" should be displayed for name in the Previous Employer details screen$")
	public void error_message_should_be_displayed_in_the_Previous_Employer_details_screen(String dataPointer) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage04_Employment_ExpectedData", testCaseID, dataPointer);
		QAFExtendedWebElement previousEmployerNameErrorMessage= new QAFExtendedWebElement("ehome.previousEmployerDetails.errorMessage");
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(previousEmployerNameErrorMessage));
       Assert.assertEquals(previousEmployerNameErrorMessage.getText(), value,"Couldn't found expected header text");
	    
	}
	
	// Previous_Employer _Details_TC-005

	
	// Previous_Employer _Details_TC-006
	
	public static void previousEmployerName(String name) throws InterruptedException {
		QAFExtendedWebElement previousemploymentName= new QAFExtendedWebElement("ehome.previousEmployerDetails.employerName");
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(previousemploymentName));
		previousemploymentName.clear();
		previousemploymentName.sendKeys(name);
		 
		 }
	@When("^Enter the \"([^\"]*)\" valid Employer name in the Previous Employer details screen$")
	public void enter_the_valid_Employer_name_in_the_Previous_Employer_details_screen(String dataPointer) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage04_Employment_InputData", testCaseID, dataPointer);
		previousEmployerName(value);
	}

	@Then("^Green with a check mark should be displayed in the Previous Employer details screen$")
	public void green_with_a_check_mark_should_be_displayed_in_the_Previous_Employer_details_screen() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		QAFExtendedWebElement greenicon= new QAFExtendedWebElement("ehome.previousEmployerDetails.greenicon.name");
		if(!greenicon.isPresent()) {
			Assert.fail("Couldn't see the green check mark");
		}
	}
	public static void previousEmployerPhone(String Phone) throws InterruptedException {
		QAFExtendedWebElement previousemploymentphone= new QAFExtendedWebElement("ehome.previousEmployerDetails.employmentPhone");
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(previousemploymentphone));
		previousemploymentphone.clear();
		previousemploymentphone.sendKeys(Phone);
		 
		 }
	@When("^Enter the \"([^\"]*)\" valid Employer phone in the Previous Employer details screen$")
	public void enter_the_valid_Employer_phone_in_the_Previous_Employer_details_screen(String dataPointer) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage04_Employment_InputData", testCaseID, dataPointer);
		previousEmployerPhone(value);
	}

	@Then("^Green with a check mark should be displayed in the phone of Previous Employer details screen$")
	public void green_with_a_check_mark_should_be_displayed_in_the_phone_of_Previous_Employer_details_screen() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		QAFExtendedWebElement greenicon= new QAFExtendedWebElement("ehome.previousEmployerDetails.greenicon.phone");
		if(!greenicon.isPresent()) {
			Assert.fail("Couldn't see the green check mark");
		}
	}


	


}
