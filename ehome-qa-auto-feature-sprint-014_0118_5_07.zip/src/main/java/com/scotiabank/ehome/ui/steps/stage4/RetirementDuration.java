package com.scotiabank.ehome.ui.steps.stage4;
import com.qmetry.qaf.automation.step.QAFTestStepProvider;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.quantum.java.pages.ExtentReportHelper;
import com.quantum.utils.ConfigurationUtils;
import com.scotiabank.ehome.ui.steps.Common;
import com.scotiabank.ehome.ui.steps.CommonAppMethodsEmployment;
import com.scotiabank.ehome.ui.steps.CommonApplicationMethods;
import com.scotiabank.ehome.ui.steps.Utility;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.support.ui.WebDriverWait;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;

import java.util.Map;
import java.util.concurrent.TimeUnit;
import static com.scotiabank.ehome.ui.steps.Utility.*;


@QAFTestStepProvider

public class RetirementDuration {
	  public static WebDriverWait wait=Utility.getWait();
	  static String curDir = System.getProperty("user.dir");
	  static String strfullPathToFile = curDir + "\\src\\main\\resources\\data\\eHomeTestData.xlsx"; // File Path
		
	  static String sheetStage04_InputData ="Stage04_Employment_InputData";
	  static String sheetStage04_ExpectedData ="Stage04_Employment_ExpectedData";
	  //String strtestCaseID = "Retirement-Duration-TC-005";
	  String strtestCaseID = Utility.getScenarioID();

	
	@When("^Customer Selects 'Retired' on 'Employment status' Screen$")
	public void Customer_Selects_Retired_and_Click_on_Continue_on_Employment_status_Screen() throws Throwable {
		Map<String, String> Stage04_InputData =  Utility.readTestData(strfullPathToFile, sheetStage04_InputData,strtestCaseID);
		String strCurrentEmpStatus	= Stage04_InputData.get("Empmt_Status"); 	// Retrieve "Current Employment status" from Excel
		CommonAppMethodsEmployment.SelectEmpStatus(strCurrentEmpStatus);
		Thread.sleep(1000);
		
		}
		
	@Then("^Verify 'Retirement Duration' Screen$")
	public void Verify_Retirement_Duration_Screen() throws Throwable {
		Map<String, String> Stage04_ExpectedData =  Utility.readTestData(strfullPathToFile, sheetStage04_ExpectedData,strtestCaseID);
			String strRetirDuration_ExpectedTitle	= Stage04_ExpectedData.get("Retirement_Duration_Title"); 	// Retrieve "Current Employment status" from Excel
			//.//*[contains(text(),'How long have you been retired?')]
			Thread.sleep(1000);
			QAFExtendedWebElement strRetirDuration_ActualTitle= new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[1]/section/div[2]/div/p");
    		if (strRetirDuration_ExpectedTitle.contentEquals(strRetirDuration_ActualTitle.getText())) {
    			ExtentReportHelper.StepPass(strRetirDuration_ExpectedTitle + " Screen# is displayed.");
    		}
    		else
    		{
    			Assert.assertEquals(strRetirDuration_ActualTitle.getText(), strRetirDuration_ExpectedTitle,"'Retirement Duration' Screen is NOT as Expected.");
    		}
 		}
 
	@Then("^Verify 'Employment Status' Screen when Click on 'Back' button$")
    		public void Verify_Employment_Status_Screen_when_Click_on_Back_button() throws Throwable {
    			Map<String, String> Stage04_ExpectedData =  Utility.readTestData(strfullPathToFile, sheetStage04_ExpectedData,strtestCaseID);
    				String strEmpStatus_ExpectedTitle	= Stage04_ExpectedData.get("Emp_Status_Screen_Title"); 	// Retrieve "Current Employment status" from Excel
    				
    				Utility.clickObject("//*[@id=\"app\"]/div/div[1]/div[2]/button[1]/span", "Back Button in Retirement Duration");
    				Thread.sleep(2000);
    				
    				QAFExtendedWebElement strEmpStatus_ActualTitle= new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[1]/section/div[2]/div/p");
    	    		if (strEmpStatus_ExpectedTitle.contentEquals(strEmpStatus_ActualTitle.getText())) {
    	    			ExtentReportHelper.StepPass(strEmpStatus_ExpectedTitle + " Screen# is displayed.");
    	    		}
    	    		else
    	    		{
    	    			Assert.assertEquals(strEmpStatus_ActualTitle.getText(), strEmpStatus_ExpectedTitle,"'Employment Status' Screen is NOT as Expected.");
    	    		}	
				}
	
	@When("^Select 'Retirement Duration' and 'Continue' from 'Retirement Duration' Screen$")
	public void Select_Retirement_Duration_and_Continue_from_Retirement_Duration_Screen() throws Throwable {
		Map<String, String> Stage04_InputData =  Utility.readTestData(strfullPathToFile, sheetStage04_InputData,strtestCaseID);
		
		String strDurationYear=  Stage04_InputData.get("Years");
		String strDurationMonth=  Stage04_InputData.get("Months");
		if (!(Utility.getDriver().findElement("ehome.employmentDuration.years").isPresent()))
		{
			Common.continueButtonClicked();
		}
				if (strDurationYear != "") {
				CommonApplicationMethods.selectValuefromDropDownListBox("ehome.employmentDuration.years", strDurationYear);
	 		Thread.sleep(250);
			}
			if (strDurationMonth != "") {
				CommonApplicationMethods.selectValuefromDropDownListBox("ehome.employmentDuration.months", strDurationMonth);
	 		Thread.sleep(250);
			}
			Thread.sleep(500);
			Common.continueButtonClicked();
			Thread.sleep(1000);
		}

	
	@Then("^Verify 'Employment Sources of Income' Screen$")
	public void Verify_Employment_Sources_Of_Income_Screen() throws Throwable {
		Map<String, String> Stage04_ExpectedData =  Utility.readTestData(strfullPathToFile, sheetStage04_ExpectedData,strtestCaseID);
			String strEmpSrcsOfIncome_ExpectedTitle	= Stage04_ExpectedData.get("Emplmt_Srcs_Of_Income_Title");
			
			QAFExtendedWebElement strEmpSrcsOfIncome_ActualTitle= new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[1]/section/div[2]/div/p");
    		if (strEmpSrcsOfIncome_ExpectedTitle.contentEquals(strEmpSrcsOfIncome_ActualTitle.getText())) {
    			ExtentReportHelper.StepPass(strEmpSrcsOfIncome_ExpectedTitle + " Screen# is displayed.");
    		}
    		else
    		{
    			Assert.assertEquals(strEmpSrcsOfIncome_ActualTitle.getText(), strEmpSrcsOfIncome_ExpectedTitle,"'Employment Sources of Inocme' Screen is NOT as Expected.");
    		}	
		}
	
	
	@Then("^Verify 'Error message' in 'Retirement Duration' Screen when select 'Continue' without giving 'Retirement Duration'$")
	public void Verify_Error_message_in_Retirement_Duration_Screen_when_select_Continue_without_giving_Retirement_Duration() throws Throwable {
		Map<String, String> Stage04_ExpectedData =  Utility.readTestData(strfullPathToFile, sheetStage04_ExpectedData,strtestCaseID);
			String strNoYrMonth_ExpectedErrMsg	= Stage04_ExpectedData.get("Retirement_Duration_Mandatory_ErrMsg");
			
			Common.continueButtonClicked();
			QAFExtendedWebElement strNoYrMonth_ActualErrMsg= new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[1]/section/div[2]/div[2]/div/div/div[2]/p");
    		if (strNoYrMonth_ExpectedErrMsg.contentEquals(strNoYrMonth_ActualErrMsg.getText())) {
    			ExtentReportHelper.StepPass(strNoYrMonth_ExpectedErrMsg + " Error Message # is displayed.");
    		}
    		else
    		{
    			Assert.assertEquals(strNoYrMonth_ActualErrMsg.getText(), strNoYrMonth_ExpectedErrMsg,"Error Message is NOT as Expected.");
    		}	
	
			}
	
	
	@Then("^Verify 'Error message' in 'Retirement Duration' Screen when select Zero 'Retirement Duration'$")
	public void Verify_Error_message_in_Retirement_Duration_Screen_when_select_Zero_Retirement_Duration() throws Throwable {
		Map<String, String> Stage04_ExpectedData =  Utility.readTestData(strfullPathToFile, sheetStage04_ExpectedData,strtestCaseID);
			String strNoYrMonth_ExpectedErrMsg	= Stage04_ExpectedData.get("Retirement_Duration_Mandatory_ErrMsg");
			
			QAFExtendedWebElement strNoYrMonth_ActualErrMsg= new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[1]/section/div[2]/div[2]/div/div/div[2]/p");
    		if (strNoYrMonth_ExpectedErrMsg.contentEquals(strNoYrMonth_ActualErrMsg.getText())) {
    			ExtentReportHelper.StepPass(strNoYrMonth_ExpectedErrMsg + " Error Message # is displayed.");
    		}
    		else
    		{
    			Assert.assertEquals(strNoYrMonth_ActualErrMsg.getText(), strNoYrMonth_ExpectedErrMsg,"Error Message is NOT as Expected.");
    		}	
	
	}
	
}