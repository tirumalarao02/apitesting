package com.scotiabank.ehome.ui.steps.coApp;
import com.qmetry.qaf.automation.step.QAFTestStepProvider;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.quantum.utils.ConfigurationUtils;
import com.scotiabank.ehome.ui.steps.Common;
import com.scotiabank.ehome.ui.steps.Utility;
import com.scotiabank.ehome.ui.steps.stage4.EmploymentDuration;
import com.scotiabank.ehome.ui.steps.stage4.PreviousEmployemntDuration;
import com.scotiabank.ehome.ui.steps.stage4.PreviousEmployerDetails;

import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.support.ui.WebDriverWait;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import java.util.concurrent.TimeUnit;
import static com.scotiabank.ehome.ui.steps.Utility.*;

@QAFTestStepProvider
public class CoAppPreviousEmpDuration {
	public static WebDriverWait wait=Utility.getWait();	
	  String testCaseID = Utility.getScenarioID();
	  
	  @Given("^Customer should login and navigates to CoApp previous employment duration screen$")
	  public void customer_should_login_and_navigates_to_CoApp_previous_employment_duration_screen() throws Throwable {
	      // Write code here that turns the phrase above into concrete actions
//			 String strtestCaseID = Utility.getScenarioID();
//		  if (strtestCaseID.contains("CoApp"))
//		  {
//			  Common.TraverseToNewHomeSectionBreaker();
//			  Thread.sleep(10000);
//			  Common.TraverseFromNewHomeToRateSectionBreaker(strtestCaseID,"Co-App_InputData");
//			  Common.TraverseRateSectionToEmploymentSectionBreaker();
//			  Common.TraverseFromEmploymentSectionToLandOnCoApplicantPage();
//			  CoAppIntro.startSectionButtonClicked();
//		  }
		  Utility.launchURL(ConfigurationUtils.getBaseBundle().getPropertyValue ("env.baseurl3"));
			CoAppIntro.startSectionButtonClicked();
			CoAppEmpStatus.employedButtonClicked();
			CoAppEmpType.commissionedSalesButtonClicked();
			  Thread.sleep(3000);
			String jobField=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Co-App_ExpectedData", testCaseID, "Industry_JobTitle_Field_of_work");
			 CoAppIndustryJobTitle.jobField(jobField);
			  Thread.sleep(3000);
			String jobTitle=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Co-App_ExpectedData", testCaseID, "Industry_JobTitle_Job_Title");
			 CoAppIndustryJobTitle.jobTitle(jobTitle);
			  Thread.sleep(3000);
			String occupationType=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Co-App_ExpectedData", testCaseID, "Industry_JobTitle_Occupation_Type");
			 CoAppIndustryJobTitle.occupationType(occupationType);
			  Thread.sleep(3000);
			Common.continueButtonClicked();
			String employername=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Co-App_InputData", testCaseID, "Employer_Details_employername");
			CoAppEmployerDetails.employername(employername);
			String employerphone=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Co-App_InputData", testCaseID, "Employer_Details_employerphone");
			CoAppEmployerDetails.employerphone(employerphone);	
			 Thread.sleep(3000);
			Common.continueButtonClicked();
			String address=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Co-App_InputData", testCaseID, "Employer_Address");
			CoAppEmployerAddress.employeraddress(address);
			Thread.sleep(3000);
			Common.continueButtonClicked();
			CoAppAnnualIncome.annualincomeSalary("5000");
			Thread.sleep(3000);
			Common.continueButtonClicked();
			Thread.sleep(30000);
			String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Co-App_InputData", testCaseID, "Employer_Duration_lessThan2Years_years");
			String value1=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Co-App_InputData", testCaseID, "Employer_Duration_lessThan2Years_months");
			EmploymentDuration.employmentDuration("1 year", "0 months"); 
			Thread.sleep(3000);
			Common.continueButtonClicked();
			String Previosemployername=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Co-App_InputData", testCaseID, "Employer_PreviosDetails_employername");
			PreviousEmployerDetails.previousEmployerName(Previosemployername);
			Thread.sleep(3000);
			Common.continueButtonClicked();
	  }
	  
	  @When("^Verify \"([^\"]*)\" should be on the CoApp previous employment duration screen$")
	  public void verify_should_be_on_the_CoApp_previous_employment_duration_screen(String dataPointer) throws Throwable {
	      // Write code here that turns the phrase above into concrete actions
		  String valueRaw=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Co-App_ExpectedData", testCaseID, dataPointer);
			String value = Utility.messageFormatName(valueRaw, Common.coApplicantFirstName);
			QAFExtendedWebElement headerMessage= new QAFExtendedWebElement("ehome.CoApp.HeaderMessage");
			 wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(headerMessage));
			Assert.assertEquals(headerMessage.getText(), value,"Couldn't found expected header text");
	      
	  }

	  @Then("^Verify \"([^\"]*)\" headertext should be on the CoApp previous employment duration screen$")
	  public void verify_headtext_should_be_on_the_CoApp_previous_employment_duration_screen(String dataPointer) throws Throwable {
	      // Write code here that turns the phrase above into concrete actions
		  String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Co-App_ExpectedData", testCaseID, dataPointer);
			Assert.assertEquals(Common.headertext(), value,"Couldn't found expected header text");
	  }

	  @When("^Enter \"([^\"]*)\" years and \"([^\"]*)\" months in CoApp previous employment duration screen$")
	  public void enter_years_and_months_in_CoApp_previous_employment_duration_screen(String dataPointer, String dataPointer1) throws Throwable {
	      // Write code here that turns the phrase above into concrete actions
		  String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Co-App_InputData", testCaseID, dataPointer);
			String value1=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Co-App_InputData", testCaseID, dataPointer1);
			PreviousEmployemntDuration.previousEmploymentDuration(value,value1);
	      
	  }
}
