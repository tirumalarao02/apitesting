package com.scotiabank.ehome.ui.steps.coApp;

import com.qmetry.qaf.automation.step.QAFTestStepProvider;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.quantum.utils.ConfigurationUtils;
import com.scotiabank.ehome.ui.steps.Common;
import com.scotiabank.ehome.ui.steps.Utility;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.support.ui.WebDriverWait;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import java.util.concurrent.TimeUnit;
import static com.scotiabank.ehome.ui.steps.Utility.*;

@QAFTestStepProvider

public class CoAppIndustryJobTitle {
	public static WebDriverWait wait=Utility.getWait();	
	  String testCaseID = Utility.getScenarioID();
	@Given("^Customer should login and navigates to CoApp Industry and Job Title$")
	public void customer_should_login_and_navigates_to_CoApp_Industry_and_Job_Title() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
//		 String strtestCaseID = Utility.getScenarioID();
//		  if (strtestCaseID.contains("CoApp"))
//		  {
//			  Common.TraverseToNewHomeSectionBreaker();
//			  Thread.sleep(10000);
//			  Common.TraverseFromNewHomeToRateSectionBreaker(strtestCaseID,"Co-App_InputData");
//			  Common.TraverseRateSectionToEmploymentSectionBreaker();
//			  Common.TraverseFromEmploymentSectionToLandOnCoApplicantPage();
//			  CoAppIntro.startSectionButtonClicked();
//		  }
		Utility.launchURL(ConfigurationUtils.getBaseBundle().getPropertyValue ("env.baseurl3"));
		CoAppIntro.startSectionButtonClicked();
		CoAppEmpStatus.employedButtonClicked();
		CoAppEmpType.commissionedSalesButtonClicked();
	   
	}

	

	@When("^Verify \"([^\"]*)\" should be on the CoApp Industry and Job Title screen$")
	public void verify_should_be_on_the_CoApp_Industry_and_Job_Title_screen(String dataPointer) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Co-App_ExpectedData", testCaseID, dataPointer);
		QAFExtendedWebElement headerMessage= new QAFExtendedWebElement("ehome.CoAppEmpType.HeaderMessage");
		 wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(headerMessage));
		Assert.assertEquals(headerMessage.getText(), value,"Couldn't found expected header text");
	   
	}

	@Then("^Verify \"([^\"]*)\" header should be on the CoApp Industry and Job Title screen$")
	public void verify_header_should_be_on_the_CoApp_Industry_and_Job_Title_screen(String dataPointer) throws Throwable {
	   // Write code here that turns the phrase above into concrete actions
		Thread.sleep(3000);
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Co-App_ExpectedData", testCaseID, dataPointer);
		System.out.println("testCaseID==========="+testCaseID);
		System.out.println("dataPointer==========="+dataPointer);
		System.out.println("value==========="+value);
		Assert.assertEquals(Common.headertext(), value,"Couldn't found expected header text");
	}

	@When("^Check all the elements are present in the field of work in CoApp Industry and Job Title screen$")
	public void check_all_the_elements_are_present_in_the_field_of_work_in_CoApp_Industry_and_Job_Title_screen() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		
	   
	}


	public static void jobField(String field) {
    	QAFExtendedWebElement jobField= new QAFExtendedWebElement("ehome.industryAndJObTitle.jobField");
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(jobField));
		Select dropdown = new Select(jobField);
        dropdown.selectByValue(field);
   	 }
    

	@When("^Click on the \"([^\"]*)\" dop down and select one in CoApp Industry and Job field screen$")
	public void click_on_the_dop_down_and_select_one_in_CoApp_Industry_and_Job_field_screen(String dataPointer) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Co-App_ExpectedData", testCaseID, dataPointer);
    	jobField(value);
	   
	}
	public static void jobTitle(String title) {
    	QAFExtendedWebElement jobTitle= new QAFExtendedWebElement("ehome.industryAndJObTitle.jobTitle");
        wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(jobTitle));
       Select dropdown2 = new Select(jobTitle);
        dropdown2.selectByValue(title);
   	 } 

	@Then("^Click on the \"([^\"]*)\" dop down and select one in CoApp Industry and Job Title screen$")
	public void click_on_the_dop_down_and_select_one_in_CoApp_Industry_and_Job_Title_screen(String dataPointer) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Co-App_ExpectedData", testCaseID, dataPointer);
    	Thread.sleep(3000);
    	 jobTitle(value);
	   
	}
	public static void occupationType(String type) {
		QAFExtendedWebElement occupationType= new QAFExtendedWebElement("ehome.industryAndJObTitle.OccupationType");
		occupationType.click();
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(occupationType));
		Select dropdown = new Select(occupationType);
        dropdown.selectByVisibleText(type);
   	 } 
	
	@Then("^Click on the \"([^\"]*)\" dop down and select one in CoApp Industry and Ocupation Type screen$")
	public void click_on_the_dop_down_and_select_one_in_CoApp_Industry_and_Ocupation_Type_screen(String dataPointer) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Co-App_ExpectedData", testCaseID, dataPointer);
		Thread.sleep(3000);
    	occupationType(value);
    	Thread.sleep(3000);
    	Common.continueButtonClicked();
	   
	}

	

	

	


}
