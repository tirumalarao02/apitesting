package com.scotiabank.ehome.ui.steps.stage4;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.step.QAFTestStepProvider;
import com.qmetry.qaf.automation.ui.WebDriverTestBase;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebDriver;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.quantum.utils.ConfigurationUtils;
import com.scotiabank.ehome.ui.steps.Common;
import com.scotiabank.ehome.ui.steps.ExcelDataToDataTable;
import com.scotiabank.ehome.ui.steps.Utility;
import com.scotiabank.ehome.ui.steps.valueObjects.Tuple;
import com.scotiabank.ehome.ui.steps.valueObjects.TypeOfRateVO;
import com.thoughtworks.qdox.model.expression.Add;

import org.junit.runner.RunWith;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;

import cucumber.api.CucumberOptions;
import cucumber.api.DataTable;
import cucumber.api.PendingException;
import cucumber.api.Transform;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import cucumber.api.junit.Cucumber;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import static com.scotiabank.ehome.ui.steps.BusinessCalculations.*;
import static com.scotiabank.ehome.ui.steps.Utility.*;

import org.openqa.selenium.Keys;
@QAFTestStepProvider

public class IndustryAndJobTitle {
	 public static WebDriverWait wait=Utility.getWait();
	  String testCaseID = Utility.getScenarioID();
    static String curDir = System.getProperty("user.dir");
    static String strfullPathToFile = curDir + "\\src\\main\\resources\\data\\eHomeTestData.xlsx"; // File Path
   
 //   static String  strfullPathToFile = "C:/MyWorkPlace/eclipse-workspace/eHomeDataPointer.xlsx";
    static String  strCommonObjects = "CommonObjects";
    static String  strJobandTitleSheet = "JobandTitle";
    public IndustryAndJobTitle() {
    	
    }
    @Given("^Customer should login and navigates to Industry and Job Title$")
    public void customer_should_login_and_navigates_to_Industry_and_Job_Title() throws Throwable {
    	// Write code here that turns the phrase above into concrete actions
    	Utility.launchURL(ConfigurationUtils.getBaseBundle().getPropertyValue ("env.baseurl2"));
    			Common.sessionBreakerContinueButtonClick();
    	        EmpStatus.employedButtonClicked();
    	        EmpType.commissionedSalesButtonClicked();
        
    }

    //Employment_Status_TC-002

    @When("^Verify \"([^\"]*)\" should be on the Industry and Job Title screen$")
    public void verify_should_be_on_the_Industry_and_Job_Title_screen1(String dataPointer) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage04_Employment_ExpectedData", testCaseID, dataPointer);
		Assert.assertEquals(Common.headerMessage(), value,"Couldn't found expected header text");
        
        
    }

    @Then("^Verify \"([^\"]*)\" header should be on the Industry and Job Title screen$")
    public void verify_header_should_be_on_the_Industry_and_Job_Title_screen(String dataPointer) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage04_Employment_ExpectedData", testCaseID, dataPointer);
    	Assert.assertEquals(Common.headertext(), value,"Couldn't found expected header text");
    }
    //Employment_Status_TC-003

    @When("^Check all the elements are present in the field of work in Industry and Job Title screen$")
    public void Check_all_the_elements_are_present_in_the_field_of_work_in_Industry_and_Job_Title_screen() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	
    	Map<String,List<String>> vals = Utility.readColumnDataFromExcel(strfullPathToFile, strJobandTitleSheet);
    	QAFExtendedWebElement element = new QAFExtendedWebElement("ehome.industryAndJObTitle.jobField");
    	Select select = new Select(element);
    	//Checking if all the elements are present in the field of work
    	List<WebElement> optionsInSelect = select.getOptions();
    	vals.keySet().stream().forEach(string -> {
    		System.out.println("Testing for sttr...:"+string);
    		Assert.assertEquals(optionsInSelect.stream().anyMatch(webElement -> {
    			return  webElement.getAttribute("value").equals(string);
    		}),true,string+" Job Field is Not Present");
    	});
    	
    	
    }

    @Then("^Check all the elements are present in the job title with restpect to field of work in Industry and Job Title screen$")
    public void Check_all_the_elements_are_present_in_the_job_title_with_restpect_to_field_of_work_in_Industry_and_Job_Title_screen() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	Map<String,List<String>> vals = Utility.readColumnDataFromExcel(strfullPathToFile, strJobandTitleSheet);
    	QAFExtendedWebElement element = new QAFExtendedWebElement("ehome.industryAndJObTitle.jobField");
    	Select select = new Select(element);
    	//Checking if all the elements are present in the field of work
    	List<WebElement> optionsInSelect = select.getOptions();
    	optionsInSelect.stream().forEach(webElement -> {
    		try {
    			String jobFieldSelected = webElement.getAttribute("value");
    			select.selectByValue(jobFieldSelected);
    			QAFExtendedWebElement elementJT = new QAFExtendedWebElement("ehome.industryAndJObTitle.jobTitle");
    			wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(elementJT));
    			Select selectJT = new Select(elementJT);
    			List<WebElement> optionsInJT = selectJT.getOptions();
    			List<String> liJobFields = vals.get(jobFieldSelected);
    			liJobFields.stream().forEach(stringEx -> {
    				boolean present = optionsInJT.stream().anyMatch(webElementOp -> webElementOp.getAttribute("value").equals(stringEx));
    				Assert.assertEquals(present, true,stringEx+ " JobTitle is not present");
    			});
    		}catch (Exception e) {
				// TODO: handle exception
    			e.printStackTrace();
			}
    		
    	});
    }

   

  //Employment_Status_TC-005
    public static void jobField(String field) {
    	QAFExtendedWebElement jobField= new QAFExtendedWebElement("ehome.industryAndJObTitle.jobField");
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(jobField));
		Select dropdown = new Select(jobField);
        dropdown.selectByValue(field);
   	 }
    
    @When("^Click on the \"([^\"]*)\" dop down and select one in Industry and Job field screen$")
    public void click_on_the_field_of_work_dop_down_and_select_one_in_Industry_and_Job_field_screen(String dataPointer) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	//String value = Utility.getLabelValueForDataPointer(industryAndJobTitleDataset, dataPointer);
    	String testCaseID = Utility.getScenarioID();
    	String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage04_Employment_InputData", testCaseID, dataPointer);
    	jobField(value);
    }
    public static void jobTitle(String title) {
    	QAFExtendedWebElement jobTitle= new QAFExtendedWebElement("ehome.industryAndJObTitle.jobTitle");
        wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(jobTitle));
       Select dropdown2 = new Select(jobTitle);
        dropdown2.selectByValue(title);
   	 } 
      
    @Then("^Click on the \"([^\"]*)\" dop down and select one in Industry and Job Title screen$")
    public void click_on_the_job_title_dop_down_and_select_one_in_Industry_and_Job_Title_screen(String dataPointer) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	//String value = Utility.getLabelValueForDataPointer(industryAndJobTitleDataset, dataPointer);
    	String testCaseID = Utility.getScenarioID();
    	String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage04_Employment_InputData", testCaseID, dataPointer);
    	Thread.sleep(3000);
    	 jobTitle(value);
    }

    

    @Then("^It should navigate to employer details screen$")
    public void it_should_navigate_to_employer_details_screen() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        
    }

}
