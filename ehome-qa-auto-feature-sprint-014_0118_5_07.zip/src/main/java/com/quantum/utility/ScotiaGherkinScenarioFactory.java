package com.quantum.utility;

import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.step.client.ScenarioFactory;
import com.qmetry.qaf.automation.step.client.ScenarioFileParser;
import com.qmetry.qaf.automation.step.client.gherkin.GherkinFileParser;
import java.util.Arrays;
import static com.quantum.config.SystemProperties.*;
import static com.quantum.config.SystemProperties.IMPORTED_SCENARIO_DIRECTORY;

public class ScotiaGherkinScenarioFactory extends ScenarioFactory {
    public ScotiaGherkinScenarioFactory() {

        super(Arrays.asList("feature"));

        try {

            if (ConfigurationManager.getBundle().getString("xray.features.jenkins.cleanup", "").contains("true"))
            {
                Utils.featureFilesCleanup();
            }

            if (ConfigurationManager.getBundle().getString("xray.import.features", "").contains("true") && !(ConfigurationManager.getBundle().getString("xray.user.name", "").contains("username")))
            {
                Utils.importCucumberFeatureFilesToJIRAUsingHTTPClient(JIRA_USERNAME, JIRA_PASSWORD, JIRA_ROOT_URL, PROJECT_KEYS, ConfigurationManager.getBundle().getString("xray.feature.files.loc", ""));
                System.out.println("import done");
            }
            else if (ConfigurationManager.getBundle().getString("xray.import.features", "").contains("true") && (ConfigurationManager.getBundle().getString("xray.user.name", "").contains("username")))
            {
                System.out.println("Please check the user credentials");
            }

            //Utils.createFile(IMPORTED_SCENARIO_DIRECTORY, FEATURE_FILE_NAME);
            Thread.sleep(10000);
            if (ConfigurationManager.getBundle().getString("xray.download.feature.file", "").contains("true") && !(ConfigurationManager.getBundle().getString("xray.user.name", "").contains("username")))
            {
                Utils.importTestsFromJIRAUsingHTTPClient(JIRA_USERNAME, JIRA_PASSWORD, JIRA_ROOT_URL, JIRA_ISSUE_KEYS, IMPORTED_SCENARIO_DIRECTORY, FEATURE_FILE_NAME);
            }
            else if (ConfigurationManager.getBundle().getString("xray.download.feature.file", "").contains("true") && (ConfigurationManager.getBundle().getString("xray.user.name", "").contains("username")))
            {
                System.out.println("Please check the user credentials");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    protected ScenarioFileParser getParser() {
        return new GherkinFileParser();
    }

}
