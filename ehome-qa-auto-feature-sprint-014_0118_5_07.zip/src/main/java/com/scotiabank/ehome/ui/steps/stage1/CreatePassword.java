package com.scotiabank.ehome.ui.steps.stage1;

import static com.scotiabank.ehome.ui.steps.Utility.getScreenDataset;

import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.qmetry.qaf.automation.step.QAFTestStepProvider;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebDriver;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.quantum.utils.ConfigurationUtils;
import com.scotiabank.ehome.ui.steps.Common;
import com.scotiabank.ehome.ui.steps.Utility;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

@QAFTestStepProvider
public class CreatePassword {
	private QAFExtendedWebDriver webDriver = Utility.getDriver();
    public Actions action = null;
    public static WebDriverWait wait=Utility.getWait();	
    
    QAFExtendedWebElement createPasswordTitle= new QAFExtendedWebElement("ehome.createPassword.Title");
    QAFExtendedWebElement createPasswordHeader= new QAFExtendedWebElement("ehome.createPassword.Header");
    QAFExtendedWebElement createPasswordText= new QAFExtendedWebElement("ehome.createPassword.createPasswordText");
    QAFExtendedWebElement confirmPasswordText= new QAFExtendedWebElement("ehome.createPassword.confirmPasswordText");
 
    QAFExtendedWebElement createPasswordCharacters= new QAFExtendedWebElement("ehome.createPassword.createPasswordCharacters");
    QAFExtendedWebElement createPasswordNumber= new QAFExtendedWebElement("ehome.createPassword.createPasswordNumber");
    QAFExtendedWebElement createPasswordUpperCase= new QAFExtendedWebElement("ehome.createPassword.createPasswordUpperCase");
    QAFExtendedWebElement createPasswordSpecialCharacters= new QAFExtendedWebElement("ehome.createPassword.createPasswordSpecialCharacters");
    QAFExtendedWebElement createPasswordSameAsUserName= new QAFExtendedWebElement("ehome.createPassword.createPasswordSameAsUserName");
    QAFExtendedWebElement timeToCreateUserNameHeaderText= new QAFExtendedWebElement("ehome.timeToCreateUserName.headerText");
    QAFExtendedWebElement NowtellusaboutyournewhomeText= new QAFExtendedWebElement("ehome.Nowtellusaboutyournewhome.headerText");
    QAFExtendedWebElement Passworddoesntmatch= new QAFExtendedWebElement("ehome.createPassword.Passworddoesntmatch");
    
    @Given("^Customer should login and navigates to Time To Create Password Screen$")
    public void customer_should_login_and_navigates_to_Time_To_Create_Password_Screen() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        
    	Utility.launchURL(ConfigurationUtils.getBaseBundle().getPropertyValue ("env.baseurl0"));
		Welcome.viewOurPrivacyAgreementButtonClicked();
		PrivacyAgreement.acceptAndContinuetButtonClicked();
		SOLCustomerQuestion.triageQuestionsButtonClicked();
		SOLCustomerQuestion.noButtonClicked();
		LegalName.validlegalname("Mrs", "Delna", "Dr", "Press");
		Common.continueButtonClicked();
		MaritalStatus.maritalstatusselect("Married");
		Common.continueButtonClicked();
		DateOfBirth.dateOfBirth("20", "Mar", "1998");
		Common.continueButtonClicked();
		WhatsYourAddress.ValidWhatsYourAddressValues("2201", "EGLINTON AVE", "TORONTO", "ONTARIO","M1K2M1");
		Common.continueButtonClicked();
		Thread.sleep(4000);
		EmailAddress.ValidEmailAddress("test@test.com", "test@test.com");
		Common.continueButtonClicked();
		Thread.sleep(4000);
		MobilePhoneNumber.ValidMobilePhoneNumber("616", "237", "2324");
		Common.continueButtonClicked();
		Thread.sleep(4000);
		OTPScreen.ValidOTPCode("1", "1", "1", "1", "1", "1");
		Thread.sleep(4000);
		Common.backButtonClicked();//THIS SHOULD BE REMOVED
	    Thread.sleep(4000);//THIS SHOULD BE REMOVED
	    Common.continueButtonClicked();//THIS SHOULD BE REMOVED
	    Common.continueButtonClicked();//THIS SHOULD BE REMOVED
	    Thread.sleep(6000);//THIS SHOULD BE REMOVED
	    TimeToCreateUserName.ValidUserName("TesterTest1");
	    Common.continueButtonClicked();
	    Thread.sleep(4000);//THIS SHOULD BE REMOVED
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(createPasswordTitle));
    }
    
    @Then("^Verify \"([^\"]*)\" message should be on Time To Create Password Screen$")
    public void verify_message_should_be_on_Time_To_Create_Password_Screen(String dataPointer) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
		String testCaseID = Utility.getScenarioID();
		String createPasswordTitleText=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage01_Registration_ExpectedDa", testCaseID, dataPointer);
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(createPasswordTitle));
		Assert.assertEquals(createPasswordTitle.getText(), createPasswordTitleText,"Couldn't find expected header message");
    }

    @Then("^Verify \"([^\"]*)\" headertext should be on Time To Create Password Screen$")
    public void verify_headertext_should_be_on_Time_To_Create_Password_Screen(String dataPointer) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	String testCaseID = Utility.getScenarioID();
		String createPasswordHeaderTxt=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage01_Registration_ExpectedDa", testCaseID, dataPointer);
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(createPasswordHeader));
		Assert.assertEquals(createPasswordHeader.getText(), createPasswordHeaderTxt,"Couldn't find expected header Text message");
    }


    @Then("^Verify \"([^\"]*)\" Password should be on Time To Create Password Screen$")
    public void verify_Password_should_be_on_Time_To_Create_Password_Screen(String dataPointer) throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    	String testCaseID = Utility.getScenarioID();
		String PasswordTxt=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage01_Registration_ExpectedDa", testCaseID, dataPointer);
		Assert.assertEquals(createPasswordText.getAttribute("placeholder"), PasswordTxt, "Couldn't find the Password field");
    }

    @Then("^Verify \"([^\"]*)\" Confirm Password should be on Time To Create Password Screen$")
    public void verify_Confirm_Password_should_be_on_Time_To_Create_Password_Screen(String dataPointer) throws Throwable {
    	// Write code here that turns the phrase above into concrete actions
    	String testCaseID = Utility.getScenarioID();
		String ConfirmPasswordTxt=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage01_Registration_ExpectedDa", testCaseID, dataPointer);
		Assert.assertEquals(confirmPasswordText.getAttribute("placeholder"), ConfirmPasswordTxt, "Couldn't find the Confirm Password field");
	}

    @Then("^Verify \"([^\"]*)\" Password Characters Text should be on Time To Create Password Screen$")
    public void verify_Password_Characters_Text_should_be_on_Time_To_Create_Password_Screen(String dataPointer) throws Throwable {
    // Write code here that turns the phrase above into concrete actions
     	String testCaseID = Utility.getScenarioID();
		String createPasswordTxt=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage01_Registration_ExpectedDa", testCaseID, dataPointer);
		Assert.assertEquals(createPasswordCharacters.getText(), createPasswordTxt,"Couldn't find expected create Password Characters Text");
	
    }

    @Then("^Verify \"([^\"]*)\" Password Numbers should be on Time To Create Password Screen$")
    public void verify_Password_Numbers_should_be_on_Time_To_Create_Password_Screen(String dataPointer) throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    	String testCaseID = Utility.getScenarioID();
		String createPasswordNumberTxt=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage01_Registration_ExpectedDa", testCaseID, dataPointer);
		Assert.assertEquals(createPasswordNumber.getText(), createPasswordNumberTxt,"Couldn't find expected create Password Numbers Text");
    }

    @Then("^Verify \"([^\"]*)\" Password Upper Case Numbers should be on Time To Create Password Screen$")
    public void verify_Password_Upper_Case_Numbers_should_be_on_Time_To_Create_Password_Screen(String dataPointer) throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    	String testCaseID = Utility.getScenarioID();
		String createPasswordUpperCaseTxt=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage01_Registration_ExpectedDa", testCaseID, dataPointer);
		Assert.assertEquals(createPasswordUpperCase.getText(), createPasswordUpperCaseTxt,"Couldn't find expected create Password UpperCase Text");
    }

    @Then("^Verify \"([^\"]*)\" Password Special Characters should be on Time To Create Password Screen$")
    public void verify_Password_Special_Characters_should_be_on_Time_To_Create_Password_Screen(String dataPointer) throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    	String testCaseID = Utility.getScenarioID();
		String createPasswordSpecialCharactersTxt=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage01_Registration_ExpectedDa", testCaseID, dataPointer);
		Assert.assertEquals(createPasswordSpecialCharacters.getText(), createPasswordSpecialCharactersTxt,"Couldn't find expected create PasswordS pecial Characters Text");
    }

    @Then("^Verify \"([^\"]*)\" Password Same User Name should be on Time To Create Password Screen$")
    public void verify_Password_Same_User_Name_should_be_on_Time_To_Create_Password_Screen(String dataPointer) throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    	String testCaseID = Utility.getScenarioID();
		String createPasswordSameUserNameTxt=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage01_Registration_ExpectedDa", testCaseID, dataPointer);
		Assert.assertEquals(createPasswordSameAsUserName.getText(), createPasswordSameUserNameTxt,"Couldn't find expected create Password Same As UserName Text");
    }

    @When("^Back button is clicked on Time To Create Password Screen$")
    public void back_button_is_clicked_on_Time_To_Create_Password_Screen() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
       Common.backButtonClicked();
       Thread.sleep(2000);
    }

    @Then("^\"([^\"]*)\" screen should be displayed from Create Password Screen$")
    public void screen_should_be_displayed_from_Create_Password_Screen(String dataPointer) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
		String testCaseID = Utility.getScenarioID();
		String createUserNameTxt=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage01_Registration_ExpectedDa", testCaseID, dataPointer);
		Assert.assertEquals(timeToCreateUserNameHeaderText.getText(), createUserNameTxt,"Couldn't find expected Create Password page");
	
    }
    
    public static void ValidPassword(String PasswordTxt,String ConfirmPasswordTxt) throws InterruptedException {
    	QAFExtendedWebElement createPasswordText= new QAFExtendedWebElement("ehome.createPassword.createPasswordText");
    	QAFExtendedWebElement confirmPasswordText= new QAFExtendedWebElement("ehome.createPassword.confirmPasswordText");
    	createPasswordText.sendKeys(PasswordTxt);
    	confirmPasswordText.sendKeys(ConfirmPasswordTxt);   
	}

    @When("^Continue button is clicked after entering valid \"([^\"]*)\" and \"([^\"]*)\" on Time To Create Password Screen$")
    public void continue_button_is_clicked_after_entering_valid_and_on_Time_To_Create_Password_Screen(String dataPointer1, String dataPointer2) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	String testCaseID = Utility.getScenarioID();
		String PasswordText=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage01_Registration_InputData", testCaseID, dataPointer1);
		String ConfirmPasswordText=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage01_Registration_InputData", testCaseID, dataPointer2);
		ValidPassword(PasswordText,ConfirmPasswordText);
		Common.continueButtonClicked();
	    Thread.sleep(2000);
    }

    @Then("^Verify \"([^\"]*)\" screen should be displayed from Create Password Screen$")
    public void verify_screen_should_be_displayed_from_Create_Password_Screen(String dataPointer) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	String testCaseID = Utility.getScenarioID();
		String NowtellusaboutyournewhomeTxt=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage01_Registration_ExpectedDa", testCaseID, dataPointer);
		Assert.assertEquals(NowtellusaboutyournewhomeText.getText(), NowtellusaboutyournewhomeTxt,"Couldn't find expected Now tell us about your new home page");
    }
    
    @When("^Entering not matching \"([^\"]*)\" and \"([^\"]*)\" on Time To Create Password Screen$")
    public void entering_not_matching_and_on_Time_To_Create_Password_Screen(String dataPointer1, String dataPointer2) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	String testCaseID = Utility.getScenarioID();
		String PasswordErrText=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage01_Registration_InputData", testCaseID, dataPointer1);
		String ConfirmPasswordErrText=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage01_Registration_InputData", testCaseID, dataPointer2);
		ValidPassword(PasswordErrText,ConfirmPasswordErrText);
		Thread.sleep(2000);
    }

    @Then("^Verify \"([^\"]*)\" Error Message should be displayed from Create Password Screen$")
    public void verify_Error_Message_should_be_displayed_from_Create_Password_Screen(String dataPointer) throws Throwable {
        // Write code here that turns the phrase above into concrete actions
    	String testCaseID = Utility.getScenarioID();
		String PassworddoesntmatchError=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage01_Registration_ExpectedDa", testCaseID, dataPointer);
		Assert.assertEquals(Passworddoesntmatch.getText(), PassworddoesntmatchError,"Couldn't find expected Error message");
    
    }
}
