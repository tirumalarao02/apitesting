package com.scotiabank.ehome.ui.steps.stage1;

import static com.scotiabank.ehome.ui.steps.Utility.getScreenDataset;

import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.qmetry.qaf.automation.step.QAFTestStepProvider;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebDriver;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.quantum.utils.ConfigurationUtils;
import com.scotiabank.ehome.ui.steps.Common;
import com.scotiabank.ehome.ui.steps.Utility;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

@QAFTestStepProvider
public class TriageQuestions {
	
	private QAFExtendedWebDriver webDriver = Utility.getDriver();
    public Actions action = null;
    public static WebDriverWait wait=Utility.getWait();	
    

	QAFExtendedWebElement backButton= new QAFExtendedWebElement("ehome.triageQuestions.backButton");
	QAFExtendedWebElement ques1Title= new QAFExtendedWebElement("ehome.triageQuestions.ques1Title");
	QAFExtendedWebElement ques2Title= new QAFExtendedWebElement("ehome.triageQuestions.ques2Title");
	QAFExtendedWebElement ques3Title= new QAFExtendedWebElement("ehome.triageQuestions.ques3Title");
	QAFExtendedWebElement ques4Title= new QAFExtendedWebElement("ehome.triageQuestions.ques4Title");
	QAFExtendedWebElement ques5Title= new QAFExtendedWebElement("ehome.triageQuestions.ques5Title");
	QAFExtendedWebElement ques6Title= new QAFExtendedWebElement("ehome.triageQuestions.ques6Title");
	QAFExtendedWebElement ques1Header= new QAFExtendedWebElement("ehome.triageQuestions.ques1Header");
	QAFExtendedWebElement ques2Header= new QAFExtendedWebElement("ehome.triageQuestions.ques2Header");
	QAFExtendedWebElement ques3Header= new QAFExtendedWebElement("ehome.triageQuestions.ques3Header");
	QAFExtendedWebElement ques4Header= new QAFExtendedWebElement("ehome.triageQuestions.ques4Header");
	QAFExtendedWebElement ques5Header= new QAFExtendedWebElement("ehome.triageQuestions.ques5Header");
	QAFExtendedWebElement ques6Header= new QAFExtendedWebElement("ehome.triageQuestions.ques6Header");
	QAFExtendedWebElement quesNo= new QAFExtendedWebElement("ehome.triageQuestions.quesNo");
	QAFExtendedWebElement quesYes= new QAFExtendedWebElement("ehome.triageQuestions.quesYes");
	QAFExtendedWebElement privacyAgreement= new QAFExtendedWebElement("ehome.triageQuestions.privacyAgreement");
	QAFExtendedWebElement warningMsg1= new QAFExtendedWebElement("ehome.triageQuestions.warningMsg1");
	QAFExtendedWebElement warningMsg2= new QAFExtendedWebElement("ehome.triageQuestions.warningMsg2");
	QAFExtendedWebElement warningMsg3= new QAFExtendedWebElement("ehome.triageQuestions.warningMsg3");
	QAFExtendedWebElement warningMsg4= new QAFExtendedWebElement("ehome.triageQuestions.warningMsg4");
	QAFExtendedWebElement warningMsg5= new QAFExtendedWebElement("ehome.triageQuestions.warningMsg5");
	QAFExtendedWebElement warningMsg6= new QAFExtendedWebElement("ehome.triageQuestions.warningMsg6");
	
	QAFExtendedWebElement flipBack= new QAFExtendedWebElement("ehome.triageQuestions.flipBack");
	QAFExtendedWebElement guarantorText= new QAFExtendedWebElement("ehome.triageQuestions.guarantorText");
	QAFExtendedWebElement ageOfMajority= new QAFExtendedWebElement("ehome.triageQuestions.ageOfMajority");
	QAFExtendedWebElement tellMeMore= new QAFExtendedWebElement("ehome.triageQuestions.tellMeMore");
	QAFExtendedWebElement headerTitle= new QAFExtendedWebElement("ehome.triageQuestions.headerTitle");
	QAFExtendedWebElement backFlip1= new QAFExtendedWebElement("ehome.triageQuestions.backFlip1");
	QAFExtendedWebElement backFlip2= new QAFExtendedWebElement("ehome.triageQuestions.backFlip2");
	QAFExtendedWebElement backFlip3= new QAFExtendedWebElement("ehome.triageQuestions.backFlip3");
	QAFExtendedWebElement StartWithQuestions= new QAFExtendedWebElement("ehome.Triage.Start");

	
	@Given("^Customer should login and navigate to triage questions screen$")
	public void customer_should_login_and_navigate_to_triage_questions_screen() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Utility.launchURL(ConfigurationUtils.getBaseBundle().getPropertyValue ("env.baseurl0"));
		Welcome.viewOurPrivacyAgreementButtonClicked();
		PrivacyAgreement.acceptAndContinuetButtonClicked();
		StartWithQuestions.click();
	}

	@Then("^Back to eHome button should be there on the screen$")
	public void back_to_eHome_button_should_be_there_on_the_screen() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		backButton.assertPresent ("Couldn't find the Back Button"  );
		if(!backButton.verifyPresent())
			throw new AssertionError("Couldn't find the Back Button");
	}
	
	@Then("^Verify title \"([^\"]*)\" from question (\\d+)$")
	public void verify_title_from_question(String arg1, int arg2) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String testCaseID = Utility.getScenarioID();
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage01_Registration_ExpectedDa", testCaseID, arg1);
		Thread.sleep(4000);
		if (arg2==1)
		{
			wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(ques1Title));
			Assert.assertEquals(ques1Title.getText(), value,"Couldn't found expected title message");
		}
		if (arg2==2)
		{
			wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(ques2Title));
			Assert.assertEquals(ques2Title.getText(), value,"Couldn't found expected title message");
		}
		if (arg2==3)
		{
			wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(ques3Title));
			Assert.assertEquals(ques3Title.getText(), value,"Couldn't found expected title message");
		}
		if (arg2==4)
		{
			wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(ques4Title));
			Assert.assertEquals(ques4Title.getText(), value,"Couldn't found expected title message");
		}
		if (arg2==5)
		{
			wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(ques5Title));
			Assert.assertEquals(ques5Title.getText(), value,"Couldn't found expected title message");
		}
		if (arg2==6)
		{
			wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(ques6Title));
			Assert.assertEquals(ques6Title.getText(), value,"Couldn't found expected title message");
		}
		
	}

	@Then("^Verify header \"([^\"]*)\" on the screen (\\d+)$")
	public void verify_header_on_the_screen(String arg1, int arg2) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String testCaseID = Utility.getScenarioID();
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage01_Registration_ExpectedDa", testCaseID, arg1);
		Thread.sleep(4000);
		if (arg2==1)
		{
			wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(ques1Header));
			Assert.assertEquals(ques1Header.getText(), value,"Couldn't found expected header message");
		}
		if (arg2==2)
		{
			wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(ques2Header));
			Assert.assertEquals(ques2Header.getText(), value,"Couldn't found expected header message");
		}
		if (arg2==3)
		{
			wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(ques3Header));
			Assert.assertEquals(ques3Header.getText(), value,"Couldn't found expected header message");
		}
		if (arg2==4)
		{
			wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(ques4Header));
			Assert.assertEquals(ques4Header.getText(), value,"Couldn't found expected header message");
		}
		if (arg2==5)
		{
			wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(ques5Header));
			Assert.assertEquals(ques5Header.getText(), value,"Couldn't found expected header message");
		}
		if (arg2==6)
		{
			wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(ques6Header));
			Assert.assertEquals(ques6Header.getText(), value,"Couldn't found expected header message");
		}
	}

	@Then("^Verify Yes button on the screen$")
	public void verify_Yes_button_on_the_screen() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		quesYes.assertPresent ("Couldn't find the Yes Button"  );
		if(!quesYes.verifyPresent())
			throw new AssertionError("Couldn't find the Yes Button");
	}

	@Then("^Verify No button on the screen$")
	public void verify_No_button_on_the_screen() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		quesNo.assertPresent ("Couldn't find the No Button"  );
		if(!quesNo.verifyPresent())
			throw new AssertionError("Couldn't find the No Button");
	}

	@When("^Click on Back to eHome from first question$")
	public void click_on_Back_to_eHome_from_first_question() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(backButton));
		backButton.click();
	}

	@Then("^should navigate to privacy agreement screen$")
	public void should_navigate_to_privacy_agreement_screen() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(privacyAgreement));
		privacyAgreement.assertPresent ("Couldn't find the Privacy Agreement"  );
		if(!privacyAgreement.verifyPresent())
			throw new AssertionError("Couldn't find the Privacy Agreement");
	}
	
	public static void noButtonClicked() throws Exception{	
		QAFExtendedWebElement quesNo= new QAFExtendedWebElement("ehome.triageQuestions.quesNo");
	    wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(quesNo));
	    quesNo.click();
	}
	
	@When("^Click on No button from triage questions screen$")
	public void click_on_No_button_from_triage_questions_screen() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		noButtonClicked();
	}

	@Then("^should able to flip from \"([^\"]*)\" from (\\d+) question$")
	public void should_able_to_flip_from_from_question(String arg1, int arg2) throws Throwable {
	   
	}

	@Then("^Verify Change Answer link$")
	public void verify_Change_Answer_link() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(flipBack));
		flipBack.assertPresent ("Couldn't find the Change Answer"  );
		if(!flipBack.verifyPresent())
			throw new AssertionError("Couldn't find the Change Answer");
	}
	
	@When("^Click on Back button from question$")
	public void click_on_Back_button_from_question() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(flipBack));
		flipBack.click();
	}

	@When("^Click on Back button from flip from (\\d+)$")
	public void click_on_Back_button_from_flip_from(int arg1) throws Throwable {
		
		Thread.sleep(4000);
		if(arg1 == 2)
		{
			wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(backFlip1));
			backFlip1.click();
		}
		if(arg1 == 3)
		{
			wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(backFlip2));
			backFlip2.click();
		}
		if(arg1 == 4)
		{
			wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(backFlip3));
			backFlip3.click();
		}
	}
	
	@Then("^Should able to navigate to \"([^\"]*)\" question to question (\\d+)$")
	public void should_able_to_navigate_to_question_to_question(String arg1, int arg2) throws Throwable {
		String testCaseID = Utility.getScenarioID();
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage01_Registration_ExpectedDa", testCaseID, arg1);
		Thread.sleep(4000);
		if(arg2 == 1)
		{
			wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(ques1Title));
			Assert.assertEquals(ques1Title.getText(), value,"Couldn't found expected title message");
		}
		if(arg2 == 2)
		{
			wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(ques2Title));
			Assert.assertEquals(ques2Title.getText(), value,"Couldn't found expected title message");
		}
		if(arg2 == 3)
		{
			wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(ques3Title));
			Assert.assertEquals(ques3Title.getText(), value,"Couldn't found expected title message");
		}
		if(arg2 == 4)
		{
			wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(ques4Title));
			Assert.assertEquals(ques4Title.getText(), value,"Couldn't found expected title message");
		}
		if(arg2 == 5)
		{
			wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(ques5Title));
			Assert.assertEquals(ques5Title.getText(), value,"Couldn't found expected title message");
		}
		if(arg2 == 6)
		{
			wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(ques6Title));
			Assert.assertEquals(ques6Title.getText(), value,"Couldn't found expected title message");
		}
	}


	public static void yesButtonClicked() throws Exception{	
		QAFExtendedWebElement quesYes= new QAFExtendedWebElement("ehome.triageQuestions.quesYes");
	    wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(quesYes));
	    quesYes.click();
	}
	
	@When("^Click on Yes button from triage questions screen$")
	public void click_on_Yes_button_from_triage_questions_screen() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		yesButtonClicked();
	}

	@Then("^Verify text \"([^\"]*)\" on the screen (\\d+)$")
	public void verify_text_on_the_screen(String arg1, int arg2) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Thread.sleep(4000);
		if(arg2 == 2)
		{
			wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(guarantorText));
			guarantorText.assertPresent ("Couldn't find the Guarantor Text"  );
			if(!guarantorText.verifyPresent())
				throw new AssertionError("Couldn't find the Guarantor Text");
		}
		if(arg2 == 3)
		{
			wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(ageOfMajority));
			ageOfMajority.assertPresent ("Couldn't find the ageOfMajority Text"  );
			if(!ageOfMajority.verifyPresent())
				throw new AssertionError("Couldn't find the ageOfMajority Text");
		}
		if(arg2 == 4)
		{
			wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(tellMeMore));
			tellMeMore.assertPresent ("Couldn't find the tellMeMore Text"  );
			if(!tellMeMore.verifyPresent())
				throw new AssertionError("Couldn't find the tellMeMore Text");
		}
		
		
	}
	
	@When("^Click on previous question$")
	public void click_on_previous_question() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(backButton));
		backButton.click();
	}
	
	@When("^Click on \"([^\"]*)\" from (\\d+) question$")
	public void click_on_from_question(String arg1, int arg2) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Thread.sleep(4000);
		if(arg2 == 2)
		{
			guarantorText.click();
		}
		if(arg2 == 3)
		{
			ageOfMajority.click();
		}
		if(arg2 == 4)
		{
			tellMeMore.click();
		}
	}
	
	@Then("^Should able to navigate to Congratulations page$")
	public void should_able_to_navigate_to_Congratulations_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(headerTitle));
		headerTitle.assertPresent ("Couldn't find the headerTitle Text"  );
		if(!headerTitle.verifyPresent())
			throw new AssertionError("Couldn't find the headerTitle Text");
	}
	
	@Then("^should able to get flip error from \"([^\"]*)\" from (\\d+) question$")
	public void should_able_to_get_flip_error_from_from_question(String arg1, int arg2) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		 // Write code here that turns the phrase above into concrete actions
		String testCaseID = Utility.getScenarioID();
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage01_Registration_ExpectedDa", testCaseID, arg1);
		Thread.sleep(6000);
		if (arg2==1)
		{
			wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(warningMsg1));
			Assert.assertEquals(warningMsg1.getText(), value,"Couldn't found expected Warning message");
		}
		if (arg2==2)
		{
			wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(warningMsg2));
			Assert.assertEquals(warningMsg2.getText(), value,"Couldn't found expected Warning message");
		}
		if (arg2==3)
		{
			wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(warningMsg3));
			Assert.assertEquals(warningMsg3.getText(), value,"Couldn't found expected Warning message");
		}
		if (arg2==4)
		{
			wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(warningMsg4));
			Assert.assertEquals(warningMsg4.getText(), value,"Couldn't found expected Warning message");
		}
		if (arg2==5)
		{
			wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(warningMsg5));
			Assert.assertEquals(warningMsg5.getText(), value,"Couldn't found expected Warning message");
		}
		if (arg2==6)
		{
			wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(warningMsg6));
			Assert.assertEquals(warningMsg6.getText(), value,"Couldn't found expected Warning message");
		}
	}
}
