package com.scotiabank.ehome.ui.steps.stage3;

import com.qmetry.qaf.automation.step.QAFTestStepProvider;
import com.qmetry.qaf.automation.ui.WebDriverTestBase;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebDriver;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.quantum.utils.ConfigurationUtils;
import com.scotiabank.ehome.ui.steps.Common;
import com.scotiabank.ehome.ui.steps.Utility;
import com.scotiabank.ehome.ui.steps.valueObjects.Tuple;
import com.scotiabank.ehome.ui.steps.valueObjects.TypeOfRateVO;

import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;

import cucumber.api.PendingException;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import static com.scotiabank.ehome.ui.steps.BusinessCalculations.*;
import static com.scotiabank.ehome.ui.steps.Utility.*;
@QAFTestStepProvider
public class TermOfRate {
		private QAFExtendedWebDriver webDriver = new WebDriverTestBase().getDriver();
			public static WebDriverWait wait=Utility.getWait();
			String testCaseID = Utility.getScenarioID();
        @Given("^Customer should login and navigates to Stage 3 Term Rate$")
        public void CustomershouldloginandnavigatestoStage3TermRate() throws Throwable {
            // Write code here that turns the phrase above into concrete actions
        	Utility.launchURL(ConfigurationUtils.getBaseBundle().getPropertyValue ("env.baseurl"));
            //Click on continue on section breaker
            QAFExtendedWebElement buttonContinue= new QAFExtendedWebElement("ehome.rate.continue.button");
            buttonContinue.click();
            //Click on the select button in fixed
            QAFExtendedWebElement selectFixed= new QAFExtendedWebElement("ehome.typeofrate.selectfixed.radio");
            selectFixed.click ();
            TypeOfRateVO.getInstance().setTypeOfRate(TypeOfRateVO.TYPE_OF_RATE_FIXED_RATE);
            Thread.sleep(3000);
                     
        }
        //Scenario: Term_Of_Rate_002
        @When("^Verify \"([^\"]*)\" in Term Rate Screen$")
        public void VerifyGreatinTermRateScreen(String dataPointer) throws Throwable {
            // Write code here that turns the phrase above into concrete actions
        	String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage03_Rate_ExpectedData", testCaseID, dataPointer);
    		Assert.assertEquals(Common.headerMessage(), value,"Couldn't found expected header text");
        }

        @Then("^\"([^\"]*)\" text should be displayed in Term Rate Screen$")
        public void WhatmortgagetermareyoulookingforShouldBeDisplayedInTermRateScreen(String dataPointer) throws Throwable {
            // Write code here that turns the phrase above into concrete actions
        	Thread.sleep(3000);
        	String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Stage03_Rate_ExpectedData", testCaseID, dataPointer);
    		QAFExtendedWebElement headertext= new QAFExtendedWebElement("ehome.Header1.text");
    		 wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(headertext));
    		Assert.assertEquals(headertext.getText(), value,"Couldn't found expected header text");
        }
        //Scenario: Term_Of_Rate_003

        //Scenario: Term_Of_Rate_004

        @When("^Click on the Back button in Term Rate$")
        public void clickOnTheBackButtonInTermRate() throws Throwable {
            // Write code here that turns the phrase above into concrete actions
            QAFExtendedWebElement backButtontermofrate = new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[2]/button");
            backButtontermofrate.click ();
            Thread.sleep(3000); 
            QAFExtendedWebElement selectchecked= new QAFExtendedWebElement("ehome.typeofrateselectchecked.input");
            String checked=selectchecked.getAttribute("checked");
            if(checked==null || !checked.contentEquals("true"))
                throw new AssertionError("Couldn't find the checked");
            QAFExtendedWebElement selectFixedUpt= new QAFExtendedWebElement("ehome.typeofrate.selectfixed.background");
            String color=selectFixedUpt.getCssValue("background-color");
            String hex = convertRGBToHex(color);
            Assert.assertEquals("#8230df",hex);
            if(!hex.contentEquals("#8230df"))
                throw new AssertionError("Select on hover is not highlighted with #8230df color");

        }
//        @Then("^Screen will be navigated to Screen \"([^\"]*)\" and the radio button \"([^\"]*)\" still should be highlighted and checked$")
//        public void screen_will_be_navigated_to_Screen_and_the_radio_button_still_should_be_highlighted_and_checked(String expectedScreenName, String radioButton) throws Throwable {
//            // Write code here that turns the phrase above into concrete actions
//            QAFExtendedWebElement screenName = new QAFExtendedWebElement("ehome.typeofrate.header");
//            Assert.assertEquals(screenName.getText(), expectedScreenName, "Not returning to expected screen");
//            QAFExtendedWebElement radioButtonSelected = new QAFExtendedWebElement(radioButton);
//            //System.out.println("Checked Value: "+radioButtonSelected.getAttribute("checked"));
//            Assert.assertEquals(radioButtonSelected.getAttribute("checked"), "true", "Variable Value Radio button not selected");
//
//        }
        //Scenario: Term_Of_Rate_005
        @And("^Continue button should not be there in Term Rate screen$")
	    public void Continue_button_should_not_be_there_in_Term_Rate_screen() throws Throwable {
	        // Write code here that turns the phrase above into concrete actions
	    	QAFExtendedWebElement ContinueCondoFees= new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[2]/button[2]");
	    	ContinueCondoFees.assertNotVisible("Continue");
	        }
		 @And("^Continue button should be there in Term Rate screen$")
		    public void Continue_button_should_be_there_in_Term_Rate_screen() throws Throwable {
		        // Write code here that turns the phrase above into concrete actions
			 QAFExtendedWebElement ContinueCondoFees= new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[2]/button[2]");
			 ContinueCondoFees.isPresent();
		        }
		 //Scenario: Term_Of_Rate_006
	
		 @And("^Verify Tell me more hyperlink and Overlay icon in the Term Rate screen$")
		 public void verify_Tell_me_more_hyperlink_and_Overlay_icon_in_the_Term_Rate_screen() throws Throwable {
		     // Write code here that turns the phrase above into concrete actions
			 //To check the Tell me more and the cursor
			 QAFExtendedWebElement Tellmemore= new QAFExtendedWebElement("ehome.termsofrate.tellmemore.button");
		        webDriver = new WebDriverTestBase().getDriver();
		        Actions action = new Actions(webDriver);
		        action = new Actions(webDriver);
		        action.moveToElement (Tellmemore).build ().perform ();
		        Thread.sleep(5000);
		        Boolean cursor= Tellmemore.getCssValue("cursor").contentEquals("pointer");
		        if(!Tellmemore.getCssValue("cursor").contentEquals( "pointer"  ))
		            throw new AssertionError("NO handicon on hover");
		        //TO check the overlay icon
		        QAFExtendedWebElement overlayIcon = new QAFExtendedWebElement("ehome.tellmemoreoverlay.icon");
		        overlayIcon.assertPresent (  );
		        overlayIcon.click();
		        if(!overlayIcon.verifyPresent())
		            throw new AssertionError("Couldn't find overlay icon beside Tell me more");
		        //TO close the button 
		        QAFExtendedWebElement close = new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[3]/div/div/div[1]/button");
		        close.click();
		        Thread.sleep(3000);
		        //TO click on the Tell me more button
		        QAFExtendedWebElement tellmemore = new QAFExtendedWebElement("//*[text()='Tell me more']");
		        tellmemore.click ();
		        if(!tellmemore.verifyText("Tell me more"))
		            throw new AssertionError("Not able to see Tell me more");
		      //TO close the button 
		        close.click();
		        Thread.sleep(3000);
		     throw new PendingException();
		   
		 }

		 @When("^Click on the Tell me more hyperlink in Term Rate screen$")
		 public void click_on_the_Tell_me_more_hyperlink_in_Term_Rate_screen() throws Throwable {
		     // Write code here that turns the phrase above into concrete actions
			 QAFExtendedWebElement tellmemore = new QAFExtendedWebElement("ehome.termsofrate.tellmemore.button");
		        tellmemore.click ();
		        if(!tellmemore.verifyText("Tell me more"))
		            throw new AssertionError("Not able to see Tell me more");
		     throw new PendingException();
		 }

		 @Then("^It should navigate to More about mortgage terms in the Term Rate screen$")
		 public void it_should_navigate_to_More_about_mortgage_terms_in_the_Term_Rate_screen() throws Throwable {
		     // Write code here that turns the phrase above into concrete actions
			 //To check the heading 
			 QAFExtendedWebElement moreaboutmortgageterms = new QAFExtendedWebElement("ehome.moreaboutmortgageterms.header");
		        Thread.sleep(5000);
		       if(!moreaboutmortgageterms.verifyText("More about mortgage terms"))
		            throw new AssertionError("Not able to see More about mortgage terms");
		     //To check the content
		       QAFExtendedWebElement contenttext = new QAFExtendedWebElement("ehome.moreaboutmortgageterms.content.text");
		        Thread.sleep(5000);
		        if(!contenttext.verifyText("The term is the length of time the interest rate, payment and other mortgage conditions will be in effect. At the end of the term, you will need to renew your mortgage into another term or repay it in full. Mortgage term is sometimes confused with amortization. While mortgages often have a 5-year term, they are typically paid off over a 25 year amortization period"))
		            throw new AssertionError("Not able to see content in More about mortgage terms");
		     //TO check consider your option
		        QAFExtendedWebElement consideryouroptions= new QAFExtendedWebElement("ehome.moreaboutmortgageterms.consideryouroptions.select");
		        consideryouroptions.verifyPresent();
		        if(!consideryouroptions.verifyPresent())
		            throw new AssertionError("Couldn't find the consider your option");
		    //TO check Discover key features
		        QAFExtendedWebElement discoverKeyFeatures= new QAFExtendedWebElement("ehome.moreaboutmortgageterms.discoverKeyFeatures.Fixed.li");
		        String someText = discoverKeyFeatures.getAttribute("class");
		        discoverKeyFeatures.getText();
		        String discoverKeyFeaturestext= discoverKeyFeatures.getText();
		        if(!discoverKeyFeaturestext.contentEquals( "Discover key features"  ))
		            throw new AssertionError("Not able to see Discover key features");
		        
		        QAFExtendedWebElement consideryouroptions123= new QAFExtendedWebElement("ehome.moreaboutmortgageterms.consideryouroptions.li");
		       
		        String Active = consideryouroptions123.getAttribute("class");
		        String consideryouroptionstext= consideryouroptions123.getText();
		      System.out.println(Active+consideryouroptionstext);
		        
		        
		     throw new PendingException();
		        
		 }

		 @When("^Click on the close button in More about mortgage terms Screen$")
		 public void click_on_the_close_button_in_More_about_mortgage_terms_Screen() throws Throwable {
		     // Write code here that turns the phrase above into concrete actions
		     throw new PendingException();
		 }

		 @Then("^More about mortgage terms page should be closed and back to Term Rate screen$")
		 public void more_about_mortgage_terms_page_should_be_closed_and_back_to_Term_Rate_screen() throws Throwable {
		     // Write code here that turns the phrase above into concrete actions
			  QAFExtendedWebElement typeofrate= new QAFExtendedWebElement("ehome.typeofrate.header");
		        typeofrate.assertText ( "What type of rate are you looking for?"  );
		        if(!typeofrate.verifyText( "What type of rate are you looking for?"  ))
		            throw new AssertionError("Not able to see What type of rate are you looking for? page");
		 }

		   


}
