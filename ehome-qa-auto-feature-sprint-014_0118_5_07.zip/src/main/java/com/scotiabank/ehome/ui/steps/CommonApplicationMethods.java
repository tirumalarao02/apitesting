package com.scotiabank.ehome.ui.steps;
import org.apache.poi.ss.formula.functions.Column;
import org.apache.poi.ss.usermodel.*;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.aventstack.extentreports.ExtentTestInterruptedException;
import com.codoid.products.exception.FilloException;
import com.qmetry.qaf.automation.step.QAFTestStepProvider;
import com.qmetry.qaf.automation.ui.WebDriverTestBase;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebDriver;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.quantum.java.pages.ExtentReportHelper;
import com.quantum.utility.Utils;
import com.quantum.utils.ConfigurationUtils;
import com.scotiabank.ehome.ui.steps.stage1.DateOfBirth;
import com.scotiabank.ehome.ui.steps.stage1.EmailAddress;
import com.scotiabank.ehome.ui.steps.stage1.LegalName;
import com.scotiabank.ehome.ui.steps.stage1.MaritalStatus;
import com.scotiabank.ehome.ui.steps.stage1.PrivacyAgreement;
import com.scotiabank.ehome.ui.steps.stage1.SOLCustomerQuestion;
import com.scotiabank.ehome.ui.steps.stage1.Welcome;
import com.scotiabank.ehome.ui.steps.stage1.WhatsYourAddress;

import cucumber.api.java.en.Given;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;
@QAFTestStepProvider

public class CommonApplicationMethods {
	
	static QAFExtendedWebDriver webDriver = null;

	public Actions action = null;
	public static WebDriverWait wait=Utility.getWait();	
	
	static String curDir = System.getProperty("user.dir");
	static String strfullPathToFile = curDir + "\\src\\main\\resources\\data\\eHomeTestData.xlsx"; // File Path
	static String  sheetUsers = "eHomeUsers";														//  Data Sheet for URLs
	static String  strStage2ToStage3Sheet = "E2EStages";                                         //  Data Sheet for E2E
	static String  sheetE2EStage4To5 = "E2EStage4To5";
	static String  sheetNameE2E ="E2E_Stages";
	static String strDocsPath = curDir + "\\src\\main\\resources\\data\\eHomeTestData.xlsx"; // File Path
	static String sheetE2E_InputData ="E2E_InputData";
	static String sheetE2E_ExpectedData ="E2E_ExpectedData";
	static String strtestCaseID = "MIMS-E2E-Scenario-001";

	//static strtestCaseID = Utility.getScenarioID();
 	

	
	 
	/* *************************************************************************************************************************************************
	 Author:      RameshChalumuri
	 Stage:       Any Stage
	 Method Name: launchSectionBreakerURL
	 Purpose:     This method is used for launching section Breaker URL for any stage 
	 Created on:  27-October-2018  
	 Updated By: 
	 Updated on:
	 *************************************************************************************************************************************************** */
		@Given("^Launch \"([^\"]*)\" section breaker stage url$")
		public void launchSectionBreakerURL(String loginDataPointer) throws Throwable {
			List<String> ExcelData = Utility.ExcelData(strfullPathToFile, sheetUsers, loginDataPointer);
			String strURL =ExcelData.get(0);
   	  	 	Utility.launchURL(strURL);
		}

		/* *************************************************************************************************************************************************
		 Author:      Ramesh Chalumuri
		 Stage:       logineHomeHub
		 Method Name: logineHomeHub
		 Purpose:     This method is used for login eHomeHub
		 Created on:  11-Jan-2019  
		 Updated By: 
		 Updated on:
		 *************************************************************************************************************************************************** */
		@Given("^logineHomeHub$")
		public void logineHomeHub() throws Throwable {
			Utility.launchURL(ConfigurationUtils.getBaseBundle ().getPropertyValue ("env.baseurlHub"));
			//String strtestCaseID = Utility.getScenarioID();
			String strtestCaseID = "MIMS-E2E-Scenario-018";
				
			// Passing "Excel Path", "Sheet name", "Test Case ID" as parameters
			Map<String, String> E2E_InputData =  Utility.readTestData(strfullPathToFile, sheetE2E_InputData,strtestCaseID);
				String streHomeUserNameInput= E2E_InputData.get("eHomeUserName");
				String streHomePasswordInput= E2E_InputData.get("eHomePassword");

			Utility.webDriver.findElement(By.xpath(".//*[contains(@id,'username')]")).sendKeys(streHomeUserNameInput);
			Utility.webDriver.findElement(By.xpath(".//*[contains(@id,'password')]")).sendKeys(streHomePasswordInput);
			Utility.webDriver.findElement(By.xpath("//button[@id='signIn']")).click();

			Utility.clickObject("ehome.eHomeLogin.Continue", "Continue Button in Redirect Screen");

			}
	
	
	 /* *************************************************************************************************************************************************
	 	Author: 	  RameshChalumuri
		Stage:       Any Stage
		Method Name: selectValuefromDropDownListBox 
		Purpose: 	  This method is for selecting Any Item value from Drop down List
		Created on:  08-October-2018
		Updated By: 
		Updated on:
		 *************************************************************************************************************************************************** */
		public static void selectValuefromDropDownListBox(String xPath, String optionValue ) throws InterruptedException{
			QAFExtendedWebElement dropDownList= new QAFExtendedWebElement(xPath);
			wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(dropDownList));
			dropDownList.click();
			Select dropDownListSelect = new Select(dropDownList);
			dropDownListSelect.selectByVisibleText(optionValue);
					  
		 }
		
		
		/* *************************************************************************************************************************************************
		 Author: 	  RameshChalumuri
		 Method Name: Registration_functionality
		 Purpose: 	  Registration_functionality
		 Created on:  17-Jan-2019  
		 Updated By:  
		 Updated on:  
		 *************************************************************************************************************************************************** */
		@Given("^CustomerRegistration$")
		public  void Registration_functionality() throws Throwable {
			
			String strFirstName = "Ramesh";
			String strLastName = "Chalumuri";
			String strMaritalStatus = "Married/Common-Law";
			String stremailAddress = "ramesh.chalumuri@scotiabank.com";
			String strUsername = "eHome"+ System.currentTimeMillis();
			String strPassword = "Password123";
				
			Utility.launchURL(ConfigurationUtils.getBaseBundle().getPropertyValue ("env.baseurlRegistration"));
			
			Utility.clickObject("//*[contains(text(),'No')]", "No Button on registration#0");
			CommonApplicationMethods.selectValuefromDropDownListBox("//*[@id=\"salutation\"]", "Mr");
			Thread.sleep(250);
			Utility.sendKeys("ehome.legalName.firstName", strFirstName);
			Thread.sleep(250);
			Utility.sendKeys("ehome.legalName.lastName", strLastName);
			Thread.sleep(250);
			Utility.clickObject("//*[contains(text(),'Continue')]", "Continue Button on registration#1");
			Thread.sleep(250);
			CommonApplicationMethods.selectValuefromDropDownListBox("//*[@id=\"maritalStatus\"]", strMaritalStatus);
			Thread.sleep(250);
			Utility.clickObject("//*[contains(text(),'Continue')]", "Continue Button on registration#3");
			CommonApplicationMethods.selectValuefromDropDownListBox("//*[@id=\"date\"]", "17");
			CommonApplicationMethods.selectValuefromDropDownListBox("//*[@id=\"month\"]", "Nov");
			CommonApplicationMethods.selectValuefromDropDownListBox("//*[@id=\"year\"]", "1993");
			Thread.sleep(250);
			Utility.clickObject("//*[contains(text(),'Continue')]", "Continue Button#4");
			Thread.sleep(250);
			WhatsYourAddress.ValidWhatsYourAddressValues("2201", "EGLINTON AVE", "TORONTO", "ONTARIO","M1K2M1");
			Utility.clickObject("//*[contains(text(),'Continue')]", "Continue Button on registration#4");
			Thread.sleep(1000);
			Utility.sendKeys("//*[@id=\"emailAddress\"]", stremailAddress);
			Thread.sleep(1000);
			Utility.sendKeys("//*[@id=\"emailConfirm\"]", stremailAddress);
			Thread.sleep(500);
			Utility.clickObject("//*[contains(text(),'Continue')]", "Continue Button on registration#5");
			Utility.sendKeys("ehome.mobilePhoneNumber.MobilePhoneNumber1", "306"); // Give first 3 digits of your phone Number
			Thread.sleep(500);
			Utility.sendKeys("ehome.mobilePhoneNumber.MobilePhoneNumber2", "450"); // Give Next 3 digits of your phone Number
			Thread.sleep(250);
			Utility.sendKeys("ehome.mobilePhoneNumber.MobilePhoneNumber3", "1353"); // Give Next 4 digits of your phone Number
			Utility.clickObject("//*[contains(text(),'Continue')]", "Continue Button on registration#6");
			Thread.sleep(250); 
			Utility.clickObject("//*[contains(text(),'Continue')]", "Continue Button on registration#7"); // Please put Break point here to Enter the 6-digit security code here:
			Utility.sendKeys("ehome.timeToCreateUserName.UserNameText", strUsername);
			Utility.clickObject("//*[contains(text(),'Continue')]", "Continue Button on registration#8");
			Utility.sendKeys("ehome.createPassword.createPasswordText", strPassword);
			Utility.sendKeys("ehome.createPassword.confirmPasswordText", strPassword);
			Utility.clickObject("//*[contains(text(),'Continue to login')]", "Continue to login Button");
				
			System.out.println("USER NAME: "+ strUsername); // Check it from Console
			System.out.printf("%n");
			System.out.println("PASSWORD: "+ strPassword); // Check it from Console
		}
		
		
		/* *************************************************************************************************************************************************
		 Author: 	  RameshChalumuri
		 Method Name: PreCondition_Traverse_HUB_to_Stage4_functionality
		 Purpose: 	  Traversing HUB to Entry of Stage4
		 Created on:  06-October-2018  
		 Updated By:  
		 Updated on:  
		 *************************************************************************************************************************************************** */
		@Given("^Traverse HUB to Entry of Stage4$")
		public void PreCondition_Traverse_HUB_to_Stage4_functionality() throws Throwable {
			//String strtestCaseID = Utility.getScenarioID();
			Map<String, String> E2E_InputData =  Utility.readTestData(strfullPathToFile, sheetE2E_InputData,strtestCaseID);
    		Map<String, String> E2E_ExpectedData =  Utility.readTestData(strfullPathToFile, sheetE2E_ExpectedData,strtestCaseID);
			
    		String strInputAddress= E2E_InputData.get("TypeOfAddress");
			String strInputPropertyType= E2E_InputData.get("PropertyType"); 
			String strExpectTypeofProperty_Title= E2E_ExpectedData.get("TypeofProperty_Title");
			String strInputHouseType= E2E_InputData.get("HouseType");									// Retrieve "HouseType" from Excel
			String strInputCondoFees = E2E_InputData.get("CondoFees");									// Retrieve "CondoFees" from Excel
			String strInputSquareFeet  = E2E_InputData.get("SquareFeet");								// Retrieve "SquareFeet" from Excel
			String strInputPurchasePrice  = E2E_InputData.get("PurchasePrice");							// Retrieve "PurchasePrice" from Excel
			String strInputDownPymtSrcBankAcct  = E2E_InputData.get("DownPymtSrcBankAcct");				// Retrieve "DownPymtSrcBankAcct" from Excel
			String strInputDownPymtSrcInvAcct  = E2E_InputData.get("DownPymtSrcInvAcct");				// Retrieve "DownPymtSrcInvAcct" from Excel
			String strInputDownPymtSrcFamilyGift  = E2E_InputData.get("DownPymtSrcFamilyGift");			// Retrieve "DownPymtSrcFamilyGift" from Excel
			String strInputDownPymtSrcRRSP  = E2E_InputData.get("DownPymtSrcRRSP");						// Retrieve "DownPymtSrcRRSP" from Excel
			String strInputDownPymtSrcSaleOfAss  = E2E_InputData.get("DownPymtSrcSaleOfAss");			// Retrieve "DownPymtSrcSaleOfAss" from Excel
			String strInputDownPymtSrcSaleOfExist  = E2E_InputData.get("DownPymtSrcSaleOfExist");		// Retrieve "DownPymtSrcSaleOfExist" from Excel
			String strInputDownPymtSrcBankAcctAmt  = E2E_InputData.get("DownPymtSrcBankAcctAmt");		// Retrieve "DownPymtSrcBankAcctAmt" from Excel
			String strInputDownPymtSrcInvAcctAmt  = E2E_InputData.get("DownPymtSrcInvAcctAmt");			// Retrieve "DownPymtSrcnvAcctAmt" from Excel
			String strInputDownPymtSrcFamilyGiftAmt  = E2E_InputData.get("DownPymtSrcFamilyGiftAmt");	// Retrieve "DownPymtSrcFamilyGiftAmt" from Excel		
			String strInputDownPymtSrcRRSPAmt  = E2E_InputData.get("DownPymtSrcRRSPAmt");				// Retrieve "DownPymtSrcRRSPAmt" from Excel
			String strInputDownPymtSrcSaleOfAssAmt  = E2E_InputData.get("DownPymtSrcSaleOfAssAmt");		// Retrieve "DownPymtSrcSaleOfAssAmt" from Excel
			String strInputDownPymtSrcSaleOfExistAmt  = E2E_InputData.get("DownPymtSrcSaleOfExistAmt");	// Retrieve "DownPymtSrcSaleOfExistAmt" from Excel
			String strInputTypeOfRate= E2E_InputData.get("TypeOfRate"); // Retrieve "TypeOfRate" from Excel 
		  	String strInputMortgageTerm   = E2E_InputData.get("MortgageTerm");// Retrieve "MortgageTerm" from Excel
			String strInputDownPayment  		= E2E_InputData.get("DownPayment");	// Retrieve "DownPayment" from Excel
		   	String strInputRateCustomization    = E2E_InputData.get("RateCustomization");// Retrieve "UnLockYourRate" from Excel
	    	String strInputRateUnlock           = E2E_InputData.get("RateUnlock");// Retrieve "RateUnlock" from Excel
	    	String strInputRateEquity           = E2E_InputData.get("RateEquity");// Retrieve "Rate Equity" from Excel 
    		
			Utility.launchURL(ConfigurationUtils.getBaseBundle ().getPropertyValue ("env.baseurlHub"));
			Thread.sleep(2000);
			Utility.clickObject("ehome.hubOnboarding.LetsGetStartedBtn","Let's Get Started Button on Hub on Boarding");
			Thread.sleep(2000);
			Utility.clickObject("ehome.hubOnboarding.SaveContinueBtn","Save and Continue Button");
			Thread.sleep(250);
			Utility.clickObject("ehome.hubOnboarding.NoCoAppBtn","No Co-Applicant Button");
			Thread.sleep(250);
			Utility.clickObject("ehome.hubOnboarding.GotitBtn","Got it Btn Button");
			Thread.sleep(250);
			Utility.clickObject("ehome.hubOnboarding.LetsGetStartedBtnSampleSteps","Lets Get Started Button in 6 simple steps");
			Thread.sleep(250);
			Utility.clickObject("ehome.hubOnboarding.StartyourAppBtn","Start your application Button");
			Thread.sleep(250);
			Utility.clickObject("ehome.hubOnboarding.ContinueyourAppBtn","Continue your application Button");
			Utility.clickObject("ehome.stage2sectionbreaker.Continue.button","Continue");
	    			
			Thread.sleep(250);
			// Enter 'Address' in 'Address of Your New Home' screen in STAGE#2
			if (strInputAddress.contentEquals("Manual")) {
				CommonApplicationMethods.enterAnyProvinceAddressManually();
			}
			else
			{
				CommonApplicationMethods.enterAutosuggestaddress(strInputAddress); // Enters Auto suggest address (DMTI field) in Address screen 
			}
			Thread.sleep(3000);      	
			CommonAppMethodsYourNewHome.selectPropertyType(strInputPropertyType); // Select Property Type in "Type of Property"
			Thread.sleep(2000);

			if (strInputPropertyType.contentEquals("Condo")) {
				Utility.sendKeys("ehome.CondoFees.CondoFees.input", strInputCondoFees); // Enter "Condo fee" in "Type of Property" 
				Thread.sleep(500);
				Utility.clickObject("ehome.CloseDtContinue.button", "Button"); // Click on Continue in "Type of Property"  
				Thread.sleep(500);
	   			}
			if (strInputPropertyType.contentEquals("House")) {
				CommonAppMethodsYourNewHome.selectTypeofHouse(strInputHouseType); // Select Type of House in "Type of house" 
				Thread.sleep(500);
	   		 	}
	   		 	
			Utility.sendKeys("//*[@id=\"sqFeet\"]", strInputSquareFeet); // Enter "Area of Property" 
			Thread.sleep(500);
			Utility.clickObject("ehome.areaOfProp.continue.button", "Button"); // Click on Continue
			Thread.sleep(1000);
			Thread.sleep(1000);
			Utility.sendKeys("ehome.PurchasePrice.inputtextbox", strInputPurchasePrice); // Enter "Purchase Price" in Purchase Price
			Thread.sleep(500);
			Utility.clickObject("ehome.areaOfProp.continue.button", "Button"); // Click on Continue
			Thread.sleep(4000);      	
			
			if (strInputDownPymtSrcBankAcct.contentEquals("Bank account")) {
	     		CommonAppMethodsYourNewHome.selectDownPaymentSources(strInputDownPymtSrcBankAcct); // Select "Bank account" option 
	     	}
	     	if (strInputDownPymtSrcInvAcct.contentEquals("Investment account")) {
	     		CommonAppMethodsYourNewHome.selectDownPaymentSources(strInputDownPymtSrcInvAcct); // Select "Investment account" option 
	     	}
	     	if (strInputDownPymtSrcFamilyGift.contentEquals("A gift from family")) {
	     		CommonAppMethodsYourNewHome.selectDownPaymentSources(strInputDownPymtSrcFamilyGift); // Select "A gift from family" option 
	     	}
	     	if (strInputDownPymtSrcRRSP.contentEquals("RRSP withdrawal")) {
	     		CommonAppMethodsYourNewHome.selectDownPaymentSources(strInputDownPymtSrcRRSP); // Select "RRSP withdrawal" option 
	     	}
	     	if (strInputDownPymtSrcSaleOfAss.contentEquals("Sale of asset")) {
	     		CommonAppMethodsYourNewHome.selectDownPaymentSources(strInputDownPymtSrcSaleOfAss); // Select "Sale of asset" option 
	     	}
	 	
	     	if (strInputDownPymtSrcSaleOfExist.contentEquals("Sale of existing property")) {
	     		CommonAppMethodsYourNewHome.selectDownPaymentSources(strInputDownPymtSrcSaleOfExist); // Select "Sale of existing property" option 
	     	}
	     	
	     	Thread.sleep(250);  
	     	Utility.clickObject("ehome.areaOfProp.continue.button", "Button");
	     	Thread.sleep(2000);

	     	//  ***** STAGE2-Detailed Down Payment Screen# *****
	       if (strInputDownPymtSrcBankAcct != null | strInputDownPymtSrcBankAcctAmt.length() != 0) {
	    	   CommonAppMethodsYourNewHome.enterDownPaymentSourcesAmount(strInputDownPymtSrcBankAcct, strInputDownPymtSrcBankAcctAmt);
	       		Thread.sleep(500); 
	     	}
	     	if (strInputDownPymtSrcInvAcct != null | strInputDownPymtSrcInvAcctAmt.length() != 0) {
	     		CommonAppMethodsYourNewHome.enterDownPaymentSourcesAmount(strInputDownPymtSrcInvAcct, strInputDownPymtSrcInvAcctAmt);
	     		Thread.sleep(500);  
	     	}
	     	if (strInputDownPymtSrcFamilyGift != null | strInputDownPymtSrcFamilyGiftAmt.length() != 0) {
	     		CommonAppMethodsYourNewHome.enterDownPaymentSourcesAmount(strInputDownPymtSrcFamilyGift, strInputDownPymtSrcFamilyGiftAmt);
	     		Thread.sleep(500);  
	     	}
	     	if (strInputDownPymtSrcRRSP != null | strInputDownPymtSrcRRSPAmt.length() != 0) {
	     		CommonAppMethodsYourNewHome.enterDownPaymentSourcesAmount(strInputDownPymtSrcRRSP, strInputDownPymtSrcRRSPAmt);
	     		Thread.sleep(500);  
	     	}
	     	if (strInputDownPymtSrcSaleOfAss != null | strInputDownPymtSrcSaleOfAssAmt.length() != 0) {
	     		CommonAppMethodsYourNewHome.enterDownPaymentSourcesAmount(strInputDownPymtSrcSaleOfAss, strInputDownPymtSrcSaleOfAssAmt);
	     		Thread.sleep(500);  
	     	}
	     	if (strInputDownPymtSrcSaleOfExist != null | strInputDownPymtSrcSaleOfExistAmt.length() != 0) {
	     		CommonAppMethodsYourNewHome.enterDownPaymentSourcesAmount(strInputDownPymtSrcSaleOfExist, strInputDownPymtSrcSaleOfExistAmt);
	     		Thread.sleep(500);  
	     	}

			Utility.clickObject("ehome.detailsofdownpayment.ContinueButtonDetails", "Button"); // Click on Continue
	     	//Utility.clickObject("//*[@id=\"app\"]/div/div[1]/div[4]/button[2]/span", "Button"); // Click on Continue
	     	Thread.sleep(1000);
	        	
	      	Utility.clickObject("ehome.closingDtPicker.button", "Button");
	      	Thread.sleep(250);
	     	Utility.clickObject("ehome.closingDtPickerSelection.button", "Button");
	     	Thread.sleep(250);
	      	Utility.clickObject("ehome.CloseDtContinue.button", "Button"); // Click on Continue
	      	
	     	Utility.clickObject("ehome.detailsofdownpayment.ContinueButtonDetails", "Button"); // Click on Continue button in Details of 
	     	//Common.continueButtonClicked();
	      	Thread.sleep(500);
	     	Utility.clickObject("//*[@id='app']/div/div[1]/div[2]/div/div[3]/div/button", "Section Breaker of Stage2 & Stage3");
	     	Thread.sleep(2000);
			
			Thread.sleep(1000); 
			CommonAppMethodsGettingNewRate.selectRateType(strInputTypeOfRate); // Select "Type of Rate" option 
	    	Thread.sleep(1000);

	    	if (strInputTypeOfRate.contentEquals("Fixed")) {
	    		Thread.sleep(6000);
	    		CommonAppMethodsGettingNewRate.selectMortgageTerm(strInputMortgageTerm); // Select "Mortgage Term" option 
	    		Thread.sleep(4000);
	    	}
	      	CommonAppMethodsGettingNewRate.chooseRatesfromRatePresentment(strInputTypeOfRate, strInputMortgageTerm); // Choose Rates button
	    	Thread.sleep(1000);
			Utility.clickObject("ehome.ratelock.LockandHold", "Button"); // Click on Lock & Hold button
	    	Thread.sleep(500);
	    	if (strInputRateCustomization.contentEquals("Unlockyourrate")) {
	    		Utility.clickObject("ehome.rateunlock.UnlockyourrateBtn", "Button"); // Click on Unlock your rate
	    		Thread.sleep(1000);
	    		if (strInputRateUnlock.contentEquals("Yes, unlock my rate")) {
	    			Utility.clickObject("ehome.rateunlock.Yesunlockmyrate", "Button"); // Click on Yes, unlock my rate
	    			return;
	    		}
	    		if (strInputRateUnlock.contentEquals("No, keep my rate")) {
	    			Utility.clickObject("ehome.rateunlock.Nokeepmyrate", "Button"); // Click on No, keep my rate
	    		}
	    	}
	    	Utility.clickObject("ehome.RateCustContiniueBtn", "Button"); // Click on Continue button
	    	QAFExtendedWebElement strActualSTEPTitle= new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[2]/div/div[2]/h2");
	    	if(strActualSTEPTitle.getText().contains("Plan (STEP)")) //"STEP" Title
	    	{
	    		Utility.clickObject("ehome.STEPContiniueBtn", "Button");
	    	}	
	    	else
	    	{
	    		System.err.printf("Plan (STEP) is NOT displayed", strActualSTEPTitle.getText());
	    	}
	    	
	    	Double dbPurchasePrice = Double.valueOf(strInputPurchasePrice);
	    	Double dbDownPayment = 	Double.valueOf(strInputDownPayment);
	    	Double defaultInsurance =  dbDownPayment/dbPurchasePrice*100;
	    	
	    	if(defaultInsurance >= 20.0)
	    	{
	    		if (strInputRateEquity.contentEquals("Yes, I'm interested")) {
	    			Utility.clickObject("ehome.step.yesImInterestedBtn", "Button");
	    			Utility.clickObject("ehome.CloseDtContinue.button", "Button");
	    		}
	    	}
//	    	if (strInputRateEquity.contentEquals("No thanks")) {
//	    		QAFExtendedWebElement NothanksBtn= new QAFExtendedWebElement("ehome.step.NothanksBtn");
//	    		NothanksBtn.click(); // Click on Continue
//	    	}
	    	Utility.clickObject("ehome.RateViewContinueBtn", "Button");
	    	Utility.clickObject("//*[@id=\"app\"]/div/div[1]/div/div/div[3]/div/button/span", "Button");
			}
		
		/* *************************************************************************************************************************************************
		 Author: 	  RameshChalumuri
		 Method Name: PreCondition_Traverse_Stage1_to_Stage2_functionality
		 Purpose: 	  Traversing Stage1 (WelcomeTriage Questions & Prospect Registration) to Entry of Stage2 (Employment)
		 Created on:  06-October-2018  
		 Updated By:  
		 Updated on:  
		 *************************************************************************************************************************************************** */
			@Given("^Traverse Stage1 to Entry of Stage2$")
				public void PreCondition_Traverse_Stage1_to_Stage2_functionality() throws Throwable {
				
					//String strtestCaseID = Utility.getScenarioID();
					Utility.launchURL(ConfigurationUtils.getBaseBundle().getPropertyValue ("env.baseurl0"));
			 		ExtentReportHelper.StepPass("Welcome to eHOME! Screen is displayed.");
			 		Welcome.viewOurPrivacyAgreementButtonClicked();
			 		Thread.sleep(2000);
					ExtentReportHelper.StepPass("Privacy agreement Screen is displayed.");
					PrivacyAgreement.acceptAndContinuetButtonClicked();
					Thread.sleep(2000);
					SOLCustomerQuestion.triageQuestionsButtonClicked();
					Thread.sleep(2000);
					ExtentReportHelper.StepPass("Triage Questions are verified.");
					SOLCustomerQuestion.noButtonClicked();
					Thread.sleep(2000);
					LegalName.validlegalname("Mrs", "Delna", "Dr", "Press");
					ExtentReportHelper.StepPass("Legal Name screen is displayed.");
					Common.continueButtonClicked();
					Thread.sleep(2000);
					ExtentReportHelper.StepPass("Marital Status screen is displayed.");
					MaritalStatus.maritalstatusselect("Married");
					Thread.sleep(2000);
					Common.continueButtonClicked();
					Thread.sleep(2000);
					ExtentReportHelper.StepPass("Date Of Birth screen is displayed.");
					DateOfBirth.dateOfBirth("20", "Mar", "1998");
					Common.continueButtonClicked();
					Thread.sleep(2000);
					ExtentReportHelper.StepPass("Address screen is displayed.");
					WhatsYourAddress.ValidWhatsYourAddressValues("2201", "EGLINTON AVE", "TORONTO", "ONTARIO","M1K2M1");
					Common.continueButtonClicked();
					Thread.sleep(2000);
					ExtentReportHelper.StepPass("Email Address screen is displayed."); 
					EmailAddress.ValidEmailAddress("test@test.com", "test@test.com");
					Common.continueButtonClicked();			
			}

	
			/* *************************************************************************************************************************************************
 			Author: 	  RameshChalumuri
 			Method Name: PreCondition_Traverse_Stage1_to_Stage3_functionality
 			Purpose: 	  Traversing Stage1 (WelcomeTriage Questions & Prospect Registration) to Entry of Stage3 (Getting New Rate)
 			Created on:  06-October-2018  
 			Updated By:  RameshChalumuri
 			Updated on:  11-October-2018
			*************************************************************************************************************************************************** */
			@Given("^Traverse Stage1 to Entry of Stage3$")
			public void PreCondition_Traverse_Stage1_to_Stage3_functionality() throws Throwable {

				String strtestCaseID = Utility.getScenarioID();
				Utility.launchURL(ConfigurationUtils.getBaseBundle ().getPropertyValue ("env.baseurl1")); 
				
			// Passing "Excel Path", "Sheet name", "Test Case ID" as parameters
			Map<String, String> E2E_ExcelData =  Utility.readTestData(strfullPathToFile, sheetNameE2E,strtestCaseID);
				String strExpectedAddress= E2E_ExcelData.get("Address"); 										// Retrieve "Address" from Excel 
		    	String strExpectedPropertyType= E2E_ExcelData.get("PropertyType");								// Retrieve "PropertyType" from Excel 
		    	String strExpectedHouseType= E2E_ExcelData.get("HouseType");									// Retrieve "HouseType" from Excel
		    	String strExpectedCondoFees = E2E_ExcelData.get("CondoFees");									// Retrieve "CondoFees" from Excel
		    	String strExpectedSquareFeet  = E2E_ExcelData.get("SquareFeet");								// Retrieve "SquareFeet" from Excel
		    	String strExpectedPurchasePrice  = E2E_ExcelData.get("PurchasePrice");							// Retrieve "PurchasePrice" from Excel
		      	String strExpectedDownPayment  = E2E_ExcelData.get("DownPayment");								// Retrieve "DownPayment" from Excel
		      	String strExpectedDownPymtSrcBankAcct  = E2E_ExcelData.get("DownPymtSrcBankAcct");				// Retrieve "DownPymtSrcBankAcct" from Excel
		    	String strExpectedDownPymtSrcInvAcct  = E2E_ExcelData.get("DownPymtSrcInvAcct");				// Retrieve "DownPymtSrcInvAcct" from Excel
		    	String strExpectedDownPymtSrcFamilyGift  = E2E_ExcelData.get("DownPymtSrcFamilyGift");			// Retrieve "DownPymtSrcFamilyGift" from Excel
		    	String strExpectedDownPymtSrcRRSP  = E2E_ExcelData.get("DownPymtSrcRRSP");						// Retrieve "DownPymtSrcRRSP" from Excel
		    	String strExpectedDownPymtSrcSaleOfAss  = E2E_ExcelData.get("DownPymtSrcSaleOfAss");			// Retrieve "DownPymtSrcSaleOfAss" from Excel
		    	String strExpectedDownPymtSrcSaleOfExist  = E2E_ExcelData.get("DownPymtSrcSaleOfExist");		// Retrieve "DownPymtSrcSaleOfExist" from Excel
		    	String strExpectedDownPymtSrcBankAcctAmt  = E2E_ExcelData.get("DownPymtSrcBankAcctAmt");		// Retrieve "DownPymtSrcBankAcctAmt" from Excel
		    	String strExpectedDownPymtSrcInvAcctAmt  = E2E_ExcelData.get("DownPymtSrcInvAcctAmt");			// Retrieve "DownPymtSrcnvAcctAmt" from Excel
		    	String strExpectedDownPymtSrcFamilyGiftAmt  = E2E_ExcelData.get("DownPymtSrcFamilyGiftAmt");	// Retrieve "DownPymtSrcFamilyGiftAmt" from Excel		
		    	String strExpectedDownPymtSrcRRSPAmt  = E2E_ExcelData.get("DownPymtSrcRRSPAmt");				// Retrieve "DownPymtSrcRRSPAmt" from Excel
		    	String strExpectedDownPymtSrcSaleOfAssAmt  = E2E_ExcelData.get("DownPymtSrcSaleOfAssAmt");		// Retrieve "DownPymtSrcSaleOfAssAmt" from Excel
		    	String strExpectedDownPymtSrcSaleOfExistAmt  = E2E_ExcelData.get("DownPymtSrcSaleOfExistAmt");	// Retrieve "DownPymtSrcSaleOfExistAmt" from Excel
	      
    		Thread.sleep(5000);

    		if (strExpectedAddress.contentEquals("Manual Address")) {
	     		CommonApplicationMethods.enterAddressManually(); // Select Address Manually in "Address of your new home"
	     	}
	     	else
	     	{
	     		CommonApplicationMethods.enterAutoSuggestAddress("4 KINGSWAY CRES", "//*[@id=\"address-lookup\"]", "//*[@id=\"app\"]/div/div[1]/div[1]/section/div[3]/div/div[1]/div/div[2]/div/ul/li");
	     	}
     	
	     	Thread.sleep(4000);
	     	CommonAppMethodsYourNewHome.selectPropertyType(strExpectedPropertyType); // Select Property Type in "Type of Property"
	     	Thread.sleep(2000);
	     	
	     	if (strExpectedPropertyType.contentEquals("Condo")) {
	     		Utility.sendKeys("ehome.CondoFees.CondoFees.input", strExpectedCondoFees); // Enter "Condo fee" in "Type of Property" 
	     		Thread.sleep(500);
	     		Utility.clickObject("ehome.CloseDtContinue.button", "Button"); // Click on Continue in "Type of Property"  
	      		Thread.sleep(500);
	     	}
	     	if (strExpectedPropertyType.contentEquals("House")) {
	     		CommonAppMethodsYourNewHome.selectTypeofHouse(strExpectedHouseType); // Select Type of House in "Type of house" 
	     		Thread.sleep(500);
	     	}
	     	Utility.sendKeys("ehome.areaOfProp.squrft.value", strExpectedSquareFeet); // Enter "Area of Property" 
	     	Thread.sleep(500);
	    	Utility.clickObject("ehome.areaOfProp.continue.button", "Button"); // Click on Continue
	    	Thread.sleep(500);
	     	Utility.sendKeys("ehome.PurchasePrice.inputtextbox", strExpectedPurchasePrice); // Enter "Purchase Price" in Purchase Price
	     	Thread.sleep(500);
	    	Utility.clickObject("ehome.areaOfProp.continue.button", "Button"); // Click on Continue
	    	Thread.sleep(500);
	    	Utility.sendKeys("ehome.DownPayement.Price", strExpectedDownPayment); // Enter "Down Payment Amount" in Down Payment
	     	Thread.sleep(500);
	     	Utility.clickObject("ehome.areaOfProp.continue.button", "Button"); // Click on Continue
	     	Thread.sleep(1000);
	 	
	     	if (strExpectedDownPymtSrcBankAcct.contentEquals("Bank account")) {
	     		CommonAppMethodsYourNewHome.selectDownPaymentSources(strExpectedDownPymtSrcBankAcct); // Select "Bank account" option 
	     	}
	     	if (strExpectedDownPymtSrcInvAcct.contentEquals("Investment account")) {
	     		CommonAppMethodsYourNewHome.selectDownPaymentSources(strExpectedDownPymtSrcInvAcct); // Select "Investment account" option 
	     	}
	     	if (strExpectedDownPymtSrcFamilyGift.contentEquals("A gift from family")) {
	     		CommonAppMethodsYourNewHome.selectDownPaymentSources(strExpectedDownPymtSrcFamilyGift); // Select "A gift from family" option 
	     	}
	     	if (strExpectedDownPymtSrcRRSP.contentEquals("RRSP withdrawal")) {
	     		CommonAppMethodsYourNewHome.selectDownPaymentSources(strExpectedDownPymtSrcRRSP); // Select "RRSP withdrawal" option 
	     	}
	     	if (strExpectedDownPymtSrcSaleOfAss.contentEquals("Sale of asset")) {
	     		CommonAppMethodsYourNewHome.selectDownPaymentSources(strExpectedDownPymtSrcSaleOfAss); // Select "Sale of asset" option 
	     	}
     	
	     	if (strExpectedDownPymtSrcSaleOfExist.contentEquals("Sale of existing property")) {
	     		CommonAppMethodsYourNewHome.selectDownPaymentSources(strExpectedDownPymtSrcSaleOfExist); // Select "Sale of existing property" option 
	     	}
	     	Thread.sleep(250);  
	     	Utility.clickObject("ehome.areaOfProp.continue.button", "Button");
	     	Thread.sleep(250);  
	     	
	     	//  ***** STAGE2-Detailed Down Payment Screen# *****
	       if (strExpectedDownPymtSrcBankAcct != null | strExpectedDownPymtSrcBankAcctAmt.length() != 0) {
	    	   CommonAppMethodsYourNewHome.enterDownPaymentSourcesAmount(strExpectedDownPymtSrcBankAcct, strExpectedDownPymtSrcBankAcctAmt);
	       		Thread.sleep(500); 
	     	}
	     	if (strExpectedDownPymtSrcInvAcct != null | strExpectedDownPymtSrcInvAcctAmt.length() != 0) {
	     		CommonAppMethodsYourNewHome.enterDownPaymentSourcesAmount(strExpectedDownPymtSrcInvAcct, strExpectedDownPymtSrcInvAcctAmt);
	     		Thread.sleep(500);  
	     	}
	     	if (strExpectedDownPymtSrcFamilyGift != null | strExpectedDownPymtSrcFamilyGiftAmt.length() != 0) {
	     		CommonAppMethodsYourNewHome.enterDownPaymentSourcesAmount(strExpectedDownPymtSrcFamilyGift, strExpectedDownPymtSrcFamilyGiftAmt);
	     		Thread.sleep(500);  
	     	}
	     	if (strExpectedDownPymtSrcRRSP != null | strExpectedDownPymtSrcRRSPAmt.length() != 0) {
	     		CommonAppMethodsYourNewHome.enterDownPaymentSourcesAmount(strExpectedDownPymtSrcRRSP, strExpectedDownPymtSrcRRSPAmt);
	     		Thread.sleep(500);  
	     	}
	     	if (strExpectedDownPymtSrcSaleOfAss != null | strExpectedDownPymtSrcSaleOfAssAmt.length() != 0) {
	     		CommonAppMethodsYourNewHome.enterDownPaymentSourcesAmount(strExpectedDownPymtSrcSaleOfAss, strExpectedDownPymtSrcSaleOfAssAmt);
	     		Thread.sleep(500);  
	     	}
	     	if (strExpectedDownPymtSrcSaleOfExist != null | strExpectedDownPymtSrcSaleOfExistAmt.length() != 0) {
	     		CommonAppMethodsYourNewHome.enterDownPaymentSourcesAmount(strExpectedDownPymtSrcSaleOfExist, strExpectedDownPymtSrcSaleOfExistAmt);
	     		Thread.sleep(500);  
	     	}
	     	Utility.clickObject("ehome.detailsofdownpayment.ContinueButtonDetails", "Button"); // Click on Continue
	      	Thread.sleep(250);
	      	Utility.clickObject("ehome.closingDtPicker.button", "Button");
	     	Thread.sleep(250);
	     	Utility.clickObject("ehome.closingDtPickerSelection.button", "Button");
	     	Thread.sleep(250);
	      	Utility.clickObject("ehome.CloseDtContinue.button", "Button"); // Click on Continue
	      	Thread.sleep(250);
	     	Utility.clickObject("ehome.detailsofdownpayment.ContinueButtonDetails", "Button"); // Click on Continue button in Details of 
	     	Thread.sleep(250);
	      }
	
	
	 /* *************************************************************************************************************************************************
	 Author: 	  RameshChalumuri
	 Method Name: PreCondition_Traverse_Stage1_to_Entry_of_Stage4_functionality
	 Purpose: 	  PreCondition Traverse Stage1 (WelcomeTriage Questions & Prospect Registration) to Entry of Stage4 (Employment) 
	 Created on:  06-October-2018  
	 Updated By:  RameshChalumuri	
	 Updated on:  06-November-2018
	 *************************************************************************************************************************************************** */
		 
	 @Given("^Traverse Stage1 to Entry of Stage4$")
	 public void PreCondition_Traverse_Stage1_to_Entry_of_Stage4_functionality() throws Throwable 
	 {
		 
		 	String strtestCaseID = Utility.getScenarioID();
			Utility.launchURL(ConfigurationUtils.getBaseBundle ().getPropertyValue ("env.baseurl1")); 

			// Passing "Excel Path", "Sheet name", "Test Case ID" as parameters
			Map<String, String> E2E_ExcelData =  Utility.readTestData(strfullPathToFile, sheetNameE2E,strtestCaseID);
		    	String strExpectedAddress= E2E_ExcelData.get("Address"); 										// Retrieve "Address" from Excel 
		    	String strExpectedPropertyType= E2E_ExcelData.get("PropertyType");								// Retrieve "PropertyType" from Excel 
		    	String strExpectedHouseType= E2E_ExcelData.get("HouseType");									// Retrieve "HouseType" from Excel
		    	String strExpectedCondoFees = E2E_ExcelData.get("CondoFees");									// Retrieve "CondoFees" from Excel
		    	String strExpectedSquareFeet  = E2E_ExcelData.get("SquareFeet");								// Retrieve "SquareFeet" from Excel
		    	String strExpectedPurchasePrice  = E2E_ExcelData.get("PurchasePrice");							// Retrieve "PurchasePrice" from Excel
		    	String strExpectedDownPayment  = E2E_ExcelData.get("DownPayment");								// Retrieve "DownPayment" from Excel
		    	String strExpectedDownPymtSrcBankAcct  = E2E_ExcelData.get("DownPymtSrcBankAcct");				// Retrieve "DownPymtSrcBankAcct" from Excel
		    	String strExpectedDownPymtSrcInvAcct  = E2E_ExcelData.get("DownPymtSrcInvAcct");				// Retrieve "DownPymtSrcInvAcct" from Excel
		    	String strExpectedDownPymtSrcFamilyGift  = E2E_ExcelData.get("DownPymtSrcFamilyGift");			// Retrieve "DownPymtSrcFamilyGift" from Excel
		    	String strExpectedDownPymtSrcRRSP  = E2E_ExcelData.get("DownPymtSrcRRSP");						// Retrieve "DownPymtSrcRRSP" from Excel
		    	String strExpectedDownPymtSrcSaleOfAss  = E2E_ExcelData.get("DownPymtSrcSaleOfAss");			// Retrieve "DownPymtSrcSaleOfAss" from Excel
		    	String strExpectedDownPymtSrcSaleOfExist  = E2E_ExcelData.get("DownPymtSrcSaleOfExist");		// Retrieve "DownPymtSrcSaleOfExist" from Excel
		    	String strExpectedDownPymtSrcBankAcctAmt  = E2E_ExcelData.get("DownPymtSrcBankAcctAmt");		// Retrieve "DownPymtSrcBankAcctAmt" from Excel
		    	String strExpectedDownPymtSrcInvAcctAmt  = E2E_ExcelData.get("DownPymtSrcInvAcctAmt");			// Retrieve "DownPymtSrcnvAcctAmt" from Excel
		    	String strExpectedDownPymtSrcFamilyGiftAmt  = E2E_ExcelData.get("DownPymtSrcFamilyGiftAmt");	// Retrieve "DownPymtSrcFamilyGiftAmt" from Excel		
		    	String strExpectedDownPymtSrcRRSPAmt  = E2E_ExcelData.get("DownPymtSrcRRSPAmt");				// Retrieve "DownPymtSrcRRSPAmt" from Excel
		    	String strExpectedDownPymtSrcSaleOfAssAmt  = E2E_ExcelData.get("DownPymtSrcSaleOfAssAmt");		// Retrieve "DownPymtSrcSaleOfAssAmt" from Excel
		    	String strExpectedDownPymtSrcSaleOfExistAmt  = E2E_ExcelData.get("DownPymtSrcSaleOfExistAmt");	// Retrieve "DownPymtSrcSaleOfExistAmt" from Excel
		    	String strTypeOfRate            = E2E_ExcelData.get("TypeOfRate"); // Retrieve "TypeOfRate" from Excel 
		    	String strMortgageTerm          = E2E_ExcelData.get("MortgageTerm");// Retrieve "MortgageTerm" from Excel 
		       	String strratecustomization     = E2E_ExcelData.get("RateCustomization");// Retrieve "UnLockYourRate" from Excel
		    	String strrateunlock            = E2E_ExcelData.get("RateUnlock");// Retrieve "RateUnlock" from Excel
		    	String strrateequity            = E2E_ExcelData.get("RateEquity");// Retrieve "Rate Equity" from Excel 

	    	Thread.sleep(500);
	     
	     	if (strExpectedAddress.contentEquals("Manual Address")) {
	     		CommonApplicationMethods.enterAddressManually(); // Select Address Manually in "Address of your new home"
	     	}
	     	else
	     	{
	     		CommonApplicationMethods.enterAutosuggestaddress(strExpectedAddress); // Enters Auto suggest address (DMTI field) in Address screen 
	     	}
	     	
	     	Thread.sleep(4000);
	     	CommonAppMethodsYourNewHome.selectPropertyType(strExpectedPropertyType); // Select Property Type in "Type of Property"
	     	Thread.sleep(3000);
	     	
	     	if (strExpectedPropertyType.contentEquals("Condo")) {
	     		Utility.sendKeys("ehome.CondoFees.CondoFees.input", strExpectedCondoFees); // Enter "Condo fee" in "Type of Property" 
	     		Thread.sleep(1000);
	     		Utility.clickObject("ehome.CloseDtContinue.button", "Button"); // Click on Continue in "Type of Property"  
	      		Thread.sleep(2000);
	     	}
	        
	     	if (strExpectedPropertyType.contentEquals("House")) {
	     		CommonAppMethodsYourNewHome.selectTypeofHouse(strExpectedHouseType); // Select Type of House in "Type of house" 
	     		Thread.sleep(2000);
	     	}
	       
	     	Utility.sendKeys("ehome.areaOfProp.squrft.value", strExpectedSquareFeet); // Enter "Area of Property" 
	     	Thread.sleep(500);
	    	Utility.clickObject("ehome.areaOfProp.continue.button", "Button"); // Click on Continue
	    	Thread.sleep(500);
	     	Utility.sendKeys("ehome.PurchasePrice.inputtextbox", strExpectedPurchasePrice); // Enter "Purchase Price" in Purchase Price
	     	Thread.sleep(500);
	    	Utility.clickObject("ehome.areaOfProp.continue.button", "Button"); // Click on Continue
	    	Thread.sleep(500);
	    	Utility.sendKeys("ehome.DownPayement.Price", strExpectedDownPayment); // Enter "Down Payment Amount" in Down Payment
	     	Thread.sleep(500);
	     	Utility.clickObject("ehome.areaOfProp.continue.button", "Button"); // Click on Continue
	     	Thread.sleep(1000);
	     	
	     	if (strExpectedDownPymtSrcBankAcct.contentEquals("Bank account")) {
	     		CommonAppMethodsYourNewHome.selectDownPaymentSources(strExpectedDownPymtSrcBankAcct); // Select "Bank account" option 
	     	}
	     	if (strExpectedDownPymtSrcInvAcct.contentEquals("Investment account")) {
	     		CommonAppMethodsYourNewHome.selectDownPaymentSources(strExpectedDownPymtSrcInvAcct); // Select "Investment account" option 
	     	}
	     	if (strExpectedDownPymtSrcFamilyGift.contentEquals("A gift from family")) {
	     		CommonAppMethodsYourNewHome.selectDownPaymentSources(strExpectedDownPymtSrcFamilyGift); // Select "A gift from family" option 
	     	}
	     	if (strExpectedDownPymtSrcRRSP.contentEquals("RRSP withdrawal")) {
	     		CommonAppMethodsYourNewHome.selectDownPaymentSources(strExpectedDownPymtSrcRRSP); // Select "RRSP withdrawal" option 
	     	}
	     	if (strExpectedDownPymtSrcSaleOfAss.contentEquals("Sale of asset")) {
	     		CommonAppMethodsYourNewHome.selectDownPaymentSources(strExpectedDownPymtSrcSaleOfAss); // Select "Sale of asset" option 
	     	}
	     	if (strExpectedDownPymtSrcSaleOfExist.contentEquals("Sale of existing property")) {
	     		CommonAppMethodsYourNewHome.selectDownPaymentSources(strExpectedDownPymtSrcSaleOfExist); // Select "Sale of existing property" option 
	     	}
	     	Thread.sleep(500);  
	     	Utility.clickObject("ehome.areaOfProp.continue.button", "Button");
	     	Thread.sleep(500);  
	     	
	     	//  ***** STAGE2-Detailed Down Payment Screen# *****
	       if (strExpectedDownPymtSrcBankAcct != null | strExpectedDownPymtSrcBankAcctAmt.length() != 0) {
	    	   CommonAppMethodsYourNewHome.enterDownPaymentSourcesAmount(strExpectedDownPymtSrcBankAcct, strExpectedDownPymtSrcBankAcctAmt);
	       		Thread.sleep(500); 
	     	}
	     	if (strExpectedDownPymtSrcInvAcct != null | strExpectedDownPymtSrcInvAcctAmt.length() != 0) {
	     		CommonAppMethodsYourNewHome.enterDownPaymentSourcesAmount(strExpectedDownPymtSrcInvAcct, strExpectedDownPymtSrcInvAcctAmt);
	     		Thread.sleep(500);  
	     	}
	     	if (strExpectedDownPymtSrcFamilyGift != null | strExpectedDownPymtSrcFamilyGiftAmt.length() != 0) {
	     		CommonAppMethodsYourNewHome.enterDownPaymentSourcesAmount(strExpectedDownPymtSrcFamilyGift, strExpectedDownPymtSrcFamilyGiftAmt);
	     		Thread.sleep(500);  
	     	}
	     	if (strExpectedDownPymtSrcRRSP != null | strExpectedDownPymtSrcRRSPAmt.length() != 0) {
	     		CommonAppMethodsYourNewHome.enterDownPaymentSourcesAmount(strExpectedDownPymtSrcRRSP, strExpectedDownPymtSrcRRSPAmt);
	     		Thread.sleep(500);  
	     	}
	     	if (strExpectedDownPymtSrcSaleOfAss != null | strExpectedDownPymtSrcSaleOfAssAmt.length() != 0) {
	     		CommonAppMethodsYourNewHome.enterDownPaymentSourcesAmount(strExpectedDownPymtSrcSaleOfAss, strExpectedDownPymtSrcSaleOfAssAmt);
	     		Thread.sleep(500);  
	     	}
	     	if (strExpectedDownPymtSrcSaleOfExist != null | strExpectedDownPymtSrcSaleOfExistAmt.length() != 0) {
	     		CommonAppMethodsYourNewHome.enterDownPaymentSourcesAmount(strExpectedDownPymtSrcSaleOfExist, strExpectedDownPymtSrcSaleOfExistAmt);
	     		Thread.sleep(500);  
	     	}
	     	
	    	Utility.clickObject("ehome.detailsofdownpayment.ContinueButtonDetails", "Button"); // Click on Continue
	      	Thread.sleep(500);
	      	Utility.clickObject("ehome.closingDtPicker.button", "Button");
	     	Thread.sleep(500);
	     	Utility.clickObject("ehome.closingDtPickerSelection.button", "Button");
	     	Thread.sleep(500);
	      	Utility.clickObject("ehome.CloseDtContinue.button", "Button"); // Click on Continue
	      	Thread.sleep(500);
	     	Utility.clickObject("ehome.detailsofdownpayment.ContinueButtonDetails", "Button"); // Click on Continue button in Details of 
	     	Thread.sleep(500);
	      	Utility.clickObject("ehome.Stage3SectionBrkContinue.button", "Button"); // Click on "Continue" button 
	  	   // Stag 2 End Here //***********************************************	 
	  
	    	CommonAppMethodsGettingNewRate.selectRateType(strTypeOfRate); // Select "Type of Rate" option 
	    	Thread.sleep(2000);
    		    	
	    	if (strTypeOfRate.contentEquals("Fixed")) {
	    		CommonAppMethodsGettingNewRate.selectMortgageTerm(strMortgageTerm); // Select "Mortgage Term" option 
	    		Thread.sleep(1000);
	    	}
	    
	    	CommonAppMethodsGettingNewRate.chooseRatesfromRatePresentment(strTypeOfRate, strMortgageTerm); // Choose Rates button
	    	Thread.sleep(500);
	    	Utility.clickObject("ehome.ratelock.LockandHold", "Button"); // Click on Lock & Hold button
	    	Thread.sleep(500);
	    	if (strratecustomization.contentEquals("Unlockyourrate")) {
	    		Utility.clickObject("ehome.rateunlock.UnlockyourrateBtn", "Button"); // Click on Unlock your rate
	    		Thread.sleep(1000);
	    		if (strrateunlock.contentEquals("Yes, unlock my rate")) {
	    			Utility.clickObject("ehome.rateunlock.Yesunlockmyrate", "Button"); // Click on Yes, unlock my rate
	    			return;
	    		}
	    		if (strrateunlock.contentEquals("No, keep my rate")) {
	    			Utility.clickObject("ehome.rateunlock.Nokeepmyrate", "Button"); // Click on No, keep my rate
	    		}
	    	}
	    	Utility.clickObject("ehome.RateCustContiniueBtn", "Button"); // Click on Continue button
	    	QAFExtendedWebElement strActualSTEPTitle= new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[2]/div/div[2]/h2");
	    	if(strActualSTEPTitle.getText().contains("Plan (STEP)")) //"STEP" Title
	    	{
	    		Utility.clickObject("ehome.STEPContiniueBtn", "Button");
	    	}	
	    	else
	    	{
	    		System.err.printf("Plan (STEP) is NOT displayed", strActualSTEPTitle.getText());
	    	}
	    	Double dbPurchasePrice = Double.valueOf(strExpectedPurchasePrice);
	    	Double dbDownPayment = 	Double.valueOf(strExpectedDownPayment);
	    	Double defaultInsurance =  dbDownPayment/dbPurchasePrice*100;
	    	
	    	if(defaultInsurance >= 20.0)
	    	{
	    		if (strrateequity.contentEquals("Yes, I'm interested")) {
	    			Utility.clickObject("ehome.step.yesImInterestedBtn", "Button");
	    			Utility.clickObject("ehome.CloseDtContinue.button", "Button");
	    		}
	    	}
	    	if (strrateequity.contentEquals("No thanks")) {
	    		QAFExtendedWebElement NothanksBtn= new QAFExtendedWebElement("ehome.step.NothanksBtn");
	    		NothanksBtn.click(); // Click on Continue
	    	}
	    	Utility.clickObject("ehome.RateViewContinueBtn", "Button");
	 }
	 
	 /* *************************************************************************************************************************************************
	 Author: 	  RameshChalumuri
	 Method Name: PreCondition_Traverse_Stage1_to_Entry_of_Stage5_functionality
	 Purpose: 	  PreCondition Traverse Stage1(WelcomeTriage Questions & Prospect Registration) to Entry of Stage5
	 Created on:  26-October-2018  
	 Updated By:  RameshChalumuri
	 Updated on:  06-November-2018
	 *************************************************************************************************************************************************** */
	 
	 	@Given("^Traverse Stage1 to Entry of Stage5$")
	 	public void PreCondition_Traverse_Stage1_to_Entry_of_Stage5_functionality() throws Throwable 
	 	{
	  		String strtestCaseID = Utility.getScenarioID();
	  		Utility.launchURL(ConfigurationUtils.getBaseBundle ().getPropertyValue ("env.baseurl1"));
	  		// Passing "Excel Path", "Sheet name", "Test Case ID" as parameters
			Map<String, String> E2E_ExcelData =  Utility.readTestData(strfullPathToFile, sheetNameE2E,strtestCaseID);
		    	String strExpectedAddress= E2E_ExcelData.get("Address"); 										// Retrieve "Address" from Excel 
		    	String strExpectedPropertyType= E2E_ExcelData.get("PropertyType");								// Retrieve "PropertyType" from Excel 
		    	String strExpectedHouseType= E2E_ExcelData.get("HouseType");									// Retrieve "HouseType" from Excel
		    	String strExpectedCondoFees = E2E_ExcelData.get("CondoFees");									// Retrieve "CondoFees" from Excel
		    	String strExpectedSquareFeet  = E2E_ExcelData.get("SquareFeet");								// Retrieve "SquareFeet" from Excel
		    	String strExpectedPurchasePrice  = E2E_ExcelData.get("PurchasePrice");							// Retrieve "PurchasePrice" from Excel
		    	String strExpectedDownPayment  = E2E_ExcelData.get("DownPayment");								// Retrieve "DownPayment" from Excel
		    	String strExpectedDownPymtSrcBankAcct  = E2E_ExcelData.get("DownPymtSrcBankAcct");				// Retrieve "DownPymtSrcBankAcct" from Excel
		    	String strExpectedDownPymtSrcInvAcct  = E2E_ExcelData.get("DownPymtSrcInvAcct");				// Retrieve "DownPymtSrcInvAcct" from Excel
		    	String strExpectedDownPymtSrcFamilyGift  = E2E_ExcelData.get("DownPymtSrcFamilyGift");			// Retrieve "DownPymtSrcFamilyGift" from Excel
		    	String strExpectedDownPymtSrcRRSP  = E2E_ExcelData.get("DownPymtSrcRRSP");						// Retrieve "DownPymtSrcRRSP" from Excel
		    	String strExpectedDownPymtSrcSaleOfAss  = E2E_ExcelData.get("DownPymtSrcSaleOfAss");			// Retrieve "DownPymtSrcSaleOfAss" from Excel
		    	String strExpectedDownPymtSrcSaleOfExist  = E2E_ExcelData.get("DownPymtSrcSaleOfExist");		// Retrieve "DownPymtSrcSaleOfExist" from Excel
		    	String strExpectedDownPymtSrcBankAcctAmt  = E2E_ExcelData.get("DownPymtSrcBankAcctAmt");		// Retrieve "DownPymtSrcBankAcctAmt" from Excel
		    	String strExpectedDownPymtSrcInvAcctAmt  = E2E_ExcelData.get("DownPymtSrcInvAcctAmt");			// Retrieve "DownPymtSrcnvAcctAmt" from Excel
		    	String strExpectedDownPymtSrcFamilyGiftAmt  = E2E_ExcelData.get("DownPymtSrcFamilyGiftAmt");	// Retrieve "DownPymtSrcFamilyGiftAmt" from Excel		
		    	String strExpectedDownPymtSrcRRSPAmt  = E2E_ExcelData.get("DownPymtSrcRRSPAmt");				// Retrieve "DownPymtSrcRRSPAmt" from Excel
		    	String strExpectedDownPymtSrcSaleOfAssAmt  = E2E_ExcelData.get("DownPymtSrcSaleOfAssAmt");		// Retrieve "DownPymtSrcSaleOfAssAmt" from Excel
		    	String strExpectedDownPymtSrcSaleOfExistAmt  = E2E_ExcelData.get("DownPymtSrcSaleOfExistAmt");	// Retrieve "DownPymtSrcSaleOfExistAmt" from Excel
		    	
		    	String strTypeOfRate            = E2E_ExcelData.get("TypeOfRate"); // Retrieve "TypeOfRate" from Excel 
		    	String strMortgageTerm          = E2E_ExcelData.get("MortgageTerm");// Retrieve "MortgageTerm" from Excel 
		       	String strratecustomization     = E2E_ExcelData.get("RateCustomization");// Retrieve "UnLockYourRate" from Excel
		    	String strrateunlock            = E2E_ExcelData.get("RateUnlock");// Retrieve "RateUnlock" from Excel
		    	String strrateequity            = E2E_ExcelData.get("RateEquity");// Retrieve "Rate Equity" from Excel 
		       
				String strCurrentEmpStatus	= E2E_ExcelData.get("CurrentEmpStatus"); 	// Retrieve "Current Employment status" from Excel
				String strEmploymentType = E2E_ExcelData.get("EmploymentType");
				String strFieldOfWork=  E2E_ExcelData.get("EmploymentFieldOfWork");
				String strJobTitle=  E2E_ExcelData.get("EmploymentJobTitle");
				String strDurationYear=  E2E_ExcelData.get("Years");
				String strDurationMonth=  E2E_ExcelData.get("Months");
				
				String strChildSupport= E2E_ExcelData.get("EmpOtherSrcsOfIncome1");
				String strCommission= E2E_ExcelData.get("EmpOtherSrcsOfIncome2");
				String strInvestments= E2E_ExcelData.get("EmpOtherSrcsOfIncome3");
				String strPartTimeWork= E2E_ExcelData.get("EmpOtherSrcsOfIncome4");
				String strPensionDisability= E2E_ExcelData.get("EmpOtherSrcsOfIncome5");
				String strRIFLIF= E2E_ExcelData.get("EmpOtherSrcsOfIncome6");
				String strSeasonalWork= E2E_ExcelData.get("EmpOtherSrcsOfIncome7");
			    String strSpousalSupport= E2E_ExcelData.get("EmpOtherSrcsOfIncome8");
				
				String strChildSupportAmt= E2E_ExcelData.get("EmpOtherSrcsOfIncome1Amt");
				String strCommissionAmt= E2E_ExcelData.get("EmpOtherSrcsOfIncome2Amt");
				String strInvestmentsAmt= E2E_ExcelData.get("EmpOtherSrcsOfIncome3Amt");
				String strPartTimeWorkAmt= E2E_ExcelData.get("EmpOtherSrcsOfIncome4Amt");
				String strPensionDisabilityAmt= E2E_ExcelData.get("EmpOtherSrcsOfIncome5Amt");
				String strRIFLIFAmt= E2E_ExcelData.get("EmpOtherSrcsOfIncome6Amt");
				String strSeasonalWorkAmt= E2E_ExcelData.get("EmpOtherSrcsOfIncome7Amt");
				String strSpousalSupportAmt= E2E_ExcelData.get("EmpOtherSrcsOfIncome8Amt");
				
				String strAutomobile = E2E_ExcelData.get("AssetSources1");
				String strCash = E2E_ExcelData.get("AssetSources2");
				String strGICTermDeposit = E2E_ExcelData.get("AssetSources3");
			 	String strPrimaryResidence = E2E_ExcelData.get("AssetSources4");
			  	String strRentalProperty = E2E_ExcelData.get("AssetSources5");
			 	String strRRSP = E2E_ExcelData.get("AssetSources6");
			 	String strSecondaryProperty = E2E_ExcelData.get("AssetSources7");
			 	String strStockBond = E2E_ExcelData.get("AssetSources8");
			 	String strOtherAssets = E2E_ExcelData.get("AssetSources9");
			 	
			 	String strAutomobileAmt = E2E_ExcelData.get("AssetSources1Amt");
			 	String strCashAmt = E2E_ExcelData.get("AssetSources2Amt");
			 	String strGICTermDepositAmt = E2E_ExcelData.get("AssetSources3Amt");
			 	String strPrimaryResidenceAmt = E2E_ExcelData.get("AssetSources4Amt");
			 	String strRentalPropertyAmt = E2E_ExcelData.get("AssetSources5Amt");
			 	String strRRSPAmt = E2E_ExcelData.get("AssetSources6Amt");
			 	String strSecondaryPropertyAmt = E2E_ExcelData.get("AssetSources7Amt");
			 	String strStockBondAmt = E2E_ExcelData.get("AssetSources8Amt");
			 	String strOtherAssetsAmt = E2E_ExcelData.get("AssetSources9Amt");
			 	
			 	String strAlimonyLiability = E2E_ExcelData.get("LiabilitySources1");
			 	String strChildSupportLiability = E2E_ExcelData.get("LiabilitySources2");
			 	String strPrivateDebtLiability = E2E_ExcelData.get("LiabilitySources3");
			 	
			 	String strAlimonyLiabilityMonthlyPaymt = E2E_ExcelData.get("LiabilitySources1MonthlyPaymt");
			 	String strChildSupportLiabilityMonthlyPayment = E2E_ExcelData.get("LiabilitySources2MonthlyPaymt");
			 	String strPrivateDebtLiabilityMonthlyPayment = E2E_ExcelData.get("LiabilitySources3MonthlyPaymt");
			 	String strPrivateDebtLiabilityBalanceOwing = E2E_ExcelData.get("LiabilitySources3BalanceOwing");
			 	String strCoAppCurrentEmpStatus = E2E_ExcelData.get("CoAppCurentEmpStatus");
			 	String strCoAppEmpOtherSrcsOfIncomeNoOtherSrcs= E2E_ExcelData.get("EmpCoAppOtherSrcsOfIncome");
			 																		 
			 	String strCoAppEmpOtherSrcsOfIncomeChildSupport = E2E_ExcelData.get("EmpCoAppOtherSrcsOfIncomeChildSupport");
			 	String strCoAppEmpOtherSrcsOfIncomeChildSupportAmt=E2E_ExcelData.get("EmpCoAppOtherSrcsOfIncomeChildSupportAmt");
			 	String strCoAppEmpOtherSrcsOfIncomeInvest = E2E_ExcelData.get("EmpCoAppOtherSrcsOfIncome");
			 	String strCoAppEmpOtherSrcsOfIncomeInvestAmt=E2E_ExcelData.get("EmpCoAppOtherSrcsOfIncomeInvAmt");
			 	String strCoAppEmpOtherSrcsOfIncomePensionDisability = E2E_ExcelData.get("EmpCoAppOtherSrcsOfIncomePensionDisab");
			 	String strCoAppEmpOtherSrcsOfIncomePensionDisabilityAmt=E2E_ExcelData.get("EmpCoAppOtherSrcsOfIncomePensionDisabAmt");
			 	
		 	Thread.sleep(500);
	    	if (strExpectedAddress.contentEquals("Manual Address")) {
	     		CommonApplicationMethods.enterAddressManually(); // Select Address Manually in "Address of your new home"
	    	}
	     	else
	     	{
	     		CommonApplicationMethods.enterAutosuggestaddress(strExpectedAddress); // Enters Auto suggest address (DMTI field) in Address screen 
	     	}
	     	
	     	Thread.sleep(4000);
	     	CommonAppMethodsYourNewHome.selectPropertyType(strExpectedPropertyType); // Select Property Type in "Type of Property"
	     	Thread.sleep(2000);
	     	
	     	if (strExpectedPropertyType.contentEquals("Condo")) {
	     		Utility.sendKeys("ehome.CondoFees.CondoFees.input", strExpectedCondoFees); // Enter "Condo fee" in "Type of Property" 
	     		Thread.sleep(1000);
	     		Utility.clickObject("ehome.CloseDtContinue.button", "Button"); // Click on Continue in "Type of Property"  
	      		Thread.sleep(2000);
	     	}
	        
	     	if (strExpectedPropertyType.contentEquals("House")) {
	     		CommonAppMethodsYourNewHome.selectTypeofHouse(strExpectedHouseType); // Select Type of House in "Type of house" 
	     		Thread.sleep(2000);
	     	}
	       
	     	Utility.sendKeys("ehome.areaOfProp.squrft.value", strExpectedSquareFeet); // Enter "Area of Property" 
	     	Thread.sleep(500);
	    	Utility.clickObject("ehome.areaOfProp.continue.button", "Button"); // Click on Continue
	    	Thread.sleep(500);
	     	Utility.sendKeys("ehome.PurchasePrice.inputtextbox", strExpectedPurchasePrice); // Enter "Purchase Price" in Purchase Price
	     	Thread.sleep(500);
	    	Utility.clickObject("ehome.areaOfProp.continue.button", "Button"); // Click on Continue
	    	Thread.sleep(500);
	    	Utility.sendKeys("ehome.DownPayement.Price", strExpectedDownPayment); // Enter "Down Payment Amount" in Down Payment
	     	Thread.sleep(500);
	     	Utility.clickObject("ehome.areaOfProp.continue.button", "Button"); // Click on Continue
	     	Thread.sleep(1000);
	     	
	     	if (strExpectedDownPymtSrcBankAcct.contentEquals("Bank account")) {
	     		CommonAppMethodsYourNewHome.selectDownPaymentSources(strExpectedDownPymtSrcBankAcct); // Select "Bank account" option 
	     	}
     		
	     	if (strExpectedDownPymtSrcInvAcct.contentEquals("Investment account")) {
	     		CommonAppMethodsYourNewHome.selectDownPaymentSources(strExpectedDownPymtSrcInvAcct); // Select "Investment account" option 
	     	}
	     	
	     	if (strExpectedDownPymtSrcFamilyGift.contentEquals("A gift from family")) {
	     		CommonAppMethodsYourNewHome.selectDownPaymentSources(strExpectedDownPymtSrcFamilyGift); // Select "A gift from family" option 
	     	}
	     	
	     	if (strExpectedDownPymtSrcRRSP.contentEquals("RRSP withdrawal")) {
	     		CommonAppMethodsYourNewHome.selectDownPaymentSources(strExpectedDownPymtSrcRRSP); // Select "RRSP withdrawal" option 
	     	}
	     	
	     	if (strExpectedDownPymtSrcSaleOfAss.contentEquals("Sale of asset")) {
	     		CommonAppMethodsYourNewHome.selectDownPaymentSources(strExpectedDownPymtSrcSaleOfAss); // Select "Sale of asset" option 
	     	}
	     	
	     	if (strExpectedDownPymtSrcSaleOfExist.contentEquals("Sale of existing property")) {
	     		CommonAppMethodsYourNewHome.selectDownPaymentSources(strExpectedDownPymtSrcSaleOfExist); // Select "Sale of existing property" option 
	     	}
	     	
	     	Thread.sleep(500);  
	     	Utility.clickObject("ehome.areaOfProp.continue.button", "Button");
	     	Thread.sleep(500);  
	     	
	     	//  ***** STAGE2-Detailed Down Payment Screen# *****
	       if (strExpectedDownPymtSrcBankAcct != null | strExpectedDownPymtSrcBankAcctAmt.length() != 0) {
	    	   CommonAppMethodsYourNewHome.enterDownPaymentSourcesAmount(strExpectedDownPymtSrcBankAcct, strExpectedDownPymtSrcBankAcctAmt);
	       		Thread.sleep(500); 
	     	}
	     	if (strExpectedDownPymtSrcInvAcct != null | strExpectedDownPymtSrcInvAcctAmt.length() != 0) {
	     		CommonAppMethodsYourNewHome.enterDownPaymentSourcesAmount(strExpectedDownPymtSrcInvAcct, strExpectedDownPymtSrcInvAcctAmt);
	     		Thread.sleep(500);  
	     	}
	     	if (strExpectedDownPymtSrcFamilyGift != null | strExpectedDownPymtSrcFamilyGiftAmt.length() != 0) {
	     		CommonAppMethodsYourNewHome.enterDownPaymentSourcesAmount(strExpectedDownPymtSrcFamilyGift, strExpectedDownPymtSrcFamilyGiftAmt);
	     		Thread.sleep(500);  
	     	}
	     	if (strExpectedDownPymtSrcRRSP != null | strExpectedDownPymtSrcRRSPAmt.length() != 0) {
	     		CommonAppMethodsYourNewHome.enterDownPaymentSourcesAmount(strExpectedDownPymtSrcRRSP, strExpectedDownPymtSrcRRSPAmt);
	     		Thread.sleep(500);  
	     	}
	     	if (strExpectedDownPymtSrcSaleOfAss != null | strExpectedDownPymtSrcSaleOfAssAmt.length() != 0) {
	     		CommonAppMethodsYourNewHome.enterDownPaymentSourcesAmount(strExpectedDownPymtSrcSaleOfAss, strExpectedDownPymtSrcSaleOfAssAmt);
	     		Thread.sleep(500);  
	     	}
	     	if (strExpectedDownPymtSrcSaleOfExist != null | strExpectedDownPymtSrcSaleOfExistAmt.length() != 0) {
	     		CommonAppMethodsYourNewHome.enterDownPaymentSourcesAmount(strExpectedDownPymtSrcSaleOfExist, strExpectedDownPymtSrcSaleOfExistAmt);
	     		Thread.sleep(500);  
	     	}
	     	
	    	Utility.clickObject("ehome.detailsofdownpayment.ContinueButtonDetails", "Button"); // Click on Continue
	      	Thread.sleep(500);
	      	
	      	Utility.clickObject("ehome.closingDtPicker.button", "Button");
	     	Thread.sleep(500);
	     	Utility.clickObject("ehome.closingDtPickerSelection.button", "Button");
	     	Thread.sleep(500);
	      	Utility.clickObject("ehome.CloseDtContinue.button", "Button"); // Click on Continue
	      	Thread.sleep(500);
	     	Utility.clickObject("ehome.detailsofdownpayment.ContinueButtonDetails", "Button"); // Click on Continue button in Details of 
	     	Thread.sleep(500);
	      	Utility.clickObject("ehome.Stage3SectionBrkContinue.button", "Button"); // Click on "Continue" button 
	  	   // Stag 2 End Here //***********************************************	 
	  
	    	CommonAppMethodsGettingNewRate.selectRateType(strTypeOfRate); // Select "Type of Rate" option 
	    	Thread.sleep(2000);
    		    	
	    	if (strTypeOfRate.contentEquals("Fixed")) {
	    		CommonAppMethodsGettingNewRate.selectMortgageTerm(strMortgageTerm); // Select "Mortgage Term" option 
	    		Thread.sleep(1000);
	    	}
	    
	    	CommonAppMethodsGettingNewRate.chooseRatesfromRatePresentment(strTypeOfRate, strMortgageTerm); // Choose Rates button
	    	Thread.sleep(500);
	    	
	    	Utility.clickObject("ehome.ratelock.LockandHold", "Button"); // Click on Lock & Hold button
	    	Thread.sleep(1000);
	    	if (strratecustomization.contentEquals("Unlockyourrate")) {
	    		Utility.clickObject("ehome.rateunlock.UnlockyourrateBtn", "Button"); // Click on Unlock your rate
	    		Thread.sleep(500);
	    		if (strrateunlock.contentEquals("Yes, unlock my rate")) {
	    			Utility.clickObject("ehome.rateunlock.Yesunlockmyrate", "Button"); // Click on Yes, unlock my rate
	    			return;
	    		}
	    		if (strrateunlock.contentEquals("No, keep my rate")) {
	    			Utility.clickObject("ehome.rateunlock.Nokeepmyrate", "Button"); // Click on No, keep my rate
	    		}
	    	}
	    	Utility.clickObject("ehome.RateCustContiniueBtn", "Button"); // Click on Continue button
	    	QAFExtendedWebElement strActualSTEPTitle= new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[2]/div/div[2]/h2");
	    	if(strActualSTEPTitle.getText().contains("Plan (STEP)")) //"STEP" Title
	    	{
	    		Utility.clickObject("ehome.STEPContiniueBtn", "Button");
	    	}	
	    	else
	    	{
	    		System.err.printf("Plan (STEP) is NOT displayed", strActualSTEPTitle.getText());
	    	}
	    	Double dbPurchasePrice = Double.valueOf(strExpectedPurchasePrice);
	    	Double dbDownPayment = 	Double.valueOf(strExpectedDownPayment);
	    	Double defaultInsurance =  dbDownPayment/dbPurchasePrice*100;
	    	
	    	if(defaultInsurance >= 20.0)
	    	{
	    		if (strrateequity.contentEquals("Yes, I'm interested")) {
	    			Utility.clickObject("ehome.step.yesImInterestedBtn", "Button");
	    			Utility.clickObject("ehome.CloseDtContinue.button", "Button");
	    		}
	    	}
	    	if (strrateequity.contentEquals("No thanks")) {
	    		QAFExtendedWebElement NothanksBtn= new QAFExtendedWebElement("ehome.step.NothanksBtn");
	    		NothanksBtn.click(); // Click on Continue
	    	}
	    	Utility.clickObject("ehome.RateViewContinueBtn", "Button");
	    	Utility.clickObject("//*[@id=\"app\"]/div/div[1]/div/div/div[3]/div/button/span", "Button");
 	
		 	Thread.sleep(2000);
		 	if (strCurrentEmpStatus.contentEquals("Employed")) {                // Selecting current Employment Status
		 		CommonAppMethodsEmployment.SelectEmpStatus("Employed");
		 		Thread.sleep(4000);
		 		if (strEmploymentType.contentEquals("Commissioned sales")) {             // Selecting Employment Type
		 			CommonAppMethodsEmployment.SelectEmpType("Commissioned sales");}
		 		else if (strEmploymentType.contentEquals("Contract")) {
		 			CommonAppMethodsEmployment.SelectEmpType("Contract");}
		 		else if (strEmploymentType.contentEquals("Full Time")) {
		 			CommonAppMethodsEmployment.SelectEmpType("Full Time");}
		 		else if (strEmploymentType.contentEquals("Part Time")) {
		 			CommonAppMethodsEmployment.SelectEmpType("Part Time");}
		 		else if (strEmploymentType.contentEquals("Seasonal")) {
		 			CommonAppMethodsEmployment.SelectEmpType("Seasonal");}
		 		Thread.sleep(2000);
		 		CommonApplicationMethods.selectValuefromDropDownListBox("//*[@id=\"jobField\"]", strFieldOfWork); // Selecting Field of work
		 		Thread.sleep(1000);
		 		CommonApplicationMethods.selectValuefromDropDownListBox("//*[@id=\"jobTitle\"]", strJobTitle);    // Selecting Job Title
		 		Common.continueButtonClicked();
		 		Thread.sleep(1000);
					
		 		Utility.sendKeys("//*[@id=\'employerName\']","Scotia Bank");
		 		Utility.sendKeys("//*[@id=\"employerPhone\"]","6471234567");
		 		Thread.sleep(1000);
		 		Common.continueButtonClicked();
		 		Thread.sleep(500);
					
		 		CommonApplicationMethods.enterAutoSuggestAddress("888 Birch","ehome.employeraddress.address","//*[@id=\"app\"]/div/div[1]/div[1]/section/div/div[3]/div[1]/div/div[2]/div/ul" );
		 		Thread.sleep(1000);
				Common.continueButtonClicked();
		 		
		 		Thread.sleep(500);
		 		Utility.sendKeys("ehome.annualIncome.salary", "120000");
		 		Utility.sendKeys("ehome.annualIncome.bonus", "9000");
		 		Utility.sendKeys("ehome.annualIncome.overtime", "50000");
		 		Thread.sleep(1000);
					
		 		Common.continueButtonClicked();
		 		Thread.sleep(1000);
		 		
		 		if (strDurationYear != "") {
		 			CommonApplicationMethods.selectValuefromDropDownListBox("ehome.employmentDuration.years", strDurationYear);
			 		Thread.sleep(500);
		 		}
		 		
		 		if (strDurationMonth != "") {
		 			CommonApplicationMethods.selectValuefromDropDownListBox("ehome.employmentDuration.months", strDurationMonth);
			 		Thread.sleep(500);
		 		}
		 		
		 		Common.continueButtonClicked();
		 		Thread.sleep(1000);
		 		
		 		if (strDurationYear.contentEquals("1 year") | strDurationYear.contentEquals("0 years") ){  
		 			Utility.sendKeys("ehome.previousEmployerDetails.employerName","Mahindra Satyam");
			 		Thread.sleep(500);
			 		Common.continueButtonClicked();
			 		Thread.sleep(500);
	 				Utility.sendKeys("ehome.previousAnnualIncome.salary", "80000");
			 		Thread.sleep(500);
			 		Common.continueButtonClicked();
			 		Thread.sleep(1000);
			 		CommonApplicationMethods.selectValuefromDropDownListBox("ehome.previousemploymentDuration.years", strDurationYear);
			 		Thread.sleep(500);
			 		CommonApplicationMethods.selectValuefromDropDownListBox("ehome.previousemploymentDuration.months", strDurationMonth);
			 		Thread.sleep(500);
			 		Common.continueButtonClicked();
			 		Thread.sleep(1000);
		 			 		}
		 		
					
					//  Do you have any other sources of income?
		 		if (strChildSupport.contentEquals("Child Support")) {
		 			CommonAppMethodsEmployment.SelectOtherSourcesOfIncome(strChildSupport); 
		 		}
		 		if (strCommission.contentEquals("Commission")) {
		 			CommonAppMethodsEmployment.SelectOtherSourcesOfIncome(strCommission); 
		 		}
		 		if (strInvestments.contentEquals("Investments")) {
		 			CommonAppMethodsEmployment.SelectOtherSourcesOfIncome(strInvestments); 
		 		}
		 		if (strPartTimeWork.contentEquals("Part Time Work")) {
		 			CommonAppMethodsEmployment.SelectOtherSourcesOfIncome(strPartTimeWork); 
		 		}
		 		if (strPensionDisability.contentEquals("Pension/Disability")) {
		 			CommonAppMethodsEmployment.SelectOtherSourcesOfIncome(strPensionDisability); 
		 		}
				if (strRIFLIF.contentEquals("RIF/LIF")) {
					CommonAppMethodsEmployment.SelectOtherSourcesOfIncome(strRIFLIF); 
				}
				if (strSeasonalWork.contentEquals("Seasonal Work")) {
					CommonAppMethodsEmployment.SelectOtherSourcesOfIncome(strSeasonalWork); 
				}
				if (strSpousalSupport.contentEquals("Spousal Support")) {
					CommonAppMethodsEmployment.SelectOtherSourcesOfIncome(strSpousalSupport); 
				}
				
				if (strChildSupport.contentEquals("No other sources of income") | strCommission.contentEquals("No other sources of income") | strPartTimeWork.contentEquals("No other sources of income") | strPensionDisability.contentEquals("No other sources of income")| strRIFLIF.contentEquals("No other sources of income")| strInvestments.contentEquals("No other sources of income")| strSeasonalWork.contentEquals("No other sources of income")| strSpousalSupport.contentEquals("No other sources of income")) {
					CommonAppMethodsEmployment.SelectOtherSourcesOfIncome("No other sources of income");
				}
				Common.continueButtonClicked();
				Thread.sleep(500); 
					
					//  What's the annual income for each source?
				if (strChildSupport != null | strChildSupportAmt.length() != 0) {
					CommonAppMethodsEmployment.EnterAnualIncomeSourceAmount(strChildSupport, strChildSupportAmt);
				}
				if (strCommission != null | strCommissionAmt.length() != 0) {
					CommonAppMethodsEmployment.EnterAnualIncomeSourceAmount(strCommission, strCommissionAmt);
				}
				if (strInvestments != null | strInvestmentsAmt.length() != 0) {
					CommonAppMethodsEmployment.EnterAnualIncomeSourceAmount(strInvestments, strInvestmentsAmt);
				}
				if (strPartTimeWork != null | strPartTimeWorkAmt.length() != 0) {
					CommonAppMethodsEmployment.EnterAnualIncomeSourceAmount(strPartTimeWork, strPartTimeWorkAmt);
				}
				if (strPensionDisability != null | strPensionDisabilityAmt.length() != 0) {
					CommonAppMethodsEmployment.EnterAnualIncomeSourceAmount(strPensionDisability, strPensionDisabilityAmt);
				}
				if (strRIFLIF != null | strRIFLIFAmt.length() != 0) {
					CommonAppMethodsEmployment.EnterAnualIncomeSourceAmount(strRIFLIF, strRIFLIFAmt);
				}
	
				if (strSeasonalWork != null | strSeasonalWorkAmt.length() != 0) {
					CommonAppMethodsEmployment.EnterAnualIncomeSourceAmount(strSeasonalWork, strSeasonalWorkAmt);
				}
				if (strSpousalSupport != null | strSpousalSupportAmt.length() != 0) {
					CommonAppMethodsEmployment.EnterAnualIncomeSourceAmount(strSpousalSupport, strSpousalSupportAmt);
				}
					 	
				Thread.sleep(500);
				
				Utility.clickObject("//*[@id=\"app\"]/div/div[1]/div[3]/button[2]/span", "Button");
				Thread.sleep(500);  
					 	
//				if (strCoAppCurrentEmpStatus.contentEquals("Unemployed")) {
//					CommonAppMethodsAssetLiabilities.SelectCoAppCurrentEmpStatus(strCoAppCurrentEmpStatus);
//				}
//				 	
//				Thread.sleep(500);
//				if (strCoAppEmpOtherSrcsOfIncomeNoOtherSrcs.contentEquals ("No other sources") | strCoAppEmpOtherSrcsOfIncomeNoOtherSrcs.contentEquals("No other sources of income")) {
//					CommonAppMethodsAssetLiabilities.SelectCoAppSrcsOfIncome(strCoAppEmpOtherSrcsOfIncomeNoOtherSrcs, "");
//				}
//				if (strCoAppEmpOtherSrcsOfIncomeChildSupport.contentEquals("Child Support")) {
//					CommonAppMethodsAssetLiabilities.SelectCoAppSrcsOfIncome(strCoAppEmpOtherSrcsOfIncomeChildSupport, strCoAppEmpOtherSrcsOfIncomeChildSupportAmt);
//				}
//						
//				if (strCoAppEmpOtherSrcsOfIncomeInvest.contentEquals("Investments")) {
//					CommonAppMethodsAssetLiabilities.SelectCoAppSrcsOfIncome(strCoAppEmpOtherSrcsOfIncomeInvest, strCoAppEmpOtherSrcsOfIncomeInvestAmt);
//				}
//						
//				if (strCoAppEmpOtherSrcsOfIncomePensionDisability.contentEquals("Pension/Disability")) {
//					CommonAppMethodsAssetLiabilities.SelectCoAppSrcsOfIncome(strCoAppEmpOtherSrcsOfIncomePensionDisability, strCoAppEmpOtherSrcsOfIncomePensionDisabilityAmt);
//				}
//					 	
//				Utility.clickObject("//*[@id=\"app\"]/div/div[1]/div/div/div[3]/div/div[2]/section/div/div[2]/div/button/span", "Button");
//				
//				//Do you have any of the following assets?
//				
//				if (strAutomobile.contentEquals("Automobile")) {
//					CommonAppMethodsAssetLiabilities.SelectAssetsSources(strAutomobile); 
//				}
//				if (strCash.contentEquals("Cash")) {
//					CommonAppMethodsAssetLiabilities.SelectAssetsSources(strCash); 
//				}
//				if (strGICTermDeposit.contentEquals("GIC/Term Deposit")) {
//					CommonAppMethodsAssetLiabilities.SelectAssetsSources(strGICTermDeposit); 
//				}
//				if (strPrimaryResidence.contentEquals("Primary Residence")) {
//					CommonAppMethodsAssetLiabilities.SelectAssetsSources(strPrimaryResidence); 
//				}
//				
//				if (strRentalProperty.contentEquals("Rental Property")) {
//					CommonAppMethodsAssetLiabilities.SelectAssetsSources(strRentalProperty); 
//				}
//				if (strRRSP.contentEquals("RRSP")) {
//					CommonAppMethodsAssetLiabilities.SelectAssetsSources(strRRSP); 
//				}
//				if (strSecondaryProperty.contentEquals("SecondaryProperty")) {
//					CommonAppMethodsAssetLiabilities.SelectAssetsSources(strSecondaryProperty); 
//				}
//				if (strStockBond.contentEquals("Stock/Bond")) {
//					CommonAppMethodsAssetLiabilities.SelectAssetsSources(strStockBond); 
//				}
//				if (strOtherAssets.contentEquals("Other Assets")) {
//					CommonAppMethodsAssetLiabilities.SelectAssetsSources(strOtherAssets); 
//				}
//				if (strAutomobile.contentEquals("No other assets") | strCash.contentEquals("No other assets") | strGICTermDeposit.contentEquals("No other assets") | strPrimaryResidence.contentEquals("No other assets")| strRentalProperty.contentEquals("No other assets")| strRRSP.contentEquals("No other assets")| strSecondaryProperty.contentEquals("No other assets")| strStockBond.contentEquals("No other assets")| strOtherAssets.contentEquals("No other assets")) {
//					CommonAppMethodsAssetLiabilities.SelectAssetsSources("No other assets"); 
//				}
//					
//				Common.continueButtonClicked();
//				 		
//				 	
//				//Do you have any of the following assets?
//				if (strAutomobile!=null | strAutomobileAmt.length()!= 0) {
//					CommonAppMethodsAssetLiabilities.EnterAssetCalculateAmount(strAutomobile, strAutomobileAmt);
//				}
//				 	
//				if (strCash!= null | strCashAmt.length()!= 0) {
//					CommonAppMethodsAssetLiabilities.EnterAssetCalculateAmount(strCash, strCashAmt);
//				}
//				if (strGICTermDeposit!= null | strGICTermDepositAmt.length()!= 0) {
//					CommonAppMethodsAssetLiabilities.EnterAssetCalculateAmount(strGICTermDeposit, strGICTermDepositAmt);
//				}
//				if (strPrimaryResidence!= null | strPrimaryResidenceAmt.length() != 0) {
//					CommonAppMethodsAssetLiabilities.EnterAssetCalculateAmount(strPrimaryResidence, strPrimaryResidenceAmt );
//				}
//				if (strRentalProperty!= null | strRentalPropertyAmt.length() != 0) {
//					CommonAppMethodsAssetLiabilities.EnterAssetCalculateAmount(strRentalProperty, strRentalPropertyAmt );
//			 	}
//				if (strRRSP!= null | strRRSPAmt.length()!= 0) {
//					CommonAppMethodsAssetLiabilities.EnterAssetCalculateAmount(strRRSP, strRRSPAmt);
//				}
//				if (strSecondaryProperty!= null | strSecondaryPropertyAmt.length()!= 0) {
//					CommonAppMethodsAssetLiabilities.EnterAssetCalculateAmount(strSecondaryProperty, strSecondaryPropertyAmt);
//				}
//				if (strStockBond!= null | strStockBondAmt.length()!= 0) {
//					CommonAppMethodsAssetLiabilities.EnterAssetCalculateAmount(strStockBond, strStockBondAmt);
//				}
//				if (strOtherAssets!= null | strOtherAssetsAmt.length() != 0) {
//					CommonAppMethodsAssetLiabilities.EnterAssetCalculateAmount(strOtherAssets, strOtherAssetsAmt );
//				}
//				
//				//Utility.clickObject("//*[@id=\"app\"]/div/div[1]/div[3]/button[2]/span", "Button");
//				Common.continueButtonClicked();
//				//Do you have any liabilities outside of Scotiabank?'
//					 
//				if (strAlimonyLiability.contentEquals("Alimony")) {
//					CommonAppMethodsAssetLiabilities.SelectLiabilitySources(strAlimonyLiability); 
//				}
//				if (strChildSupportLiability.contentEquals("Child Support")) {
//					CommonAppMethodsAssetLiabilities.SelectLiabilitySources(strChildSupportLiability); 
//				}
//				if (strPrivateDebtLiability .contentEquals("Private Debt")) {
//					CommonAppMethodsAssetLiabilities.SelectLiabilitySources(strPrivateDebtLiability ); 
//				}
//					
//				if (strAlimonyLiability.contentEquals("No other liabilities") | strChildSupportLiability.contentEquals("No other liabilities") | strPrivateDebtLiability.contentEquals("No other liabilities")) {
//					CommonAppMethodsAssetLiabilities.SelectLiabilitySources("No other liabilities"); 
//				}
//				
//				Common.continueButtonClicked();
//					
//				//Do you have any liabilities outside of Scotiabank?
//					
//				if (strAlimonyLiability!=null | strAlimonyLiabilityMonthlyPaymt.length()!= 0) {
//					CommonAppMethodsAssetLiabilities.EnterLiabilityCalculateAmount(strAlimonyLiability, strAlimonyLiabilityMonthlyPaymt);
//			 	}
//				 	
//				if (strChildSupportLiability!= null | strChildSupportLiabilityMonthlyPayment.length()!= 0) {
//					CommonAppMethodsAssetLiabilities.EnterLiabilityCalculateAmount(strChildSupportLiability, strChildSupportLiabilityMonthlyPayment);
//				}
//					 
//				if (strPrivateDebtLiabilityBalanceOwing.length()!= 0) {
//					String strBalanceOwing = "Balance Owing";
//					CommonAppMethodsAssetLiabilities.EnterLiabilityCalculateAmount(strBalanceOwing, strPrivateDebtLiabilityBalanceOwing);
//				}
//				if (strPrivateDebtLiability!= null | strPrivateDebtLiabilityMonthlyPayment.length()!= 0) {
//					CommonAppMethodsAssetLiabilities.EnterLiabilityCalculateAmount(strPrivateDebtLiability, strPrivateDebtLiabilityMonthlyPayment);
//				 }
//					 
//				Utility.clickObject("//*[@id=\"app\"]/div/div[1]/div[3]/button[2]/span", "Button");
				
				
		}
		
		 	else if (strCurrentEmpStatus.contentEquals("UnEmployed")) {
		 		CommonAppMethodsEmployment.SelectEmpStatus("UnEmployed");
		 		Thread.sleep(2000); 
		 		
		 		if (strChildSupport.contentEquals("Child Support")) {
		 			CommonAppMethodsEmployment.SelectOtherSourcesOfIncome(strChildSupport); 
		 		}
		 		if (strInvestments.contentEquals("Investments")) {
		 			CommonAppMethodsEmployment.SelectOtherSourcesOfIncome(strInvestments); 
		 		}
		 		if (strPensionDisability.contentEquals("Pension/Disability")) {
		 			CommonAppMethodsEmployment.SelectOtherSourcesOfIncome(strPensionDisability); 
		 		}
				if (strSpousalSupport.contentEquals("Spousal Support")) {
					CommonAppMethodsEmployment.SelectOtherSourcesOfIncome(strSpousalSupport); 
				} 
				
				
				Common.continueButtonClicked();
				Thread.sleep(500); 
					
					//  What's the annual income for each source?
				if (strChildSupport != null | strChildSupportAmt.length() != 0) {
					CommonAppMethodsEmployment.EnterAnualIncomeSourceAmount(strChildSupport, strChildSupportAmt);
					//Thread.sleep(1000);  
				}
				if (strInvestments != null | strInvestmentsAmt.length() != 0) {
					CommonAppMethodsEmployment.EnterAnualIncomeSourceAmount(strInvestments, strInvestmentsAmt);
					//Thread.sleep(1000);  
				}
				if (strPensionDisability != null | strPensionDisabilityAmt.length() != 0) {
					CommonAppMethodsEmployment.EnterAnualIncomeSourceAmount(strPensionDisability, strPensionDisabilityAmt);
					//Thread.sleep(1000);  
				}
				if (strSpousalSupport != null | strSpousalSupportAmt.length() != 0) {
					CommonAppMethodsEmployment.EnterAnualIncomeSourceAmount(strSpousalSupport, strSpousalSupportAmt);
					//Thread.sleep(1000);  
				}
					 	
				Thread.sleep(500);
				
				Utility.clickObject("//*[@id=\"app\"]/div/div[1]/div[3]/button[2]/span", "Button");
				Thread.sleep(500);  
		 		
		 		
		 	}
		 	else if (strCurrentEmpStatus.contentEquals("Retired")) {
		 		CommonAppMethodsEmployment.SelectEmpStatus("Retired");
		 		
		 		if (strDurationYear != "") {
		 			CommonApplicationMethods.selectValuefromDropDownListBox("ehome.employmentDuration.years", strDurationYear);
			 		Thread.sleep(500);
		 		}
		 		
		 		if (strDurationMonth != "") {
		 			CommonApplicationMethods.selectValuefromDropDownListBox("ehome.employmentDuration.months", strDurationMonth);
			 		Thread.sleep(500);
		 		}
		 		
		 		Thread.sleep(1000);
		 		Common.continueButtonClicked();
		 		Thread.sleep(1000);
		 		
		 		if (strInvestments.contentEquals("Investments")) {
		 			CommonAppMethodsEmployment.SelectRetiredSourcesOfIncome(strInvestments); 
		 		}
		 		if (strPensionDisability.contentEquals("Pension/Disability")) {
		 			CommonAppMethodsEmployment.SelectRetiredSourcesOfIncome(strPensionDisability); 
		 		}
		 		if (strRIFLIF.contentEquals("RIF/LIF")) {
					CommonAppMethodsEmployment.SelectRetiredSourcesOfIncome(strRIFLIF); 
				}
		 		if (strInvestments.contentEquals("No sources of income") | strPensionDisability.contentEquals("No sources of income")  | strRIFLIF.contentEquals("No sources of income")  ) {
					CommonAppMethodsEmployment.SelectRetiredSourcesOfIncome("No sources of income"); 
				}
		 		Common.continueButtonClicked();
		 		Thread.sleep(1000);
		 		if (strInvestments != null | strInvestmentsAmt.length() != 0) {
					CommonAppMethodsEmployment.EnterRetiredAnualIncomeSourceAmount(strInvestments, strInvestmentsAmt);
				}
				if (strPensionDisability != null | strPensionDisabilityAmt.length() != 0) {
					CommonAppMethodsEmployment.EnterRetiredAnualIncomeSourceAmount(strPensionDisability, strPensionDisabilityAmt);
				}
				if (strRIFLIF != null | strRIFLIFAmt.length() != 0) {
					CommonAppMethodsEmployment.EnterRetiredAnualIncomeSourceAmount(strRIFLIF, strRIFLIFAmt);
				}
				Thread.sleep(500);
				if (strInvestments != "" | strPensionDisability != "" | strRIFLIF !=""  )
				{
					Utility.clickObject("//*[@id=\"app\"]/div/div[1]/div[3]/button[2]/span", "Button");
					Thread.sleep(500);
				}
		 	}
		 	else if (strEmploymentType.contentEquals("Self Employed")) {
		 		CommonAppMethodsEmployment.SelectEmpType("Self Employed");}
	 	}
	 
	
	 	 /* *************************************************************************************************************************************************
		 Author: 	  RameshChalumuri
		 Method Name: PreCondition_Traverse_Stage1_to_Entry_of_Stage6_functionality
		 Purpose: 	  PreCondition Traverse Stage1(WelcomeTriage Questions & Prospect Registration) to Entry of Stage6
		 Created on:  26-October-2018  
		 Updated By:  RameshChalumuri
		 Updated on:  11-November-2018
		 *************************************************************************************************************************************************** */
		 
		 	@Given("^Traverse Stage1 to Entry of Stage6$")
		 	public static void PreCondition_Traverse_Stage1_to_Entry_of_Stage6_functionality() throws Throwable 
		 	{
		 		
		 		String strtestCaseID = "E2E-Scenario-001"; // Utility.getScenarioID();
				//Utility.launchURL(ConfigurationUtils.getBaseBundle ().getPropertyValue ("env.baseurl1"));
		 		Utility.launchURL(ConfigurationUtils.getBaseBundle ().getPropertyValue ("env.baseurl2"));

					// Passing "Excel Path", "Sheet name", "Test Case ID" as parameters
				Map<String, String> E2E_ExcelData =  Utility.readTestData(strfullPathToFile, sheetNameE2E,strtestCaseID);
		    	String strExpectedAddress= E2E_ExcelData.get("Address"); 										// Retrieve "Address" from Excel 
		    	String strExpectedPropertyType= E2E_ExcelData.get("PropertyType");								// Retrieve "PropertyType" from Excel 
		    	String strExpectedHouseType= E2E_ExcelData.get("HouseType");									// Retrieve "HouseType" from Excel
		    	String strExpectedCondoFees = E2E_ExcelData.get("CondoFees");									// Retrieve "CondoFees" from Excel
		    	String strExpectedSquareFeet  = E2E_ExcelData.get("SquareFeet");								// Retrieve "SquareFeet" from Excel
		    	String strExpectedPurchasePrice  = E2E_ExcelData.get("PurchasePrice");							// Retrieve "PurchasePrice" from Excel
		    	String strExpectedDownPayment  = E2E_ExcelData.get("DownPayment");								// Retrieve "DownPayment" from Excel
		    	String strExpectedDownPymtSrcBankAcct  = E2E_ExcelData.get("DownPymtSrcBankAcct");				// Retrieve "DownPymtSrcBankAcct" from Excel
		    	String strExpectedDownPymtSrcInvAcct  = E2E_ExcelData.get("DownPymtSrcInvAcct");				// Retrieve "DownPymtSrcInvAcct" from Excel
		    	String strExpectedDownPymtSrcFamilyGift  = E2E_ExcelData.get("DownPymtSrcFamilyGift");			// Retrieve "DownPymtSrcFamilyGift" from Excel
		    	String strExpectedDownPymtSrcRRSP  = E2E_ExcelData.get("DownPymtSrcRRSP");						// Retrieve "DownPymtSrcRRSP" from Excel
		    	String strExpectedDownPymtSrcSaleOfAss  = E2E_ExcelData.get("DownPymtSrcSaleOfAss");			// Retrieve "DownPymtSrcSaleOfAss" from Excel
		    	String strExpectedDownPymtSrcSaleOfExist  = E2E_ExcelData.get("DownPymtSrcSaleOfExist");		// Retrieve "DownPymtSrcSaleOfExist" from Excel
		    	String strExpectedDownPymtSrcBankAcctAmt  = E2E_ExcelData.get("DownPymtSrcBankAcctAmt");		// Retrieve "DownPymtSrcBankAcctAmt" from Excel
		    	String strExpectedDownPymtSrcInvAcctAmt  = E2E_ExcelData.get("DownPymtSrcInvAcctAmt");			// Retrieve "DownPymtSrcnvAcctAmt" from Excel
		    	String strExpectedDownPymtSrcFamilyGiftAmt  = E2E_ExcelData.get("DownPymtSrcFamilyGiftAmt");	// Retrieve "DownPymtSrcFamilyGiftAmt" from Excel		
		    	String strExpectedDownPymtSrcRRSPAmt  = E2E_ExcelData.get("DownPymtSrcRRSPAmt");				// Retrieve "DownPymtSrcRRSPAmt" from Excel
		    	String strExpectedDownPymtSrcSaleOfAssAmt  = E2E_ExcelData.get("DownPymtSrcSaleOfAssAmt");		// Retrieve "DownPymtSrcSaleOfAssAmt" from Excel
		    	String strExpectedDownPymtSrcSaleOfExistAmt  = E2E_ExcelData.get("DownPymtSrcSaleOfExistAmt");	// Retrieve "DownPymtSrcSaleOfExistAmt" from Excel
		    	
		    	String strTypeOfRate            = E2E_ExcelData.get("TypeOfRate"); // Retrieve "TypeOfRate" from Excel 
		    	String strMortgageTerm          = E2E_ExcelData.get("MortgageTerm");// Retrieve "MortgageTerm" from Excel 
		       	String strratecustomization     = E2E_ExcelData.get("RateCustomization");// Retrieve "UnLockYourRate" from Excel
		    	String strrateunlock            = E2E_ExcelData.get("RateUnlock");// Retrieve "RateUnlock" from Excel
		    	String strrateequity            = E2E_ExcelData.get("RateEquity");// Retrieve "Rate Equity" from Excel 
		       
				String strCurrentEmpStatus	= E2E_ExcelData.get("CurrentEmpStatus"); 	// Retrieve "Current Employment status" from Excel
				String strEmploymentType = E2E_ExcelData.get("EmploymentType");
				String strFieldOfWork=  E2E_ExcelData.get("EmploymentFieldOfWork");
				String strJobTitle=  E2E_ExcelData.get("EmploymentJobTitle");
				String strDurationYear=  E2E_ExcelData.get("Years");
				String strDurationMonth=  E2E_ExcelData.get("Months");
				
				String strChildSupport= E2E_ExcelData.get("EmpOtherSrcsOfIncome1");
				String strCommission= E2E_ExcelData.get("EmpOtherSrcsOfIncome2");
				String strInvestments= E2E_ExcelData.get("EmpOtherSrcsOfIncome3");
				String strPartTimeWork= E2E_ExcelData.get("EmpOtherSrcsOfIncome4");
				String strPensionDisability= E2E_ExcelData.get("EmpOtherSrcsOfIncome5");
				String strRIFLIF= E2E_ExcelData.get("EmpOtherSrcsOfIncome6");
				String strSeasonalWork= E2E_ExcelData.get("EmpOtherSrcsOfIncome7");
			    String strSpousalSupport= E2E_ExcelData.get("EmpOtherSrcsOfIncome8");
				
				String strChildSupportAmt= E2E_ExcelData.get("EmpOtherSrcsOfIncome1Amt");
				String strCommissionAmt= E2E_ExcelData.get("EmpOtherSrcsOfIncome2Amt");
				String strInvestmentsAmt= E2E_ExcelData.get("EmpOtherSrcsOfIncome3Amt");
				String strPartTimeWorkAmt= E2E_ExcelData.get("EmpOtherSrcsOfIncome4Amt");
				String strPensionDisabilityAmt= E2E_ExcelData.get("EmpOtherSrcsOfIncome5Amt");
				String strRIFLIFAmt= E2E_ExcelData.get("EmpOtherSrcsOfIncome6Amt");
				String strSeasonalWorkAmt= E2E_ExcelData.get("EmpOtherSrcsOfIncome7Amt");
				String strSpousalSupportAmt= E2E_ExcelData.get("EmpOtherSrcsOfIncome8Amt");
				
				String strAutomobile = E2E_ExcelData.get("AssetSources1");
				String strCash = E2E_ExcelData.get("AssetSources2");
				String strGICTermDeposit = E2E_ExcelData.get("AssetSources3");
			 	String strPrimaryResidence = E2E_ExcelData.get("AssetSources4");
			  	String strRentalProperty = E2E_ExcelData.get("AssetSources5");
			 	String strRRSP = E2E_ExcelData.get("AssetSources6");
			 	String strSecondaryProperty = E2E_ExcelData.get("AssetSources7");
			 	String strStockBond = E2E_ExcelData.get("AssetSources8");
			 	String strOtherAssets = E2E_ExcelData.get("AssetSources9");
			 	
			 	String strAutomobileAmt = E2E_ExcelData.get("AssetSources1Amt");
			 	String strCashAmt = E2E_ExcelData.get("AssetSources2Amt");
			 	String strGICTermDepositAmt = E2E_ExcelData.get("AssetSources3Amt");
			 	String strPrimaryResidenceAmt = E2E_ExcelData.get("AssetSources4Amt");
			 	String strRentalPropertyAmt = E2E_ExcelData.get("AssetSources5Amt");
			 	String strRRSPAmt = E2E_ExcelData.get("AssetSources6Amt");
			 	String strSecondaryPropertyAmt = E2E_ExcelData.get("AssetSources7Amt");
			 	String strStockBondAmt = E2E_ExcelData.get("AssetSources8Amt");
			 	String strOtherAssetsAmt = E2E_ExcelData.get("AssetSources9Amt");
			 	
			 	String strAlimonyLiability = E2E_ExcelData.get("LiabilitySources1");
			 	String strChildSupportLiability = E2E_ExcelData.get("LiabilitySources2");
			 	String strPrivateDebtLiability = E2E_ExcelData.get("LiabilitySources3");
			 	
			 	String strAlimonyLiabilityMonthlyPaymt = E2E_ExcelData.get("LiabilitySources1MonthlyPaymt");
			 	String strChildSupportLiabilityMonthlyPayment = E2E_ExcelData.get("LiabilitySources2MonthlyPaymt");
			 	String strPrivateDebtLiabilityMonthlyPayment = E2E_ExcelData.get("LiabilitySources3MonthlyPaymt");
			 	String strPrivateDebtLiabilityBalanceOwing = E2E_ExcelData.get("LiabilitySources3BalanceOwing");
			 	String strCoAppCurrentEmpStatus = E2E_ExcelData.get("CoAppCurentEmpStatus");
			 	String strCoAppEmpOtherSrcsOfIncomeNoOtherSrcs= E2E_ExcelData.get("EmpCoAppNoOtherSrcsOfIncome");
			 																		 
			 	String strCoAppEmpOtherSrcsOfIncomeChildSupport = E2E_ExcelData.get("EmpCoAppSrcsOfIncomeChildSupport");
			 	String strCoAppEmpOtherSrcsOfIncomeChildSupportAmt=E2E_ExcelData.get("EmpCoAppSrcsOfIncomeChildSupportAmt");
			 	String strCoAppEmpOtherSrcsOfIncomeInvest = E2E_ExcelData.get("EmpCoAppSrcsOfIncomeInvestment");
			 	String strCoAppEmpOtherSrcsOfIncomeInvestAmt=E2E_ExcelData.get("EmpCoAppSrcsOfIncomeInvestmentAmt");
			 	String strCoAppEmpOtherSrcsOfIncomePensionDisability = E2E_ExcelData.get("EmpCoAppSrcsOfIncomePensionDisab");
			 	String strCoAppEmpOtherSrcsOfIncomePensionDisabilityAmt=E2E_ExcelData.get("EmpCoAppSrcsOfIncomePensionDisabAmt");
 			 	
		    	if (strExpectedAddress.contentEquals("Manual Address")) {
		     		CommonApplicationMethods.enterAddressManually(); // Select Address Manually in "Address of your new home"
		     	}
		     	else
		     	{
		     		CommonApplicationMethods.enterAutosuggestaddress(strExpectedAddress); // Enters Auto suggest address (DMTI field) in Address screen 
		     	}
		     	
		     	Thread.sleep(4000);
		     	CommonAppMethodsYourNewHome.selectPropertyType(strExpectedPropertyType); // Select Property Type in "Type of Property"
		     	Thread.sleep(2000);
		     	
		     	if (strExpectedPropertyType.contentEquals("Condo")) {
		     		Utility.sendKeys("ehome.CondoFees.CondoFees.input", strExpectedCondoFees); // Enter "Condo fee" in "Type of Property" 
		     		Thread.sleep(1000);
		     		Utility.clickObject("ehome.CloseDtContinue.button", "Button"); // Click on Continue in "Type of Property"  
		      		Thread.sleep(2000);
		     	}
		        
		     	if (strExpectedPropertyType.contentEquals("House")) {
		     		CommonAppMethodsYourNewHome.selectTypeofHouse(strExpectedHouseType); // Select Type of House in "Type of house" 
		     		Thread.sleep(2000);
		     	}
		       
		     	Utility.sendKeys("ehome.areaOfProp.squrft.value", strExpectedSquareFeet); // Enter "Area of Property" 
		     	Thread.sleep(500);
		    	Utility.clickObject("ehome.areaOfProp.continue.button", "Button"); // Click on Continue
		    	Thread.sleep(500);
		     	Utility.sendKeys("ehome.PurchasePrice.inputtextbox", strExpectedPurchasePrice); // Enter "Purchase Price" in Purchase Price
		     	Thread.sleep(500);
		    	Utility.clickObject("ehome.areaOfProp.continue.button", "Button"); // Click on Continue
		    	Thread.sleep(500);
		    	Utility.sendKeys("ehome.DownPayement.Price", strExpectedDownPayment); // Enter "Down Payment Amount" in Down Payment
		     	Thread.sleep(500);
		     	Utility.clickObject("ehome.areaOfProp.continue.button", "Button"); // Click on Continue
		     	Thread.sleep(1000);
		     	
		     	if (strExpectedDownPymtSrcBankAcct.contentEquals("Bank account")) {
		     		CommonAppMethodsYourNewHome.selectDownPaymentSources(strExpectedDownPymtSrcBankAcct); // Select "Bank account" option 
		     	}
	     		
		     	if (strExpectedDownPymtSrcInvAcct.contentEquals("Investment account")) {
		     		CommonAppMethodsYourNewHome.selectDownPaymentSources(strExpectedDownPymtSrcInvAcct); // Select "Investment account" option 
		     	}
		     	
		     	if (strExpectedDownPymtSrcFamilyGift.contentEquals("A gift from family")) {
		     		CommonAppMethodsYourNewHome.selectDownPaymentSources(strExpectedDownPymtSrcFamilyGift); // Select "A gift from family" option 
		     	}
		     	
		     	if (strExpectedDownPymtSrcRRSP.contentEquals("RRSP withdrawal")) {
		     		CommonAppMethodsYourNewHome.selectDownPaymentSources(strExpectedDownPymtSrcRRSP); // Select "RRSP withdrawal" option 
		     	}
		     	
		     	if (strExpectedDownPymtSrcSaleOfAss.contentEquals("Sale of asset")) {
		     		CommonAppMethodsYourNewHome.selectDownPaymentSources(strExpectedDownPymtSrcSaleOfAss); // Select "Sale of asset" option 
		     	}
		     	
		     	if (strExpectedDownPymtSrcSaleOfExist.contentEquals("Sale of existing property")) {
		     		CommonAppMethodsYourNewHome.selectDownPaymentSources(strExpectedDownPymtSrcSaleOfExist); // Select "Sale of existing property" option 
		     	}
		     	
		     	Thread.sleep(500);  
		     	Utility.clickObject("ehome.areaOfProp.continue.button", "Button");
		     	Thread.sleep(500);  
		     	
		     	//  ***** STAGE2-Detailed Down Payment Screen# *****
		       if (strExpectedDownPymtSrcBankAcct != null | strExpectedDownPymtSrcBankAcctAmt.length() != 0) {
		    	   CommonAppMethodsYourNewHome.enterDownPaymentSourcesAmount(strExpectedDownPymtSrcBankAcct, strExpectedDownPymtSrcBankAcctAmt);
		       		Thread.sleep(500); 
		     	}
		     	if (strExpectedDownPymtSrcInvAcct != null | strExpectedDownPymtSrcInvAcctAmt.length() != 0) {
		     		CommonAppMethodsYourNewHome.enterDownPaymentSourcesAmount(strExpectedDownPymtSrcInvAcct, strExpectedDownPymtSrcInvAcctAmt);
		     		Thread.sleep(500);  
		     	}
		     	if (strExpectedDownPymtSrcFamilyGift != null | strExpectedDownPymtSrcFamilyGiftAmt.length() != 0) {
		     		CommonAppMethodsYourNewHome.enterDownPaymentSourcesAmount(strExpectedDownPymtSrcFamilyGift, strExpectedDownPymtSrcFamilyGiftAmt);
		     		Thread.sleep(500);  
		     	}
		     	if (strExpectedDownPymtSrcRRSP != null | strExpectedDownPymtSrcRRSPAmt.length() != 0) {
		     		CommonAppMethodsYourNewHome.enterDownPaymentSourcesAmount(strExpectedDownPymtSrcRRSP, strExpectedDownPymtSrcRRSPAmt);
		     		Thread.sleep(500);  
		     	}
		     	if (strExpectedDownPymtSrcSaleOfAss != null | strExpectedDownPymtSrcSaleOfAssAmt.length() != 0) {
		     		CommonAppMethodsYourNewHome.enterDownPaymentSourcesAmount(strExpectedDownPymtSrcSaleOfAss, strExpectedDownPymtSrcSaleOfAssAmt);
		     		Thread.sleep(500);  
		     	}
		     	if (strExpectedDownPymtSrcSaleOfExist != null | strExpectedDownPymtSrcSaleOfExistAmt.length() != 0) {
		     		CommonAppMethodsYourNewHome.enterDownPaymentSourcesAmount(strExpectedDownPymtSrcSaleOfExist, strExpectedDownPymtSrcSaleOfExistAmt);
		     		Thread.sleep(500);  
		     	}
		     	
		    	Utility.clickObject("ehome.detailsofdownpayment.ContinueButtonDetails", "Button"); // Click on Continue
		      	Thread.sleep(500);
		      	
		      	Utility.clickObject("ehome.closingDtPicker.button", "Button");
		     	Thread.sleep(500);
		     	Utility.clickObject("ehome.closingDtPickerSelection.button", "Button");
		     	Thread.sleep(500);
		      	Utility.clickObject("ehome.CloseDtContinue.button", "Button"); // Click on Continue
		      	Thread.sleep(500);
		     	Utility.clickObject("ehome.detailsofdownpayment.ContinueButtonDetails", "Button"); // Click on Continue button in Details of 
		     	Thread.sleep(500);
		      	Utility.clickObject("ehome.Stage3SectionBrkContinue.button", "Button"); // Click on "Continue" button 
		  	   // Stag 2 End Here //***********************************************	 
		  
		    	CommonAppMethodsGettingNewRate.selectRateType(strTypeOfRate); // Select "Type of Rate" option 
		    	Thread.sleep(2000);
	    		    	
		    	if (strTypeOfRate.contentEquals("Fixed")) {
		    		CommonAppMethodsGettingNewRate.selectMortgageTerm(strMortgageTerm); // Select "Mortgage Term" option 
		    		Thread.sleep(1000);
		    	}
		    
		    	CommonAppMethodsGettingNewRate.chooseRatesfromRatePresentment(strTypeOfRate, strMortgageTerm); // Choose Rates button
		    	Thread.sleep(500);
		    	
		    	Utility.clickObject("ehome.ratelock.LockandHold", "Button"); // Click on Lock & Hold button
		    	Thread.sleep(1000);
		    	if (strratecustomization.contentEquals("Unlockyourrate")) {
		    		Utility.clickObject("ehome.rateunlock.UnlockyourrateBtn", "Button"); // Click on Unlock your rate
		    		Thread.sleep(500);
		    		if (strrateunlock.contentEquals("Yes, unlock my rate")) {
		    			Utility.clickObject("ehome.rateunlock.Yesunlockmyrate", "Button"); // Click on Yes, unlock my rate
		    			return;
		    		}
		    		if (strrateunlock.contentEquals("No, keep my rate")) {
		    			Utility.clickObject("ehome.rateunlock.Nokeepmyrate", "Button"); // Click on No, keep my rate
		    		}
		    	}
		    	Utility.clickObject("ehome.RateCustContiniueBtn", "Button"); // Click on Continue button
		    	QAFExtendedWebElement strActualSTEPTitle= new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[2]/div/div[2]/h2");
		    	if(strActualSTEPTitle.getText().contains("Plan (STEP)")) //"STEP" Title
		    	{
		    		Utility.clickObject("ehome.STEPContiniueBtn", "Button");
		    	}	
		    	else
		    	{
		    		System.err.printf("Plan (STEP) is NOT displayed", strActualSTEPTitle.getText());
		    	}
		    	Double dbPurchasePrice = Double.valueOf(strExpectedPurchasePrice);
		    	Double dbDownPayment = 	Double.valueOf(strExpectedDownPayment);
		    	Double defaultInsurance =  dbDownPayment/dbPurchasePrice*100;
		    	
		    	if(defaultInsurance >= 20.0)
		    	{
		    		if (strrateequity.contentEquals("Yes, I'm interested")) {
		    			Utility.clickObject("ehome.step.yesImInterestedBtn", "Button");
		    			Utility.clickObject("ehome.CloseDtContinue.button", "Button");
		    		}
		    	}
		    	if (strrateequity.contentEquals("No thanks")) {
		    		QAFExtendedWebElement NothanksBtn= new QAFExtendedWebElement("ehome.step.NothanksBtn");
		    		NothanksBtn.click(); // Click on Continue
		    	}
		    	Utility.clickObject("ehome.RateViewContinueBtn", "Button");
		    	Utility.clickObject("//*[@id=\"app\"]/div/div[1]/div/div/div[3]/div/button/span", "Button");
			 	Thread.sleep(2000);
			 	if (strCurrentEmpStatus.contentEquals("Employed")) {                // Selecting current Employment Status
			 		CommonAppMethodsEmployment.SelectEmpStatus("Employed");
			 		Thread.sleep(4000);
			 		if (strEmploymentType.contentEquals("Commissioned sales")) {             // Selecting Employment Type
			 			CommonAppMethodsEmployment.SelectEmpType("Commissioned sales");}
			 		else if (strEmploymentType.contentEquals("Contract")) {
			 			CommonAppMethodsEmployment.SelectEmpType("Contract");}
			 		else if (strEmploymentType.contentEquals("Full Time")) {
			 			CommonAppMethodsEmployment.SelectEmpType("Full Time");}
			 		else if (strEmploymentType.contentEquals("Part Time")) {
			 			CommonAppMethodsEmployment.SelectEmpType("Part Time");}
			 		else if (strEmploymentType.contentEquals("Seasonal")) {
			 			CommonAppMethodsEmployment.SelectEmpType("Seasonal");}
			 		Thread.sleep(2000);
			 		CommonApplicationMethods.selectValuefromDropDownListBox("//*[@id=\"jobField\"]", strFieldOfWork); // Selecting Field of work
			 		Thread.sleep(1000);
			 		CommonApplicationMethods.selectValuefromDropDownListBox("//*[@id=\"jobTitle\"]", strJobTitle);    // Selecting Job Title
			 		Common.continueButtonClicked();
			 		Thread.sleep(1000);
						
			 		Utility.sendKeys("//*[@id=\'employerName\']","Scotia Bank");
			 		Utility.sendKeys("//*[@id=\"employerPhone\"]","6471234567");
			 		Thread.sleep(1000);
			 		Common.continueButtonClicked();
			 		Thread.sleep(500);
						
			 		CommonApplicationMethods.enterAutoSuggestAddress("888 Birch","ehome.employeraddress.address","//*[@id=\"app\"]/div/div[1]/div[1]/section/div/div[3]/div[1]/div/div[2]/div/ul" );
			 		Thread.sleep(1000);
					Common.continueButtonClicked();
			 		
			 		Thread.sleep(4000);
			 		Utility.sendKeys("ehome.annualIncome.salary", "120000");
			 		Utility.sendKeys("ehome.annualIncome.bonus", "9000");
			 		Utility.sendKeys("ehome.annualIncome.overtime", "50000");
			 		Thread.sleep(1000);
						
			 		Common.continueButtonClicked();
			 		Thread.sleep(1000);
			 		
			 		if (strDurationYear != "") {
			 			CommonApplicationMethods.selectValuefromDropDownListBox("ehome.employmentDuration.years", strDurationYear);
				 		Thread.sleep(500);
			 		}
			 		
			 		if (strDurationMonth != "") {
			 			CommonApplicationMethods.selectValuefromDropDownListBox("ehome.employmentDuration.months", strDurationMonth);
				 		Thread.sleep(500);
			 		}
			 		Common.continueButtonClicked();
			 		Thread.sleep(1000);
			 		
			 		if (strDurationYear.contentEquals("1 year") | strDurationYear.contentEquals("0 years") ){  
			 			Utility.sendKeys("ehome.previousEmployerDetails.employerName","Mahindra Satyam");
				 		Thread.sleep(500);
				 		Common.continueButtonClicked();
				 		Thread.sleep(500);
		 				Utility.sendKeys("ehome.previousAnnualIncome.salary", "80000");
				 		Thread.sleep(500);
				 		Common.continueButtonClicked();
				 		Thread.sleep(1000);
				 		CommonApplicationMethods.selectValuefromDropDownListBox("ehome.previousemploymentDuration.years", strDurationYear);
				 		Thread.sleep(500);
				 		CommonApplicationMethods.selectValuefromDropDownListBox("ehome.previousemploymentDuration.months", strDurationMonth);
				 		Thread.sleep(500);
				 		Common.continueButtonClicked();
				 		Thread.sleep(1000);
			 			 		}
			 			
						//  Do you have any other sources of income?
			 		if (strChildSupport.contentEquals("Child Support")) {
			 			CommonAppMethodsEmployment.SelectOtherSourcesOfIncome(strChildSupport); 
			 		}
			 		if (strCommission.contentEquals("Commission")) {
			 			CommonAppMethodsEmployment.SelectOtherSourcesOfIncome(strCommission); 
			 		}
			 		if (strInvestments.contentEquals("Investments")) {
			 			CommonAppMethodsEmployment.SelectOtherSourcesOfIncome(strInvestments); 
			 		}
			 		if (strPartTimeWork.contentEquals("Part Time Work")) {
			 			CommonAppMethodsEmployment.SelectOtherSourcesOfIncome(strPartTimeWork); 
			 		}
			 		if (strPensionDisability.contentEquals("Pension/Disability")) {
			 			CommonAppMethodsEmployment.SelectOtherSourcesOfIncome(strPensionDisability); 
			 		}
					if (strRIFLIF.contentEquals("RIF/LIF")) {
						CommonAppMethodsEmployment.SelectOtherSourcesOfIncome(strRIFLIF); 
					}
					if (strSeasonalWork.contentEquals("Seasonal Work")) {
						CommonAppMethodsEmployment.SelectOtherSourcesOfIncome(strSeasonalWork); 
					}
					if (strSpousalSupport.contentEquals("Spousal Support")) {
						CommonAppMethodsEmployment.SelectOtherSourcesOfIncome(strSpousalSupport); 
					}
					
					if (strChildSupport.contentEquals("No other sources of income") | strCommission.contentEquals("No other sources of income") | strPartTimeWork.contentEquals("No other sources of income") | strPensionDisability.contentEquals("No other sources of income")| strRIFLIF.contentEquals("No other sources of income")| strInvestments.contentEquals("No other sources of income")| strSeasonalWork.contentEquals("No other sources of income")| strSpousalSupport.contentEquals("No other sources of income")) {
						CommonAppMethodsEmployment.SelectOtherSourcesOfIncome("No other sources of income");
					}
					Common.continueButtonClicked();
					Thread.sleep(500); 
						
						//  What's the annual income for each source?
					if (strChildSupport != null | strChildSupportAmt.length() != 0) {
						CommonAppMethodsEmployment.EnterAnualIncomeSourceAmount(strChildSupport, strChildSupportAmt);
					}
					if (strCommission != null | strCommissionAmt.length() != 0) {
						CommonAppMethodsEmployment.EnterAnualIncomeSourceAmount(strCommission, strCommissionAmt);
					}
					if (strInvestments != null | strInvestmentsAmt.length() != 0) {
						CommonAppMethodsEmployment.EnterAnualIncomeSourceAmount(strInvestments, strInvestmentsAmt);
					}
					if (strPartTimeWork != null | strPartTimeWorkAmt.length() != 0) {
						CommonAppMethodsEmployment.EnterAnualIncomeSourceAmount(strPartTimeWork, strPartTimeWorkAmt);
					}
					if (strPensionDisability != null | strPensionDisabilityAmt.length() != 0) {
						CommonAppMethodsEmployment.EnterAnualIncomeSourceAmount(strPensionDisability, strPensionDisabilityAmt);
					}
					if (strRIFLIF != null | strRIFLIFAmt.length() != 0) {
						CommonAppMethodsEmployment.EnterAnualIncomeSourceAmount(strRIFLIF, strRIFLIFAmt);
					}
		
					if (strSeasonalWork != null | strSeasonalWorkAmt.length() != 0) {
						CommonAppMethodsEmployment.EnterAnualIncomeSourceAmount(strSeasonalWork, strSeasonalWorkAmt);
					}
					if (strSpousalSupport != null | strSpousalSupportAmt.length() != 0) {
						CommonAppMethodsEmployment.EnterAnualIncomeSourceAmount(strSpousalSupport, strSpousalSupportAmt);
					}
						 	
					Thread.sleep(500);
					
					Utility.clickObject("//*[@id=\"app\"]/div/div[1]/div[3]/button[2]/span", "Button");
					Thread.sleep(500);  
					Utility.clickObject("//*[@id=\"app\"]/div/div[1]/div/div/div[2]/aside/div[2]/div[2]/div/div/button","Skip section Button");
					
					 	
					Thread.sleep(500);
					//Do you have any of the following assets?
					
					if (strAutomobile.contentEquals("Automobile")) {
						CommonAppMethodsAssetLiabilities.SelectAssetsSources(strAutomobile); 
					}
					if (strCash.contentEquals("Cash")) {
						CommonAppMethodsAssetLiabilities.SelectAssetsSources(strCash); 
					}
					if (strGICTermDeposit.contentEquals("GIC/Term Deposit")) {
						CommonAppMethodsAssetLiabilities.SelectAssetsSources(strGICTermDeposit); 
					}
					if (strPrimaryResidence.contentEquals("Primary Residence")) {
						CommonAppMethodsAssetLiabilities.SelectAssetsSources(strPrimaryResidence); 
					}
					if (strRentalProperty.contentEquals("Rental Property")) {
						CommonAppMethodsAssetLiabilities.SelectAssetsSources(strRentalProperty); 
					}
					if (strRRSP.contentEquals("RRSP")) {
						CommonAppMethodsAssetLiabilities.SelectAssetsSources(strRRSP); 
					}
					if (strSecondaryProperty.contentEquals("SecondaryProperty")) {
						CommonAppMethodsAssetLiabilities.SelectAssetsSources(strSecondaryProperty); 
					}
					if (strStockBond.contentEquals("Stock/Bond")) {
						CommonAppMethodsAssetLiabilities.SelectAssetsSources(strStockBond); 
					}
					if (strOtherAssets.contentEquals("Other Assets")) {
						CommonAppMethodsAssetLiabilities.SelectAssetsSources(strOtherAssets); 
					}
					if (strAutomobile.contentEquals("No other assets") | strCash.contentEquals("No other assets") | strGICTermDeposit.contentEquals("No other assets") | strPrimaryResidence.contentEquals("No other assets")| strRentalProperty.contentEquals("No other assets")| strRRSP.contentEquals("No other assets")| strSecondaryProperty.contentEquals("No other assets")| strStockBond.contentEquals("No other assets")| strOtherAssets.contentEquals("No other assets")) {
						CommonAppMethodsAssetLiabilities.SelectAssetsSources("No other assets"); 
					}
						
					Common.continueButtonClicked();
				//Do you have any of the following assets?
					if (strAutomobile!=null | strAutomobileAmt.length()!= 0) {
						CommonAppMethodsAssetLiabilities.EnterAssetCalculateAmount(strAutomobile, strAutomobileAmt);
					}
					 	
					if (strCash!= null | strCashAmt.length()!= 0) {
						CommonAppMethodsAssetLiabilities.EnterAssetCalculateAmount(strCash, strCashAmt);
					}
					if (strGICTermDeposit!= null | strGICTermDepositAmt.length()!= 0) {
						CommonAppMethodsAssetLiabilities.EnterAssetCalculateAmount(strGICTermDeposit, strGICTermDepositAmt);
					}
					if (strPrimaryResidence!= null | strPrimaryResidenceAmt.length() != 0) {
						CommonAppMethodsAssetLiabilities.EnterAssetCalculateAmount(strPrimaryResidence, strPrimaryResidenceAmt );
					}
					if (strRentalProperty!= null | strRentalPropertyAmt.length() != 0) {
						CommonAppMethodsAssetLiabilities.EnterAssetCalculateAmount(strRentalProperty, strRentalPropertyAmt );
				 	}
					if (strRRSP!= null | strRRSPAmt.length()!= 0) {
						CommonAppMethodsAssetLiabilities.EnterAssetCalculateAmount(strRRSP, strRRSPAmt);
					}
					if (strSecondaryProperty!= null | strSecondaryPropertyAmt.length()!= 0) {
						CommonAppMethodsAssetLiabilities.EnterAssetCalculateAmount(strSecondaryProperty, strSecondaryPropertyAmt);
					}
					if (strStockBond!= null | strStockBondAmt.length()!= 0) {
						CommonAppMethodsAssetLiabilities.EnterAssetCalculateAmount(strStockBond, strStockBondAmt);
					}
					if (strOtherAssets!= null | strOtherAssetsAmt.length() != 0) {
						CommonAppMethodsAssetLiabilities.EnterAssetCalculateAmount(strOtherAssets, strOtherAssetsAmt );
					}
					
					Utility.clickObject("//*[@id=\"app\"]/div/div[1]/div[3]/button[2]/span", "Button");
					
				//	Common.continueButtonClicked();
					//Do you have any liabilities outside of Scotiabank?'
						 
					if (strAlimonyLiability.contentEquals("Alimony")) {
						CommonAppMethodsAssetLiabilities.SelectLiabilitySources(strAlimonyLiability); 
					}
					if (strChildSupportLiability.contentEquals("Child Support")) {
						CommonAppMethodsAssetLiabilities.SelectLiabilitySources(strChildSupportLiability); 
					}
					if (strPrivateDebtLiability .contentEquals("Private Debt")) {
						CommonAppMethodsAssetLiabilities.SelectLiabilitySources(strPrivateDebtLiability ); 
					}
						
					if (strAlimonyLiability.contentEquals("No other liabilities") | strChildSupportLiability.contentEquals("No other liabilities") | strPrivateDebtLiability.contentEquals("No other liabilities")) {
						CommonAppMethodsAssetLiabilities.SelectLiabilitySources("No other liabilities"); 
					}
					
					Common.continueButtonClicked();
						
					//Do you have any liabilities outside of Scotiabank?
						
					if (strAlimonyLiability!=null | strAlimonyLiabilityMonthlyPaymt.length()!= 0) {
						CommonAppMethodsAssetLiabilities.EnterLiabilityCalculateAmount(strAlimonyLiability, strAlimonyLiabilityMonthlyPaymt);
				 	}
					 	
					Thread.sleep(2000);
					
					if (strChildSupportLiability!= null | strChildSupportLiabilityMonthlyPayment.length()!= 0) {
						CommonAppMethodsAssetLiabilities.EnterLiabilityCalculateAmount(strChildSupportLiability, strChildSupportLiabilityMonthlyPayment);
					}
						 
					if (strPrivateDebtLiabilityBalanceOwing.length()!= 0) {
						String strBalanceOwing = "Balance Owing";
						CommonAppMethodsAssetLiabilities.EnterLiabilityCalculateAmount(strBalanceOwing, strPrivateDebtLiabilityBalanceOwing);
					}
					if (strPrivateDebtLiability!= null | strPrivateDebtLiabilityMonthlyPayment.length()!= 0) {
						CommonAppMethodsAssetLiabilities.EnterLiabilityCalculateAmount(strPrivateDebtLiability, strPrivateDebtLiabilityMonthlyPayment);
					 }
						 
					Utility.clickObject("//*[@id=\"app\"]/div/div[1]/div[3]/button[2]/span", "Button");
					Thread.sleep(2000);
					
					Utility.clickObject("//*[@id=\"app\"]/div/div[1]/div/div/div[1]/aside/div[2]/div[2]/div/div/button", "Skip Selection Button");
					Thread.sleep(2000);
					
					//Stage 6 Starts here
					
					Utility.clickObject("//*[@id=\"app\"]/div/div[1]/div[3]/div[2]/div[4]/div/div[1]/div[1]/div[2]/div/label/span[2]", "Purchase & Sale Agreement upload Button");
			    	Thread.sleep(6000);
			    	Runtime.getRuntime().exec("C:\\MyWorkPlace\\AutoIt-workspace\\documentUpload_1.PropertyDocs_PurchaseSaleAgre.exe");
			    	Thread.sleep(1000);
			    	
			    	Utility.clickObject("//*[@id=\"app\"]/div/div[1]/div[3]/div[2]/div[4]/div/div[2]/div[1]/div[2]/div/label/span[2]", "House Listing upload Button");
			    	Thread.sleep(6000);
			    	Runtime.getRuntime().exec("C:\\MyWorkPlace\\AutoIt-workspace\\documentUpload_2.PropertyDocs_HouseListing.exe");
			    	Thread.sleep(1000);
			    	
			    	
			    	Utility.clickObject("//*[@id=\"app\"]/div/div[1]/div[3]/div[2]/div[6]/div/div[1]/div[1]/div[2]/div/label/span[2]", "House Listing upload Button");
			    	Thread.sleep(6000);
			    	Runtime.getRuntime().exec("C:\\MyWorkPlace\\AutoIt-workspace\\documentUpload_3.DownpaymentDocs_RRSPWithdrawalStatement.exe");
			    	Thread.sleep(1000);
			    	Utility.clickObject("//*[@id=\"app\"]/div/div[1]/div[3]/div[3]/div/button[2]/span", "Continue Button");
			}
				 	else if (strCurrentEmpStatus.contentEquals("UnEmployed")) {
			 		CommonAppMethodsEmployment.SelectEmpStatus("UnEmployed");
			 		Thread.sleep(2000); 
			 		if (strChildSupport.contentEquals("Child Support")) {
			 			CommonAppMethodsEmployment.SelectOtherSourcesOfIncome(strChildSupport); 
			 		}
			 		if (strInvestments.contentEquals("Investments")) {
			 			CommonAppMethodsEmployment.SelectOtherSourcesOfIncome(strInvestments); 
			 		}
			 		if (strPensionDisability.contentEquals("Pension/Disability")) {
			 			CommonAppMethodsEmployment.SelectOtherSourcesOfIncome(strPensionDisability); 
			 		}
					if (strSpousalSupport.contentEquals("Spousal Support")) {
						CommonAppMethodsEmployment.SelectOtherSourcesOfIncome(strSpousalSupport); 
					} 
					Common.continueButtonClicked();
					Thread.sleep(500); 
						
						//  What's the annual income for each source?
					if (strChildSupport != null | strChildSupportAmt.length() != 0) {
						CommonAppMethodsEmployment.EnterAnualIncomeSourceAmount(strChildSupport, strChildSupportAmt);
						}
					if (strInvestments != null | strInvestmentsAmt.length() != 0) {
						CommonAppMethodsEmployment.EnterAnualIncomeSourceAmount(strInvestments, strInvestmentsAmt);
						}
					if (strPensionDisability != null | strPensionDisabilityAmt.length() != 0) {
						CommonAppMethodsEmployment.EnterAnualIncomeSourceAmount(strPensionDisability, strPensionDisabilityAmt);
					}
					if (strSpousalSupport != null | strSpousalSupportAmt.length() != 0) {
						CommonAppMethodsEmployment.EnterAnualIncomeSourceAmount(strSpousalSupport, strSpousalSupportAmt);
					}
						 	
					Thread.sleep(500);
					
					Utility.clickObject("//*[@id=\"app\"]/div/div[1]/div[3]/button[2]/span", "Button");
					Thread.sleep(500);  
			 	}
			 	else if (strCurrentEmpStatus.contentEquals("Retired")) {
			 		CommonAppMethodsEmployment.SelectEmpStatus("Retired");
			 		
			 		if (strDurationYear != "") {
			 			CommonApplicationMethods.selectValuefromDropDownListBox("ehome.employmentDuration.years", strDurationYear);
				 		Thread.sleep(500);
			 		}
			 		
			 		if (strDurationMonth != "") {
			 			CommonApplicationMethods.selectValuefromDropDownListBox("ehome.employmentDuration.months", strDurationMonth);
				 		Thread.sleep(500);
			 		}
			 		Thread.sleep(1000);
			 		Common.continueButtonClicked();
			 		Thread.sleep(1000);
		 		
			 		if (strInvestments.contentEquals("Investments")) {
			 			CommonAppMethodsEmployment.SelectRetiredSourcesOfIncome(strInvestments); 
			 		}
			 		if (strPensionDisability.contentEquals("Pension/Disability")) {
			 			CommonAppMethodsEmployment.SelectRetiredSourcesOfIncome(strPensionDisability); 
			 		}
			 		if (strRIFLIF.contentEquals("RIF/LIF")) {
						CommonAppMethodsEmployment.SelectRetiredSourcesOfIncome(strRIFLIF); 
					}
			 		if (strInvestments.contentEquals("No sources of income") | strPensionDisability.contentEquals("No sources of income")  | strRIFLIF.contentEquals("No sources of income")  ) {
						CommonAppMethodsEmployment.SelectRetiredSourcesOfIncome("No sources of income"); 
					}
			 		Common.continueButtonClicked();
			 		Thread.sleep(1000);
			 		
			 		if (strInvestments != null | strInvestmentsAmt.length() != 0) {
						CommonAppMethodsEmployment.EnterRetiredAnualIncomeSourceAmount(strInvestments, strInvestmentsAmt);
					}
					if (strPensionDisability != null | strPensionDisabilityAmt.length() != 0) {
						CommonAppMethodsEmployment.EnterRetiredAnualIncomeSourceAmount(strPensionDisability, strPensionDisabilityAmt);
					}
					
					if (strRIFLIF != null | strRIFLIFAmt.length() != 0) {
						CommonAppMethodsEmployment.EnterRetiredAnualIncomeSourceAmount(strRIFLIF, strRIFLIFAmt);
					}
					Thread.sleep(500);
					if (strInvestments != "" | strPensionDisability != "" | strRIFLIF !=""  )
					{
						Utility.clickObject("//*[@id=\"app\"]/div/div[1]/div[3]/button[2]/span", "Button");
						Thread.sleep(500);
					}
			 	}
			 	else if (strEmploymentType.contentEquals("Self Employed")) {
			 		CommonAppMethodsEmployment.SelectEmpType("Self Employed");}
		 	}
		 	
		 	 /* *************************************************************************************************************************************************
			 Author: 	  RameshChalumuri
			 Method Name: PreCondition_Traverse_Stage1_to_Entry_of_Stage6_functionality
			 Purpose: 	  PreCondition Traverse Stage1(WelcomeTriage Questions & Prospect Registration) to Entry of Stage6
			 Created on:  26-October-2018  
			 Updated By:  RameshChalumuri
			 Updated on:  11-November-2018
			 *************************************************************************************************************************************************** */
			 
			 	@Given("^E2E Stage1 to Stage6$")
			 	public static void E2E_Stage1ToStage6() throws Throwable 
			 	{
			 		
			 		String strtestCaseID = "E2E-Scenario-001"; // Utility.getScenarioID();
					Utility.launchURL(ConfigurationUtils.getBaseBundle ().getPropertyValue ("env.baseurl1"));
			 		

						// Passing "Excel Path", "Sheet name", "Test Case ID" as parameters
					Map<String, String> E2E_ExcelData =  Utility.readTestData(strfullPathToFile, sheetNameE2E,strtestCaseID);
			    	String strExpectedAddress= E2E_ExcelData.get("Address"); 										// Retrieve "Address" from Excel 
			    	String strExpectedPropertyType= E2E_ExcelData.get("PropertyType");								// Retrieve "PropertyType" from Excel 
			    	String strExpectedHouseType= E2E_ExcelData.get("HouseType");									// Retrieve "HouseType" from Excel
			    	String strExpectedCondoFees = E2E_ExcelData.get("CondoFees");									// Retrieve "CondoFees" from Excel
			    	String strExpectedSquareFeet  = E2E_ExcelData.get("SquareFeet");								// Retrieve "SquareFeet" from Excel
			    	String strExpectedPurchasePrice  = E2E_ExcelData.get("PurchasePrice");							// Retrieve "PurchasePrice" from Excel
			    	String strExpectedDownPayment  = E2E_ExcelData.get("DownPayment");								// Retrieve "DownPayment" from Excel
			    	String strExpectedDownPymtSrcBankAcct  = E2E_ExcelData.get("DownPymtSrcBankAcct");				// Retrieve "DownPymtSrcBankAcct" from Excel
			    	String strExpectedDownPymtSrcInvAcct  = E2E_ExcelData.get("DownPymtSrcInvAcct");				// Retrieve "DownPymtSrcInvAcct" from Excel
			    	String strExpectedDownPymtSrcFamilyGift  = E2E_ExcelData.get("DownPymtSrcFamilyGift");			// Retrieve "DownPymtSrcFamilyGift" from Excel
			    	String strExpectedDownPymtSrcRRSP  = E2E_ExcelData.get("DownPymtSrcRRSP");						// Retrieve "DownPymtSrcRRSP" from Excel
			    	String strExpectedDownPymtSrcSaleOfAss  = E2E_ExcelData.get("DownPymtSrcSaleOfAss");			// Retrieve "DownPymtSrcSaleOfAss" from Excel
			    	String strExpectedDownPymtSrcSaleOfExist  = E2E_ExcelData.get("DownPymtSrcSaleOfExist");		// Retrieve "DownPymtSrcSaleOfExist" from Excel
			    	String strExpectedDownPymtSrcBankAcctAmt  = E2E_ExcelData.get("DownPymtSrcBankAcctAmt");		// Retrieve "DownPymtSrcBankAcctAmt" from Excel
			    	String strExpectedDownPymtSrcInvAcctAmt  = E2E_ExcelData.get("DownPymtSrcInvAcctAmt");			// Retrieve "DownPymtSrcnvAcctAmt" from Excel
			    	String strExpectedDownPymtSrcFamilyGiftAmt  = E2E_ExcelData.get("DownPymtSrcFamilyGiftAmt");	// Retrieve "DownPymtSrcFamilyGiftAmt" from Excel		
			    	String strExpectedDownPymtSrcRRSPAmt  = E2E_ExcelData.get("DownPymtSrcRRSPAmt");				// Retrieve "DownPymtSrcRRSPAmt" from Excel
			    	String strExpectedDownPymtSrcSaleOfAssAmt  = E2E_ExcelData.get("DownPymtSrcSaleOfAssAmt");		// Retrieve "DownPymtSrcSaleOfAssAmt" from Excel
			    	String strExpectedDownPymtSrcSaleOfExistAmt  = E2E_ExcelData.get("DownPymtSrcSaleOfExistAmt");	// Retrieve "DownPymtSrcSaleOfExistAmt" from Excel
			    	
			    	String strTypeOfRate            = E2E_ExcelData.get("TypeOfRate"); // Retrieve "TypeOfRate" from Excel 
			    	String strMortgageTerm          = E2E_ExcelData.get("MortgageTerm");// Retrieve "MortgageTerm" from Excel 
			       	String strratecustomization     = E2E_ExcelData.get("RateCustomization");// Retrieve "UnLockYourRate" from Excel
			    	String strrateunlock            = E2E_ExcelData.get("RateUnlock");// Retrieve "RateUnlock" from Excel
			    	String strrateequity            = E2E_ExcelData.get("RateEquity");// Retrieve "Rate Equity" from Excel 
			       
					String strCurrentEmpStatus	= E2E_ExcelData.get("CurrentEmpStatus"); 	// Retrieve "Current Employment status" from Excel
					String strEmploymentType = E2E_ExcelData.get("EmploymentType");
					String strFieldOfWork=  E2E_ExcelData.get("EmploymentFieldOfWork");
					String strJobTitle=  E2E_ExcelData.get("EmploymentJobTitle");
					String strDurationYear=  E2E_ExcelData.get("Years");
					String strDurationMonth=  E2E_ExcelData.get("Months");
					
					String strChildSupport= E2E_ExcelData.get("EmpOtherSrcsOfIncome1");
					String strCommission= E2E_ExcelData.get("EmpOtherSrcsOfIncome2");
					String strInvestments= E2E_ExcelData.get("EmpOtherSrcsOfIncome3");
					String strPartTimeWork= E2E_ExcelData.get("EmpOtherSrcsOfIncome4");
					String strPensionDisability= E2E_ExcelData.get("EmpOtherSrcsOfIncome5");
					String strRIFLIF= E2E_ExcelData.get("EmpOtherSrcsOfIncome6");
					String strSeasonalWork= E2E_ExcelData.get("EmpOtherSrcsOfIncome7");
				    String strSpousalSupport= E2E_ExcelData.get("EmpOtherSrcsOfIncome8");
					
					String strChildSupportAmt= E2E_ExcelData.get("EmpOtherSrcsOfIncome1Amt");
					String strCommissionAmt= E2E_ExcelData.get("EmpOtherSrcsOfIncome2Amt");
					String strInvestmentsAmt= E2E_ExcelData.get("EmpOtherSrcsOfIncome3Amt");
					String strPartTimeWorkAmt= E2E_ExcelData.get("EmpOtherSrcsOfIncome4Amt");
					String strPensionDisabilityAmt= E2E_ExcelData.get("EmpOtherSrcsOfIncome5Amt");
					String strRIFLIFAmt= E2E_ExcelData.get("EmpOtherSrcsOfIncome6Amt");
					String strSeasonalWorkAmt= E2E_ExcelData.get("EmpOtherSrcsOfIncome7Amt");
					String strSpousalSupportAmt= E2E_ExcelData.get("EmpOtherSrcsOfIncome8Amt");
					
					String strAutomobile = E2E_ExcelData.get("AssetSources1");
					String strCash = E2E_ExcelData.get("AssetSources2");
					String strGICTermDeposit = E2E_ExcelData.get("AssetSources3");
				 	String strPrimaryResidence = E2E_ExcelData.get("AssetSources4");
				  	String strRentalProperty = E2E_ExcelData.get("AssetSources5");
				 	String strRRSP = E2E_ExcelData.get("AssetSources6");
				 	String strSecondaryProperty = E2E_ExcelData.get("AssetSources7");
				 	String strStockBond = E2E_ExcelData.get("AssetSources8");
				 	String strOtherAssets = E2E_ExcelData.get("AssetSources9");
				 	
				 	String strAutomobileAmt = E2E_ExcelData.get("AssetSources1Amt");
				 	String strCashAmt = E2E_ExcelData.get("AssetSources2Amt");
				 	String strGICTermDepositAmt = E2E_ExcelData.get("AssetSources3Amt");
				 	String strPrimaryResidenceAmt = E2E_ExcelData.get("AssetSources4Amt");
				 	String strRentalPropertyAmt = E2E_ExcelData.get("AssetSources5Amt");
				 	String strRRSPAmt = E2E_ExcelData.get("AssetSources6Amt");
				 	String strSecondaryPropertyAmt = E2E_ExcelData.get("AssetSources7Amt");
				 	String strStockBondAmt = E2E_ExcelData.get("AssetSources8Amt");
				 	String strOtherAssetsAmt = E2E_ExcelData.get("AssetSources9Amt");
				 	
				 	String strAlimonyLiability = E2E_ExcelData.get("LiabilitySources1");
				 	String strChildSupportLiability = E2E_ExcelData.get("LiabilitySources2");
				 	String strPrivateDebtLiability = E2E_ExcelData.get("LiabilitySources3");
				 	
				 	String strAlimonyLiabilityMonthlyPaymt = E2E_ExcelData.get("LiabilitySources1MonthlyPaymt");
				 	String strChildSupportLiabilityMonthlyPayment = E2E_ExcelData.get("LiabilitySources2MonthlyPaymt");
				 	String strPrivateDebtLiabilityMonthlyPayment = E2E_ExcelData.get("LiabilitySources3MonthlyPaymt");
				 	String strPrivateDebtLiabilityBalanceOwing = E2E_ExcelData.get("LiabilitySources3BalanceOwing");
				 	String strCoAppCurrentEmpStatus = E2E_ExcelData.get("CoAppCurentEmpStatus");
				 	String strCoAppEmpOtherSrcsOfIncomeNoOtherSrcs= E2E_ExcelData.get("EmpCoAppNoOtherSrcsOfIncome");
				 																		 
				 	String strCoAppEmpOtherSrcsOfIncomeChildSupport = E2E_ExcelData.get("EmpCoAppSrcsOfIncomeChildSupport");
				 	String strCoAppEmpOtherSrcsOfIncomeChildSupportAmt=E2E_ExcelData.get("EmpCoAppSrcsOfIncomeChildSupportAmt");
				 	String strCoAppEmpOtherSrcsOfIncomeInvest = E2E_ExcelData.get("EmpCoAppSrcsOfIncomeInvestment");
				 	String strCoAppEmpOtherSrcsOfIncomeInvestAmt=E2E_ExcelData.get("EmpCoAppSrcsOfIncomeInvestmentAmt");
				 	String strCoAppEmpOtherSrcsOfIncomePensionDisability = E2E_ExcelData.get("EmpCoAppSrcsOfIncomePensionDisab");
				 	String strCoAppEmpOtherSrcsOfIncomePensionDisabilityAmt=E2E_ExcelData.get("EmpCoAppSrcsOfIncomePensionDisabAmt");
	 
				 	Thread.sleep(1000);
				 	
				// 	Common.continueButtonClicked();
				 	
				 	Utility.clickObject("//*[@id=\"app\"]/div/div[1]/div[2]/div/div[3]/div/button/span", "Continue Button in New Home Screen");
					 
			    	if (strExpectedAddress.contentEquals("Manual Address")) {
			     		CommonApplicationMethods.enterAddressManually(); // Select Address Manually in "Address of your new home"
			     	}
			     	else
			     	{
			     		CommonApplicationMethods.enterAutosuggestaddress(strExpectedAddress); // Enters Auto suggest address (DMTI field) in Address screen 
			     	}
			     	
			     	Thread.sleep(4000);
			     	CommonAppMethodsYourNewHome.selectPropertyType(strExpectedPropertyType); // Select Property Type in "Type of Property"
			     	Thread.sleep(2000);
			     	
			     	if (strExpectedPropertyType.contentEquals("Condo")) {
			     		Utility.sendKeys("ehome.CondoFees.CondoFees.input", strExpectedCondoFees); // Enter "Condo fee" in "Type of Property" 
			     		Thread.sleep(1000);
			     		Utility.clickObject("ehome.CloseDtContinue.button", "Button"); // Click on Continue in "Type of Property"  
			      		Thread.sleep(2000);
			     	}
			        
			     	if (strExpectedPropertyType.contentEquals("House")) {
			     		CommonAppMethodsYourNewHome.selectTypeofHouse(strExpectedHouseType); // Select Type of House in "Type of house" 
			     		Thread.sleep(2000);
			     	}
			       
			     	Utility.sendKeys("ehome.areaOfProp.squrft.value", strExpectedSquareFeet); // Enter "Area of Property" 
			     	Thread.sleep(500);
			    	Utility.clickObject("ehome.areaOfProp.continue.button", "Button"); // Click on Continue
			    	Thread.sleep(500);
			     	Utility.sendKeys("ehome.PurchasePrice.inputtextbox", strExpectedPurchasePrice); // Enter "Purchase Price" in Purchase Price
			     	Thread.sleep(500);
			    	Utility.clickObject("ehome.areaOfProp.continue.button", "Button"); // Click on Continue
			    	Thread.sleep(500);
			    	Utility.sendKeys("ehome.DownPayement.Price", strExpectedDownPayment); // Enter "Down Payment Amount" in Down Payment
			     	Thread.sleep(500);
			     	Utility.clickObject("ehome.areaOfProp.continue.button", "Button"); // Click on Continue
			     	Thread.sleep(1000);
			     	
			     	if (strExpectedDownPymtSrcBankAcct.contentEquals("Bank account")) {
			     		CommonAppMethodsYourNewHome.selectDownPaymentSources(strExpectedDownPymtSrcBankAcct); // Select "Bank account" option 
			     	}
		     		
			     	if (strExpectedDownPymtSrcInvAcct.contentEquals("Investment account")) {
			     		CommonAppMethodsYourNewHome.selectDownPaymentSources(strExpectedDownPymtSrcInvAcct); // Select "Investment account" option 
			     	}
			     	
			     	if (strExpectedDownPymtSrcFamilyGift.contentEquals("A gift from family")) {
			     		CommonAppMethodsYourNewHome.selectDownPaymentSources(strExpectedDownPymtSrcFamilyGift); // Select "A gift from family" option 
			     	}
			     	
			     	if (strExpectedDownPymtSrcRRSP.contentEquals("RRSP withdrawal")) {
			     		CommonAppMethodsYourNewHome.selectDownPaymentSources(strExpectedDownPymtSrcRRSP); // Select "RRSP withdrawal" option 
			     	}
			     	
			     	if (strExpectedDownPymtSrcSaleOfAss.contentEquals("Sale of asset")) {
			     		CommonAppMethodsYourNewHome.selectDownPaymentSources(strExpectedDownPymtSrcSaleOfAss); // Select "Sale of asset" option 
			     	}
			     	
			     	if (strExpectedDownPymtSrcSaleOfExist.contentEquals("Sale of existing property")) {
			     		CommonAppMethodsYourNewHome.selectDownPaymentSources(strExpectedDownPymtSrcSaleOfExist); // Select "Sale of existing property" option 
			     	}
			     	
			     	Thread.sleep(500);  
			     	Utility.clickObject("ehome.areaOfProp.continue.button", "Button");
			     	Thread.sleep(500);  
			     	
			     	//  ***** STAGE2-Detailed Down Payment Screen# *****
			       if (strExpectedDownPymtSrcBankAcct != null | strExpectedDownPymtSrcBankAcctAmt.length() != 0) {
			    	   CommonAppMethodsYourNewHome.enterDownPaymentSourcesAmount(strExpectedDownPymtSrcBankAcct, strExpectedDownPymtSrcBankAcctAmt);
			       		Thread.sleep(500); 
			     	}
			     	if (strExpectedDownPymtSrcInvAcct != null | strExpectedDownPymtSrcInvAcctAmt.length() != 0) {
			     		CommonAppMethodsYourNewHome.enterDownPaymentSourcesAmount(strExpectedDownPymtSrcInvAcct, strExpectedDownPymtSrcInvAcctAmt);
			     		Thread.sleep(500);  
			     	}
			     	if (strExpectedDownPymtSrcFamilyGift != null | strExpectedDownPymtSrcFamilyGiftAmt.length() != 0) {
			     		CommonAppMethodsYourNewHome.enterDownPaymentSourcesAmount(strExpectedDownPymtSrcFamilyGift, strExpectedDownPymtSrcFamilyGiftAmt);
			     		Thread.sleep(500);  
			     	}
			     	if (strExpectedDownPymtSrcRRSP != null | strExpectedDownPymtSrcRRSPAmt.length() != 0) {
			     		CommonAppMethodsYourNewHome.enterDownPaymentSourcesAmount(strExpectedDownPymtSrcRRSP, strExpectedDownPymtSrcRRSPAmt);
			     		Thread.sleep(500);  
			     	}
			     	if (strExpectedDownPymtSrcSaleOfAss != null | strExpectedDownPymtSrcSaleOfAssAmt.length() != 0) {
			     		CommonAppMethodsYourNewHome.enterDownPaymentSourcesAmount(strExpectedDownPymtSrcSaleOfAss, strExpectedDownPymtSrcSaleOfAssAmt);
			     		Thread.sleep(500);  
			     	}
			     	if (strExpectedDownPymtSrcSaleOfExist != null | strExpectedDownPymtSrcSaleOfExistAmt.length() != 0) {
			     		CommonAppMethodsYourNewHome.enterDownPaymentSourcesAmount(strExpectedDownPymtSrcSaleOfExist, strExpectedDownPymtSrcSaleOfExistAmt);
			     		Thread.sleep(500);  
			     	}
			     	
			    	Utility.clickObject("ehome.detailsofdownpayment.ContinueButtonDetails", "Button"); // Click on Continue
			      	Thread.sleep(500);
			      	
			      	Utility.clickObject("ehome.closingDtPicker.button", "Button");
			     	Thread.sleep(500);
			     	Utility.clickObject("ehome.closingDtPickerSelection.button", "Button");
			     	Thread.sleep(500);
			      	Utility.clickObject("ehome.CloseDtContinue.button", "Button"); // Click on Continue
			      	Thread.sleep(500);
			     	Utility.clickObject("ehome.detailsofdownpayment.ContinueButtonDetails", "Button"); // Click on Continue button in Details of 
			     	Thread.sleep(500);
			      	Utility.clickObject("ehome.Stage3SectionBrkContinue.button", "Button"); // Click on "Continue" button 
			  	   // Stag 2 End Here //***********************************************	 
			  
			    	CommonAppMethodsGettingNewRate.selectRateType(strTypeOfRate); // Select "Type of Rate" option 
			    	Thread.sleep(2000);
		    		    	
			    	if (strTypeOfRate.contentEquals("Fixed")) {
			    		CommonAppMethodsGettingNewRate.selectMortgageTerm(strMortgageTerm); // Select "Mortgage Term" option 
			    		Thread.sleep(1000);
			    	}
			    
			    	CommonAppMethodsGettingNewRate.chooseRatesfromRatePresentment(strTypeOfRate, strMortgageTerm); // Choose Rates button
			    	Thread.sleep(500);
			    	
			    	Utility.clickObject("ehome.ratelock.LockandHold", "Button"); // Click on Lock & Hold button
			    	Thread.sleep(1000);
			    	if (strratecustomization.contentEquals("Unlockyourrate")) {
			    		Utility.clickObject("ehome.rateunlock.UnlockyourrateBtn", "Button"); // Click on Unlock your rate
			    		Thread.sleep(500);
			    		if (strrateunlock.contentEquals("Yes, unlock my rate")) {
			    			Utility.clickObject("ehome.rateunlock.Yesunlockmyrate", "Button"); // Click on Yes, unlock my rate
			    			return;
			    		}
			    		if (strrateunlock.contentEquals("No, keep my rate")) {
			    			Utility.clickObject("ehome.rateunlock.Nokeepmyrate", "Button"); // Click on No, keep my rate
			    		}
			    	}
			    	Utility.clickObject("ehome.RateCustContiniueBtn", "Button"); // Click on Continue button
			    	QAFExtendedWebElement strActualSTEPTitle= new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[2]/div/div[2]/h2");
			    	if(strActualSTEPTitle.getText().contains("Plan (STEP)")) //"STEP" Title
			    	{
			    		Utility.clickObject("ehome.STEPContiniueBtn", "Button");
			    	}	
			    	else
			    	{
			    		System.err.printf("Plan (STEP) is NOT displayed", strActualSTEPTitle.getText());
			    	}
			    	Double dbPurchasePrice = Double.valueOf(strExpectedPurchasePrice);
			    	Double dbDownPayment = 	Double.valueOf(strExpectedDownPayment);
			    	Double defaultInsurance =  dbDownPayment/dbPurchasePrice*100;
			    	
			    	if(defaultInsurance >= 20.0)
			    	{
			    		if (strrateequity.contentEquals("Yes, I'm interested")) {
			    			Utility.clickObject("ehome.step.yesImInterestedBtn", "Button");
			    			Utility.clickObject("ehome.CloseDtContinue.button", "Button");
			    		}
			    	}
			    	if (strrateequity.contentEquals("No thanks")) {
			    		QAFExtendedWebElement NothanksBtn= new QAFExtendedWebElement("ehome.step.NothanksBtn");
			    		NothanksBtn.click(); // Click on Continue
			    	}
			    	Utility.clickObject("ehome.RateViewContinueBtn", "Button");
			    	Utility.clickObject("//*[@id=\"app\"]/div/div[1]/div/div/div[3]/div/button/span", "Button");
		 	
		
				 	Thread.sleep(2000);
				 	if (strCurrentEmpStatus.contentEquals("Employed")) {                // Selecting current Employment Status
				 		CommonAppMethodsEmployment.SelectEmpStatus("Employed");
				 		
				 		Thread.sleep(4000);
				 		if (strEmploymentType.contentEquals("Commissioned sales")) {             // Selecting Employment Type
				 			CommonAppMethodsEmployment.SelectEmpType("Commissioned sales");}
				 		else if (strEmploymentType.contentEquals("Contract")) {
				 			CommonAppMethodsEmployment.SelectEmpType("Contract");}
				 		else if (strEmploymentType.contentEquals("Full Time")) {
				 			CommonAppMethodsEmployment.SelectEmpType("Full Time");}
				 		else if (strEmploymentType.contentEquals("Part Time")) {
				 			CommonAppMethodsEmployment.SelectEmpType("Part Time");}
				 		else if (strEmploymentType.contentEquals("Seasonal")) {
				 			CommonAppMethodsEmployment.SelectEmpType("Seasonal");}
				 		Thread.sleep(2000);
				 		CommonApplicationMethods.selectValuefromDropDownListBox("//*[@id=\"jobField\"]", strFieldOfWork); // Selecting Field of work
				 		Thread.sleep(1000);
				 		CommonApplicationMethods.selectValuefromDropDownListBox("//*[@id=\"jobTitle\"]", strJobTitle);    // Selecting Job Title
				 		Common.continueButtonClicked();
				 		Thread.sleep(1000);
							
				 		Utility.sendKeys("//*[@id=\'employerName\']","Scotia Bank");
				 		Utility.sendKeys("//*[@id=\"employerPhone\"]","6471234567");
				 		Thread.sleep(1000);
				 		Common.continueButtonClicked();
				 		Thread.sleep(500);
							
				 		CommonApplicationMethods.enterAutoSuggestAddress("888 Birch","ehome.employeraddress.address","//*[@id=\"app\"]/div/div[1]/div[1]/section/div/div[3]/div[1]/div/div[2]/div/ul" );
				 		Thread.sleep(1000);
						Common.continueButtonClicked();
				 		
				 		Thread.sleep(4000);
				 		Utility.sendKeys("ehome.annualIncome.salary", "120000");
				 		Utility.sendKeys("ehome.annualIncome.bonus", "9000");
				 		Utility.sendKeys("ehome.annualIncome.overtime", "50000");
				 		Thread.sleep(1000);
							
				 		Common.continueButtonClicked();
				 		Thread.sleep(1000);
				 		
				 		if (strDurationYear != "") {
				 			CommonApplicationMethods.selectValuefromDropDownListBox("ehome.employmentDuration.years", strDurationYear);
					 		Thread.sleep(500);
				 		}
				 		
				 		if (strDurationMonth != "") {
				 			CommonApplicationMethods.selectValuefromDropDownListBox("ehome.employmentDuration.months", strDurationMonth);
					 		Thread.sleep(500);
				 		}
				 		
				 		Common.continueButtonClicked();
				 		Thread.sleep(1000);
				 		
				 		if (strDurationYear.contentEquals("1 year") | strDurationYear.contentEquals("0 years") ){  
				 			Utility.sendKeys("ehome.previousEmployerDetails.employerName","Mahindra Satyam");
					 		Thread.sleep(500);
					 		Common.continueButtonClicked();
					 		Thread.sleep(500);
			 				Utility.sendKeys("ehome.previousAnnualIncome.salary", "80000");
					 		Thread.sleep(500);
					 		Common.continueButtonClicked();
					 		Thread.sleep(1000);
					 		CommonApplicationMethods.selectValuefromDropDownListBox("ehome.previousemploymentDuration.years", strDurationYear);
					 		Thread.sleep(500);
					 		CommonApplicationMethods.selectValuefromDropDownListBox("ehome.previousemploymentDuration.months", strDurationMonth);
					 		Thread.sleep(500);
					 		Common.continueButtonClicked();
					 		Thread.sleep(1000);
				 			 		}
				 		
						
							//  Do you have any other sources of income?
				 		if (strChildSupport.contentEquals("Child Support")) {
				 			CommonAppMethodsEmployment.SelectOtherSourcesOfIncome(strChildSupport); 
				 		}
				 		if (strCommission.contentEquals("Commission")) {
				 			CommonAppMethodsEmployment.SelectOtherSourcesOfIncome(strCommission); 
				 		}
				 		if (strInvestments.contentEquals("Investments")) {
				 			CommonAppMethodsEmployment.SelectOtherSourcesOfIncome(strInvestments); 
				 		}
				 		if (strPartTimeWork.contentEquals("Part Time Work")) {
				 			CommonAppMethodsEmployment.SelectOtherSourcesOfIncome(strPartTimeWork); 
				 		}
				 		if (strPensionDisability.contentEquals("Pension/Disability")) {
				 			CommonAppMethodsEmployment.SelectOtherSourcesOfIncome(strPensionDisability); 
				 		}
						if (strRIFLIF.contentEquals("RIF/LIF")) {
							CommonAppMethodsEmployment.SelectOtherSourcesOfIncome(strRIFLIF); 
						}
						if (strSeasonalWork.contentEquals("Seasonal Work")) {
							CommonAppMethodsEmployment.SelectOtherSourcesOfIncome(strSeasonalWork); 
						}
						if (strSpousalSupport.contentEquals("Spousal Support")) {
							CommonAppMethodsEmployment.SelectOtherSourcesOfIncome(strSpousalSupport); 
						}
						
						if (strChildSupport.contentEquals("No other sources of income") | strCommission.contentEquals("No other sources of income") | strPartTimeWork.contentEquals("No other sources of income") | strPensionDisability.contentEquals("No other sources of income")| strRIFLIF.contentEquals("No other sources of income")| strInvestments.contentEquals("No other sources of income")| strSeasonalWork.contentEquals("No other sources of income")| strSpousalSupport.contentEquals("No other sources of income")) {
							CommonAppMethodsEmployment.SelectOtherSourcesOfIncome("No other sources of income");
						}
						Common.continueButtonClicked();
						Thread.sleep(500); 
							
							//  What's the annual income for each source?
						if (strChildSupport != null | strChildSupportAmt.length() != 0) {
							CommonAppMethodsEmployment.EnterAnualIncomeSourceAmount(strChildSupport, strChildSupportAmt);
						}
						if (strCommission != null | strCommissionAmt.length() != 0) {
							CommonAppMethodsEmployment.EnterAnualIncomeSourceAmount(strCommission, strCommissionAmt);
						}
						if (strInvestments != null | strInvestmentsAmt.length() != 0) {
							CommonAppMethodsEmployment.EnterAnualIncomeSourceAmount(strInvestments, strInvestmentsAmt);
						}
						if (strPartTimeWork != null | strPartTimeWorkAmt.length() != 0) {
							CommonAppMethodsEmployment.EnterAnualIncomeSourceAmount(strPartTimeWork, strPartTimeWorkAmt);
						}
						if (strPensionDisability != null | strPensionDisabilityAmt.length() != 0) {
							CommonAppMethodsEmployment.EnterAnualIncomeSourceAmount(strPensionDisability, strPensionDisabilityAmt);
						}
						if (strRIFLIF != null | strRIFLIFAmt.length() != 0) {
							CommonAppMethodsEmployment.EnterAnualIncomeSourceAmount(strRIFLIF, strRIFLIFAmt);
						}
			
						if (strSeasonalWork != null | strSeasonalWorkAmt.length() != 0) {
							CommonAppMethodsEmployment.EnterAnualIncomeSourceAmount(strSeasonalWork, strSeasonalWorkAmt);
						}
						if (strSpousalSupport != null | strSpousalSupportAmt.length() != 0) {
							CommonAppMethodsEmployment.EnterAnualIncomeSourceAmount(strSpousalSupport, strSpousalSupportAmt);
						}
							 	
						Thread.sleep(500);
						
						Utility.clickObject("//*[@id=\"app\"]/div/div[1]/div[3]/button[2]/span", "Button");
						Thread.sleep(500);  
						
						Utility.clickObject("//*[@id=\"app\"]/div/div[1]/div/div/div[2]/aside/div[2]/div[2]/div/div/button","Skip section Button");
						
						 	
						Thread.sleep(500);
//						if (strCoAppEmpOtherSrcsOfIncomeNoOtherSrcs.contentEquals ("No other sources") | strCoAppEmpOtherSrcsOfIncomeNoOtherSrcs.contentEquals("No other sources of income")) {
//							CommonAppMethodsAssetLiabilities.SelectCoAppSrcsOfIncome(strCoAppEmpOtherSrcsOfIncomeNoOtherSrcs, "");
//						}
//						if (strCoAppEmpOtherSrcsOfIncomeChildSupport.contentEquals("Child Support")) {
//							CommonAppMethodsAssetLiabilities.SelectCoAppSrcsOfIncome(strCoAppEmpOtherSrcsOfIncomeChildSupport, strCoAppEmpOtherSrcsOfIncomeChildSupportAmt);
//						}
//								
//						if (strCoAppEmpOtherSrcsOfIncomeInvest.contentEquals("Investments")) {
//							CommonAppMethodsAssetLiabilities.SelectCoAppSrcsOfIncome(strCoAppEmpOtherSrcsOfIncomeInvest, strCoAppEmpOtherSrcsOfIncomeInvestAmt);
//						}
//								
//						if (strCoAppEmpOtherSrcsOfIncomePensionDisability.contentEquals("Pension/Disability")) {
//							CommonAppMethodsAssetLiabilities.SelectCoAppSrcsOfIncome(strCoAppEmpOtherSrcsOfIncomePensionDisability, strCoAppEmpOtherSrcsOfIncomePensionDisabilityAmt);
//						}
//							 	
//						Utility.clickObject("//*[@id=\"app\"]/div/div[1]/div/div/div[3]/div/div[2]/section/div/div[2]/div/button/span", "Button");
						
						//Do you have any of the following assets?
						
						if (strAutomobile.contentEquals("Automobile")) {
							CommonAppMethodsAssetLiabilities.SelectAssetsSources(strAutomobile); 
						}
						if (strCash.contentEquals("Cash")) {
							CommonAppMethodsAssetLiabilities.SelectAssetsSources(strCash); 
						}
						if (strGICTermDeposit.contentEquals("GIC/Term Deposit")) {
							CommonAppMethodsAssetLiabilities.SelectAssetsSources(strGICTermDeposit); 
						}
						if (strPrimaryResidence.contentEquals("Primary Residence")) {
							CommonAppMethodsAssetLiabilities.SelectAssetsSources(strPrimaryResidence); 
						}
						
						if (strRentalProperty.contentEquals("Rental Property")) {
							CommonAppMethodsAssetLiabilities.SelectAssetsSources(strRentalProperty); 
						}
						if (strRRSP.contentEquals("RRSP")) {
							CommonAppMethodsAssetLiabilities.SelectAssetsSources(strRRSP); 
						}
						if (strSecondaryProperty.contentEquals("SecondaryProperty")) {
							CommonAppMethodsAssetLiabilities.SelectAssetsSources(strSecondaryProperty); 
						}
						if (strStockBond.contentEquals("Stock/Bond")) {
							CommonAppMethodsAssetLiabilities.SelectAssetsSources(strStockBond); 
						}
						if (strOtherAssets.contentEquals("Other Assets")) {
							CommonAppMethodsAssetLiabilities.SelectAssetsSources(strOtherAssets); 
						}
						if (strAutomobile.contentEquals("No other assets") | strCash.contentEquals("No other assets") | strGICTermDeposit.contentEquals("No other assets") | strPrimaryResidence.contentEquals("No other assets")| strRentalProperty.contentEquals("No other assets")| strRRSP.contentEquals("No other assets")| strSecondaryProperty.contentEquals("No other assets")| strStockBond.contentEquals("No other assets")| strOtherAssets.contentEquals("No other assets")) {
							CommonAppMethodsAssetLiabilities.SelectAssetsSources("No other assets"); 
						}
							
						Common.continueButtonClicked();
						 		
						 	
						//Do you have any of the following assets?
						if (strAutomobile!=null | strAutomobileAmt.length()!= 0) {
							CommonAppMethodsAssetLiabilities.EnterAssetCalculateAmount(strAutomobile, strAutomobileAmt);
						}
						 	
						if (strCash!= null | strCashAmt.length()!= 0) {
							CommonAppMethodsAssetLiabilities.EnterAssetCalculateAmount(strCash, strCashAmt);
						}
						if (strGICTermDeposit!= null | strGICTermDepositAmt.length()!= 0) {
							CommonAppMethodsAssetLiabilities.EnterAssetCalculateAmount(strGICTermDeposit, strGICTermDepositAmt);
						}
						if (strPrimaryResidence!= null | strPrimaryResidenceAmt.length() != 0) {
							CommonAppMethodsAssetLiabilities.EnterAssetCalculateAmount(strPrimaryResidence, strPrimaryResidenceAmt );
						}
						if (strRentalProperty!= null | strRentalPropertyAmt.length() != 0) {
							CommonAppMethodsAssetLiabilities.EnterAssetCalculateAmount(strRentalProperty, strRentalPropertyAmt );
					 	}
						if (strRRSP!= null | strRRSPAmt.length()!= 0) {
							CommonAppMethodsAssetLiabilities.EnterAssetCalculateAmount(strRRSP, strRRSPAmt);
						}
						if (strSecondaryProperty!= null | strSecondaryPropertyAmt.length()!= 0) {
							CommonAppMethodsAssetLiabilities.EnterAssetCalculateAmount(strSecondaryProperty, strSecondaryPropertyAmt);
						}
						if (strStockBond!= null | strStockBondAmt.length()!= 0) {
							CommonAppMethodsAssetLiabilities.EnterAssetCalculateAmount(strStockBond, strStockBondAmt);
						}
						if (strOtherAssets!= null | strOtherAssetsAmt.length() != 0) {
							CommonAppMethodsAssetLiabilities.EnterAssetCalculateAmount(strOtherAssets, strOtherAssetsAmt );
						}
						
						Utility.clickObject("//*[@id=\"app\"]/div/div[1]/div[3]/button[2]/span", "Button");
						
					//	Common.continueButtonClicked();
						//Do you have any liabilities outside of Scotiabank?'
							 
						if (strAlimonyLiability.contentEquals("Alimony")) {
							CommonAppMethodsAssetLiabilities.SelectLiabilitySources(strAlimonyLiability); 
						}
						if (strChildSupportLiability.contentEquals("Child Support")) {
							CommonAppMethodsAssetLiabilities.SelectLiabilitySources(strChildSupportLiability); 
						}
						if (strPrivateDebtLiability .contentEquals("Private Debt")) {
							CommonAppMethodsAssetLiabilities.SelectLiabilitySources(strPrivateDebtLiability ); 
						}
							
						if (strAlimonyLiability.contentEquals("No other liabilities") | strChildSupportLiability.contentEquals("No other liabilities") | strPrivateDebtLiability.contentEquals("No other liabilities")) {
							CommonAppMethodsAssetLiabilities.SelectLiabilitySources("No other liabilities"); 
						}
						
						Common.continueButtonClicked();
							
						//Do you have any liabilities outside of Scotiabank?
							
						if (strAlimonyLiability!=null | strAlimonyLiabilityMonthlyPaymt.length()!= 0) {
							CommonAppMethodsAssetLiabilities.EnterLiabilityCalculateAmount(strAlimonyLiability, strAlimonyLiabilityMonthlyPaymt);
					 	}
						 	
						Thread.sleep(2000);
						
						if (strChildSupportLiability!= null | strChildSupportLiabilityMonthlyPayment.length()!= 0) {
							CommonAppMethodsAssetLiabilities.EnterLiabilityCalculateAmount(strChildSupportLiability, strChildSupportLiabilityMonthlyPayment);
						}
							 
						if (strPrivateDebtLiabilityBalanceOwing.length()!= 0) {
							String strBalanceOwing = "Balance Owing";
							CommonAppMethodsAssetLiabilities.EnterLiabilityCalculateAmount(strBalanceOwing, strPrivateDebtLiabilityBalanceOwing);
						}
						if (strPrivateDebtLiability!= null | strPrivateDebtLiabilityMonthlyPayment.length()!= 0) {
							CommonAppMethodsAssetLiabilities.EnterLiabilityCalculateAmount(strPrivateDebtLiability, strPrivateDebtLiabilityMonthlyPayment);
						 }
							 
						Utility.clickObject("//*[@id=\"app\"]/div/div[1]/div[3]/button[2]/span", "Button");
						Thread.sleep(2000);
						
						Utility.clickObject("//*[@id=\"app\"]/div/div[1]/div/div/div[1]/aside/div[2]/div[2]/div/div/button", "Skip Selection Button");
						Thread.sleep(2000);
						
						//Stage 6 Starts here
						
						Utility.clickObject("//*[@id=\"app\"]/div/div[1]/div[3]/div[2]/div[4]/div/div[1]/div[1]/div[2]/div/label/span[2]", "Purchase & Sale Agreement upload Button");
				    	Thread.sleep(6000);
				    	Runtime.getRuntime().exec("C:\\MyWorkPlace\\AutoIt-workspace\\documentUpload_1.PropertyDocs_PurchaseSaleAgre.exe");
				    	Thread.sleep(1000);
				    	
				    	Utility.clickObject("//*[@id=\"app\"]/div/div[1]/div[3]/div[2]/div[4]/div/div[2]/div[1]/div[2]/div/label/span[2]", "House Listing upload Button");
				    	Thread.sleep(6000);
				    	Runtime.getRuntime().exec("C:\\MyWorkPlace\\AutoIt-workspace\\documentUpload_2.PropertyDocs_HouseListing.exe");
				    	Thread.sleep(1000);
				    	
				    	
				    	Utility.clickObject("//*[@id=\"app\"]/div/div[1]/div[3]/div[2]/div[6]/div/div[1]/div[1]/div[2]/div/label/span[2]", "House Listing upload Button");
				    	Thread.sleep(6000);
				    	Runtime.getRuntime().exec("C:\\MyWorkPlace\\AutoIt-workspace\\documentUpload_3.DownpaymentDocs_RRSPWithdrawalStatement.exe");
				    	Thread.sleep(1000);
					    	
				    	Utility.clickObject("//*[@id=\"app\"]/div/div[1]/div[3]/div[3]/div/button[2]/span", "Continue Button");
		
				 	
				 	}
				
				 	else if (strCurrentEmpStatus.contentEquals("UnEmployed")) {
				 		CommonAppMethodsEmployment.SelectEmpStatus("UnEmployed");
				 		Thread.sleep(2000); 
				 		if (strChildSupport.contentEquals("Child Support")) {
				 			CommonAppMethodsEmployment.SelectOtherSourcesOfIncome(strChildSupport); 
				 		}
				 		if (strInvestments.contentEquals("Investments")) {
				 			CommonAppMethodsEmployment.SelectOtherSourcesOfIncome(strInvestments); 
				 		}
				 		if (strPensionDisability.contentEquals("Pension/Disability")) {
				 			CommonAppMethodsEmployment.SelectOtherSourcesOfIncome(strPensionDisability); 
				 		}
						if (strSpousalSupport.contentEquals("Spousal Support")) {
							CommonAppMethodsEmployment.SelectOtherSourcesOfIncome(strSpousalSupport); 
						} 
						
						
						Common.continueButtonClicked();
						Thread.sleep(500); 
							
							//  What's the annual income for each source?
						if (strChildSupport != null | strChildSupportAmt.length() != 0) {
							CommonAppMethodsEmployment.EnterAnualIncomeSourceAmount(strChildSupport, strChildSupportAmt);
							}
						if (strInvestments != null | strInvestmentsAmt.length() != 0) {
							CommonAppMethodsEmployment.EnterAnualIncomeSourceAmount(strInvestments, strInvestmentsAmt);
							}
						if (strPensionDisability != null | strPensionDisabilityAmt.length() != 0) {
							CommonAppMethodsEmployment.EnterAnualIncomeSourceAmount(strPensionDisability, strPensionDisabilityAmt);
						}
						if (strSpousalSupport != null | strSpousalSupportAmt.length() != 0) {
							CommonAppMethodsEmployment.EnterAnualIncomeSourceAmount(strSpousalSupport, strSpousalSupportAmt);
						}
							 	
						Thread.sleep(500);
						
						Utility.clickObject("//*[@id=\"app\"]/div/div[1]/div[3]/button[2]/span", "Button");
						Thread.sleep(500);  
				 		
				 		
				 	}
				 	else if (strCurrentEmpStatus.contentEquals("Retired")) {
				 		CommonAppMethodsEmployment.SelectEmpStatus("Retired");
				 		
				 		if (strDurationYear != "") {
				 			CommonApplicationMethods.selectValuefromDropDownListBox("ehome.employmentDuration.years", strDurationYear);
					 		Thread.sleep(500);
				 		}
				 		
				 		if (strDurationMonth != "") {
				 			CommonApplicationMethods.selectValuefromDropDownListBox("ehome.employmentDuration.months", strDurationMonth);
					 		Thread.sleep(500);
				 		}
				 		
				 		Thread.sleep(1000);
				 		
				 		Common.continueButtonClicked();
				 		Thread.sleep(1000);
				 		
				 		if (strInvestments.contentEquals("Investments")) {
				 			CommonAppMethodsEmployment.SelectRetiredSourcesOfIncome(strInvestments); 
				 		}
				 		if (strPensionDisability.contentEquals("Pension/Disability")) {
				 			CommonAppMethodsEmployment.SelectRetiredSourcesOfIncome(strPensionDisability); 
				 		}
				 		
				 		if (strRIFLIF.contentEquals("RIF/LIF")) {
							CommonAppMethodsEmployment.SelectRetiredSourcesOfIncome(strRIFLIF); 
						}
				 		
				 		if (strInvestments.contentEquals("No sources of income") | strPensionDisability.contentEquals("No sources of income")  | strRIFLIF.contentEquals("No sources of income")  ) {
							CommonAppMethodsEmployment.SelectRetiredSourcesOfIncome("No sources of income"); 
						}
				 		
				 		Common.continueButtonClicked();
				 		Thread.sleep(1000);
				 		
				 		if (strInvestments != null | strInvestmentsAmt.length() != 0) {
							CommonAppMethodsEmployment.EnterRetiredAnualIncomeSourceAmount(strInvestments, strInvestmentsAmt);
						}
						if (strPensionDisability != null | strPensionDisabilityAmt.length() != 0) {
							CommonAppMethodsEmployment.EnterRetiredAnualIncomeSourceAmount(strPensionDisability, strPensionDisabilityAmt);
							}
						
						if (strRIFLIF != null | strRIFLIFAmt.length() != 0) {
							CommonAppMethodsEmployment.EnterRetiredAnualIncomeSourceAmount(strRIFLIF, strRIFLIFAmt);
							}
						
						Thread.sleep(500);
						
						if (strInvestments != "" | strPensionDisability != "" | strRIFLIF !=""  )
						{
							Utility.clickObject("//*[@id=\"app\"]/div/div[1]/div[3]/button[2]/span", "Button");
							Thread.sleep(500);
						}
					 	}
				 	else if (strEmploymentType.contentEquals("Self Employed")) {
				 		CommonAppMethodsEmployment.SelectEmpType("Self Employed");}
			 	}
		 	
			
		 	 /* *************************************************************************************************************************************************
			 Author: 	  RameshChalumuri
			 Method Name: Demo Stage1 to Stage6
			 Purpose: 	  Demo Stage1 to Stage6
			 Created on:  14-November-2018  
			 Updated By:  
			 Updated on:  
			 *************************************************************************************************************************************************** */
			 
			 	@Given("^eHome-E2E-Stage1 To Stage 6 functionality$")
			 	public static void Demo_Stage1_to_Stage6() throws Throwable 
			 	{
			 		
			 		Utility.launchURL(ConfigurationUtils.getBaseBundle().getPropertyValue ("env.baseurl0"));
			 		
			 		ExtentReportHelper.StepPass("Welcome to eHOME! Screen is displayed.");
			 		Welcome.viewOurPrivacyAgreementButtonClicked();
			 		Thread.sleep(2000);
					ExtentReportHelper.StepPass("Privacy agreement Screen is displayed.");
					PrivacyAgreement.acceptAndContinuetButtonClicked();
					Thread.sleep(2000);
					SOLCustomerQuestion.triageQuestionsButtonClicked();
					Thread.sleep(2000);
					ExtentReportHelper.StepPass("Triage Questions are verified.");
					SOLCustomerQuestion.noButtonClicked();
					Thread.sleep(2000);
					LegalName.validlegalname("Mrs", "Delna", "Dr", "Press");
					ExtentReportHelper.StepPass("Legal Name screen is displayed.");
					Common.continueButtonClicked();
					Thread.sleep(2000);
					ExtentReportHelper.StepPass("Marital Status screen is displayed.");
					MaritalStatus.maritalstatusselect("Married");
					Thread.sleep(2000);
					Common.continueButtonClicked();
					Thread.sleep(2000);
					ExtentReportHelper.StepPass("Date Of Birth screen is displayed.");
					DateOfBirth.dateOfBirth("20", "Mar", "1998");
					Common.continueButtonClicked();
					Thread.sleep(2000);
					ExtentReportHelper.StepPass("Address screen is displayed.");
					WhatsYourAddress.ValidWhatsYourAddressValues("2201", "EGLINTON AVE", "TORONTO", "ONTARIO","M1K2M1");
					Common.continueButtonClicked();
					Thread.sleep(2000);
					ExtentReportHelper.StepPass("Email Address screen is displayed."); 
					EmailAddress.ValidEmailAddress("test@test.com", "test@test.com");
					Common.continueButtonClicked();
					
			 		
			 		String strtestCaseID = "E2E-Scenario-001"; // Utility.getScenarioID();
					Utility.launchURL(ConfigurationUtils.getBaseBundle ().getPropertyValue ("env.baseurl1"));
					
					Utility.clickObject("//*[@id=\"app\"]/div/div[1]/div[2]/div/div[3]/div/button/span", "Continue Button in New Home Section Breaker");
					
			 		//Utility.launchURL(ConfigurationUtils.getBaseBundle ().getPropertyValue ("env.baseurl2"));

						// Passing "Excel Path", "Sheet name", "Test Case ID" as parameters
					Map<String, String> E2E_ExcelData =  Utility.readTestData(strfullPathToFile, sheetNameE2E,strtestCaseID);
			    	String strExpectedAddress= E2E_ExcelData.get("Address"); 										// Retrieve "Address" from Excel 
			    	String strExpectedPropertyType= E2E_ExcelData.get("PropertyType");								// Retrieve "PropertyType" from Excel 
			    	String strExpectedHouseType= E2E_ExcelData.get("HouseType");									// Retrieve "HouseType" from Excel
			    	String strExpectedCondoFees = E2E_ExcelData.get("CondoFees");									// Retrieve "CondoFees" from Excel
			    	String strExpectedSquareFeet  = E2E_ExcelData.get("SquareFeet");								// Retrieve "SquareFeet" from Excel
			    	String strExpectedPurchasePrice  = E2E_ExcelData.get("PurchasePrice");							// Retrieve "PurchasePrice" from Excel
			    	String strExpectedDownPayment  = E2E_ExcelData.get("DownPayment");								// Retrieve "DownPayment" from Excel
			    	String strExpectedDownPymtSrcBankAcct  = E2E_ExcelData.get("DownPymtSrcBankAcct");				// Retrieve "DownPymtSrcBankAcct" from Excel
			    	String strExpectedDownPymtSrcInvAcct  = E2E_ExcelData.get("DownPymtSrcInvAcct");				// Retrieve "DownPymtSrcInvAcct" from Excel
			    	String strExpectedDownPymtSrcFamilyGift  = E2E_ExcelData.get("DownPymtSrcFamilyGift");			// Retrieve "DownPymtSrcFamilyGift" from Excel
			    	String strExpectedDownPymtSrcRRSP  = E2E_ExcelData.get("DownPymtSrcRRSP");						// Retrieve "DownPymtSrcRRSP" from Excel
			    	String strExpectedDownPymtSrcSaleOfAss  = E2E_ExcelData.get("DownPymtSrcSaleOfAss");			// Retrieve "DownPymtSrcSaleOfAss" from Excel
			    	String strExpectedDownPymtSrcSaleOfExist  = E2E_ExcelData.get("DownPymtSrcSaleOfExist");		// Retrieve "DownPymtSrcSaleOfExist" from Excel
			    	String strExpectedDownPymtSrcBankAcctAmt  = E2E_ExcelData.get("DownPymtSrcBankAcctAmt");		// Retrieve "DownPymtSrcBankAcctAmt" from Excel
			    	String strExpectedDownPymtSrcInvAcctAmt  = E2E_ExcelData.get("DownPymtSrcInvAcctAmt");			// Retrieve "DownPymtSrcnvAcctAmt" from Excel
			    	String strExpectedDownPymtSrcFamilyGiftAmt  = E2E_ExcelData.get("DownPymtSrcFamilyGiftAmt");	// Retrieve "DownPymtSrcFamilyGiftAmt" from Excel		
			    	String strExpectedDownPymtSrcRRSPAmt  = E2E_ExcelData.get("DownPymtSrcRRSPAmt");				// Retrieve "DownPymtSrcRRSPAmt" from Excel
			    	String strExpectedDownPymtSrcSaleOfAssAmt  = E2E_ExcelData.get("DownPymtSrcSaleOfAssAmt");		// Retrieve "DownPymtSrcSaleOfAssAmt" from Excel
			    	String strExpectedDownPymtSrcSaleOfExistAmt  = E2E_ExcelData.get("DownPymtSrcSaleOfExistAmt");	// Retrieve "DownPymtSrcSaleOfExistAmt" from Excel
			    	
			    	String strTypeOfRate            = E2E_ExcelData.get("TypeOfRate"); // Retrieve "TypeOfRate" from Excel 
			    	String strMortgageTerm          = E2E_ExcelData.get("MortgageTerm");// Retrieve "MortgageTerm" from Excel 
			       	String strratecustomization     = E2E_ExcelData.get("RateCustomization");// Retrieve "UnLockYourRate" from Excel
			    	String strrateunlock            = E2E_ExcelData.get("RateUnlock");// Retrieve "RateUnlock" from Excel
			    	String strrateequity            = E2E_ExcelData.get("RateEquity");// Retrieve "Rate Equity" from Excel 
			       
					String strCurrentEmpStatus	= E2E_ExcelData.get("CurrentEmpStatus"); 	// Retrieve "Current Employment status" from Excel
					String strEmploymentType = E2E_ExcelData.get("EmploymentType");
					String strFieldOfWork=  E2E_ExcelData.get("EmploymentFieldOfWork");
					String strJobTitle=  E2E_ExcelData.get("EmploymentJobTitle");
					String strDurationYear=  E2E_ExcelData.get("Years");
					String strDurationMonth=  E2E_ExcelData.get("Months");
					
					String strChildSupport= E2E_ExcelData.get("EmpOtherSrcsOfIncome1");
					String strCommission= E2E_ExcelData.get("EmpOtherSrcsOfIncome2");
					String strInvestments= E2E_ExcelData.get("EmpOtherSrcsOfIncome3");
					String strPartTimeWork= E2E_ExcelData.get("EmpOtherSrcsOfIncome4");
					String strPensionDisability= E2E_ExcelData.get("EmpOtherSrcsOfIncome5");
					String strRIFLIF= E2E_ExcelData.get("EmpOtherSrcsOfIncome6");
					String strSeasonalWork= E2E_ExcelData.get("EmpOtherSrcsOfIncome7");
				    String strSpousalSupport= E2E_ExcelData.get("EmpOtherSrcsOfIncome8");
					
					String strChildSupportAmt= E2E_ExcelData.get("EmpOtherSrcsOfIncome1Amt");
					String strCommissionAmt= E2E_ExcelData.get("EmpOtherSrcsOfIncome2Amt");
					String strInvestmentsAmt= E2E_ExcelData.get("EmpOtherSrcsOfIncome3Amt");
					String strPartTimeWorkAmt= E2E_ExcelData.get("EmpOtherSrcsOfIncome4Amt");
					String strPensionDisabilityAmt= E2E_ExcelData.get("EmpOtherSrcsOfIncome5Amt");
					String strRIFLIFAmt= E2E_ExcelData.get("EmpOtherSrcsOfIncome6Amt");
					String strSeasonalWorkAmt= E2E_ExcelData.get("EmpOtherSrcsOfIncome7Amt");
					String strSpousalSupportAmt= E2E_ExcelData.get("EmpOtherSrcsOfIncome8Amt");
					
					String strAutomobile = E2E_ExcelData.get("AssetSources1");
					String strCash = E2E_ExcelData.get("AssetSources2");
					String strGICTermDeposit = E2E_ExcelData.get("AssetSources3");
				 	String strPrimaryResidence = E2E_ExcelData.get("AssetSources4");
				  	String strRentalProperty = E2E_ExcelData.get("AssetSources5");
				 	String strRRSP = E2E_ExcelData.get("AssetSources6");
				 	String strSecondaryProperty = E2E_ExcelData.get("AssetSources7");
				 	String strStockBond = E2E_ExcelData.get("AssetSources8");
				 	String strOtherAssets = E2E_ExcelData.get("AssetSources9");
				 	
				 	String strAutomobileAmt = E2E_ExcelData.get("AssetSources1Amt");
				 	String strCashAmt = E2E_ExcelData.get("AssetSources2Amt");
				 	String strGICTermDepositAmt = E2E_ExcelData.get("AssetSources3Amt");
				 	String strPrimaryResidenceAmt = E2E_ExcelData.get("AssetSources4Amt");
				 	String strRentalPropertyAmt = E2E_ExcelData.get("AssetSources5Amt");
				 	String strRRSPAmt = E2E_ExcelData.get("AssetSources6Amt");
				 	String strSecondaryPropertyAmt = E2E_ExcelData.get("AssetSources7Amt");
				 	String strStockBondAmt = E2E_ExcelData.get("AssetSources8Amt");
				 	String strOtherAssetsAmt = E2E_ExcelData.get("AssetSources9Amt");
				 	
				 	String strAlimonyLiability = E2E_ExcelData.get("LiabilitySources1");
				 	String strChildSupportLiability = E2E_ExcelData.get("LiabilitySources2");
				 	String strPrivateDebtLiability = E2E_ExcelData.get("LiabilitySources3");
				 	
				 	String strAlimonyLiabilityMonthlyPaymt = E2E_ExcelData.get("LiabilitySources1MonthlyPaymt");
				 	String strChildSupportLiabilityMonthlyPayment = E2E_ExcelData.get("LiabilitySources2MonthlyPaymt");
				 	String strPrivateDebtLiabilityMonthlyPayment = E2E_ExcelData.get("LiabilitySources3MonthlyPaymt");
				 	String strPrivateDebtLiabilityBalanceOwing = E2E_ExcelData.get("LiabilitySources3BalanceOwing");
				 	String strCoAppCurrentEmpStatus = E2E_ExcelData.get("CoAppCurentEmpStatus");
				 	String strCoAppEmpOtherSrcsOfIncomeNoOtherSrcs= E2E_ExcelData.get("EmpCoAppNoOtherSrcsOfIncome");
				 																		 
				 	String strCoAppEmpOtherSrcsOfIncomeChildSupport = E2E_ExcelData.get("EmpCoAppSrcsOfIncomeChildSupport");
				 	String strCoAppEmpOtherSrcsOfIncomeChildSupportAmt=E2E_ExcelData.get("EmpCoAppSrcsOfIncomeChildSupportAmt");
				 	String strCoAppEmpOtherSrcsOfIncomeInvest = E2E_ExcelData.get("EmpCoAppSrcsOfIncomeInvestment");
				 	String strCoAppEmpOtherSrcsOfIncomeInvestAmt=E2E_ExcelData.get("EmpCoAppSrcsOfIncomeInvestmentAmt");
				 	String strCoAppEmpOtherSrcsOfIncomePensionDisability = E2E_ExcelData.get("EmpCoAppSrcsOfIncomePensionDisab");
				 	String strCoAppEmpOtherSrcsOfIncomePensionDisabilityAmt=E2E_ExcelData.get("EmpCoAppSrcsOfIncomePensionDisabAmt");
	 			
				 	ExtentReportHelper.StepPass("Address of your new home screen is displayed."); 
				 	
			    	if (strExpectedAddress.contentEquals("Manual Address")) {
			     		CommonApplicationMethods.enterAddressManually(); // Select Address Manually in "Address of your new home"
			     	}
			     	else
			     	{
			     		CommonApplicationMethods.enterAutosuggestaddress(strExpectedAddress); // Enters Auto suggest address (DMTI field) in Address screen 
			     	}
			     	
			     	Thread.sleep(4000);
			     	CommonAppMethodsYourNewHome.selectPropertyType(strExpectedPropertyType); // Select Property Type in "Type of Property"
			     	Thread.sleep(2000);
			     	
			     	ExtentReportHelper.StepPass("Type of Property screen is displayed.");
			     	
			     				     	
			     	if (strExpectedPropertyType.contentEquals("Condo")) {
			     		ExtentReportHelper.StepPass("Monthly condo fees screen is displayed.");
			     		Utility.sendKeys("ehome.CondoFees.CondoFees.input", strExpectedCondoFees); // Enter "Condo fee" in "Type of Property" 
			     		Thread.sleep(1000);
			     		Utility.clickObject("ehome.CloseDtContinue.button", "Button"); // Click on Continue in "Type of Property"  
			      		Thread.sleep(2000);
			     	}
			        
			     	if (strExpectedPropertyType.contentEquals("House")) {
			     		CommonAppMethodsYourNewHome.selectTypeofHouse(strExpectedHouseType); // Select Type of House in "Type of house" 
			     		Thread.sleep(2000);
			     		ExtentReportHelper.StepPass("Type of House screen is displayed.");
			     	}
			       
			     	Utility.sendKeys("ehome.areaOfProp.squrft.value", strExpectedSquareFeet); // Enter "Area of Property" 
			     	Thread.sleep(500);
			    	Utility.clickObject("ehome.areaOfProp.continue.button", "Button"); // Click on Continue
			    	Thread.sleep(500);
			    	ExtentReportHelper.StepPass("Purchase Price screen is displayed.");
			    	
			     	Utility.sendKeys("ehome.PurchasePrice.inputtextbox", strExpectedPurchasePrice); // Enter "Purchase Price" in Purchase Price
			     	Thread.sleep(500);
			    	Utility.clickObject("ehome.areaOfProp.continue.button", "Button"); // Click on Continue
			    	Thread.sleep(500);
			    	
			    	ExtentReportHelper.StepPass("Down Payment screen is displayed.");
			    	
			    	Utility.sendKeys("ehome.DownPayement.Price", strExpectedDownPayment); // Enter "Down Payment Amount" in Down Payment
			     	Thread.sleep(500);
			     	
			     	Utility.clickObject("ehome.areaOfProp.continue.button", "Button"); // Click on Continue
			     	Thread.sleep(1000);
			     	
			     	ExtentReportHelper.StepPass("Sources of your down payment screen is displayed.");
			     	
			     	if (strExpectedDownPymtSrcBankAcct.contentEquals("Bank account")) {
			     		CommonAppMethodsYourNewHome.selectDownPaymentSources(strExpectedDownPymtSrcBankAcct); // Select "Bank account" option 
			     	}
		     		
			     	if (strExpectedDownPymtSrcInvAcct.contentEquals("Investment account")) {
			     		CommonAppMethodsYourNewHome.selectDownPaymentSources(strExpectedDownPymtSrcInvAcct); // Select "Investment account" option 
			     	}
			     	
			     	if (strExpectedDownPymtSrcFamilyGift.contentEquals("A gift from family")) {
			     		CommonAppMethodsYourNewHome.selectDownPaymentSources(strExpectedDownPymtSrcFamilyGift); // Select "A gift from family" option 
			     	}
			     	
			     	if (strExpectedDownPymtSrcRRSP.contentEquals("RRSP withdrawal")) {
			     		CommonAppMethodsYourNewHome.selectDownPaymentSources(strExpectedDownPymtSrcRRSP); // Select "RRSP withdrawal" option 
			     	}
			     	
			     	if (strExpectedDownPymtSrcSaleOfAss.contentEquals("Sale of asset")) {
			     		CommonAppMethodsYourNewHome.selectDownPaymentSources(strExpectedDownPymtSrcSaleOfAss); // Select "Sale of asset" option 
			     	}
			     	
			     	if (strExpectedDownPymtSrcSaleOfExist.contentEquals("Sale of existing property")) {
			     		CommonAppMethodsYourNewHome.selectDownPaymentSources(strExpectedDownPymtSrcSaleOfExist); // Select "Sale of existing property" option 
			     	}
			     	
			     	Thread.sleep(500);  
			     	Utility.clickObject("ehome.areaOfProp.continue.button", "Button");
			     	Thread.sleep(500); 
			     	
			     	ExtentReportHelper.StepPass("Details of your down payment sources screen is displayed.");
			     	
			     	//  ***** STAGE2-Detailed Down Payment Screen# *****
			       if (strExpectedDownPymtSrcBankAcct != null | strExpectedDownPymtSrcBankAcctAmt.length() != 0) {
			    	   CommonAppMethodsYourNewHome.enterDownPaymentSourcesAmount(strExpectedDownPymtSrcBankAcct, strExpectedDownPymtSrcBankAcctAmt);
			       		Thread.sleep(500); 
			     	}
			     	if (strExpectedDownPymtSrcInvAcct != null | strExpectedDownPymtSrcInvAcctAmt.length() != 0) {
			     		CommonAppMethodsYourNewHome.enterDownPaymentSourcesAmount(strExpectedDownPymtSrcInvAcct, strExpectedDownPymtSrcInvAcctAmt);
			     		Thread.sleep(500);  
			     	}
			     	if (strExpectedDownPymtSrcFamilyGift != null | strExpectedDownPymtSrcFamilyGiftAmt.length() != 0) {
			     		CommonAppMethodsYourNewHome.enterDownPaymentSourcesAmount(strExpectedDownPymtSrcFamilyGift, strExpectedDownPymtSrcFamilyGiftAmt);
			     		Thread.sleep(500);  
			     	}
			     	if (strExpectedDownPymtSrcRRSP != null | strExpectedDownPymtSrcRRSPAmt.length() != 0) {
			     		CommonAppMethodsYourNewHome.enterDownPaymentSourcesAmount(strExpectedDownPymtSrcRRSP, strExpectedDownPymtSrcRRSPAmt);
			     		Thread.sleep(500);  
			     	}
			     	if (strExpectedDownPymtSrcSaleOfAss != null | strExpectedDownPymtSrcSaleOfAssAmt.length() != 0) {
			     		CommonAppMethodsYourNewHome.enterDownPaymentSourcesAmount(strExpectedDownPymtSrcSaleOfAss, strExpectedDownPymtSrcSaleOfAssAmt);
			     		Thread.sleep(500);  
			     	}
			     	if (strExpectedDownPymtSrcSaleOfExist != null | strExpectedDownPymtSrcSaleOfExistAmt.length() != 0) {
			     		CommonAppMethodsYourNewHome.enterDownPaymentSourcesAmount(strExpectedDownPymtSrcSaleOfExist, strExpectedDownPymtSrcSaleOfExistAmt);
			     		Thread.sleep(500);  
			     	}
			     	
			    	Utility.clickObject("ehome.detailsofdownpayment.ContinueButtonDetails", "Button"); // Click on Continue
			      	Thread.sleep(500);
			      	
			      	ExtentReportHelper.StepPass("Closing date of your new home screen is displayed.");
			      	
			      	
			      	Utility.clickObject("ehome.closingDtPicker.button", "Button");
			     	Thread.sleep(500);
			     	Utility.clickObject("ehome.closingDtPickerSelection.button", "Button");
			     	Thread.sleep(500);
			      	Utility.clickObject("ehome.CloseDtContinue.button", "Button"); // Click on Continue
			      	Thread.sleep(500);
			      	
			      	ExtentReportHelper.StepPass("Your eHOME Summary screen is displayed.");
			      	
			     	Utility.clickObject("ehome.detailsofdownpayment.ContinueButtonDetails", "Button"); // Click on Continue button in Details of 
			     	Thread.sleep(1000);
			      	Utility.clickObject("ehome.Stage3SectionBrkContinue.button", "Button"); // Click on "Continue" button 
			  	   // Stag 2 End Here //***********************************************	 
			  
			      	ExtentReportHelper.StepPass("Rate Type Term Section Breaker Screen is displayed.");
			      	
			    	CommonAppMethodsGettingNewRate.selectRateType(strTypeOfRate); // Select "Type of Rate" option 
			    	Thread.sleep(2000);
		    		    	
			    	if (strTypeOfRate.contentEquals("Fixed")) {
			    		CommonAppMethodsGettingNewRate.selectMortgageTerm(strMortgageTerm); // Select "Mortgage Term" option 
			    		Thread.sleep(1000);
			    	}
			    
			    	CommonAppMethodsGettingNewRate.chooseRatesfromRatePresentment(strTypeOfRate, strMortgageTerm); // Choose Rates button
			    	Thread.sleep(1000);
			    	
			    	Utility.clickObject("ehome.ratelock.LockandHold", "Button"); // Click on Lock & Hold button
			    	Thread.sleep(1000);
			    	if (strratecustomization.contentEquals("Unlockyourrate")) {
			    		Utility.clickObject("ehome.rateunlock.UnlockyourrateBtn", "Button"); // Click on Unlock your rate
			    		Thread.sleep(1000);
			    		if (strrateunlock.contentEquals("Yes, unlock my rate")) {
			    			Utility.clickObject("ehome.rateunlock.Yesunlockmyrate", "Button"); // Click on Yes, unlock my rate
			    			return;
			    		}
			    		if (strrateunlock.contentEquals("No, keep my rate")) {
			    			Utility.clickObject("ehome.rateunlock.Nokeepmyrate", "Button"); // Click on No, keep my rate
			    		}
			    	}
			    	Thread.sleep(1000);
			    	Utility.clickObject("ehome.RateCustContiniueBtn", "Button"); // Click on Continue button
			    	Thread.sleep(1000);
			    	QAFExtendedWebElement strActualSTEPTitle= new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[2]/div/div[2]/h2");
			    	if(strActualSTEPTitle.getText().contains("Plan (STEP)")) //"STEP" Title
			    	{
			    		Utility.clickObject("ehome.STEPContiniueBtn", "Button");
			    	}	
			    	else
			    	{
			    		System.err.printf("Plan (STEP) is NOT displayed", strActualSTEPTitle.getText());
			    	}
			    	Double dbPurchasePrice = Double.valueOf(strExpectedPurchasePrice);
			    	Double dbDownPayment = 	Double.valueOf(strExpectedDownPayment);
			    	Double defaultInsurance =  dbDownPayment/dbPurchasePrice*100;
			    	
			    	if(defaultInsurance >= 20.0)
			    	{
			    		if (strrateequity.contentEquals("Yes, I'm interested")) {
			    			Utility.clickObject("ehome.step.yesImInterestedBtn", "Button");
			    			Utility.clickObject("ehome.CloseDtContinue.button", "Button");
			    		}
			    	}
			    	if (strrateequity.contentEquals("No thanks")) {
			    		QAFExtendedWebElement NothanksBtn= new QAFExtendedWebElement("ehome.step.NothanksBtn");
			    		NothanksBtn.click(); // Click on Continue
			    	}
			    	Utility.clickObject("ehome.RateViewContinueBtn", "Button");
			    	Thread.sleep(1000);
			    	Utility.clickObject("//*[@id=\"app\"]/div/div[1]/div/div/div[3]/div/button/span", "Button");
		 	
	
				 	Thread.sleep(2000);
				 	if (strCurrentEmpStatus.contentEquals("Employed")) {                // Selecting current Employment Status
				 		CommonAppMethodsEmployment.SelectEmpStatus("Employed");
				 		
				 		Thread.sleep(4000);
				 		if (strEmploymentType.contentEquals("Commissioned sales")) {             // Selecting Employment Type
				 			CommonAppMethodsEmployment.SelectEmpType("Commissioned sales");}
				 		else if (strEmploymentType.contentEquals("Contract")) {
				 			CommonAppMethodsEmployment.SelectEmpType("Contract");}
				 		else if (strEmploymentType.contentEquals("Full Time")) {
				 			CommonAppMethodsEmployment.SelectEmpType("Full Time");}
				 		else if (strEmploymentType.contentEquals("Part Time")) {
				 			CommonAppMethodsEmployment.SelectEmpType("Part Time");}
				 		else if (strEmploymentType.contentEquals("Seasonal")) {
				 			CommonAppMethodsEmployment.SelectEmpType("Seasonal");}
				 		Thread.sleep(2000);
				 		CommonApplicationMethods.selectValuefromDropDownListBox("//*[@id=\"jobField\"]", strFieldOfWork); // Selecting Field of work
				 		Thread.sleep(1000);
				 		CommonApplicationMethods.selectValuefromDropDownListBox("//*[@id=\"jobTitle\"]", strJobTitle);    // Selecting Job Title
				 		Common.continueButtonClicked();
				 		Thread.sleep(1000);
							
				 		Utility.sendKeys("//*[@id=\'employerName\']","Scotia Bank");
				 		Utility.sendKeys("//*[@id=\"employerPhone\"]","6471234567");
				 		Thread.sleep(1000);
				 		Common.continueButtonClicked();
				 		Thread.sleep(500);
							
				 		CommonApplicationMethods.enterAutoSuggestAddress("888 Birch","ehome.employeraddress.address","//*[@id=\"app\"]/div/div[1]/div[1]/section/div/div[3]/div[1]/div/div[2]/div/ul" );
				 		Thread.sleep(1000);
						Common.continueButtonClicked();
				 		
				 		Thread.sleep(4000);
				 		Utility.sendKeys("ehome.annualIncome.salary", "120000");
				 		Utility.sendKeys("ehome.annualIncome.bonus", "9000");
				 		Utility.sendKeys("ehome.annualIncome.overtime", "50000");
				 		Thread.sleep(1000);
							
				 		Common.continueButtonClicked();
				 		Thread.sleep(1000);
				 		
				 		if (strDurationYear != "") {
				 			CommonApplicationMethods.selectValuefromDropDownListBox("ehome.employmentDuration.years", strDurationYear);
					 		Thread.sleep(500);
				 		}
				 		
				 		if (strDurationMonth != "") {
				 			CommonApplicationMethods.selectValuefromDropDownListBox("ehome.employmentDuration.months", strDurationMonth);
					 		Thread.sleep(500);
				 		}
				 		
				 		Common.continueButtonClicked();
				 		Thread.sleep(1000);
				 		
				 		if (strDurationYear.contentEquals("1 year") | strDurationYear.contentEquals("0 years") ){  
				 			Utility.sendKeys("ehome.previousEmployerDetails.employerName","Mahindra Satyam");
					 		Thread.sleep(500);
					 		Common.continueButtonClicked();
					 		Thread.sleep(500);
			 				Utility.sendKeys("ehome.previousAnnualIncome.salary", "80000");
					 		Thread.sleep(500);
					 		Common.continueButtonClicked();
					 		Thread.sleep(1000);
					 		CommonApplicationMethods.selectValuefromDropDownListBox("ehome.previousemploymentDuration.years", strDurationYear);
					 		Thread.sleep(500);
					 		CommonApplicationMethods.selectValuefromDropDownListBox("ehome.previousemploymentDuration.months", strDurationMonth);
					 		Thread.sleep(500);
					 		Common.continueButtonClicked();
					 		Thread.sleep(1000);
				 			 		}
				 		
						//  Do you have any other sources of income?
				 		if (strChildSupport.contentEquals("Child Support")) {
				 			CommonAppMethodsEmployment.SelectOtherSourcesOfIncome(strChildSupport); 
				 		}
				 		if (strCommission.contentEquals("Commission")) {
				 			CommonAppMethodsEmployment.SelectOtherSourcesOfIncome(strCommission); 
				 		}
				 		if (strInvestments.contentEquals("Investments")) {
				 			CommonAppMethodsEmployment.SelectOtherSourcesOfIncome(strInvestments); 
				 		}
				 		if (strPartTimeWork.contentEquals("Part Time Work")) {
				 			CommonAppMethodsEmployment.SelectOtherSourcesOfIncome(strPartTimeWork); 
				 		}
				 		if (strPensionDisability.contentEquals("Pension/Disability")) {
				 			CommonAppMethodsEmployment.SelectOtherSourcesOfIncome(strPensionDisability); 
				 		}
						if (strRIFLIF.contentEquals("RIF/LIF")) {
							CommonAppMethodsEmployment.SelectOtherSourcesOfIncome(strRIFLIF); 
						}
						if (strSeasonalWork.contentEquals("Seasonal Work")) {
							CommonAppMethodsEmployment.SelectOtherSourcesOfIncome(strSeasonalWork); 
						}
						if (strSpousalSupport.contentEquals("Spousal Support")) {
							CommonAppMethodsEmployment.SelectOtherSourcesOfIncome(strSpousalSupport); 
						}
						
						if (strChildSupport.contentEquals("No other sources of income") | strCommission.contentEquals("No other sources of income") | strPartTimeWork.contentEquals("No other sources of income") | strPensionDisability.contentEquals("No other sources of income")| strRIFLIF.contentEquals("No other sources of income")| strInvestments.contentEquals("No other sources of income")| strSeasonalWork.contentEquals("No other sources of income")| strSpousalSupport.contentEquals("No other sources of income")) {
							CommonAppMethodsEmployment.SelectOtherSourcesOfIncome("No other sources of income");
						}
						Common.continueButtonClicked();
						Thread.sleep(1000); 
							
							//  What's the annual income for each source?
						if (strChildSupport != null | strChildSupportAmt.length() != 0) {
							CommonAppMethodsEmployment.EnterAnualIncomeSourceAmount(strChildSupport, strChildSupportAmt);
							//Thread.sleep(1000);  
						}
						if (strCommission != null | strCommissionAmt.length() != 0) {
							CommonAppMethodsEmployment.EnterAnualIncomeSourceAmount(strCommission, strCommissionAmt);
						}
						if (strInvestments != null | strInvestmentsAmt.length() != 0) {
							CommonAppMethodsEmployment.EnterAnualIncomeSourceAmount(strInvestments, strInvestmentsAmt);
						}
						if (strPartTimeWork != null | strPartTimeWorkAmt.length() != 0) {
							CommonAppMethodsEmployment.EnterAnualIncomeSourceAmount(strPartTimeWork, strPartTimeWorkAmt);
						}
						if (strPensionDisability != null | strPensionDisabilityAmt.length() != 0) {
							CommonAppMethodsEmployment.EnterAnualIncomeSourceAmount(strPensionDisability, strPensionDisabilityAmt);
						}
						if (strRIFLIF != null | strRIFLIFAmt.length() != 0) {
							CommonAppMethodsEmployment.EnterAnualIncomeSourceAmount(strRIFLIF, strRIFLIFAmt);
					}
			
						if (strSeasonalWork != null | strSeasonalWorkAmt.length() != 0) {
							CommonAppMethodsEmployment.EnterAnualIncomeSourceAmount(strSeasonalWork, strSeasonalWorkAmt);
							//Thread.sleep(1000);  
						}
						if (strSpousalSupport != null | strSpousalSupportAmt.length() != 0) {
							CommonAppMethodsEmployment.EnterAnualIncomeSourceAmount(strSpousalSupport, strSpousalSupportAmt);
					}
							 	
						Thread.sleep(500);
						
						Utility.clickObject("//*[@id=\"app\"]/div/div[1]/div[3]/button[2]/span", "Button");
						Thread.sleep(1000);  
			
						Utility.clickObject("//*[@id=\"app\"]/div/div[1]/div/div/div[2]/aside/div[2]/div[2]/div/div/button","Skip section Button");
						 	
						Thread.sleep(1000);
				
						//Do you have any of the following assets?
						
						if (strAutomobile.contentEquals("Automobile")) {
							CommonAppMethodsAssetLiabilities.SelectAssetsSources(strAutomobile); 
						}
						if (strCash.contentEquals("Cash")) {
							CommonAppMethodsAssetLiabilities.SelectAssetsSources(strCash); 
						}
						if (strGICTermDeposit.contentEquals("GIC/Term Deposit")) {
							CommonAppMethodsAssetLiabilities.SelectAssetsSources(strGICTermDeposit); 
						}
						if (strPrimaryResidence.contentEquals("Primary Residence")) {
							CommonAppMethodsAssetLiabilities.SelectAssetsSources(strPrimaryResidence); 
						}
						
						if (strRentalProperty.contentEquals("Rental Property")) {
							CommonAppMethodsAssetLiabilities.SelectAssetsSources(strRentalProperty); 
						}
						if (strRRSP.contentEquals("RRSP")) {
							CommonAppMethodsAssetLiabilities.SelectAssetsSources(strRRSP); 
						}
						if (strSecondaryProperty.contentEquals("SecondaryProperty")) {
							CommonAppMethodsAssetLiabilities.SelectAssetsSources(strSecondaryProperty); 
						}
						if (strStockBond.contentEquals("Stock/Bond")) {
							CommonAppMethodsAssetLiabilities.SelectAssetsSources(strStockBond); 
						}
						if (strOtherAssets.contentEquals("Other Assets")) {
							CommonAppMethodsAssetLiabilities.SelectAssetsSources(strOtherAssets); 
						}
						if (strAutomobile.contentEquals("No other assets") | strCash.contentEquals("No other assets") | strGICTermDeposit.contentEquals("No other assets") | strPrimaryResidence.contentEquals("No other assets")| strRentalProperty.contentEquals("No other assets")| strRRSP.contentEquals("No other assets")| strSecondaryProperty.contentEquals("No other assets")| strStockBond.contentEquals("No other assets")| strOtherAssets.contentEquals("No other assets")) {
							CommonAppMethodsAssetLiabilities.SelectAssetsSources("No other assets"); 
						}
							
						Common.continueButtonClicked();
						Thread.sleep(2000);		
						 	
						//Do you have any of the following assets?
						if (strAutomobile!=null | strAutomobileAmt.length()!= 0) {
							CommonAppMethodsAssetLiabilities.EnterAssetCalculateAmount(strAutomobile, strAutomobileAmt);
						}
						 	
						if (strCash!= null | strCashAmt.length()!= 0) {
							CommonAppMethodsAssetLiabilities.EnterAssetCalculateAmount(strCash, strCashAmt);
						}
						if (strGICTermDeposit!= null | strGICTermDepositAmt.length()!= 0) {
							CommonAppMethodsAssetLiabilities.EnterAssetCalculateAmount(strGICTermDeposit, strGICTermDepositAmt);
						}
						if (strPrimaryResidence!= null | strPrimaryResidenceAmt.length() != 0) {
							CommonAppMethodsAssetLiabilities.EnterAssetCalculateAmount(strPrimaryResidence, strPrimaryResidenceAmt );
						}
						if (strRentalProperty!= null | strRentalPropertyAmt.length() != 0) {
							CommonAppMethodsAssetLiabilities.EnterAssetCalculateAmount(strRentalProperty, strRentalPropertyAmt );
					 	}
						if (strRRSP!= null | strRRSPAmt.length()!= 0) {
							CommonAppMethodsAssetLiabilities.EnterAssetCalculateAmount(strRRSP, strRRSPAmt);
						}
						if (strSecondaryProperty!= null | strSecondaryPropertyAmt.length()!= 0) {
							CommonAppMethodsAssetLiabilities.EnterAssetCalculateAmount(strSecondaryProperty, strSecondaryPropertyAmt);
						}
						if (strStockBond!= null | strStockBondAmt.length()!= 0) {
							CommonAppMethodsAssetLiabilities.EnterAssetCalculateAmount(strStockBond, strStockBondAmt);
						}
						if (strOtherAssets!= null | strOtherAssetsAmt.length() != 0) {
							CommonAppMethodsAssetLiabilities.EnterAssetCalculateAmount(strOtherAssets, strOtherAssetsAmt );
						}
						
						Utility.clickObject("//*[@id=\"app\"]/div/div[1]/div[3]/button[2]/span", "Button");
						
						//Do you have any liabilities outside of Scotiabank?'
							 
						if (strAlimonyLiability.contentEquals("Alimony")) {
							CommonAppMethodsAssetLiabilities.SelectLiabilitySources(strAlimonyLiability); 
						}
						if (strChildSupportLiability.contentEquals("Child Support")) {
							CommonAppMethodsAssetLiabilities.SelectLiabilitySources(strChildSupportLiability); 
						}
						if (strPrivateDebtLiability .contentEquals("Private Debt")) {
							CommonAppMethodsAssetLiabilities.SelectLiabilitySources(strPrivateDebtLiability ); 
						}
							
						if (strAlimonyLiability.contentEquals("No other liabilities") | strChildSupportLiability.contentEquals("No other liabilities") | strPrivateDebtLiability.contentEquals("No other liabilities")) {
							CommonAppMethodsAssetLiabilities.SelectLiabilitySources("No other liabilities"); 
						}
						
						Common.continueButtonClicked();
						Thread.sleep(2000);
						
							
						//Do you have any liabilities outside of Scotiabank?
							
						if (strAlimonyLiability!=null | strAlimonyLiabilityMonthlyPaymt.length()!= 0) {
							CommonAppMethodsAssetLiabilities.EnterLiabilityCalculateAmount(strAlimonyLiability, strAlimonyLiabilityMonthlyPaymt);
					 	}
						 	
						Thread.sleep(2000);
						
						if (strChildSupportLiability!= null | strChildSupportLiabilityMonthlyPayment.length()!= 0) {
							CommonAppMethodsAssetLiabilities.EnterLiabilityCalculateAmount(strChildSupportLiability, strChildSupportLiabilityMonthlyPayment);
						}
							 
						if (strPrivateDebtLiabilityBalanceOwing.length()!= 0) {
							String strBalanceOwing = "Balance Owing";
							CommonAppMethodsAssetLiabilities.EnterLiabilityCalculateAmount(strBalanceOwing, strPrivateDebtLiabilityBalanceOwing);
						}
						if (strPrivateDebtLiability!= null | strPrivateDebtLiabilityMonthlyPayment.length()!= 0) {
							CommonAppMethodsAssetLiabilities.EnterLiabilityCalculateAmount(strPrivateDebtLiability, strPrivateDebtLiabilityMonthlyPayment);
						 }
							 
						Utility.clickObject("//*[@id=\"app\"]/div/div[1]/div[3]/button[2]/span", "Button");
						Thread.sleep(2000);
						
						Utility.clickObject("//*[@id=\"app\"]/div/div[1]/div/div/div[1]/aside/div[2]/div[2]/div/div/button", "Skip Selection Button");
						Thread.sleep(2000);
						
						//Stage 6 Starts here
						
						Utility.clickObject("//*[@id=\"app\"]/div/div[1]/div[3]/div[2]/div[4]/div/div[1]/div[1]/div[2]/div/label/span[2]", "Purchase & Sale Agreement upload Button");
				    	Thread.sleep(6000);
				    	Runtime.getRuntime().exec("C:\\MyWorkPlace\\AutoIt-workspace\\documentUpload_1.PropertyDocs_PurchaseSaleAgre.exe");
				    	Thread.sleep(1000);
				    	
				    	Utility.clickObject("//*[@id=\"app\"]/div/div[1]/div[3]/div[2]/div[4]/div/div[2]/div[1]/div[2]/div/label/span[2]", "House Listing upload Button");
				    	Thread.sleep(6000);
				    	Runtime.getRuntime().exec("C:\\MyWorkPlace\\AutoIt-workspace\\documentUpload_2.PropertyDocs_HouseListing.exe");
				    	Thread.sleep(1000);
				    	
				    	Utility.clickObject("//*[@id=\"app\"]/div/div[1]/div[3]/div[2]/div[6]/div/div[1]/div[1]/div[2]/div/label/span[2]", "House Listing upload Button");
				    	Thread.sleep(6000);
				    	Runtime.getRuntime().exec("C:\\MyWorkPlace\\AutoIt-workspace\\documentUpload_3.DownpaymentDocs_RRSPWithdrawalStatement.exe");
				    	Thread.sleep(1000);
				    	
				    	Utility.clickObject("//*[@id=\"app\"]/div/div[1]/div[3]/div[3]/div/button[2]/span", "Continue Button");
						
				}
				
				 	else if (strCurrentEmpStatus.contentEquals("UnEmployed")) {
				 		CommonAppMethodsEmployment.SelectEmpStatus("UnEmployed");
				 		Thread.sleep(2000); 
				 		if (strChildSupport.contentEquals("Child Support")) {
				 			CommonAppMethodsEmployment.SelectOtherSourcesOfIncome(strChildSupport); 
				 		}
				 		if (strInvestments.contentEquals("Investments")) {
				 			CommonAppMethodsEmployment.SelectOtherSourcesOfIncome(strInvestments); 
				 		}
				 		if (strPensionDisability.contentEquals("Pension/Disability")) {
				 			CommonAppMethodsEmployment.SelectOtherSourcesOfIncome(strPensionDisability); 
				 		}
						if (strSpousalSupport.contentEquals("Spousal Support")) {
							CommonAppMethodsEmployment.SelectOtherSourcesOfIncome(strSpousalSupport); 
						} 
						
						Common.continueButtonClicked();
						Thread.sleep(500); 
							
							//  What's the annual income for each source?
						if (strChildSupport != null | strChildSupportAmt.length() != 0) {
							CommonAppMethodsEmployment.EnterAnualIncomeSourceAmount(strChildSupport, strChildSupportAmt);
							}
						if (strInvestments != null | strInvestmentsAmt.length() != 0) {
							CommonAppMethodsEmployment.EnterAnualIncomeSourceAmount(strInvestments, strInvestmentsAmt);
						}
						if (strPensionDisability != null | strPensionDisabilityAmt.length() != 0) {
							CommonAppMethodsEmployment.EnterAnualIncomeSourceAmount(strPensionDisability, strPensionDisabilityAmt);
							}
						if (strSpousalSupport != null | strSpousalSupportAmt.length() != 0) {
							CommonAppMethodsEmployment.EnterAnualIncomeSourceAmount(strSpousalSupport, strSpousalSupportAmt);
						}
							 	
						Thread.sleep(500);
						
						Utility.clickObject("//*[@id=\"app\"]/div/div[1]/div[3]/button[2]/span", "Button");
						Thread.sleep(500);  
				 		
				 	}
				 	else if (strCurrentEmpStatus.contentEquals("Retired")) {
				 		CommonAppMethodsEmployment.SelectEmpStatus("Retired");
				 		
				 		if (strDurationYear != "") {
				 			CommonApplicationMethods.selectValuefromDropDownListBox("ehome.employmentDuration.years", strDurationYear);
					 		Thread.sleep(500);
				 		}
				 		
				 		if (strDurationMonth != "") {
				 			CommonApplicationMethods.selectValuefromDropDownListBox("ehome.employmentDuration.months", strDurationMonth);
					 		Thread.sleep(500);
				 		}
				 		
				 		Thread.sleep(1000);
				 		
				 		Common.continueButtonClicked();
				 		Thread.sleep(1000);
				 		
				 		if (strInvestments.contentEquals("Investments")) {
				 			CommonAppMethodsEmployment.SelectRetiredSourcesOfIncome(strInvestments); 
				 		}
				 		if (strPensionDisability.contentEquals("Pension/Disability")) {
				 			CommonAppMethodsEmployment.SelectRetiredSourcesOfIncome(strPensionDisability); 
				 		}
				 		
				 		if (strRIFLIF.contentEquals("RIF/LIF")) {
							CommonAppMethodsEmployment.SelectRetiredSourcesOfIncome(strRIFLIF); 
						}
				 		
				 		if (strInvestments.contentEquals("No sources of income") | strPensionDisability.contentEquals("No sources of income")  | strRIFLIF.contentEquals("No sources of income")  ) {
							CommonAppMethodsEmployment.SelectRetiredSourcesOfIncome("No sources of income"); 
						}
				 		
				 		Common.continueButtonClicked();
				 		Thread.sleep(1000);
				 		
				 		if (strInvestments != null | strInvestmentsAmt.length() != 0) {
							CommonAppMethodsEmployment.EnterRetiredAnualIncomeSourceAmount(strInvestments, strInvestmentsAmt);
					
						}
						if (strPensionDisability != null | strPensionDisabilityAmt.length() != 0) {
							CommonAppMethodsEmployment.EnterRetiredAnualIncomeSourceAmount(strPensionDisability, strPensionDisabilityAmt);
				
						}
						
						if (strRIFLIF != null | strRIFLIFAmt.length() != 0) {
							CommonAppMethodsEmployment.EnterRetiredAnualIncomeSourceAmount(strRIFLIF, strRIFLIFAmt);
				
						}
						
						Thread.sleep(500);
						
						if (strInvestments != "" | strPensionDisability != "" | strRIFLIF !=""  )
						{
							Utility.clickObject("//*[@id=\"app\"]/div/div[1]/div[3]/button[2]/span", "Button");
							Thread.sleep(500);
						}
				 	}
				 	else if (strEmploymentType.contentEquals("Self Employed")) {
				 		CommonAppMethodsEmployment.SelectEmpType("Self Employed");}
			 	}
	 		 	
		 	 /* *************************************************************************************************************************************************
			 Author: 	  Pavan Erra
			 Stage:       Stage 02
			 Method Name: enterAddressManually
			 Purpose: 	  This method is for entering Address Manually in New-Home screen 
			 Created on:  18-September-2018  
			 Updated By: 
			 Updated on:
			 *************************************************************************************************************************************************** */
		    public static void enterAddressManually() throws InterruptedException{
		    	QAFExtendedWebElement streetNumber= new QAFExtendedWebElement("ehome.enteraddressmanually.streetnumber");
		    	QAFExtendedWebElement streetName= new QAFExtendedWebElement("ehome.enteraddressmanually.streetname");
		    	QAFExtendedWebElement city= new QAFExtendedWebElement("ehome.enteraddressmanually.city");
		    	QAFExtendedWebElement province= new QAFExtendedWebElement("ehome.enteraddressmanually.province");
		    	QAFExtendedWebElement postalCode= new QAFExtendedWebElement("ehome.enteraddressmanually.postalCode");
		    	QAFExtendedWebElement continueInManualAddress= new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[2]/button[2]/span");
		    	
		    	QAFExtendedWebElement EnteraddressManually= new QAFExtendedWebElement("//*[@id='app']/div/div[1]/div[1]/section/div[3]/div/div[2]/button/span");
		        EnteraddressManually.click();
		    	streetNumber.sendKeys("2201");
				streetName.sendKeys("EGLINTON AVE");
				Thread.sleep(4000);
				city.sendKeys("TORONTO");
				province.sendKeys("Ontario");
				postalCode.sendKeys("m1k2m1");
				continueInManualAddress.click();
				Thread.sleep(4000);
		    }
		    
		    
		    /* *************************************************************************************************************************************************
			 Author: 	  RameshChalumuri
			 Stage:       Stage 02
			 Method Name: Auto suggest address
			 Purpose: 	  This method is for enters Auto suggest address (DMTI field) in New-Home screen 
			 Created on:  18-September-2018  
			 Updated By: 
			 Updated on:
			 *************************************************************************************************************************************************** */
		   public static void enterAutosuggestaddress(String DMTIAddress) throws InterruptedException{
			   QAFExtendedWebElement Enteraddress= new QAFExtendedWebElement("ehome.Address.address.text");
		       Enteraddress.clear();
		       char[] addarr = DMTIAddress.toCharArray();
		       for(char oneAt : addarr) {
		     	  	Enteraddress.sendKeys(oneAt+"");
		       	}                                                                                                                       
		       QAFExtendedWebElement eleAddress = new QAFExtendedWebElement(By.xpath("//*[@id='app']/div/div[1]/div[1]/section/div[3]/div/div[1]/div/div[2]/div/ul"));
		       List<WebElement> liLi = eleAddress.findElements(By.tagName("li"));
		        liLi.get(1).click();
		         QAFExtendedWebElement ContinueAddress= new QAFExtendedWebElement("//*[@id='app']/div/div[1]/div[2]/button[2]"); //click on continue button is address screen
		        ContinueAddress.click(); 
		   }
		   
		   
		   /* *************************************************************************************************************************************************
		   Author: 	  Ramesh Chalumuri
		   Stage:       Any Stage
		   Method Name: Auto suggest address
		   Purpose: 	  This method is for enters Auto suggest address (DMTI field) in New-Home screen 
		   Created on:  11-October-2018  
		   Updated By: 
		   Updated on:
		   *************************************************************************************************************************************************** */
		   public static void enterAutoSuggestAddress(String DMTIAddress,String xPathAddress, String xPathAddressLi ) throws InterruptedException{
		  	 QAFExtendedWebElement Enteraddress= new QAFExtendedWebElement(xPathAddress);
		  	 char[] addarr = DMTIAddress.toCharArray();
		  	 for(char oneAt : addarr) {
		  		 Enteraddress.sendKeys(oneAt+"");
		  		 Thread.sleep(1000);
		  	 }	
		  	 
		  	 Thread.sleep(2000);
		  	 
		   	 QAFExtendedWebElement eleAddress = new QAFExtendedWebElement(By.xpath(xPathAddressLi));
//		  	 List<WebElement> liLi = eleAddress.findElements(By.tagName("li"));
//		  	 Thread.sleep(1000);
//		  	 liLi.get(1).click();
		   	eleAddress.click();
		  	 Thread.sleep(1000);
		   }
		   
		   
			 /* *************************************************************************************************************************************************
			 Author: 	  Ramesh Chalumuri
			 Stage:       Any Stage
			 Method Name: enterAnyProvinceAddressManually
			 Purpose: 	  This method is for entering Any Province Address Manually in New-Home screen 
			 Created on:  14-January-2019
			 Updated By: 
			 Updated on:
			 *************************************************************************************************************************************************** */
		    public static void enterAnyProvinceAddressManually() throws InterruptedException, FilloException{
		    	
		    	QAFExtendedWebElement streetNumber= new QAFExtendedWebElement("ehome.enteraddressmanually.streetnumber");
		    	QAFExtendedWebElement streetName= new QAFExtendedWebElement("ehome.enteraddressmanually.streetname");
		    	QAFExtendedWebElement city= new QAFExtendedWebElement("ehome.enteraddressmanually.city");
		    	QAFExtendedWebElement province= new QAFExtendedWebElement("ehome.enteraddressmanually.province");
		    	QAFExtendedWebElement postalCode= new QAFExtendedWebElement("ehome.enteraddressmanually.postalCode");
		    	QAFExtendedWebElement continueInManualAddress= new QAFExtendedWebElement("//*[@id=\"app\"]/div/div[1]/div[2]/button[2]/span");
		    	
		    	Map<String, String> E2E_InputData =  Utility.readTestData(strfullPathToFile, sheetE2E_InputData,strtestCaseID);
		    	
    				String strStreetNumber= E2E_InputData.get("StreetNumber");
    				String strStreetName= E2E_InputData.get("StreetName");
    				String strCity= E2E_InputData.get("City");
    				String strProvince= E2E_InputData.get("Province");
    				String strPostalCode= E2E_InputData.get("PostalCode");
    			
		    	QAFExtendedWebElement EnteraddressManually= new QAFExtendedWebElement("//*[@id='app']/div/div[1]/div[1]/section/div[3]/div/div[2]/button/span");
		        EnteraddressManually.click();
		    	streetNumber.sendKeys(strStreetNumber);
				streetName.sendKeys(strStreetName);
				Thread.sleep(4000);
				city.sendKeys(strCity);
				province.sendKeys(strProvince);
				postalCode.sendKeys(strPostalCode);
				continueInManualAddress.click();
				Thread.sleep(4000);
		    }
		
//		    /* *************************************************************************************************************************************************
//			 Author: 	  Ramesh Chalumuri
//			 Stage:       Any Stage
//			 Method Name: enterAnyProvinceAddressDMTI
//			 Purpose: 	  This method is for entering Any Province Address DMTI in New-Home screen 
//			 Created on:  14-January-2019
//			 Updated By: 
//			 Updated on:
//			 *************************************************************************************************************************************************** */
//		    public static void enterAnyProvinceAddressDMTI (String xPathAddress, String xPathAddressLi ) throws InterruptedException{
//				  	 
//		    	Map<String, String> E2E_InputData =  Utility.readTestData(strfullPathToFile, sheetE2E_InputData,strtestCaseID);
//				String strStreetNumber= E2E_InputData.get("StreetNumber");
//				String strStreetName= E2E_InputData.get("StreetName");
//				String strCity= E2E_InputData.get("City");
//				String strProvince= E2E_InputData.get("Province");
//				String strPostalCode= E2E_InputData.get("PostalCode");
//				
//				String DMTIAddress =  strStreetNumber + " " + strStreetName + " " + strCity + " " + strProvince + " " + strPostalCode;
//		    	
//		    	QAFExtendedWebElement Enteraddress= new QAFExtendedWebElement(xPathAddress);
//				  	 char[] addarr = DMTIAddress.toCharArray();
//				  	 for(char oneAt : addarr) {
//				  		 Enteraddress.sendKeys(oneAt+"");
//				  		 Thread.sleep(1000);
//				  	 }	
//				  	 Thread.sleep(2000);
//				   	 QAFExtendedWebElement eleAddress = new QAFExtendedWebElement(By.xpath(xPathAddressLi));
//				   	eleAddress.click();
//				  	 Thread.sleep(1000);
//				   }   
	
	}