package com.scotiabank.ehome.ui.steps.coApp;
import com.qmetry.qaf.automation.step.QAFTestStepProvider;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.quantum.utils.ConfigurationUtils;
import com.scotiabank.ehome.ui.steps.Common;
import com.scotiabank.ehome.ui.steps.Utility;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import java.util.List;
import java.util.concurrent.TimeUnit;
import static com.scotiabank.ehome.ui.steps.Utility.*;

@QAFTestStepProvider

public class CoAppAnnualIncome {
	public static WebDriverWait wait=Utility.getWait();	
	  String testCaseID = Utility.getScenarioID();
	  @Given("^Customer should login and navigates to CoApp Employment annual income$")
	  public void customer_should_login_and_navigates_to_CoApp_Employment_annual_income() throws Throwable {
	      // Write code here that turns the phrase above into concrete actions
//			 String strtestCaseID = Utility.getScenarioID();
//		  if (strtestCaseID.contains("CoApp"))
//		  {
//			  Common.TraverseToNewHomeSectionBreaker();
//			  Thread.sleep(10000);
//			  Common.TraverseFromNewHomeToRateSectionBreaker(strtestCaseID,"Co-App_InputData");
//			  Common.TraverseRateSectionToEmploymentSectionBreaker();
//			  Common.TraverseFromEmploymentSectionToLandOnCoApplicantPage();
//			  CoAppIntro.startSectionButtonClicked();
//		  }
		  Utility.launchURL(ConfigurationUtils.getBaseBundle().getPropertyValue ("env.baseurl3"));
			CoAppIntro.startSectionButtonClicked();

			CoAppEmpStatus.employedButtonClicked();
			CoAppEmpType.commissionedSalesButtonClicked();
			  Thread.sleep(3000);
			String jobField=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Co-App_ExpectedData", testCaseID, "Industry_JobTitle_Field_of_work");
			 CoAppIndustryJobTitle.jobField(jobField);
			  Thread.sleep(3000);
			String jobTitle=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Co-App_ExpectedData", testCaseID, "Industry_JobTitle_Job_Title");
			 CoAppIndustryJobTitle.jobTitle(jobTitle);
			  Thread.sleep(3000);
			String occupationType=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Co-App_ExpectedData", testCaseID, "Industry_JobTitle_Occupation_Type");
			 CoAppIndustryJobTitle.occupationType(occupationType);
			  Thread.sleep(3000);
			Common.continueButtonClicked();
			String employername=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Co-App_InputData", testCaseID, "Employer_Details_employername");
			CoAppEmployerDetails.employername(employername);
			String employerphone=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Co-App_InputData", testCaseID, "Employer_Details_employerphone");
			CoAppEmployerDetails.employerphone(employerphone);	
			 Thread.sleep(3000);
			Common.continueButtonClicked();
			String address=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Co-App_InputData", testCaseID, "Employer_Address");
			CoAppEmployerAddress.employeraddress(address);
			Thread.sleep(3000);
			Common.continueButtonClicked();
			Thread.sleep(3000);
	      
	  }

	@When("^Verify \"([^\"]*)\" message should be on the CoApp Employment annual income screen$")
	public void verify_message_should_be_on_the_CoApp_Employment_annual_income_screen(String dataPointer) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String valueRaw=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Co-App_ExpectedData", testCaseID, dataPointer);
		String value = Utility.messageFormatName(valueRaw, Common.coApplicantFirstName);
		QAFExtendedWebElement headerMessage= new QAFExtendedWebElement("ehome.CoApp.HeaderMessage");
		 wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(headerMessage));
		Assert.assertEquals(headerMessage.getText(), value,"Couldn't found expected header text");
	    
	}
	
	@Then("^Verify \"([^\"]*)\" header text should be on the CoApp Employment annual income screen$")
	public void verify_header_text_should_be_on_the_CoApp_Employment_annual_income_screen(String dataPointer) throws Throwable {
	   // Write code here that turns the phrase above into concrete actions
			String valueRaw=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Co-App_ExpectedData", testCaseID, dataPointer);
			String value = Utility.messageFormatName(valueRaw, Common.coApplicantFirstName);
			Assert.assertEquals(Common.headertext(), value,"Couldn't found expected header text");
	    
	}
	@When("^Enter \"([^\"]*)\" invalid salary in CoApp Employment annual income screen$")
	public void enter_invalid_salary_in_CoApp_Employment_annual_income_screen(String dataPointer) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String col="InputValues";
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "CommonErrorMessages", dataPointer,col);
		QAFExtendedWebElement salary= new QAFExtendedWebElement("ehome.annualIncome.salary");
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(salary));
		salary.clear();
		salary.sendKeys(value);
	    
	}

	@Then("^\"([^\"]*)\" should be displayed for salary in the CoApp annual income screen$")
	public void should_be_displayed_for_salary_in_the_CoApp_annual_income_screen(String dataPointer) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Co-App_ExpectedData", testCaseID, dataPointer);
		QAFExtendedWebElement salaryErrorMessage= new QAFExtendedWebElement("ehome.annualIncome.salary.errormessage");
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(salaryErrorMessage));
        Assert.assertEquals(salaryErrorMessage.getText(), value,"Couldn't found expected header text");
	}

	@When("^Enter \"([^\"]*)\" invalid bonus in CoApp Employment annual income screen$")
	public void enter_invalid_bonus_in_CoApp_Employment_annual_income_screen(String dataPointer) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String col="InputValues";
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "CommonErrorMessages", dataPointer,col);
		QAFExtendedWebElement bonus= new QAFExtendedWebElement("ehome.annualIncome.bonus");
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(bonus));
		bonus.clear();
		bonus.sendKeys(value);
	    
	}

	@Then("^\"([^\"]*)\" should be displayed for bonus in the CoApp annual income screen$")
	public void should_be_displayed_for_bonus_in_the_CoApp_annual_income_screen(String dataPointer) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
			    
	}

	@When("^Enter \"([^\"]*)\" invalid overtime in CoApp Employment annual income screen$")
	public void enter_invalid_overtime_in_CoApp_Employment_annual_income_screen(String dataPointer) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String col="InputValues";
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "CommonErrorMessages", dataPointer,col);
		QAFExtendedWebElement overtime= new QAFExtendedWebElement("ehome.annualIncome.overtime");
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(overtime));
		overtime.clear();
		overtime.sendKeys(value);
	    
	}

	@Then("^\"([^\"]*)\" should be displayed for overtime in the CoApp annual income screen$")
	public void should_be_displayed_for_overtime_in_the_CoApp_annual_income_screen(String dataPointer) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    
	}
	 public static void annualincomeSalary(String amount) {
		 QAFExtendedWebElement salary= new QAFExtendedWebElement("ehome.annualIncome.salary");
			wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(salary));
			salary.clear();
			salary.sendKeys(amount);
			QAFExtendedWebElement bonus= new QAFExtendedWebElement("ehome.annualIncome.bonus");
			bonus.clear();
			QAFExtendedWebElement overtime= new QAFExtendedWebElement("ehome.annualIncome.overtime");
			overtime.clear();
			overtime.clear();
		 }
	@When("^Enter \"([^\"]*)\" salary in CoApp Employment annual income screen$")
	public void enter_salary_in_CoApp_Employment_annual_income_screen(String dataPointer) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Co-App_InputData", testCaseID, dataPointer);
		annualincomeSalary(value);
	}

	@When("^Enter \"([^\"]*)\" Bonus in CoApp Employment annual income screen$")
	public void enter_Bonus_in_CoApp_Employment_annual_income_screen(String dataPointer) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Co-App_InputData", testCaseID, dataPointer);
		QAFExtendedWebElement bonus= new QAFExtendedWebElement("ehome.annualIncome.bonus");
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(bonus));
		bonus.clear();
		bonus.sendKeys(value);
	    
	}

	@When("^Enter \"([^\"]*)\" Overtime in CoApp Employment annual income screen$")
	public void enter_Overtime_in_CoApp_Employment_annual_income_screen(String dataPointer) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String value=Utility.getValueFromExcelMatrix("src\\main\\resources\\data\\eHomeTestData.xlsx", "Co-App_InputData", testCaseID, dataPointer);
		QAFExtendedWebElement overtime= new QAFExtendedWebElement("ehome.annualIncome.overtime");
		wait.pollingEvery(3, TimeUnit.SECONDS).ignoring(NoSuchElementException.class).until(ExpectedConditions.visibilityOf(overtime));
		overtime.clear();
		overtime.sendKeys(value);
	    
	}
}
